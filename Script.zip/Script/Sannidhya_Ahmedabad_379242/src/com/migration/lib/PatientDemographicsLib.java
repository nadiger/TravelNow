/**
 * 
 */
package com.migration.lib;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.Hashtable;
import java.util.concurrent.Callable;

import com.migration.form.DBConnection;
import com.migration.form.PMMigUI;
import com.mysql.jdbc.PreparedStatement;

/**
 * @author jay.shah
 *
 */

public class PatientDemographicsLib 
{


	/**********************************************************************************************************
	 *  Users Related Functions
	 * 
	 **********************************************************************************************************/

	private static Connection getConnection() throws Exception{
		Connection connDes2 = DBConnection.getDSNConnection(PMMigUI.destDNSName,PMMigUI.destUname,PMMigUI.destPwd);
		return connDes2;
	}

	public static int getOccupationByName(String strVMID, Connection con) throws Exception
	{
		String strSQL = "";
		//strVMID = strVMID.substring(0,strVMID.indexOf('.'));
		ResultSet rsUsers = null;
		int uid = 0 ;
		Statement stmt = getConnection().createStatement();
		
		java.sql.PreparedStatement pstmt=null;
		String strSQL2="";
		int i=0;
		strSQL = "Select OccupationID from Occupation where OccupationDescription='"+strVMID+"' and status='A'";
		rsUsers = stmt.executeQuery(strSQL);
		if(rsUsers.next())
		{
			uid = rsUsers.getInt("OccupationID");
		}
		if(uid==0){
			strSQL2="insert into Occupation(OccupationDescription,Status,EncodedBy,EncodedDate,LastChangedBy,LastChangedDate) values(?,?,?,?,?,?)";
			pstmt= getConnection().prepareStatement(strSQL2);
			pstmt.setString(++i, strVMID);
			pstmt.setString(++i, "A");
			pstmt.setString(++i, "2");
			pstmt.setString(++i, "2015-01-01 12:33:26.827");
			pstmt.setString(++i, "2");
			pstmt.setString(++i, "2015-01-01 12:33:26.827");
			pstmt.executeUpdate();
			
			strSQL = "Select OccupationID from Occupation where OccupationDescription='"+strVMID+"' and status='A'";
			rsUsers = stmt.executeQuery(strSQL);
			if(rsUsers.next())
			{
				uid = rsUsers.getInt("OccupationID");
			}
		}
		
		

		stmt.close();
		return uid;
	}

	public static int getSponsorIdByName(String sponsor, Connection con) throws Exception {

		String strSQL = "";
		ResultSet rsUsers = null;
		int uid = 0 ;
		Statement stmt = getConnection().createStatement();
		
		java.sql.PreparedStatement pstmt=null;
		String strSQL2="";

		strSQL = "SELECT SponsorID FROM Sponsor WHERE SponsorName = '" + sponsor + "' AND Status='A'";
		rsUsers = stmt.executeQuery(strSQL);
		if (rsUsers.next()) {
			uid = rsUsers.getInt("SponsorID");
		}
		stmt.close();
		return uid;
	}
	
	public static int getConsultantIdByName(String firstname,String lastname, Connection con) throws Exception {

		String strSQL = "";
		ResultSet rsUsers = null;
		int uid = 0 ;
		Statement stmt = getConnection().createStatement();

		strSQL = "SELECT EmployeeID FROM prEmployees WHERE FirstName = '" + firstname + "' AND LastName='"+lastname+"' and Status='A'";
		rsUsers = stmt.executeQuery(strSQL);
		if (rsUsers.next()) {
			uid = rsUsers.getInt("EmployeeID");
		}

		stmt.close();
		return uid;
	}
	

	
	
	public static int getReferralIdByName(String referral, Connection con) throws Exception {

		String strSQL = "";
		ResultSet rsUsers = null;
		int uid = 0 ;
		Statement stmt = getConnection().createStatement();

		strSQL = "SELECT ReferralID FROM Referrals WHERE ReferralDescription = '" + referral + "' AND  Status='A'";
		rsUsers = stmt.executeQuery(strSQL);
		if (rsUsers.next()) {
			uid = rsUsers.getInt("ReferralID");
		}

		stmt.close();
		return uid;
	}
	
	
	public static int getTitle(String title, Connection con) throws Exception {

		String strSQL = "";
		ResultSet rsUsers = null;
		int uid = 0 ;
		Statement stmt = getConnection().createStatement();
		
		java.sql.PreparedStatement pstmt=null;
		String strSQL2="";
		int i=0;
		strSQL = "SELECT * from title where ShortName='"+title+"' OR Description='"+title+"' and status='A'";
		rsUsers = stmt.executeQuery(strSQL);
		if (rsUsers.next()) {
			uid = rsUsers.getInt("titleid");
		}
		if(uid==0 && !title.equals("")){
			strSQL2="insert into title(ShortName,Description,Status,EncodedBy,EncodedDate,MinAge,MaxAge,Minagetype,Minagevalue,Maxagetype,Maxagevalue) values(?,?,?,?,?,?,?,?,?,?,?)";
			pstmt=getConnection().prepareStatement(strSQL2);
			pstmt.setString(++i, title);
			pstmt.setString(++i, title);
			pstmt.setString(++i, "A");
			pstmt.setString(++i, "2");
			pstmt.setString(++i, "2016-01-01 14:29:56.583");
			pstmt.setString(++i, "0");
			pstmt.setString(++i, "110");
			pstmt.setString(++i, "3"); //Min Age Type Must not be null
			pstmt.setString(++i, "1"); // Min Age Value
			pstmt.setString(++i, "1"); // Max Age Type Must not be null
			pstmt.setString(++i, "40150"); //Age Value
			pstmt.executeUpdate();
			
			strSQL = "SELECT * from title where ShortName='"+title+"' and status='A'";
			rsUsers = stmt.executeQuery(strSQL);
			if (rsUsers.next()) {
				uid = rsUsers.getInt("titleid");
			}
			
		}
		stmt.close();
		return uid;
	}
	
	public static int getTitleByProcedureCall(String title, Connection con) throws Exception {

		ResultSet rsUsers = null;
		int uid = 0 ;
		String s="";
		CallableStatement clstmt = null;
		String strSQL="{CALL SP_TITLE_INSERT(?,?)}";
		int i=0;
		
		if(uid==0 && !title.equals("")){
			
			//clstmt=getConnection().prepareCall(strSQL);
			clstmt=con.prepareCall(strSQL);
			clstmt.setString(++i, title);
			clstmt.registerOutParameter(++i, Types.INTEGER);
			clstmt.execute();
			//s=clstmt.getString(2);
			uid =clstmt.getInt(2);
			clstmt.close();
		}
		
		return uid;
	}
	
	
	public static int getCountryByProcedureCall(String city, Connection con) throws Exception {

		ResultSet rsUsers = null;
		int uid = 0 ;
		String s="";
		CallableStatement clstmt = null;
		String strSQL="{CALL SP_COUNTRY_INSERT(?,?)}";
		int i=0;
		
		if(uid==0 && !city.equals("")){
			
			//clstmt=getConnection().prepareCall(strSQL);
			clstmt=con.prepareCall(strSQL);
			clstmt.setString(++i, city);
			clstmt.registerOutParameter(++i, Types.INTEGER);
			clstmt.execute();
			uid =clstmt.getInt(2);
			clstmt.close();
		}
		
		return uid;
	}
	
	
	
	public static int getStateByProcedureCall(String state, String countryId, Connection con) throws Exception {

		ResultSet rsUsers = null;
		int uid = 0 ;
		String s="";
		CallableStatement clstmt = null;
		String strSQL="{CALL SP_STATE_INSERT(?,?,?)}";
		int i=0;
		
		if(uid==0 && !state.equals("")){
			
			//clstmt=getConnection().prepareCall(strSQL);
			clstmt=con.prepareCall(strSQL);
			clstmt.setString(++i, state);
			clstmt.setString(++i, countryId);
			clstmt.registerOutParameter(++i, Types.INTEGER);
			clstmt.execute();
			//s=clstmt.getString(2);
			uid =clstmt.getInt(3);
			clstmt.close();
		}
		
		return uid;
	}
	
	
	public static int getCityByProcedureCall(String city, String StateId, Connection con) throws Exception {

		ResultSet rsUsers = null;
		int uid = 0 ;
		String s="";
		CallableStatement clstmt = null;
		String strSQL="{CALL SP_CITY_INSERT(?,?,?)}";
		int i=0;
		
		if(uid==0 && !city.equals("")){
			
			//clstmt=getConnection().prepareCall(strSQL);
			clstmt=con.prepareCall(strSQL);
			clstmt.setString(++i, city);
			clstmt.setString(++i, StateId);
			clstmt.registerOutParameter(++i, Types.INTEGER);
			clstmt.execute();
			//s=clstmt.getString(2);
			uid =clstmt.getInt(3);
			clstmt.close();
		}
		
		return uid;
	}
	
	public static int getAreaByProcedureCall(String area, String cityId, Connection con) throws Exception {

		ResultSet rsUsers = null;
		int uid = 0 ;
		String s="";
		CallableStatement clstmt = null;
		String strSQL="{CALL SP_AREA_INSERT(?,?,?)}";
		int i=0;
		System.out.println(area+" "+cityId);
		if(uid==0 && !area.equals("")){
			
			//clstmt=getConnection().prepareCall(strSQL);
			clstmt=con.prepareCall(strSQL);
			clstmt.setString(++i, area);
			clstmt.setString(++i, cityId);
			clstmt.registerOutParameter(++i, Types.INTEGER);
			clstmt.execute();
			//s=clstmt.getString(2);
			uid =clstmt.getInt(3);
			clstmt.close();
		}
		
		return uid;
	}
	
	
	public static int getRelationByProcedureCall(String relation, Connection con) throws Exception {

		ResultSet rsUsers = null;
		int uid = 0 ;
		String s="";
		CallableStatement clstmt = null;
		String strSQL="{CALL SP_RELATION_INSERT(?,?)}";
		int i=0;
		if(uid==0 && !relation.equals("")){
			
			//clstmt=getConnection().prepareCall(strSQL);
			clstmt=con.prepareCall(strSQL);
			clstmt.setString(++i, relation);
			clstmt.registerOutParameter(++i, Types.INTEGER);
			clstmt.execute();
			//s=clstmt.getString(2);
			uid =clstmt.getInt(2);
			clstmt.close();
		}
		
		return uid;
	}
	
	
	public static int getReligionByProcedureCall(String religion, Connection con) throws Exception {

		ResultSet rsUsers = null;
		int uid = 0 ;
		String s="";
		CallableStatement clstmt = null;
		String strSQL="{CALL SP_RELIGION_INSERT(?,?)}";
		int i=0;
		if(uid==0 && !religion.equals("")){
			
			//clstmt=getConnection().prepareCall(strSQL);
			clstmt=con.prepareCall(strSQL);
			clstmt.setString(++i, religion);
			clstmt.registerOutParameter(++i, Types.INTEGER);
			clstmt.execute();
			//s=clstmt.getString(2);
			uid =clstmt.getInt(2);
			clstmt.close();
		}
		
		return uid;
	}
	/*
	public static int getStateByName(String state,String country, Connection con) throws Exception {

		String strSQL = "";
		ResultSet rsUsers = null;
		int uid = 0 ;
		Statement stmt = getConnection().createStatement();
		
		java.sql.PreparedStatement pstmt=null;
		String strSQL2="";
		int i=0;
		strSQL = "SELECT * from state where statename='"+state+"' and countryid='"+country+"' and status='A'";
		rsUsers = stmt.executeQuery(strSQL);
		if (rsUsers.next()) {
			uid = rsUsers.getInt("stateid");
		}
		if(uid==0){
			strSQL2="insert into state(CountryID,StateName,Status,EncodedBy,EncodedDate) values(?,?,?,?,?)";
			pstmt=getConnection().prepareStatement(strSQL2);
			pstmt.setString(++i, country);
			pstmt.setString(++i, state);
			pstmt.setString(++i, "A");
			pstmt.setString(++i, "2");
			pstmt.setString(++i, "2015-01-01 14:29:56.583");
			pstmt.executeUpdate();
			
			strSQL = "SELECT * from state where statename='"+state+"' and countryid='"+1+"' and status='A'";
			rsUsers = stmt.executeQuery(strSQL);
			if (rsUsers.next()) {
				uid = rsUsers.getInt("stateid");
			}
			
		}

		stmt.close();
		return uid;
	}
	
	
	
	
	public static int getCityByName(String city,String state, Connection con) throws Exception {

		String strSQL = "";
		ResultSet rsUsers = null;
		int uid = 0 ;
		Statement stmt = getConnection().createStatement();
		
		java.sql.PreparedStatement pstmt=null;
		String strSQL2="";
		int i=0;
		strSQL = "SELECT * from city where cityname='"+city.trim()+"' and stateid='"+state+"' and status='A'";
		System.out.println(strSQL);
		rsUsers = stmt.executeQuery(strSQL);
		if (rsUsers.next()) {
			uid = rsUsers.getInt("cityid");
		}
		if(uid==0){
			strSQL2="insert into city(stateid,cityname,Status,EncodedBy,EncodedDate) values(?,?,?,?,?)";
			pstmt=getConnection().prepareStatement(strSQL2);
			pstmt.setString(++i, state);
			pstmt.setString(++i, city);
			pstmt.setString(++i, "A");
			pstmt.setString(++i, "2");
			pstmt.setString(++i, "2015-01-01 14:29:56.583");
			pstmt.executeUpdate();
			
			strSQL = "SELECT * from city where cityname='"+city+"' and stateid='"+state+"' and status='A'";
			rsUsers = stmt.executeQuery(strSQL);
			if (rsUsers.next()) {
				uid = rsUsers.getInt("cityid");
			}
			
		}

		stmt.close();
		return uid;
	}
	
	public static int getAreaByName(String area,String cityId, Connection con) throws Exception {

		String strSQL = "";
		ResultSet rsUsers = null;
		int uid = 0 ;
		Statement stmt = getConnection().createStatement();
		
		java.sql.PreparedStatement pstmt=null;
		String strSQL2="";
		int i=0;
		strSQL = "SELECT * from area where AreaName='"+area.trim()+"' and cityid='"+cityId+"' and status='A'";
		System.out.println(strSQL);
		rsUsers = stmt.executeQuery(strSQL);
		if (rsUsers.next()) {
			uid = rsUsers.getInt("areaId");
		}
		if(uid==0){
			strSQL2="insert into area(cityID,AreaName,Status,EncodedBy,EncodedDate) values(?,?,?,?,?)";
			pstmt=getConnection().prepareStatement(strSQL2);
			pstmt.setString(++i, cityId);
			pstmt.setString(++i, area);
			pstmt.setString(++i, "A");
			pstmt.setString(++i, "2");
			pstmt.setString(++i, "2015-01-01 14:29:56.583");
			pstmt.executeUpdate();
			
			strSQL = "SELECT * from area where areaname='"+area+"' and cityId='"+cityId+"' and status='A'";
			rsUsers = stmt.executeQuery(strSQL);
			if (rsUsers.next()) {
				uid = rsUsers.getInt("areaId");
			}
			
		}

		stmt.close();
		return uid;
	}
	
	
	public static int getCountryByName(String country, Connection con) throws Exception {

		String strSQL = "";
		ResultSet rsUsers = null;
		int uid = 0 ;
		Statement stmt = getConnection().createStatement();
		
		java.sql.PreparedStatement pstmt=null;
		String strSQL2="";
		int i=0;
		strSQL = "SELECT * from country where countryname='"+country+"' and status='A'";
		rsUsers = stmt.executeQuery(strSQL);
		if (rsUsers.next()) {
			uid = rsUsers.getInt("countryid");
		}
		if(uid==0){
			strSQL2="insert into country(countryname,Status,EncodedBy,EncodedDate) values(?,?,?,?)";
			pstmt=getConnection().prepareStatement(strSQL2);
			pstmt.setString(++i, country);
			pstmt.setString(++i, "A");
			pstmt.setString(++i, "2");
			pstmt.setString(++i, "2015-01-01 14:29:56.583");
			pstmt.executeUpdate();
			
			strSQL = "SELECT * from country where countryname='"+country+"' and status='A'";
			rsUsers = stmt.executeQuery(strSQL);
			if (rsUsers.next()) {
				uid = rsUsers.getInt("countryid");
			}
			
		}

		stmt.close();
		return uid;
	}
	
	
	
	
	public static String getRelation(String relation, Connection con) throws Exception {

		String strSQL = "";
		ResultSet rsUsers = null;
		String uid = "" ;
		Statement stmt = getConnection().createStatement();
		
		java.sql.PreparedStatement pstmt=null;
		String strSQL2="";
		int i=0;
		strSQL = "select * from Relations where RelationDescription='"+relation+"' and status='A'";
		rsUsers = stmt.executeQuery(strSQL);
		if (rsUsers.next()) {
			uid = rsUsers.getString("RelationID");
		}
		if(uid.equals("")){
			strSQL2="insert into Relations(RelationDescription,Status,EncodedBy,EncodedDate) values(?,?,?,?)";
			pstmt=getConnection().prepareStatement(strSQL2);
			pstmt.setString(++i, relation);
			pstmt.setString(++i, "A");
			pstmt.setString(++i, "2");
			pstmt.setString(++i, "2015-01-01 14:29:56.583");
			pstmt.executeUpdate();
			
			strSQL = "SELECT * from Relations where RelationDescription='"+relation+"' and status='A'";
			rsUsers = stmt.executeQuery(strSQL);
			if (rsUsers.next()) {
				uid = rsUsers.getString("RelationID");
			}
			
		}

		stmt.close();
		return uid;
	}

	
	public static String getReligionByName(String religion, Connection con) throws Exception {

		String strSQL = "";
		ResultSet rsUsers = null;
		String uid = "" ;
		Statement stmt = getConnection().createStatement();
		
		java.sql.PreparedStatement pstmt=null;
		String strSQL2="";
		int i=0;
		strSQL = "select * from religion where ReligionDescription='"+religion+"' and status='A'";
		rsUsers = stmt.executeQuery(strSQL);
		if (rsUsers.next()) {
			uid = rsUsers.getString("ReligionID");
		}
		if(uid.equals("") && uid.equals("")){
			strSQL2="insert into religion(ReligionDescription,Status,EncodedBy,EncodedDate) values(?,?,?,?)";
			pstmt=getConnection().prepareStatement(strSQL2);
			pstmt.setString(++i, religion);
			pstmt.setString(++i, "A");
			pstmt.setString(++i, "2");
			pstmt.setString(++i, "2015-01-01 14:29:56.583");
			pstmt.executeUpdate();
			
			strSQL = "SELECT * from religion where ReligionDescription='"+religion+"' and status='A'";
			rsUsers = stmt.executeQuery(strSQL);
			if (rsUsers.next()) {
				uid = rsUsers.getString("Religionid");
			}
			
		}

		stmt.close();
		return uid;
	}

	*/

	
	public static String AMPM(String time)
	{
		String[] times = time.split(" ");
		time = times[0];
		
		String[] tim = time.split(":");
		String hh = tim[0];
		int h = Integer.parseInt(hh);
		String AMPM = times[1];
		if(AMPM.contains("PM"))
		{
			if(h !=12)
			{
				h = h + 12;
				time = h + ":" + tim[1] + ":" + tim[2];
				//time = h + ":" + tim[1];
			}
			/*else if(h ==12)
			{
				
				time = h + ":" + tim[1] + ":" + tim[2];
			}*/
			
		}
		return time;
	}
	
	public static String getPinCode(String Area, Connection Src) throws SQLException {
		 
		String strSQL="";
		ResultSet rs1=null;
		Statement stmt1=null;
		stmt1=Src.createStatement();
		
		String uid="";
		strSQL="select * from Pincodes where Location='"+Area+"'";
		rs1=stmt1.executeQuery(strSQL);
		if(rs1!=null){
			while(rs1.next()){
				uid=rs1.getString("Pincode");
			}
		}
		rs1.close();
		stmt1.close();
		return uid;
	}
}







