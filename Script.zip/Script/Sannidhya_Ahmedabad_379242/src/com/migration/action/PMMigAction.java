/**
 * 
 */
package com.migration.action;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;






import jxl.Workbook;
import jxl.WorkbookSettings;
import jxl.format.Border;
import jxl.format.BorderLineStyle;
import jxl.format.Colour;
import jxl.write.Label;
import jxl.write.Number;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

import com.migration.form.PMMigUI;
import com.migration.lib.CommonFunction;
import com.migration.lib.JLib;
import com.migration.lib.JUtil;
import com.migration.lib.PatientDemographicsLib;
import com.migration.lib.PatientDemographicsUtil;
import com.migration.model.Appointments;
import com.migration.model.InsertSponsorMaster;
import com.migration.model.MasterLab;
import com.migration.model.MasterLabBean;
import com.migration.model.PatientDemographics;
import com.migration.model.PatientDemographicsBean;
import com.migration.model.ServiceCharges;
import com.migration.model.ServiceChargesBean;
import com.migration.model.Users;
import com.sun.org.apache.bcel.internal.generic.IAND;
import com.sun.org.apache.bcel.internal.generic.LUSHR;
import com.sun.org.apache.xerces.internal.impl.xpath.regex.ParseException;


public class PMMigAction 
{
	public static String datetype="";

	public void execute(String strAction, Connection connSrc, Connection connDest, PMMigUI objUI) throws Exception
	{
		if (strAction.equalsIgnoreCase("facility")){
			updatePatientDemographics(connSrc, connDest, objUI);
		}
		else if (strAction.equalsIgnoreCase("PatientDemographics"))
		{			
			addPatientDemographics(connSrc, connDest, objUI);
		}
		else if (strAction.equalsIgnoreCase("MasterLab")) {
			addMasterLab(connSrc, connDest, objUI);
		}
		else if (strAction.equalsIgnoreCase("Services")) {
			addServicePackage(connSrc, connDest, objUI);
		}

		else if (strAction.equalsIgnoreCase("ServiceCharges"))
		{
			addServiceCharges(connSrc, connDest, objUI);
		}
		/*else if (strAction.equalsIgnoreCase("insurance"))
		{
			//addInsurance(connSrc, connDest, objUI);
		}
		else if (strAction.equalsIgnoreCase("patients")) {
			//addPatients(connSrc, connDest, objUI);
		}
		else if (strAction.equalsIgnoreCase("PatientInsurance")) {
			//addInsuranceDetail(connSrc, connDest,objUI);
		}
		else if (strAction.equalsIgnoreCase("Appointments"))
		{			
			//addAppointments(connSrc, connDest, objUI);
		}
		else if (strAction.equalsIgnoreCase("Contacts"))
		{			
			//addContacts(connSrc, connDest, objUI);
		}
		else if (strAction.equalsIgnoreCase("Guarantor"))
		{			
			//addGuarantors(connSrc, connDest, objUI);
		}
		else if (strAction.equalsIgnoreCase("PatientInsuredGuarantors"))
		{			
			//addPatientInsuredGuarantors(connSrc, connDest, objUI);
		}
		else if (strAction.equalsIgnoreCase("Relation"))
		{			
			//addRelation(connSrc, connDest, objUI);
		}
		else if (strAction.equalsIgnoreCase("Employers"))
		{			
			//addEmployer(connSrc, connDest, objUI);
		}
		else if (strAction.equalsIgnoreCase("GuarantorEmployers"))
		{			
			//addGuarantorEmployers(connSrc, connDest, objUI);
		}
		else if (strAction.equalsIgnoreCase("VisitType"))
		{			
			//addVisitType(connSrc, connDest, objUI);
		}
		else if (strAction.equalsIgnoreCase("VisitStatus"))
		{			
			//addVisitStatus(connSrc, connDest, objUI);
		}*/

	}

	private void addServiceCharges(Connection connSrc, Connection connDest,PMMigUI objUI) throws SQLException, IOException {
		// TODO Auto-generated method stub	

		String strSQL = "";
		String strSQL2 = "";
		Statement stmt = null;
		Statement stmt2 = null;
		ResultSet rsUsr = null;
		ResultSet rsUsr2 = null;
		stmt = connSrc.createStatement();
		stmt2 = connSrc.createStatement();
		ArrayList<String> BedList =null;
		ServiceCharges sChargeInsert =  new ServiceCharges();
		ServiceChargesBean SCBean = new ServiceChargesBean();
		try
		{
			objUI.displayProgress("Started at: "+new Date());

			BedList=JLib.getBedCategories();
			//where SponsorName = 'Indian Institute of Entrepreneurship (IIE)  (Genral)' 
			strSQL = "Select * from MasterTariff  order by ID";
			String serviceName="",actualServiceName="";
			rsUsr = stmt.executeQuery(strSQL);	

			while (rsUsr.next()) {
				SCBean.clearall();
				serviceName="";actualServiceName="";
				System.out.println(rsUsr.getString("ID"));
				SCBean.setSponsorName(JUtil.validateString(rsUsr.getString("SponsorName")));
				SCBean.setSponsorID(JLib.getSponsorIdByName(SCBean.getSponsorName(), connDest)+"");
				serviceName=JUtil.validateString(rsUsr.getString("ServiceName"));
				actualServiceName=JLib.getActualServiceName(serviceName,connSrc);
				if(!serviceName.equals("")){
					SCBean.setServiceName(serviceName);
					SCBean.setServiceId(JLib.getServiceIdByName(SCBean.getServiceName(), connDest)+"");
				}

				if(SCBean.getServiceId().equals("0")){
					SCBean.setServiceName(actualServiceName);
					SCBean.setServiceId(JLib.getServiceIdByName(SCBean.getServiceName(), connDest)+"");
				}

				SCBean.setServiceId(JLib.getServiceIdByName(SCBean.getServiceName(), connDest)+"");
				SCBean.setServiceCharges(JUtil.validateString(rsUsr.getString("ServiceCharges")));

				for (String string : BedList){
					SCBean.setBedCategoryId(string);
					sChargeInsert.insertData(SCBean, connSrc, connDest);
					objUI.displayStatus("ServiceCharges: Added: " + SCBean.getAddCount() + " , Duplicate: " + SCBean.getDupCount() + " , Invalid: " + SCBean.getInvCount());
				}

			}



		}catch(Exception e) {
			e.printStackTrace();
			objUI.displayProgress("ServiceCharges : " + e.toString());
			JUtil.logExceptions(e);
		}
		finally {
			rsUsr.close();
			stmt.close();
		}
		JUtil.appendToFile("Report.csv", "ServiceCharges: Added: " + SCBean.getAddCount() + " , Duplicate: " + SCBean.getDupCount() + " , Invalid: " + SCBean.getInvCount());
		objUI.displayStatus("ServiceCharges: Added: " + SCBean.getAddCount() + " , Duplicate: " + SCBean.getDupCount() + " , Invalid: " + SCBean.getInvCount());
		objUI.displayProgress("Ended at: "+new Date());
	}


	private void updatePatientDemographics (Connection connSrc, Connection connDest,PMMigUI objUI) throws Exception {
		String strSQL = "";
		String strSQL2 = "";
		String strSQL3 = "";
		String title="",city="",state="",country="",vmid="",religion="",religionID="",cRelation="",cRelationID="";
		String countryId="",stateId="",cityId="",titleId="",occupation="",occupationID="",sponsorID="",sponsor="",permanentAddress="",pincode="";
		String fname="",lname="",mname="",gender="";String tor="";
		PreparedStatement stmtPr =null;
		Statement stmt = null;
		Statement stmtSrc = null;
		Statement stmtDest = null;
		ResultSet rows = null;
		ResultSet destUsr = null;
		ResultSet rsUsr2 = null;
		ResultSet rsUsr3 = null;
		stmt=connSrc.createStatement();
		stmtSrc = connSrc.createStatement();
		stmtDest = connDest.createStatement();
		int i=0, ID=0;
		/*String [] tableName = {"DISPUR1994","DISPUR1995","DISPUR1996","DISPUR1997",
				"DISPUR1998","DISPUR1999","DISPUR2000","DISPUR2001","DISPUR2002",
				"DISPUR2003","DISPUR2004","DISPUR2005","DISPUR2006","DISPUR2007",
				"DISPUR2008","DISPUR2009","DISPUR2010","DISPUR2011","DISPUR2012",
				"DISPUR2013","DISPUR2014","DISPUR2015Nov15"};*/

		
		
			strSQL = "SELECT * from Patients Order by ID"; //+" where [PatientID/AccountNo]='MR/1050585'"
			try{
				//strSQL = "SELECT * from DISPUR2012 where [PatientID/AccountNo]='DS/121001/000011'";// where  City='CACHAR'";  where [PatientID/AccountNo]='DS/150719/000002'
				rows=stmt.executeQuery(strSQL);
				while(rows.next()){
					title="";city="";state="";country="";vmid="";
					countryId="";stateId="";cityId="";pincode="";gender="";
					religion="";religionID="";cRelation="";cRelationID="";
					occupation="";occupationID="";sponsorID="";sponsor="";permanentAddress="";
					titleId="";fname="";lname="";mname="";
					//Retrieving values to variables 
					System.out.println(rows.getString("ID"));
					vmid=rows.getString("PatID");
					city=rows.getString("area");
					pincode=PatientDemographicsLib.getPinCode(city, connSrc);
					/*fname=JLib.Left(JUtil.validateString(rows.getString("FirstName")),20);
					lname=JLib.Left(JUtil.validateString(rows.getString("LastName")),20);
					mname=JLib.Left(JUtil.validateString(rows.getString("MiddleName")),20);
					vmid=rows.getString("PatientID/AccountNo");
					gender=rows.getString("Gender");
					title = rows.getString("Title");
					city=rows.getString("City");
					state=rows.getString("State");
					country=rows.getString("country");
					occupation=rows.getString("Occupation");
					religion=rows.getString("Religion");
					sponsor=rows.getString("Sponsor");
					cRelation=rows.getString("ContactPersonRelation");
					permanentAddress=JLib.Left(JUtil.validateString(rows.getString("Address")),80);
					pincode=JLib.Left(JUtil.validateString(rows.getString("ZipCode")),6);*/

					/*//Title
					if(title==null || title=="Null" ||title==null ){
						title="";
					}
					titleId=PatientDemographicsUtil.convertTitle(title);
					if(title.equalsIgnoreCase("BABY")){
						if(gender.equals("Male"))
						{
							titleId="53";
						}
						else if(gender.equals("Female")){
							titleId="5";
						}
					}
					if(titleId.equals("")){
						titleId = PatientDemographicsLib.getTitle(title, connDest)+"";
					}


					//Country 
					if(country==null || country.equals("null") || country.equals(null)){
						country="OtherCountry";
					}
					String countryID=""+PatientDemographicsLib.getCountryByName(country, connDest);

					//State
					if(state==null || state.equals("") || state.equals(null)){
						state="OtherState";
					}
					stateId=""+PatientDemographicsLib.getStateByName(state, countryID, connDest);

					//City
					if(city==null || city.equals("") || city.equals(null)){
						city="OtherCity";
					}
					cityId=""+PatientDemographicsLib.getCityByName(city, stateId, connDest);

					// Occupation

					if(occupation==null || occupation.equals("") || occupation.equals(null)){
						occupation="Other";
					}
					occupationID=""+PatientDemographicsLib.getOccupationByName(occupation, connDest);


					//Religion
					if(religion==null || religion.equals("") || religion.equals(null)){
						religionID="";
					}
					religionID = PatientDemographicsLib.getReligionByName(religion, connDest);

					// Relationship
					if(cRelation==null || cRelation.equals("") || cRelation.equals(null)){
						cRelationID="";
					}

					cRelationID = PatientDemographicsLib.getRelation(cRelation, connDest);*/

					// Update code goes here.
					
					/*strSQL2 = "Update PatientRegistration set occupationId='"+occupationID+"',titleId="+titleId+",localcityid="+cityId+",religionID="+religionID+
							",LocalAddress1='"+permanentAddress+"', LocalPostalCode='"+pincode+"', PermanentPostalCode='"+pincode+"',PermanentAddress1='"+permanentAddress+"',PermanentCityID="+cityId+", relationID="+cRelationID+", FirstName='"+fname+"',Lastname='"+lname+"',middlename='"+mname+"' where registrationNo='"+vmid+"'" ;
					*/

					strSQL2 = "Update PatientRegistration set  LocalPostalCode='"+pincode+"',PermanentPostalCode='"+pincode+"'  where registrationNo='"+vmid+"'" ;
					//System.out.println(strSQL2);
					ID++;
					stmtDest.executeUpdate(strSQL2);
				}

			}

			catch(Exception e){
				e.printStackTrace();
			}
			finally{

			}
		// For loop

	}


	private void addPatientDemographics (Connection connSrc, Connection connDest,PMMigUI objUI) throws SQLException {

		String strSQL = "";
		String strSQL2 = "";
		String strSQL3 = "";
		String strSQL4 = "";
		String strSql5="";
		String asgndPrSQL="";
		String pcpSQL="";

		String assignedProvider="";
		String pcp="";
		String employer="";
		PreparedStatement stmtPr =null;

		int assignedPrId = 0;
		int pcpId = 0;
		int defFeeschid=0;
		Statement stmt = null;
		Statement destStmt = null;
		Statement stmt2 = null;
		Statement stmt3 = null;
		Statement stmt4 = null;
		Statement stmt5 = null;
		Statement stmt6 = null;

		ResultSet rsUsr = null;
		ResultSet destUsr = null;
		ResultSet rsUsr2 = null;
		ResultSet rsUsr3 = null;
		ResultSet rsUsr4 = null;
		ResultSet rsUsr5 = null;
		ResultSet rsUsr6 = null;

		//SOURCE
		stmt = connSrc.createStatement();
		destStmt = connDest.createStatement();
		stmt2 = connSrc.createStatement();
		stmt3 = connSrc.createStatement();
		stmt4 = connSrc.createStatement();
		stmt5 = connSrc.createStatement();

		//DESTINATION


		stmt6 = connDest.createStatement();


		String facility="";
		String patEmployer="";


		String insNotes="";
		String insTemp="";




		String strSQL10 = "";
		Statement stmt10 = null;
		ResultSet rs10 = null;
		stmt10 = connSrc.createStatement();

		String strSQL11="";
		Statement stmt11 = null;
		ResultSet rs11 = null;
		stmt11 = connSrc.createStatement();


		String strSQL12 = "";
		Statement stmt12 = null;
		ResultSet rs12 = null;
		stmt12 = connSrc.createStatement();


		String strSQL13 = "";
		Statement stmt13 = null;
		ResultSet rs13 = null;
		stmt13 = connSrc.createStatement();

		String title="",city="",state="",country="",vmid="",religion="",religionID="",cRelation="",cRelationID="";
		String countryId="",stateId="",cityId="",titleId="",occupation="",occupationID="",sponsorID="",sponsor="",permanentAddress="",Localarea="",pincode="";
		String fname="",lname="",mname="",gender="",dob="",father="",mother="",relationship="";
		String mStatus="";
		String mStatusId="";String cPerson="";
		int tor=1;

		String notes="";
		String temp="";

		PatientDemographics patientDemographics=new PatientDemographics();
		PatientDemographicsBean patientDemographicsBean = new PatientDemographicsBean();


		try {



			strSQL = "SELECT * from Patients where id>0 order by ID"; // Location 1 
			//strSQL = "SELECT * from six where id>0 order by ID"; // Location 2
			//strSQL = "SELECT * from ngp where id>0 order by ID"; // Location 3



			rsUsr = stmt.executeQuery(strSQL);

			while (rsUsr.next()) {
				patientDemographicsBean.clearallUsers();


				mStatusId="";
				title="";city="";state="";country="";vmid="";
				countryId="";stateId="";cityId="";pincode="";gender="";
				religion="";religionID="";cRelation="";cRelationID="";
				occupation="";occupationID="";sponsorID="";sponsor="";permanentAddress="";
				titleId="";fname="";lname="";mname="";father="";mother="";
				mStatus="";dob="";Localarea="";relationship="";
				tor=1;

				//Location
				patientDemographicsBean.setLocationID("1");



				System.out.println("ID: "+rsUsr.getString("ID"));

				fname=JUtil.validateString(rsUsr.getString("FName"));
				lname=JUtil.validateString(rsUsr.getString("LName"));
				mname=JUtil.validateString(rsUsr.getString("MName"));
				vmid=JUtil.validateString(rsUsr.getString("PatID"));
				gender=JUtil.validateString(rsUsr.getString("Sex"));
				title = JUtil.validateString(rsUsr.getString("Title"));
				city=JUtil.validateString(rsUsr.getString("City"));
				state="Karnataka";//JUtil.validateString(rsUsr.getString("State"));
				country="India";//JUtil.validateString(rsUsr.getString("country"));
				//occupation=JUtil.validateString(rsUsr.getString("Occupation"));
				//religion=JUtil.validateString(rsUsr.getString("Religion"));
				sponsor="CASH";//JUtil.validateString(rsUsr.getString("Sponsor"));
				cRelation="";//JUtil.validateString(rsUsr.getString("ContactPersonRelation"));
				permanentAddress=JLib.Left(JUtil.validateString(rsUsr.getString("Address")),80);
				Localarea=JLib.Left(JUtil.validateString(rsUsr.getString("area")),30);
				pincode="";//JLib.Left(JUtil.validateString(rsUsr.getString("ZipCode")),6);
				dob=rsUsr.getString("DOB");
				father=JUtil.validateString(rsUsr.getString("ParentName"));
				mother=fname;
				if(fname.contains("/")){

					if(father.equals("")){
						father=fname.substring((fname.indexOf("/")+2),fname.length());
					}

					relationship = fname.substring((fname.indexOf("/")-1),(fname.indexOf("/")+2));
					fname=fname.substring(0,(fname.indexOf("/")-1));
				}

				if(mname.contains("/")){
					relationship = mname.substring((mname.indexOf("/")-1),(mname.indexOf("/")+2));
					if(father.equals("")){
						father=mname.substring((mname.indexOf("/")+2),mname.length());
					}
				}
				
				if(!fname.equals("") && lname.equals("")){
					String name[]=fname.split(" ");

					if(name.length==1){
						fname = name[0];
					}
					else if(name.length==2)
					{
						fname=name[0];
						patientDemographicsBean.setMiddleName(name[1]);
					}
					else if(name.length==3){
						fname=name[0];
						patientDemographicsBean.setMiddleName(name[1]);
						lname=name[2];
					}
					else if(name.length>3)
					{
						for (int i = 2; i < name.length; i++) {
							lname=name[i]+" ";
							
						}
						fname=name[0];
						patientDemographicsBean.setMiddleName(name[1]);
						patientDemographicsBean.setLastName(mname);
					}
				}

				String table =	strSQL.trim();
				String tableSplitef[]=table.split(" ");
				table=tableSplitef[3];

				//Option
				patientDemographicsBean.setCategory("R");


				//RegistrationNo
				patientDemographicsBean.setRegistrationNo(vmid);


				//UHIGNew
				String UHID=vmid.replaceAll("MR", "UHID");
				patientDemographicsBean.setUHIDNew(UHID);
				//	count++;


				//RegistrationDate
				patientDemographicsBean.setRegistrationDate(JUtil.validateString(rsUsr.getString("RegDate")));
				DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
				/*Date date = new Date();
				System.out.println(dateFormat.format(date));*/
				patientDemographicsBean.setRegistrationDate(patientDemographicsBean.getRegistrationDate());//


				//Status
				patientDemographicsBean.setStatus("A");

				//Gender
				//gender=rsUsr.getString("Gender");
				String genderId=PatientDemographicsUtil.convertSex(gender);
				patientDemographicsBean.setGender(genderId);


				//Title
				if(title==null || title=="Null" ||title==null ){
					title="";
				}
				/*titleId=PatientDemographicsUtil.convertTitle(title);
				if(title.equalsIgnoreCase("Baby.")){
					if(gender.equals("Male"))
					{
						titleId="53";
					}
					else if(gender.equals("Female")){
						titleId="5";
					}
				}*/
				if(titleId.equals("") && !title.equals("")){
					titleId = PatientDemographicsLib.getTitleByProcedureCall(title, connDest)+"";
				}

				patientDemographicsBean.setTitleID(titleId);
				patientDemographicsBean.setFirstName(fname);
				patientDemographicsBean.setLastName(lname);
				//patientDemographicsBean.setMiddleName(mname);
				//DOB
				//Year-month-day
				if(dob==null || dob=="null" || dob.equals("") || dob.equals(null)){

				}else{
					dob=dob.replaceAll(" 00:00:00", "");
					String dobSplited[]=dob.split("-");
					patientDemographicsBean.setAgeYear(dobSplited[0]);
					patientDemographicsBean.setAgeMonth(dobSplited[1]);
					patientDemographicsBean.setAgeDay(dobSplited[2]);
				}
				patientDemographicsBean.setDobStatus("Y");
				patientDemographicsBean.setDOB(dob);


				//Marital Status

				//mStatus=JUtil.validateString(rsUsr.getString("MaritalStatus"));
				mStatusId=PatientDemographicsUtil.convertMaritalStatus(mStatus);
				patientDemographicsBean.setMaritalStatusID(mStatusId);


				//Guarantor
				/*String guarantor=rsUsr.getString("");
				String guarantorId=PatientDemographicsUtil.convertRel(guarantor);
				patientDemographicsBean.setGuardianName(guarantorId);*/


				/*//Occupation

				String GPM_PARAMETER_DESC=rsUsr.getString("Occupation");
				String occupationId=""+PatientDemographicsLib.getOccupationByName(GPM_PARAMETER_DESC, connDest);*/




				//TOR TypeOfRelation

				if(relationship.equalsIgnoreCase("S/O")){
					tor=1;
				}else if(relationship.equalsIgnoreCase("D/O") ||  titleId.equals("2")){
					tor=2;
				}
				else if(relationship.equalsIgnoreCase("W/O") || titleId.equals("3")){
					tor=3;
				}
				patientDemographicsBean.setTOR(tor+"");



				//Father
				//father=rsUsr.getString("Father");
				if(father.contains("N/A")){
					father="";
				}else if(father.length()>30){
					patientDemographicsBean.setFather(father.substring(0, 30));
				}else{
					patientDemographicsBean.setFather(father);
				}


				//Mother
				/*mother=rsUsr.getString("Mother");
				if(mother.contains("N/A")){
					mother="";
				}else if(mother.length()>30){
					patientDemographicsBean.setMother(mother.substring(0, 30));
				}else{
					patientDemographicsBean.setMother(mother);
				}*/


				//Nationality
				String CPA_COUNTRY_CD="INDIAN";//rsUsr.getString("Nationality");
				if(CPA_COUNTRY_CD.equalsIgnoreCase("INDIAN")){
					patientDemographicsBean.setNationalityID("1");
				}else{
					patientDemographicsBean.setNationalityID("2");
				}

				/*//Religion
				religion=rsUsr.getString("Religion");
				if(religion==null || religion.equals("")){

				}else{
					String relgionId=PatientDemographicsUtil.convertReligion(religion);
					patientDemographicsBean.setReligionID(relgionId);
				}





				//Sponsor
				sponsor=rsUsr.getString("Sponsor");

				if(sponsor.equals("")){
					String sponsorId=""+PatientDemographicsLib.getSponsorIdByName("cash", connDest);
					patientDemographicsBean.setSponsorID(sponsorId);
				}else{
					String sponsorId=""+PatientDemographicsLib.getSponsorIdByName(sponsor, connDest);
					patientDemographicsBean.setSponsorID(sponsorId);
				}*/


				//Consultant
				//String consultant=rsUsr.getString("");
				//String consultantId=""+PatientDemographicsLib.getConsultantIdByName("", "", connDest);
				//patientDemographicsBean.setConsultantID("1");


				//BloodGroup
				/*String bloodGroup=rsUsr.getString("BloodGoup");
				if(bloodGroup==null || bloodGroup=="null" || bloodGroup.equals("") || bloodGroup.equals(null)){
					bloodGroup="";
				}
				String bloodGroupId=PatientDemographicsUtil.convertBloodGroup(bloodGroup);
				patientDemographicsBean.setBloodGroupID(bloodGroupId);
				 */

				//ReferralType
				/*String referralTypes=rsUsr.getString("ReferralType");
				String referralTypeId=PatientDemographicsUtil.convertreferralTypes(referralTypes);
				patientDemographicsBean.setReferralType_ID(referralTypeId);*/


				//Referrals
				/*String referral=rsUsr.getString("");
				if(referralTypeId.equals("1")){
					//get referralId from prEmployees
					String refId=""+PatientDemographicsLib.getReferralIdByName(referral, connDest);
					patientDemographicsBean.setReferralID(refId);
				}else if(referralTypeId.equals("2")){
					//get referralId from  Referrals
					String refId=""+PatientDemographicsLib.getConsultantIdByName("", "", connDest);
				}
				 */

				//VIP
				/*String vip=rsUsr.getString("");
				String vipValue=PatientDemographicsUtil.convertVip(vip);
				patientDemographicsBean.setVIP(vipValue);*/



				//Address1
				if(permanentAddress.length()<81){
					patientDemographicsBean.setLocalAddress1(permanentAddress);
					patientDemographicsBean.setPermanentAddress1(permanentAddress);
					patientDemographicsBean.setSpecialNote(table+" Migration");
				}else{
					patientDemographicsBean.setSpecialNote(table+" Migration "+permanentAddress);
				}


				//Area
				//patientDemographicsBean.setLocalAreaID("27");



				//Pin Code
				/*if(pincode==null || pincode.equals("null") || pincode.equals(null)){
					pincode="";
				}
				else if(pincode.length()>0) {
					if(pincode.length()>6){
						patientDemographicsBean.setLocalPostalCode(pincode.substring(0, 6));
						patientDemographicsBean.setPermanentPostalCode(pincode.substring(0, 6));
					}else{
						patientDemographicsBean.setLocalPostalCode(pincode);
						patientDemographicsBean.setPermanentPostalCode(pincode);
					}
				}*/
				
				patientDemographicsBean.setLocalPostalCode(PatientDemographicsLib.getPinCode(Localarea, connSrc));
				patientDemographicsBean.setPermanentPostalCode(patientDemographicsBean.getLocalPostalCode());

				//Country 
				if(country==null || country.equals("null") || country.equals(null)){
					country="OtherCountry";
				}
				String countryID=""+PatientDemographicsLib.getCountryByProcedureCall(country, connDest);

				//State
				if(state==null || state.equals("") || state.equals(null)){
					state="OtherState";
				}
				stateId=""+PatientDemographicsLib.getStateByProcedureCall(state, countryID, connDest);

				//City
				if(city==null || city.equals("") || city.equals(null)){
					city="OtherCity";
				}
				
				cityId=""+PatientDemographicsLib.getCityByProcedureCall(city, stateId, connDest);
				patientDemographicsBean.setLocalCityID(cityId);
				patientDemographicsBean.setPermanentCityID(cityId);
				
				//Local Area
				if(Localarea==null || Localarea.equals("") || Localarea.equals(null)){
					Localarea="";
				}
				patientDemographicsBean.setLocalAreaID(PatientDemographicsLib.getAreaByProcedureCall(Localarea, cityId, connDest)+"");
				patientDemographicsBean.setPermanentAreaID(patientDemographicsBean.getLocalAreaID());
				// Occupation

				if(occupation==null || occupation.equals("") || occupation.equals(null)){
					occupation="Other";
				}
				occupationID=""+PatientDemographicsLib.getOccupationByName(occupation, connDest);
				patientDemographicsBean.setOccupationID(occupationID);


				//Religion
				religion="Hindu";
				if(religion==null || religion.equals("") || religion.equals(null)){
					religionID="";
				}
				religionID = ""+PatientDemographicsLib.getReligionByProcedureCall(religion, connDest);
				patientDemographicsBean.setReligionID(religionID);


				//Contact Person

				//patientDemographicsBean.setContactPerson(cPerson);


				// Relationship
				cRelation="FAther";
				if(cRelation==null || cRelation.equals("") || cRelation.equals(null)){
					cRelationID="";
				}
				cRelationID =""+PatientDemographicsLib.getRelationByProcedureCall(cRelation, connDest);
				patientDemographicsBean.setRelationID(cRelationID);

				//Contact Person MobileNumber
				/*String cPersionMobileNumber=JUtil.validateString(rsUsr.getString("ContactPersonPhoneNo"));
				if(!cPersionMobileNumber.equals("")){
					if(cPersionMobileNumber.length()>15){
						patientDemographicsBean.setContactPersonMobile(cPersionMobileNumber.substring(0, 14));
					}else{
						patientDemographicsBean.setContactPersonMobile(cPersionMobileNumber);
					}
				}*/

				//Phone
				/*
				 * First Field is Code/ISD Code
				 * Second Field is phone number
				 */

				/*String code=rsUsr.getString("");
				patientDemographicsBean.setLocalStdCode(code);
				patientDemographicsBean.setLocalIsdCode(code);

				String phone=rsUsr.getString("");
				patientDemographicsBean.setLocalPhoneOff(phone);
				patientDemographicsBean.setLocalPhoneRes(phone);
				 */


				//Mobile NUmber

				String mobileNUmber=JUtil.validateString(rsUsr.getString("TelePhone"));
				if(mobileNUmber.length()>15){
					patientDemographicsBean.setMobile(mobileNUmber.substring(0, 14));
				}else{
					patientDemographicsBean.setMobile(mobileNUmber);
				}





				//EmailId
				/*String emailId=rsUsr.getString("");
				patientDemographicsBean.setEmail(emailId);*/







				//PAN Card
				/*String panCard=rsUsr.getString("");
				patientDemographicsBean.setPancard(panCard);*/


				//SSN
				/*String ssn=rsUsr.getString("");
				patientDemographicsBean.setAadharCard(ssn);*/


				//Medical Alerts
				/*String medicalAlerts=rsUsr.getString("");
				patientDemographicsBean.setMedicalAlerts(medicalAlerts);*/


				//Reason
				//String reason=rsUsr.getString("");
				//patientDemographicsBean.setSpecialNote("Migration");





				patientDemographics.insertData(patientDemographicsBean, connSrc, connDest, 3);

				objUI.displayStatus("Patients: Added: " + patientDemographicsBean.getAddCount() + " , Duplicate: " + patientDemographicsBean.getDupCount() + " , Invalid: " + patientDemographicsBean.getInvCount());
			}

		} catch (Exception e) {
			e.printStackTrace();
			objUI.displayProgress("Patients : " + e.toString());
			JUtil.logExceptions(e);
		} finally {
			rsUsr.close();
			//			stmt.close();
		}

		objUI.displayStatus("Patients: Added: " + patientDemographicsBean.getAddCount() + " , Duplicate: " + patientDemographicsBean.getDupCount() + " , Invalid: " + patientDemographicsBean.getInvCount());

	}





	/*private void addVisitType(Connection connSrc, Connection connDest,PMMigUI objUI) throws SQLException {

		//This method is used to create new visit Type

		String strSQL = "";
		Statement stmt = null;
		ResultSet rsVst = null;
		stmt = connSrc.createStatement();

		VisitTypeBean objVisitTypeBean = new VisitTypeBean();
		VisitType objVisttype = new VisitType();

		try
		{

			Users objUsr = new Users();
			Provider objPrv = new Provider();
			strSQL = "Select * from Visit_Type where Create_new = '1'";

			rsVst = stmt.executeQuery(strSQL);			

			while (rsVst.next()) 
			{	
				objVisitTypeBean.clearAll();

				String name = rsVst.getString("ClientVisitCode");
				name = JLib.Left(name, 10);System.out.println(name);
				String description =rsVst.getString("Description");
				description = "Mig- " + description;
				objVisitTypeBean.setStrVName(name);
				objVisitTypeBean.setStrVDescription(JUtil.validateString(description));

				objVisttype.insertData(objVisitTypeBean, connSrc, connDest);

				objUI.displayStatus("VisitType: Added: " + objVisitTypeBean.getAddCount() + " , Duplicate: " + objVisitTypeBean.getDupCount() + " , Invalid: " + objVisitTypeBean.getInvCount());

			}

		}catch(Exception e) {
			e.printStackTrace();
			objUI.displayProgress("VisitType: " + e.toString());
			JUtil.logExceptions(e);
		}
		finally {
			rsVst.close();
			stmt.close();
		}

		objUI.displayStatus("VisitType: Added: " + objVisitTypeBean.getAddCount() + " , Duplicate: " + objVisitTypeBean.getDupCount() + " , Invalid: " + objVisitTypeBean.getInvCount());

	}

	 */





	//Visit Status


	/*private void addVisitStatus(Connection connSrc, Connection connDest,PMMigUI objUI) throws SQLException {
		//This method is used to create new visit Status

		String strSQL = "";
		Statement stmt = null;
		ResultSet rsVst = null;
		stmt = connSrc.createStatement();

		VisitStatusBean objVisitStatusBean = new VisitStatusBean();
		VisitStatus objVisitStatus = new VisitStatus();

		try
		{

			Users objUsr = new Users();
			Provider objPrv = new Provider();
			strSQL = "Select * from Visit_Status where Create_new = '1'";

			rsVst = stmt.executeQuery(strSQL);			

			while (rsVst.next()) 
			{	
				System.out.println("hi");
				objVisitStatusBean.clearAll();

				String code = rsVst.getString("ClientVisitStatusCode");
				String Status =rsVst.getString("Description");
				Status = "Mig- " + Status;
				objVisitStatusBean.setStrVisitCode(JUtil.validateString(code));
				objVisitStatusBean.setStrVisitstatus(JUtil.validateString(Status));

				objVisitStatus.insertData(objVisitStatusBean, connSrc, connDest);

				objUI.displayStatus("Visit Status: Added: " + objVisitStatusBean.getAddCount() + " , Duplicate: " + objVisitStatusBean.getDupCount() + " , Invalid: " + objVisitStatusBean.getInvCount());
			}

		}catch(Exception e) {
			e.printStackTrace();
			objUI.displayProgress("Visit Status: " + e.toString());
			JUtil.logExceptions(e);
		}
		finally {
			rsVst.close();
			stmt.close();
		}

		objUI.displayStatus("Visit Status: Added: " + objVisitStatusBean.getAddCount() + " , Duplicate: " + objVisitStatusBean.getDupCount() + " , Invalid: " + objVisitStatusBean.getInvCount());


	}


	 */

















	//Add Guarantor Employer
	/*private void addGuarantorEmployers(Connection connSrc, Connection connDest,PMMigUI objUI) throws SQLException {
		String strSQL = "";
		String strSQL2 = "";

		String employer="";
		String name="";
		String[] flname=null;
		Statement stmt = null;
		Statement stmt2 = null;
		Statement stmt3 = null;
		Statement stmt4 = null;
		Statement stmt5 = null;
		Statement stmt6 = null;
		PreparedStatement stmt7 = null;
		PreparedStatement pstmt=null;

		ResultSet rsUsr = null;
		ResultSet rsUsr2 = null;
		ResultSet rsUsr3 = null;
		ResultSet rsUsr4 = null;
		ResultSet rsUsr5 = null;
		ResultSet rsUsr6 = null;
		ResultSet rs = null;

		//SOURCE
		stmt = connSrc.createStatement();
		stmt2 = connSrc.createStatement();
		stmt3 = connSrc.createStatement();

		//DESTINATION
		stmt4 = connDest.createStatement();
		stmt5 = connDest.createStatement();
		stmt6 = connDest.createStatement();
		//stmt7 = connDest.createStatement();
		int i=0,j=0,k=0;
		System.out.println("hereee");

		EmployerBean objEmpBean=new EmployerBean();
		try{


			String empyrName="";
			String empyrAddress="";
			String empyrAddress2="";
			String empyrCity="";
			String empyrState="";
			String empyrZip="";
			String empPhone="";
			strSQL = "SELECT * FROM Guarantor where [Employer Name]<>''";
			rsUsr = stmt.executeQuery(strSQL);
			String Lang="";
			Employer objEmp=new Employer();

			String empName="";
			while (rsUsr.next()) {
				empName=JUtil.validateString(rsUsr.getString("Employer Name"));
				objEmpBean.setStrEmpName(empName);
				objEmpBean.setStrempAddress1(JUtil.validateString(rsUsr.getString("Employer Address 1")));
				objEmpBean.setStrempAddress2(JUtil.validateString(rsUsr.getString("Employer Address 2")));
				objEmpBean.setStrempCity(JUtil.validateString(rsUsr.getString("Employer City")));
				objEmpBean.setStrempState(JUtil.validateString(rsUsr.getString("Employer State")));
				objEmpBean.setStrempZip(JUtil.validateString(rsUsr.getString("Employer Zip")));

				objEmp.insertData(objEmpBean, connSrc, connDest);
				objUI.displayStatus("Employers: Added: " + i + " ; Duplicates: " + j + " ; Invalid: " + k);
				i++;
			}{
				j++;
			}


		}catch(Exception e){
			e.printStackTrace();
			JUtil.logExceptions(e);

		}finally{
			rsUsr.close();


		}
		objUI.displayStatus("Employers: Added: " + i + " ; Duplicates: " + j + " ; Invalid: " + k);		



	}
	 */

	//Add Employer
	/*private void addEmployer(Connection connSrc, Connection connDest,PMMigUI objUI) throws SQLException {
		String strSQL = "";
		String strSQL2 = "";

		String employer="";
		String name="";
		String[] flname=null;
		Statement stmt = null;
		Statement stmt2 = null;
		Statement stmt3 = null;
		Statement stmt4 = null;
		Statement stmt5 = null;
		Statement stmt6 = null;
		PreparedStatement stmt7 = null;
		PreparedStatement pstmt=null;

		ResultSet rsUsr = null;
		ResultSet rsUsr2 = null;
		ResultSet rsUsr3 = null;
		ResultSet rsUsr4 = null;
		ResultSet rsUsr5 = null;
		ResultSet rsUsr6 = null;
		ResultSet rs = null;

		//SOURCE
		stmt = connSrc.createStatement();
		stmt2 = connSrc.createStatement();
		stmt3 = connSrc.createStatement();

		//DESTINATION
		stmt4 = connDest.createStatement();
		stmt5 = connDest.createStatement();
		stmt6 = connDest.createStatement();
		//stmt7 = connDest.createStatement();
		int i=0,j=0,k=0;
		System.out.println("hereee");

		EmployerBean objEmpBean=new EmployerBean();
		try{



			strSQL = "SELECT * FROM Employer where name<>''";
			rsUsr = stmt.executeQuery(strSQL);
			String Lang="";
			Employer objEmp=new Employer();

			String empName="";
			while (rsUsr.next()) {
				empName=JUtil.validateString(rsUsr.getString("name"));
				objEmpBean.setStrEmpName(empName);


					objEmpBean.setStrempAddress1(JUtil.validateString(rsUsr.getString("Address1")));
					objEmpBean.setStrempAddress2(JUtil.validateString(rsUsr.getString("Address2")));
					objEmpBean.setStrempCity(JUtil.validateString(rsUsr.getString("City")));
					objEmpBean.setStrempState(JUtil.validateString(rsUsr.getString("State")));
					objEmpBean.setStrempZip(JUtil.validateString(rsUsr.getString("Zip")));
					objEmpBean.setStrempPhone(JUtil.validateString(rsUsr.getString("Phone1")));


				objEmp.insertData(objEmpBean, connSrc, connDest);
				objUI.displayStatus("Employers: Added: " + i + " ; Duplicates: " + j + " ; Invalid: " + k);
				i++;
			}{
				j++;
			}


		}catch(Exception e){
			e.printStackTrace();
			JUtil.logExceptions(e);

		}finally{
			rsUsr.close();


		}
		objUI.displayStatus("Employers: Added: " + i + " ; Duplicates: " + j + " ; Invalid: " + k);		



	}
	 */






	//Add Relation
	/*private void addRelation(Connection connSrc, Connection connDest,PMMigUI objUI) throws SQLException 
	{
		String strSQL = "";
		String strSQL2 = "";
		String strSQL3 = "";
		String strSQL4 = "";

		Statement stmt = null;
		Statement stmt2 = null;
		Statement stmt3 = null;
		Statement stmt4 = null;

		ResultSet rsUsr = null;
		ResultSet rsUsr2 = null;
		ResultSet rsUsr3 = null;
		ResultSet rsUsr4 = null;

		stmt = connSrc.createStatement();
		stmt2 = connDest.createStatement();
		stmt3 = connDest.createStatement();

		String chartNo="";
		String guarantor="";
		int grid=0;
		int pid=0;
		int isGrPt=0;
		int userType=0;
		int i=0,j=0;
		//stmt2 = connSrc.createStatement();
		//stmt3 = connSrc.createStatement();
		stmt4 = connDest.createStatement();
		System.out.println("ADD RELATION");
		PatientsBean SCBean = new PatientsBean();
		//select distinct[chart number],[Guarantor]  from mwcas where [chart number]<>[Guarantor]
		String relation="";
		try{
			//strSQL="SELECT * FROM dbo_uvPatientDemographics WHERE  PatientSameAsGuarantor=0 and PatientRelationToGuarantor<>'Self'";

			strSQL="SELECT * FROM PatientDemographics WHERE [Relation to Guarantor]<>''";
			//strSQL="SELECT * FROM dbo_uvPatientDemographics where [PatientProfileId]='1454'";
			//strSQL="select *  from Patient where [Chart Number]='100200'";  1454
			rsUsr=stmt.executeQuery(strSQL);
			while(rsUsr.next())
			{

				chartNo="";
				guarantor="";
				grid=0;
				pid=0;
				isGrPt=0;
				userType=0;

				chartNo=rsUsr.getString("Patient ID");

				//guarantor=rsUsr.getString("GuarantorId");

				relation=JUtil.validateString(rsUsr.getString("Relation to Guarantor"));

				String relConvert=JUtil.convertRel(relation);


				grid = JLib.getUidByVmid("Gr-"+chartNo, connDest);
				if(grid==0){
					grid = JLib.getUidByVmidFromMdb(chartNo, connSrc);
					//System.out.println("GRID for Guarantor= "+guarantor+" FROM MDB= "+grid);
				}
				if(grid==0){
					grid=JLib.getUidByVmid("Pat-"+chartNo, connDest);
				}

				pid = JLib.getUidByVmid("Pat-"+chartNo, connDest);




				//System.out.println(grid+"=GRID , PID="+pid);


				userType=JLib.getUserTypeByUid(grid, connDest);
				System.out.println("UT="+userType);
				if(grid!=0 && grid!=pid){
					if(userType==4){
						System.out.println("here");

						strSQL3="UPDATE patients SET isgrpt=0,GrRel='"+relConvert+"' , Grid='"+grid+"' where pid='"+pid+"'";
						System.out.println(strSQL3);
						stmt3.executeUpdate(strSQL3);
						i++;

					}else{
						strSQL2="UPDATE patients SET GrRel='"+relConvert+"', isgrpt=0,Grid="+grid+" where pid='"+pid+"'";
						System.out.println(strSQL2);
						stmt4.executeUpdate(strSQL2);

						i++;
					}

				}
				else
				{
					j++;
					System.out.println( "Not Addes: " + j + " , chartNo: " + chartNo+ " , GUARANTOR: " +guarantor);
				}

				objUI.displayStatus("Relation: Added: " + i + " , Not Addes: " + j);

			}


		}
		catch(Exception e){
			e.printStackTrace();
		}

	}

	 */


	/*private void addFacility (Connection connSrc, Connection connDest, PMMigUI objUI) throws SQLException {

		String strSQL = "";
		Statement stmt = null;
		ResultSet rsFac = null;
		stmt = connSrc.createStatement();


		String strSQL1 = "";
		Statement stmt1 = null;
		ResultSet rsFac1 = null;
		stmt1 = connSrc.createStatement();



		FacilityBean objFacBean = new FacilityBean();

		try {

			Facility  objFac = new Facility();

			strSQL = "select * from Facility where [name]<>''";

			int i = 0;

			rsFac = stmt.executeQuery(strSQL);

			while (rsFac.next()) {

				objFacBean.clearAll();

				String facId=JUtil.validateString(rsFac.getString("facility_id"));
				objFacBean.setStrvmid("Fac-"+facId );
				objFacBean.setStrName(JUtil.validateString(rsFac.getString("name")));
				objFacBean.setStrTel(JUtil.validateString(rsFac.getString("phone")));


				objFacBean.setStrAddressLine1(JUtil.validateString(rsFac.getString("Address1")));
				objFacBean.setStrAddressLine2(JUtil.validateString(rsFac.getString("Address2")));
				objFacBean.setStrCity(JUtil.validateString(rsFac.getString("City")));
				objFacBean.setStrState(JUtil.validateString(rsFac.getString("State")));
				objFacBean.setStrZip(JUtil.validateString(rsFac.getString("Zip")));

				objFacBean.setStrFax(JUtil.validateString(rsFac.getString("Phone2")));
				objFacBean.setStrFederalTaxID(JUtil.validateString(rsFac.getString("FederalTaxId")));
				objFacBean.setStrNPI(rsFac.getString("NPI"));




				//objFacBean.setPOS(rsFac.getInt("LOC_POS_NUMBER"));
				//objFacBean.setStrCliaId(JUtil.validateString(rsFac.getString("Extra 2")));

				//Fedral Tax id
				//objFacBean.setStrFederalTaxID(JUtil.validateString(rsFac.getString("FederalTaxId")));
				//objFacBean.setStrNPI(rsFac.getString("National Provider Identifier"));
				//objFacBean.setStrTaxonomyCode(rsFac.getString("taxonomy_code"));

				objFac.insertData(objFacBean, connSrc, connDest);
				objUI.displayStatus("Facility: Added: " + objFacBean.getAddCount() + " , Duplicate: " + objFacBean.getDupCount() + " , Invalid: " + objFacBean.getInvCount());

			}



			strSQL1 = "select * from mwpra";
			rsFac1 = stmt1.executeQuery(strSQL1);

			while (rsFac1.next()) {
				objFacBean.clearAll();
				objFacBean.setStrvmid("Fac-" + rsFac1.getString("ID"));


				objFacBean.setStrName(JUtil.validateString(rsFac1.getString("Practice Name")));
				objFacBean.setStrCity(JUtil.validateString(rsFac1.getString("City")));
				objFacBean.setStrState(JUtil.validateString(rsFac1.getString("State")));
				objFacBean.setStrAddressLine1(JUtil.validateString(rsFac1.getString("Street 1")));
				objFacBean.setStrAddressLine2(JUtil.validateString(rsFac1.getString("Street 2")));
				objFacBean.setStrTel(JUtil.validateString(rsFac1.getString("Phone"))); 
				objFacBean.setStrZip(JUtil.validateString(rsFac1.getString("Zip Code")));
				objFacBean.setStrFax(JUtil.validateString(rsFac1.getString("Fax")));
				objFacBean.setStrFederalTaxID(JUtil.validateString(rsFac1.getString("Federal Tax ID")));



				//objFacBean.setPOS(rsFac1.getInt("LOC_POS_NUMBER"));
				//objFacBean.setStrCliaId(JUtil.validateString(rsFac1.getString("Extra 2")));

				//objFacBean.setStrFederalTaxID(JUtil.validateString(rsFac1.getString("LOC_TAX_ID_2")));
				//objFacBean.setStrNPI(rsFac1.getString("National Provider Identifier"));
				//objFacBean.setStrTaxonomyCode(rsFac1.getString("taxonomy_code"));

				objFac.insertData(objFacBean, connSrc, connDest);
			}



		} catch(Exception e) {
			e.printStackTrace();
			objUI.displayProgress("Facility : " + e.toString());
			JUtil.logExceptions(e);
		}
		finally {
			rsFac.close();
			stmt.close();
		}

		objUI.displayStatus("Facility: " + objFacBean.getAddCount() + "-" + objFacBean.getDupCount() + "-" + objFacBean.getInvCount());




	}

	 */
	/*private void addDoctors(Connection connSrc, Connection connDest,PMMigUI objUI) throws SQLException {
		// TODO Auto-generated method stub	

		String strSQL = "";

		String strSQL2 = "";

		Statement stmt = null;

		Statement stmt2 = null;

		ResultSet rsUsr = null;

		ResultSet rsUsr2 = null;

		stmt = connSrc.createStatement();

		stmt2 = connSrc.createStatement();

		ProviderBean SCBean = new ProviderBean();
		try
		{

			Users objUsr = new Users();
			Provider objPrv = new Provider();
			strSQL="";


			strSQL = "Select * from User where isprovider='1' and isinactive='0'";

			rsUsr = stmt.executeQuery(strSQL);			
			//int c=1;
			while (rsUsr.next()) {	
				SCBean.clearall();
				SCBean.clearallUsers();
				//SCBean.set
				//SCBean.setFacVmid(rsUsr.getString("code"));

				String c=rsUsr.getString("user_id");
				SCBean.setVmid("Dr-" + c);

				SCBean.setUfname(JUtil.validateString(rsUsr.getString("firstname")));

				SCBean.setUlname(JUtil.validateString(rsUsr.getString("lastname")));


				SCBean.setSuffix(JUtil.validateString(rsUsr.getString("suffix")));
				SCBean.setUname(SCBean.getUfname() + JLib.Left(SCBean.getUlname(),1));
				SCBean.setSpecialty(JUtil.validateString(rsUsr.getString("speciality"))); 
				SCBean.setDeano(JUtil.validateString(rsUsr.getString("dea")));
				SCBean.setStLicNo(JUtil.validateString(rsUsr.getString("state_license")));
				SCBean.setNPI(JUtil.validateString(rsUsr.getString("national_provider_id")));
				SCBean.setTaxid(JUtil.validateString(rsUsr.getString("federal")));


				SCBean.setUfname(JUtil.validateString(rsUsr.getString("First")));
				SCBean.setUminitial(JUtil.validateString(rsUsr.getString("Middle")));
				SCBean.setUlname(JUtil.validateString(rsUsr.getString("Last")));

				SCBean.setSuffix(JUtil.validateString(rsUsr.getString("Suffix")));




				SCBean.setUpaddress(JUtil.validateString(rsUsr.getString("Address1")));
				SCBean.setUpcity(JUtil.validateString(rsUsr.getString("City")));
				SCBean.setUpstate(JUtil.validateString(rsUsr.getString("State")));
				SCBean.setZipcode(JUtil.validateString(rsUsr.getString("Zip")));
				SCBean.setUpphone(JUtil.validateString(rsUsr.getString("Phone1")));
				SCBean.setFaxno(JUtil.validateString(rsUsr.getString("Phone2")));

				SCBean.setTaxidtype(JUtil.validateString(rsUsr.getString("FederalTaxIdType")));
				SCBean.setSpLicNo(JUtil.validateString(rsUsr.getString("Ledger")));


				//SCBean.setSsn(rsUsr.getString("SSN or Fed Tax ID").intern());
				//SCBean.setSsn(JUtil.validateString(SCBean.getTaxid()));
				//SCBean.setUpin(JUtil.validateString(rsUsr.getString("UPIN")));
				//
				//SCBean.setTaxonomycode(JUtil.validateString(rsUsr.getString("Taxonomy_Code")));


				objUsr.insertData(SCBean, connSrc, connDest, 1);
				if (!(SCBean.getUID()==0)){
					objPrv.insertData(SCBean, connSrc, connDest, SCBean.getUID());	            	            
				}
				objUI.displayStatus("Providers: Added: " + SCBean.getAddCount() + " , Duplicate: " + SCBean.getDupCount() + " , Invalid: " + SCBean.getInvCount());

			}



		}catch(Exception e) {
			e.printStackTrace();
			objUI.displayProgress("Providers : " + e.toString());
			JUtil.logExceptions(e);
		}
		finally {
			rsUsr.close();
			stmt.close();
		}

		objUI.displayStatus("Providers: Added: " + SCBean.getAddCount() + " , Duplicate: " + SCBean.getDupCount() + " , Invalid: " + SCBean.getInvCount());

	}

	 */




	/*private void addResource(Connection connSrc, Connection connDest,PMMigUI objUI) throws SQLException {
		String strSQL = "";
		Statement stmt = null;
		ResultSet rsUsr = null;
		stmt = connSrc.createStatement();

		ProviderBean SCBean = new ProviderBean();

		try
		{

			Users objUsr = new Users();
			Provider objPrv = new Provider();
			strSQL = "Select * from Resource";

			rsUsr = stmt.executeQuery(strSQL);			

			while (rsUsr.next()) {	
				SCBean.clearall();
				SCBean.clearallUsers();

				SCBean.setVmid("Res-" + rsUsr.getString("resource_id"));

				SCBean.setUfname(JUtil.validateString(rsUsr.getString("name")));
				SCBean.setUlname("Resource");

				SCBean.setUname(SCBean.getUfname());

				objUsr.insertData(SCBean, connSrc, connDest, 9);
				if (!(SCBean.getUID()==0))
				{
					objPrv.insertData(SCBean, connSrc, connDest, SCBean.getUID());	            	            
				}
				objUI.displayStatus("Resources: Added: " + SCBean.getAddCount() + " , Duplicate: " + SCBean.getDupCount() + " , Invalid: " + SCBean.getInvCount());

			}

		}catch(Exception e) {
			e.printStackTrace();
			objUI.displayProgress("Resources: " + e.toString());
			JUtil.logExceptions(e);
		}
		finally {
			rsUsr.close();
			stmt.close();
		}

		objUI.displayStatus("Resources: Added: " + SCBean.getAddCount() + " , Duplicate: " + SCBean.getDupCount() + " , Invalid: " + SCBean.getInvCount());

	}

	 */









	/*private void addRefProviders(Connection connSrc, Connection connDest,PMMigUI objUI) throws SQLException {
		// TODO Auto-generated method stub	
		String strSQL = "";
		Statement stmt = null;
		ResultSet rsUsr = null;
		stmt = connSrc.createStatement();


		String strSQL1 = "";
		Statement stmt1 = null;
		ResultSet rsUsr1 = null;
		stmt1 = connSrc.createStatement();


		ProviderBean SCBean = new ProviderBean();

		String temp2[];
		String temp[];
		String licno[];



		try
		{

			Users objUsr = new Users();
			Provider objPrv = new Provider();
			strSQL="";


			strSQL = "Select * from referralsAddress";  
			//strSQL = "Select * from dbo_DoctorFacility where DoctorFacilityId='215'";
			rsUsr = stmt.executeQuery(strSQL);			

			while (rsUsr.next()) {	
				SCBean.clearall();
				SCBean.clearallUsers();

				String c="";
				String upin[];
				String notes = "";

				c=JUtil.validateString(rsUsr.getString("referrals_id"));
				SCBean.setVmid("Ref-" + c);


				SCBean.setUfname(JUtil.validateString(rsUsr.getString("first")));
				//SCBean.setUminitial(JUtil.validateString(rsUsr.getString("Middle Name")));
				SCBean.setUlname(JUtil.validateString(rsUsr.getString("last")));
				SCBean.setUname(SCBean.getUfname() + JLib.Left(SCBean.getUlname(),1));
				SCBean.setSuffix(JUtil.validateString(rsUsr.getString("suffix"))); 
				//
				//SCBean.setUpaddress2(JUtil.validateString(rsUsr.getString("address2")));

				SCBean.setUpphone(JUtil.validateString(rsUsr.getString("phone2")));
				SCBean.setTaxonomycode(JUtil.validateString(rsUsr.getString("taxonomy")));
				SCBean.setMedicareNo(JUtil.validateString(rsUsr.getString("id_medicare")));
				//SCBean.setFaxno(JUtil.validateString(rsUsr.getString("Fax")));
				//SCBean.setTaxid(JUtil.validateString(rsUsr.getString("FederalTaxId")));
				//SCBean.setTaxidtype(JUtil.validateString(rsUsr.getString("FederalTaxIdType")));
				//SCBean.setSpLicNo(JUtil.validateString(rsUsr.getString("Ledger")));
				//SCBean.setNPI(JUtil.validateString(rsUsr.getString("NPI")));

				SCBean.setUpaddress(JUtil.validateString(rsUsr.getString("address1")));
				SCBean.setUpaddress2(JUtil.validateString(rsUsr.getString("address2")));




				SCBean.setNPI(JUtil.validateString(rsUsr.getString("id_nationalprovider")));
				//SCBean.setTaxid(JUtil.validateString(rsUsr.getString("SSN or Fed Tax ID")));
				//SCBean.setSsn(rsUsr.getString("SSN or Fed Tax ID").intern());
				//SCBean.setSsn(JUtil.validateString(SCBean.getTaxid()));


				//SCBean.setDeano(JUtil.validateString(rsUsr.getString("DEA Registration")));

				String citystatezip_id=JUtil.validateString(rsUsr.getString("citystatezip_id"));
				strSQL1="select * from Citystatezip where [citystatezip_id]='"+citystatezip_id+"'";
				rsUsr1=stmt1.executeQuery(strSQL1);
				if(rsUsr1!=null){
					if(rsUsr1.next()){

						SCBean.setUpcity(JUtil.validateString(rsUsr1.getString("city")));
						SCBean.setUpstate(JUtil.validateString(rsUsr1.getString("state")));
						SCBean.setZipcode(JUtil.validateString(rsUsr1.getString("zip")));
					}
				}

				SCBean.setUpcity(JUtil.validateString(rsUsr.getString("city")));
				SCBean.setUpstate(JUtil.validateString(rsUsr.getString("state")));
				SCBean.setZipcode(JUtil.validateString(rsUsr.getString("zip")));


				objUsr.insertData(SCBean, connSrc, connDest, 5);
				if (!(SCBean.getUID()==0)){
					objPrv.insertData(SCBean, connSrc, connDest, SCBean.getUID());	            	            
				}
				objUI.displayStatus("Referring Provider: Added: " + SCBean.getAddCount() + " , Duplicate: " + SCBean.getDupCount() + " , Invalid: " + SCBean.getInvCount());

			}



		}catch(Exception e) {
			//e.printStackTrace();
			objUI.displayProgress("Referring Provider : " + e.toString());
			JUtil.logExceptions(e);
		}
		finally {
			rsUsr.close();
			stmt.close();
		}

		objUI.displayStatus("Referring Provider: Added: " + SCBean.getAddCount() + " , Duplicate: " + SCBean.getDupCount() + " , Invalid: " + SCBean.getInvCount());

	}
	 */

	/*private void addInsurance(Connection connSrc, Connection connDest, PMMigUI objUI) throws Exception {
		String strSQL = "";
		Statement stmt = null;
		ResultSet rsIns = null;
		stmt = connSrc.createStatement();
		InsuranceBean objInsBean = new InsuranceBean();

		try
		{

			Insurance  objIns = new Insurance();

			strSQL ="Select * from Insurance where insurance_id<>'1'";

			rsIns = stmt.executeQuery(strSQL);

			while (rsIns.next())
			{

				objInsBean.clearAll();
				String c=JUtil.validateString(rsIns.getString("insurance_id"));
				System.out.println(c);
				objInsBean.setStrInsVMID("Ins-" +c );
				objInsBean.setStrName(JUtil.validateString(rsIns.getString("carrier")));
				//objInsBean.setStrAddress1(JUtil.validateString(rsIns.getString("Insurance Address")));
				//objInsBean.setStrAddress2(JUtil.validateString(rsIns.getString("Address2")));
				//objInsBean.setStrCity(JUtil.validateString(rsIns.getString("Insurance City")));
				//objInsBean.setStrState(JUtil.validateString(rsIns.getString("Insurance State")));
				//objInsBean.setStrZip(JUtil.validateString(rsIns.getString("Insurance Zip Code")));
				objInsBean.setStrPhone(JUtil.validateString(rsIns.getString("phone")));
				objInsBean.setStrPayorID(JUtil.validateString(rsIns.getString("payer_id")));
				objInsBean.setStrMediGapID(JUtil.validateString(rsIns.getString("medigap")));



				objIns.insertData(objInsBean, connSrc, connDest);
				objUI.displayStatus("Insurance: Added: " + objInsBean.getAddCount() + " , Duplicate: " + objInsBean.getDupCount() + " , Invalid: " + objInsBean.getInvCount());

			}

		}
		catch(Exception e)
		{
			e.printStackTrace();
			objUI.displayProgress("Insurance : " + e.toString());
			JUtil.logExceptions(e);

		}
		finally
		{
			rsIns.close();
			stmt.close();
		}
		objUI.displayStatus("Insurance: " + objInsBean.getAddCount() + "-" + objInsBean.getDupCount() + "-" + objInsBean.getInvCount());
	}
	 */

	/*private void addPatients (Connection connSrc, Connection connDest,PMMigUI objUI) throws SQLException {

		String strSQL = "";
		String strSQL2 = "";
		String strSQL3 = "";
		String strSQL4 = "";
		String strSql5="";
		String asgndPrSQL="";
		String pcpSQL="";

		String assignedProvider="";
		String pcp="";
		String employer="";
		java.sql.PreparedStatement stmtPr =null;

		int assignedPrId = 0;
		int pcpId = 0;
		int defFeeschid=0;
		Statement stmt = null;
		Statement destStmt = null;
		Statement stmt2 = null;
		Statement stmt3 = null;
		Statement stmt4 = null;
		Statement stmt5 = null;
		Statement stmt6 = null;

		ResultSet rsUsr = null;
		ResultSet destUsr = null;
		ResultSet rsUsr2 = null;
		ResultSet rsUsr3 = null;
		ResultSet rsUsr4 = null;
		ResultSet rsUsr5 = null;
		ResultSet rsUsr6 = null;

		//SOURCE
		stmt = connSrc.createStatement();
		destStmt = connDest.createStatement();
		stmt2 = connSrc.createStatement();
		stmt3 = connSrc.createStatement();
		stmt4 = connSrc.createStatement();
		stmt5 = connSrc.createStatement();

		//DESTINATION


		stmt6 = connDest.createStatement();
		PatientsBean SCBean = new PatientsBean();

		String facility="";
		String patEmployer="";


		String insNotes="";
		String insTemp="";




		String strSQL10 = "";
		Statement stmt10 = null;
		ResultSet rs10 = null;
		stmt10 = connSrc.createStatement();

		String strSQL11="";
		Statement stmt11 = null;
		ResultSet rs11 = null;
		stmt11 = connSrc.createStatement();


		String strSQL12 = "";
		Statement stmt12 = null;
		ResultSet rs12 = null;
		stmt12 = connSrc.createStatement();


		String strSQL13 = "";
		Statement stmt13 = null;
		ResultSet rs13 = null;
		stmt13 = connSrc.createStatement();




		String notes="";
		String temp="";


		stmt.executeUpdate("DELETE from duppat");
		try {

			Users objUsr = new Users();
			Patients objPat = new Patients();
			strSQL = "";
			String strSQL1 = "";
			int contNo=10000; //control number if new ecw account numbers has to be set

			strSQL = "SELECT  * from PatPersonJoinTable";  // 7992
			//strSQL = "SELECT  * from PatPersonJoinTable where [patient_id]='2'";




			rsUsr = stmt.executeQuery(strSQL);
			String sexValue="";
			String sex="";
			String dob="";
			String[]  dateBirth=null;
			String DateOfBirth="";
			while (rsUsr.next()) {

				SCBean.clearall();
				SCBean.clearallUsers();
				String patid= rsUsr.getString("patient_id").intern(); //Patient ID
				System.out.println("Patient: "+patid);



				//Inactive
				String Inactive=JUtil.validateString(rsUsr.getString("PatientInactive"));
				if(Inactive=="1" || Inactive.equals("1")){
					SCBean.setStatus("1");
				} else if(Inactive=="0" || Inactive.equals("0")){
					SCBean.setStatus("0");
				}else{
					SCBean.setStatus("0");
				}



				//Control Number
				SCBean.setControlNo(""+contNo);
				contNo++;


				//Vmid
				SCBean.setVmid("Pat-" + patid); //VMID




				//MRN
				SCBean.setMrn(JUtil.validateString(rsUsr.getString("chart_num"))); //old patient id goes to MRN in front-end  cos we didnt find mrn


				//Deceased

				String deathDate=JUtil.validateString(rsUsr.getString("PatientDeathDate"));
				if(deathDate==null || deathDate=="" || deathDate.equals("") || deathDate.equals("NULL")){

				}else{
					SCBean.setDeceased("1");
				}



				//Patient fnamme,lname,mname

				String lname =JUtil.validateString(rsUsr.getString("last"));
				String fname = JUtil.validateString(rsUsr.getString("first"));
				String mname = JUtil.validateString(rsUsr.getString("middle"));

				if (fname != null)
					SCBean.setUfname(fname);
				if (lname != null)
					SCBean.setUlname(lname);
				if (mname != null)
					SCBean.setUminitial(mname);

				//suffix
				//SCBean.setSuffix(JUtil.validateString(rsUsr.getString("PatientSuffix")));


				//Address
				String address_id=JUtil.validateString(rsUsr.getString("address_id"));
				strSQL2="select * from Address where address_id='"+address_id+"'";
				rsUsr2=stmt2.executeQuery(strSQL2);
				if(rsUsr2!=null){
					if(rsUsr2.next()){
						SCBean.setUpaddress(JUtil.validateString(rsUsr2.getString("address1")));
						SCBean.setUpaddress2(JUtil.validateString(rsUsr2.getString("address2")));
						String cityStateZip=JUtil.validateString(rsUsr2.getString("citystatezip_id"));
						strSQL3="select * from Citystatezip where citystatezip_id='"+cityStateZip+"'";
						rsUsr3=stmt3.executeQuery(strSQL3);
						if(rsUsr3!=null){
							if(rsUsr3.next()){
								String city=JUtil.validateString(rsUsr3.getString("city"));
								if(city.length()>24){
									city=city.substring(0,24);
									SCBean.setUpcity(city);
								}else{
									SCBean.setUpcity(city);
								}
								SCBean.setUpstate(JUtil.validateString(rsUsr3.getString("state")));
								SCBean.setZipcode(JUtil.validateString(rsUsr3.getString("zip")));
							}
						}

					}
				}




				//Country

				String country=JUtil.validateString(rsUsr.getString("PatientCountry"));
				if(country=="" || country==null || country.equals("") || country.equals("null")){
					SCBean.setCountryCode("US");
				}else

				SCBean.setCountryCode("US");


				// Gender
				String gender=JUtil.validateString(rsUsr.getString("pop_sex"));
				SCBean.setSex(JUtil.convertSex(gender));





				// Date Of Birth
				dob = JUtil.validateString(rsUsr.getString("birthday"));

				System.out.println(dob);
				if(dob==null || dob.equals("NULL")){
					dob="";
				}
				if(dob!=""){
					System.out.println(dob);
					String dobValue=dob.substring(5,7)+"/"+dob.substring(8, 10)+"/"+dob.substring(0, 4);
					System.out.println(dobValue);
					SCBean.setDob(dobValue, "MM/dd/yyyy");
					SCBean.setPtDob(dobValue, "MM/dd/yyyy");
				}else{
					SCBean.setDob("", "MM/dd/yyyy");
					SCBean.setPtDob("", "MM/dd/yyyy");
				}




				//UpPhone
				String phone1=JUtil.validateString(rsUsr.getString("phone1")).intern();
				SCBean.setUpphone(phone1);


				//UMObile
				SCBean.setUmobileno(JUtil.validateString(rsUsr.getString("phone2")));

				//Work Phone
				SCBean.setEmployerphone(CommonFunction.convertPhone(JUtil.validateString(rsUsr.getString("phone3")).intern()));


				//SSN
				SCBean.setSsn(CommonFunction.convertSSN(JUtil.validateString(rsUsr.getString("ssn")).intern()));


				//Marital Status

				String mStatus=JUtil.validateString(rsUsr.getString("pop_marital_status"));
				SCBean.setMaritalstatus(JUtil.convertMaritalStatus(mStatus));




				//Email
				SCBean.setUemail(JUtil.validateString(rsUsr.getString("email")));


				// Rendering Provider

				String rendProvider=JUtil.validateString(rsUsr.getString("provider_id"));
				int uid=JLib.getUidByVmid("Dr-"+rendProvider, connDest);
				SCBean.setRendprid(""+uid);


				//PCP   No Data



				//Refering Provider
				//String refProvider=JUtil.validateString(rsUsr.getString("Referring Physician"));

				String refProvider=JUtil.validateString(rsUsr.getString("Referring Physician"));
				if(refProvider==null || refProvider=="" || refProvider.equals("") || refProvider.equals(null)){
				}else{
				String[] refProviderSplited=refProvider.split(",");

				String refLName=refProviderSplited[0];
				String refFName=refProviderSplited[1];

				if(refLName.contains(" ")){
					String refLNameSplited[]=refLName.split(" ");
					refLName=refLNameSplited[0];
				}

				if(refFName.contains(" ")){
					String refFNameSplited[]=refFName.split(" ");
					refFName=refFNameSplited[0];
					if(refFName.equals("")){
						refFName=refFNameSplited[1];
					}else if(refFName.equals("")){
						refFName=refFNameSplited[2];
					}
				}

				int uid=JLib.getRefProviderUidByFname(refFName,connDest);

				if(uid==0){
					 uid=JLib.getProviderUidByFname(refFName,connDest);
				}

				SCBean.setRefPrID(""+uid);
				}


				//Race

				//String race=JUtil.validateString(rsUsr.getString("Race"));
				//SCBean.setRace(JUtil.convertRace(race));

				//Language

				//String language=JUtil.validateString(rsUsr.getString("Preffered Language"));
				//SCBean.setLanguage(JUtil.convertLanguage(language));
				SCBean.setLanguage("English");	


				//Ethnicity
				String ethnicity=JUtil.validateString(rsUsr.getString("ethnicity_id"));
				SCBean.setEthnicity(JUtil.convertEthnicityStatus(ethnicity));



				SCBean.setRelinfo("Y");
				SCBean.setRelinfodate("1900-01-01");
				SCBean.setGrrel("1");


				// Facilities

				SCBean.setDefaultFacility(119);		

				// Notes
				//String patNote=JUtil.validateString(rsUsr.getString("Notes"));
				//SCBean.setNotes("Ref-Provider: "+refProvider+"\n"+patNote);


				// Employers

				//SCBean.setEmployername(rsUsr.getString("Employer Details"));



				objUsr.insertData(SCBean, connSrc, connDest, 3);

				if (!(SCBean.getUID()==0)){

					objPat.insertData(SCBean, connSrc, connDest, SCBean.getUID());	            	            
				}
				objUI.displayStatus("Patients: Added: " + SCBean.getAddCount() + " , Duplicate: " + SCBean.getDupCount() + " , Invalid: " + SCBean.getInvCount());
			}

		} catch (Exception e) {
			e.printStackTrace();
			objUI.displayProgress("Patients : " + e.toString());
			JUtil.logExceptions(e);
		} finally {
			rsUsr.close();
			//			stmt.close();
		}

		objUI.displayStatus("Patients: Added: " + SCBean.getAddCount() + " , Duplicate: " + SCBean.getDupCount() + " , Invalid: " + SCBean.getInvCount());

		long total = SCBean.getDupCount() + SCBean.getAddCount() + SCBean.getInvCount();
		strSQL2 = "insert into pm_mig_status (tot_read,tot_add,tot_inv,tot_dup) values ('" + String.valueOf(total) + "', '" + SCBean.getAddCount() + "', '" + SCBean.getInvCount() + "', '" + SCBean.getDupCount() + "')";
		stmtPr = connDest.prepareStatement(strSQL2);
		stmtPr.executeUpdate();
		SCBean.incrInvCount();
		stmtPr.close();

	}
	 */


	/*private void addGuarantors (Connection connSrc, Connection connDest,PMMigUI objUI) throws SQLException {

		String strSQL = "";
		String strSQL2 = "";
		String strSQL3 = "";
		Statement stmt = null;
		Statement stmt2 = null;
		Statement stmt3 = null;
		ResultSet rsUsr = null;
		ResultSet rsUsr2 = null;
		ResultSet rsUsr3 = null;

		stmt = connSrc.createStatement();
		stmt2 = connSrc.createStatement();
		stmt3 = connSrc.createStatement();
		PatientsBean SCBean = new PatientsBean();

		try {

			String dob="";
			Users objUsr = new Users();
			Patients objPat = new Patients();
			strSQL = "";
			String arr[]=null;
			strSQL = "SELECT  * from PatientDemographics";
			rsUsr = stmt.executeQuery(strSQL);

			while (rsUsr.next()) {

				SCBean.clearall();
				SCBean.clearallUsers();


				String GuarantorId = rsUsr.getString("Patient ID");
				SCBean.setVmid("Gr-" + GuarantorId);

				String lname =JUtil.validateString(rsUsr.getString("Guarantor Last Name"));
				String fname = JUtil.validateString(rsUsr.getString("Guarantor First Name"));


				if (fname != null)
					SCBean.setUfname(fname);
				if (lname != null)
					SCBean.setUlname(lname);



				SCBean.setUpcity(JUtil.validateString(rsUsr.getString("Guarantor City")));
				SCBean.setUpstate(JUtil.validateString(rsUsr.getString("Guarantor State")));
				SCBean.setZipcode(JUtil.validateString(rsUsr.getString("Guarantor Zipcode")));
				SCBean.setCountryCode("US");

				// Date Of Birth
				dob = JUtil.validateString(rsUsr.getString("Guarantor DOB"));
				System.out.println(dob);
				if(dob==null || dob.equals("NULL")){
					dob="";
				}
				if(dob!=""){
					System.out.println(dob);
					SCBean.setDob(dob, "MM/dd/yyyy");
					SCBean.setPtDob(dob, "MM/dd/yyyy");
				}else{
					SCBean.setDob("", "MM/dd/yyyy");
					SCBean.setPtDob("", "MM/dd/yyyy");
				}




				objUsr.insertData(SCBean, connSrc, connDest, 4);
				if (!(SCBean.getUID()==0)){
					objPat.insertData(SCBean, connSrc, connDest, SCBean.getUID());	            	            
				}	
				objUI.displayStatus("Guarantors: Added: " + SCBean.getAddCount() + " , Duplicate: " + SCBean.getDupCount() + " , Invalid: " + SCBean.getInvCount());
			}

		} catch (Exception e) {
			e.printStackTrace();
			objUI.displayProgress("Guarantors : " + e.toString());
			JUtil.logExceptions(e);
		} finally {
			rsUsr.close();
			//			stmt.close();
		}

		objUI.displayStatus("Guarantors: Added: " + SCBean.getAddCount() + " , Duplicate: " + SCBean.getDupCount() + " , Invalid: " + SCBean.getInvCount());

	}
	 */

	/*private void addPatientInsuredGuarantors (Connection connSrc, Connection connDest,PMMigUI objUI) throws SQLException {

		String strSQL = "";
		String strSQL2 = "";
		String strSQL3="";
		Statement stmt = null;
		Statement stmt2 = null;
		Statement stmt3 = null;
		ResultSet rsUsr = null;
		ResultSet rsUsr2 = null;
		ResultSet rsUsr3 = null;
		int cntNo=30000;
		String chartNo = "";
		String maritalStatus = "";
		String refProvider = "";
		int refProviderId = 0;
		String phone3="",phone5="";
		String notes="";
		String employer = "";


		stmt = connSrc.createStatement();
		stmt2 = connSrc.createStatement();
		stmt3 = connSrc.createStatement();
		PatientsBean SCBean = new PatientsBean();
		String dob = "";
		String guatEmployer="";

		String strSQL13="";
		ResultSet rs13=null;
		Statement stmt13=null;
		stmt13=connSrc.createStatement();
		try {

			Users objUsr = new Users();
			Patients objPat = new Patients();
			strSQL = "";

			//strSQL = "SELECT * FROM PatientInsurance where [Primary Insurance Subscriber Relation]='child' or [Primary Insurance Subscriber Relation]='spouse'"; 
			//strSQL="SELECT * FROM PatientInsurance where [Secondary Insurance Subscriber Relation]='child' or [Secondary Insurance Subscriber Relation]='spouse'";
			strSQL = "SELECT * FROM PatientInsurance where [Tertiary Insurance Subscriber Relation]='child' or [Tertiary Insurance Subscriber Relation]='spouse'"; 


			rsUsr = stmt.executeQuery(strSQL);

			while (rsUsr.next()) {

				SCBean.clearall();
				SCBean.clearallUsers();

				//SCBean.setVmid("GrIns-" + rsUsr.getString("Patient ID")+"PI");   //PI Primary Insured
				//SCBean.setVmid("GrIns-" + rsUsr.getString("Patient ID")+"SI");   //SI Secondary Insured
				SCBean.setVmid("GrIns-" + rsUsr.getString("Patient ID")+"TI");   //TI Tertary Insured



				String lName="";
				String fName="";
				String mName="";
				String fMName="";



				//String guarName=JUtil.validateString(rsUsr.getString("Primary Insurance Subscriber Name"));
				//String guarName=JUtil.validateString(rsUsr.getString("Secondary Insurance Subscriber Name"));
				String guarName=JUtil.validateString(rsUsr.getString("Tertiary Insurance Subscriber Name"));


				if( guarName==null  || guarName.equals("") ){

				}else{
					String[] gNameSplited=guarName.split(",");

					if(gNameSplited.length==1){
						lName=gNameSplited[0];
					}else if(gNameSplited.length==2){
						lName=gNameSplited[0];
						fMName=gNameSplited[1];
					}



					fMName=fMName.trim();

					if(fMName.contains(" ")){
						String[] fMNameSplited=fMName.split(" ");
						fMName=fMNameSplited[0];
						if(fName.contains(" ")){
							fName=fName.replaceAll(" ", "");
						}
						mName=fMNameSplited[1];
					}

					System.out.println(lName+" "+fMName+" "+mName);

				}




				System.out.println(SCBean.getVmid());
				SCBean.setUlname(lName);
				SCBean.setUfname(fMName);
				SCBean.setUminitial(mName);			



				objUsr.insertData(SCBean, connSrc, connDest, 4);
				if (!(SCBean.getUID()==0)){
					objPat.insertData(SCBean, connSrc, connDest, SCBean.getUID());	            	            
				}
				objUI.displayStatus("Patient Insured Guarantors: Added: " + SCBean.getAddCount() + " , Duplicate: " + SCBean.getDupCount() + " , Invalid: " + SCBean.getInvCount());
			}

		} catch (Exception e) {
			e.printStackTrace();
			objUI.displayProgress("Guarantors : " + e.toString());
			JUtil.logExceptions(e);
		} finally {
			rsUsr.close();
			//			stmt.close();
		}

		objUI.displayStatus("Patient Insured Guarantors:: Added: " + SCBean.getAddCount() + " , Duplicate: " + SCBean.getDupCount() + " , Invalid: " + SCBean.getInvCount());

	}
	 */


	/*private void addContacts(Connection connSrc, Connection connDest, PMMigUI objUI) throws SQLException {

		String strSQL = "";
		Statement stmt = null;
		ResultSet rsCont = null;
		stmt = connSrc.createStatement();
		ContactsBean objContBean = new ContactsBean();

		try	{			

			Contacts objCont = new Contacts();

			strSQL = "Select * from PatientDemographics where [Emergency Contact Name]<>''";
			rsCont = stmt.executeQuery(strSQL);

			while (rsCont.next()) {

				objContBean.incrReadCount(); 

				objContBean.clearAll();


				//Contact Name
				String conName=JUtil.validateString(rsCont.getString("Emergency Contact Name"));
				objContBean.setStrName(conName);
				//Contact Address
				objContBean.setStrAddress(rsCont.getString("Emergency Contact Address"));

				//Contact City
				objContBean.setStrCity(rsCont.getString("Emergency Contact City"));

				//Contact State

				//Contact Zip
				objContBean.setStrZipcode(rsCont.getString("Emergency Contact Zip"));

				//Contact Phone
				//objContBean.setStrWorkPhone(rsCont.getString("Contact Phone 1"));
				objContBean.setStrHomePhone(rsCont.getString("Emergency Contact Phone"));

				//Relation
				objContBean.setStrRelation(rsCont.getString("Emergency Contact Relation"));


				objContBean.setStrPatVMID(rsCont.getString("Patient ID"));

				objContBean.setStrVMID("Cont-" + objContBean.getStrPatVMID());


				objCont.insertData(objContBean, connSrc, connDest);

			}

			//System.out.println("Total records Read:" + objContBean.getReadCount());
			objUI.displayStatus("Contacts Added: " + objContBean.getAddCount() + ", Duplicate: " + objContBean.getDupCount() + " , Invalid: " + objContBean.getInvCount());


		} catch(Exception e) {
			objUI.displayProgress("Contacts:" + e.toString());
			JUtil.logExceptions(e);
		}
		finally {
			rsCont.close();
			stmt.close();			
		}

		objUI.displayProgress("Contacts Added: " + objContBean.getAddCount() + " , Duplicate: " + objContBean.getDupCount() + " , Invalid: " + objContBean.getInvCount());
	}
	 */
	/*private void addInsuranceDetail (Connection connSrc, Connection connDest, PMMigUI objUI) throws SQLException {

		String strSQL = "";
		String strSQL2 = "";
		Statement stmt = null;
		Statement stmt2 = null;
		ResultSet rsInsDet = null;
		ResultSet rsInsDet2 = null;
		stmt = connSrc.createStatement();
		stmt2 = connSrc.createStatement();
		InsDetBean objInsDetBean = new InsDetBean();

		String strSQL3="";
		ResultSet rs3=null;
		Statement stmt3=null;
		stmt3=connSrc.createStatement();

		String strSQL4="";
		ResultSet rs4=null;
		Statement stmt4=null;
		stmt4=connSrc.createStatement();


		String strSQL5="";
		ResultSet rs5=null;
		Statement stmt5=null;
		stmt5=connSrc.createStatement();


		String patid="";
		String arr[]=null;
		try {

			InsuranceDetail  objInsDet = new InsuranceDetail();


			//strSQL = "SELECT * FROM MWCAS where [Chart Number] is Not Null order by [Chart Number], [Date Created] desc";
			strSQL="SELECT  *  FROM Person_ins_tie";  //3359
			//strSQL="SELECT  *  FROM Person_ins_tie where [person_id]='7'";



			//JONDE000
			String previousPat ="";


			int i = 0;
			int j = 0;
			Boolean skip1 =false;


			rsInsDet = stmt.executeQuery(strSQL);


			previousPat="";
			patid="";

			while (rsInsDet.next()) {
				j = 0;

				String vmid="";
				String personId=JUtil.validateString(rsInsDet.getString("person_id"));

				strSQL3="select * from Person where person_id='"+personId+"'";
				rs3=stmt3.executeQuery(strSQL3);
				if(rs3!=null){
					if(rs3.next()){

						String fname=JUtil.validateString(rs3.getString("first"));
						String lname=JUtil.validateString(rs3.getString("last"));
						String dob=JUtil.validateString(rs3.getString("birthday"));
						System.out.println(dob);
						String dobValue="";
						if(dob==null || dob.equals("")){
							dobValue="";
						}
						if(dob!=""){
							System.out.println(dob);
							dobValue=dob.substring(5,7)+"/"+dob.substring(8, 10)+"/"+dob.substring(0, 4);
							System.out.println(dobValue);
						}

						vmid=JLib.getVmidPatientByNameDOB(lname, fname, dobValue, connDest);


					}
				}
				//System.out.println( vmid);
				objInsDetBean.setStrPatvmid(vmid);


				System.out.println("chart no: "+objInsDetBean.getStrPatvmid());

				//Copay
				String person_ins_tie_id=JUtil.validateString(rsInsDet.getString("person_ins_tie_id"));
				strSQL5="select copay from Patient_person_ins_tie where person_ins_tie_id="+person_ins_tie_id+"";
				rs5=stmt5.executeQuery(strSQL5);
				if(rs5!=null){
					if(rs5.next()){
						objInsDetBean.setStrCopay(rs5.getString("copay"));
					}
				}

				//String person_ins_tie_id=JUtil.validateString(rsInsDet.getString("person_ins_tie_id"));
				//strSQL4="select * from where [person_ins_tie_id]='"+person_ins_tie_id+"'";
				objInsDetBean.setStrvmid(JUtil.validateString(rsInsDet.getString("insurance_id")));


				objInsDetBean.setStrSubscriberNo(JUtil.validateString(rsInsDet.getString("subscriber_number")));
				objInsDetBean.setStrGroupNo(JUtil.validateString(rsInsDet.getString("group_number")));
				//objInsDetBean.setStrGrRel(JUtil.validateString(rsInsDet.getString("Primary Insurance Subscriber Relation")));
				//objInsDetBean.setGuarName(rsInsDet.getString("Primary Insurance Subscriber Name"));


				//objInsDetBean.setStrGuarVmid(primaryGuarantorVmid);
				objInsDetBean.setStrStartDate(JUtil.validateString(rsInsDet.getString("person_start_date")));
				objInsDetBean.setStrEndDate(JUtil.validateString(rsInsDet.getString("person_end_date")));
				//objInsDetBean.setStrSeqNo("1");





				System.out.println(objInsDetBean.getStrvmid());
				if (objInsDetBean.getStrvmid() != ""){

					strSQL2 = "select [carrier] from Insurance where insurance_id='" + objInsDetBean.getStrvmid() + "'";
					rsInsDet2 = stmt2.executeQuery(strSQL2);
					while (rsInsDet2.next()) {
						objInsDetBean.setStrName(JUtil.validateString(rsInsDet2.getString("carrier")));
						System.out.println(objInsDetBean.getStrName());
					}	
					objInsDet.insertData(objInsDetBean, connSrc, connDest);

				}
				else {
					System.out.println("Insurance not found," + objInsDetBean.getStrvmid());
					//objInsDetBean.incrInvCount();
				}
				objUI.displayStatus("InsuranceDetail: Added: " + objInsDetBean.getAddCount() + " , Duplicate: " + objInsDetBean.getDupCount() + " , Invalid: " + objInsDetBean.getInvCount());

			}

		} catch(Exception e) {
			objUI.displayProgress("InsuranceDetail : " + e.toString());
			JUtil.logExceptions(e);
		}
		finally {
			rsInsDet.close();
			stmt.close();
		}

		objUI.displayStatus("InsuranceDetail: " + objInsDetBean.getAddCount() + "-" + objInsDetBean.getDupCount() + "-" + objInsDetBean.getInvCount());



	}
	 */


	/*public String AMPM(String time)
	{
		String[] times = time.split(" ");
		time = times[2];

		String[] tim = time.split(":");
		String hh = tim[0];
		int h = Integer.parseInt(hh);
		String AMPM = times[3];
		if(AMPM.contains("PM"))
		{
			if(h !=12)
			{
				h = h + 12;
				time = h + ":" + tim[1] + ":" + tim[2];
			}
			else if(h ==12)
			{

				time = h + ":" + tim[1] + ":" + tim[2];
			}

		}
		return time;
	}*/




	/*private void addAppointments(Connection connSrc, Connection connDest, PMMigUI objUI) throws SQLException {
		Statement st = null;

		JUtil.PROCESS_startTime = new Date();

		String    strInsertSql = "";		
		String    strSQL       = "";
		Statement stmt         = null;
		ResultSet rsApt        = null;

		stmt = connSrc.createStatement();
		AppointmentsBean objAptBean = new AppointmentsBean();

		try	{
			st = connSrc.createStatement();
			Appointments objApt = new Appointments();


			strSQL= "SELECT *  FROM Appointment";  

			//strSQL= "SELECT *  FROM Appointment where [appointment_id]=9930";


			rsApt = stmt.executeQuery(strSQL);

			while (rsApt.next()) {
				objAptBean.clearAll();
				objAptBean.incrReadCount(); 

				//Appointment ID
				objAptBean.setLngApt_RecordID_Source(rsApt.getLong("appointment_id"));

				//Facilities
				objAptBean.setStrFacilityID_Source("2");



				//Doctors and resource

				String doc=JUtil.validateString(rsApt.getString("resource_id"));

				if(doc.equals("5") || doc.contains("5")){
					objAptBean.setStrDoctorID_Source("5");
				}else if(doc.equals("4") || doc.contains("4")){
					objAptBean.setStrResourceID_Source("4");
				} 





				//Patient
				String PID = JUtil.validateString(rsApt.getString("patient_id"));
				System.out.println("PID: "+PID);
				objAptBean.setStrPatientID_Source(PID);


				//Date 
				String apptDate=JUtil.validateString(rsApt.getString("start"));
				if(apptDate==null || apptDate=="NULL" || apptDate.equals("") || apptDate.equals("NULL")){

				}else{
					String dateSplited[]=apptDate.split(" ");

					String dateValue=dateSplited[0];
					String startTimeValue=dateSplited[1];
					objAptBean.setStrAptDate_Source(dateValue.substring(5,7)+"/"+dateValue.substring(8,10)+"/"+dateValue.substring(0,4));
					objAptBean.setStrStartTime_Source(startTimeValue);
					System.out.println(objAptBean.getStrAptDate_Source());
				}



				//start time

	         	String startTime=rsApt.getString("Appointment Start Time");
	         	String startTimeSAplit[]=startTime.split(" ");
	         	String startTimeValue=startTimeSAplit[2];
	         	System.out.println(startTimeValue);
	         	objAptBean.setStrStartTime_Source(startTimeValue);






				//objAptBean.setStrAptDate_Source(rsApt.getString("Date"));
				//String time=rsApt.getString("Start Time");
				//String newTime=JLib.AMPM(time);
				//objAptBean.setStrStartTime_Source(newTime);
				//String[] TimeSep=objAptBean.getStrStartTime_Source().split(" ");
				//objAptBean.setStrStartTime_Source(TimeSep[0]);
				//objAptBean.setAMPM(TimeSep[1]);
				//objAptBean.setStrReason_Source(rsApt.getString("Reason Code"));


				//Notes
				//objAptBean.setStrGeneralNotes_Source(rsApt.getString("Notes"));



				//Duration or End Time

				String endTime=JUtil.validateString(rsApt.getString("end"));
				if(endTime==null || endTime=="NULL" || endTime.equals("") || endTime.equals("NULL")){

				}else{
					String endArray[]=endTime.split(" ");
					String endTimeValue=endArray[1];
					objAptBean.setStrEndTime_Source(endTimeValue);
				}


				//String endArray
				//objAptBean.setDuration(rsApt.getString("Duration"));



				//Visit Type

				String visitType=JUtil.validateString(rsApt.getString("Reason Code"));
				if(visitType.equals("")){
					objAptBean.setStrVisitType_Source("Migrated");
				}else{
				objAptBean.setStrVisitType_Source(visitType);
				}

				objAptBean.setStrVisitType_Source("Migrated");




				//Visit Status

				String status=JUtil.validateString(rsApt.getString("Appointment Status"));
				String visitStatus="";
				if(status.equals("Cancelled")){
					visitStatus="CANCS";
				}else if(status.equals("Check In")){
					visitStatus="ARR";
				}else if(status.equals("Check Out")){
					visitStatus="CHK";
				}else if(status.equals("Completed")){
					visitStatus="CHK";
				}else if(status.equals("No show")){
					visitStatus="N/S";
				}else if(status.equals("pending")){
					visitStatus="PEN";
				}else if(status.equals("Rescheduled")){
					visitStatus="R/S";
				} else{
					visitStatus="Migrated";
				}

				objAptBean.setStrStatus_Source("Migrated");






				objAptBean.setStrNotes_Source(JUtil.validateString(rsApt.getString("notes")));

				objApt.insertData(objAptBean, connSrc, connDest);
				objUI.displayStatus("Appointments Read: " + objAptBean.getCntRead() + " ; Added: " + objAptBean.getCntAdd() + " ; Duplicate: " + objAptBean.getCntDup() + " ; Pat not found: " + objAptBean.getCntNoPat() + " ; No Dr: " + objAptBean.getCntNoDr() + " ; No Fac: " + objAptBean.getCntNoFac() + " ; Invalid: " + objAptBean.getCntInv());



			}


			//Excel start...
			try{


				java.io.File file = new java.io.File("AppointmentsCount.xls");
				//file.createNewFile(); //Niteesh
				WorkbookSettings wbs = new WorkbookSettings();
				wbs.setInitialFileSize((int)file.length());		    

				// Workbook workbook = Workbook.getWorkbook(file,wbs);				
				WritableWorkbook workbook = Workbook.createWorkbook(file, wbs);

				workbook.createSheet("Apt", 0);

				WritableSheet excelsheet = workbook.getSheet(0);


				WritableFont cellFont1 = new WritableFont(WritableFont.TIMES, 12);
				cellFont1.setColour(Colour.BLUE);

				WritableCellFormat cellFormat1 = new WritableCellFormat(cellFont1);
				cellFormat1.setBackground(Colour.LIGHT_GREEN);
				cellFormat1.setBorder(Border.ALL, BorderLineStyle.THIN);


				WritableFont cellFont2 = new WritableFont(WritableFont.TIMES, 12);			    
				WritableCellFormat cellFormat2 = new WritableCellFormat(cellFont2);			    
				cellFormat2.setBorder(Border.ALL, BorderLineStyle.THIN);

				WritableFont cellFont3 = new WritableFont(WritableFont.TIMES, 14);			    
				WritableCellFormat cellFormat3 = new WritableCellFormat(cellFont3);		

				excelsheet.setColumnView(1, 50);
				excelsheet.setColumnView(2, 20);


				Calendar currentDate = Calendar.getInstance();
				SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy HH:mm");
				String dateNow = formatter.format(currentDate.getTime());

				excelsheet.addCell(new Label(1,3,"Appointments loading Statistics",cellFormat3));
				excelsheet.addCell(new Label(2,3,dateNow,cellFormat3));


				excelsheet.addCell(new Label(1,5,"Description",cellFormat1));
				excelsheet.addCell(new Label(2,5,"Total Records",cellFormat1));

				excelsheet.addCell(new Label(1,6," Appointments Read: ",cellFormat2));
				excelsheet.addCell(new Number(2,6, objAptBean.getCntRead(),cellFormat2));

				excelsheet.addCell(new Label(1,7," Appointments Migrated: ",cellFormat2));
				excelsheet.addCell(new Number(2,7, objAptBean.getCntAdd(),cellFormat2));

				excelsheet.addCell(new Label(1,8," Patient not found: ",cellFormat2));
				excelsheet.addCell(new Number(2,8, objAptBean.getCntNoPat(),cellFormat2));

				excelsheet.addCell(new Label(1,9," Doctor not found: ",cellFormat2));
				excelsheet.addCell(new Number(2,9, objAptBean.getCntNoDr(),cellFormat2));

				excelsheet.addCell(new Label(1,10," Duplicate Appointments: ",cellFormat2));
				excelsheet.addCell(new Number(2,10, objAptBean.getCntDup(),cellFormat2));

				workbook.write();
				workbook.close();

			}
			catch(Exception e)	{
				System.err.println(e.toString());
				// return(e.getMessage());
				//throw e;
			}
			finally	{

			}

			//Excel End ...


		}catch(Exception e)	{
			objUI.displayProgress("Appointments:" + e.toString());
			JUtil.logExceptions(e);
		}
		finally	{
			rsApt.close();
			stmt.close();	

		}

		JUtil.PROCESS_EndTime = new Date();

		System.out.println("Start Time: " + JUtil.PROCESS_startTime );
		System.out.println("End Time: " + JUtil.PROCESS_EndTime );


		objUI.displayProgress( "AppointmentsRead: " + objAptBean.getCntRead() + "; Added: " + objAptBean.getCntAdd() + "; Duplicate: " + objAptBean.getCntDup() + "; Pat not found: " + objAptBean.getCntNoPat() + "; No Dr: " + objAptBean.getCntNoDr() + "; No Fac: " + objAptBean.getCntNoFac() + " ; Invalid: " + objAptBean.getCntInv());
	}
	 */

	private void addMasterLab(Connection connSrc, Connection connDest,PMMigUI objUI) throws SQLException, IOException {
		// TODO Auto-generated method stub	

		String strSQL = "";
		String strSQL2 = "";
		Statement stmt = null;
		Statement stmt2Dest = null;
		Statement stmt3Dest = null;
		ResultSet rsUsr = null;
		ResultSet rsUsr2 = null;
		stmt = connSrc.createStatement();
		stmt2Dest = connDest.createStatement();
		stmt3Dest = connDest.createStatement();
		PreparedStatement pstmt = null;
		int i=0;
		MasterLabBean SCBean = new MasterLabBean();
		MasterLab objMstLabInsert = new MasterLab();
		try
		{
			//Patients: Added: 22484 , Duplicate: 0 , Invalid: 0
			strSQL="";
			String [] subserviceSeq = null;

			strSQL = "Select * from MasterTestLab where ReportType not in ('R/M','Findings')  order by ID";// where ID>717 

			rsUsr = stmt.executeQuery(strSQL);			
			while (rsUsr.next()) {	
				System.out.println(rsUsr.getString("ID"));
				SCBean.clearall();
				SCBean.setDepartment(JUtil.validateString(rsUsr.getString("Department"))); //Department
				SCBean.setDeptID(JLib.getDepartmentIDByName(SCBean.getDepartment(), connDest)+"");

				SCBean.setSubDepartment(JUtil.validateString(rsUsr.getString("SubDepartment")));
				SCBean.setSubDeptId(JLib.getSubDepartmentIDByName(SCBean.getSubDepartment(),SCBean.getDeptID(), connDest)+"");

				SCBean.setServiceName(JUtil.validateString(rsUsr.getString("serviceName")).replace(":", "").replace(" :-", "").trim());
				System.out.println(SCBean.getServiceName());
				if(!SCBean.getServiceName().equals("")){
					char s = SCBean.getServiceName().charAt(0);
					if(s=='-'){
						SCBean.setServiceName(SCBean.getServiceName().substring(1, SCBean.getServiceName().length()).trim());
					}
				}

				SCBean.setServiceId(JLib.getServiceIdByName(SCBean.getServiceName(), connDest)+"");
				subserviceSeq = JLib.findSubServiceName(SCBean.getServiceName(), connSrc);
				if(subserviceSeq!=null)
				{
					SCBean.setSubServiceName(subserviceSeq[0]);
					SCBean.setSubServiceSequence(subserviceSeq[1]);
				}

				SCBean.setSubServiceId(JLib.getSubServiceId(SCBean.getSubServiceName(),connDest)+"");

				SCBean.setReportType(JUtil.convertReportType(JUtil.validateString(rsUsr.getString("ReportType"))));
				SCBean.setUnits(JUtil.validateString(rsUsr.getString("Units")));
				SCBean.setUnitId(JLib.getUnitIdByName(SCBean.getUnits(), connDest)+"");

				SCBean.setSample(JUtil.validateString(rsUsr.getString("Sample"))); 
				SCBean.setSampleId(JLib.getSampleIdByName(SCBean.getSample(), connDest)+"");

				SCBean.setMethod(JUtil.validateString(rsUsr.getString("method")));
				SCBean.setMethodId(JLib.getMethodIdByName(SCBean.getMethod(), connDest)+"");

				SCBean.setServiceNameReferanceCode(JUtil.validateString(rsUsr.getString("ServiceNameReferanceCode")));
				SCBean.setReportTimeIn(JUtil.validateString(rsUsr.getString("ReportTimeIn")));
				SCBean.setFormula(JUtil.validateString(rsUsr.getString("formula")));
				SCBean.setSampleCollectItem(JUtil.validateString(rsUsr.getString("SampleCollectItem")));
				//	if(SCBean.getReportType().equals("N")){
				SCBean.setCategoryType(JUtil.convertCategoryType(JUtil.validateString(rsUsr.getString("CategoryType"))));
				SCBean.setGender(JUtil.convertSex(JUtil.validateString(rsUsr.getString("Gender"))));
				SCBean.setAgeFrom(JUtil.validateString(rsUsr.getString("AgeFrom")));
				SCBean.setAgeUpTo(JUtil.validateString(rsUsr.getString("AgeUpTo")));
				if(SCBean.getAgeFrom().contains("DAY"))
				{
					SCBean.setAgeType("3");//Day
					SCBean.setAgeFrom(SCBean.getAgeFrom().replace("DAY", "").trim());
					SCBean.setAgeUpTo(SCBean.getAgeUpTo().replace("DAY", "").trim());
					SCBean.setAgeUpTo(SCBean.getAgeUpTo().replace("YR", "").trim());

				}else if(SCBean.getAgeFrom().contains("MNT"))
				{
					SCBean.setAgeType("2");//Month
					SCBean.setAgeFrom(SCBean.getAgeFrom().replace("MNT", "").trim());
					SCBean.setAgeUpTo(SCBean.getAgeUpTo().replace("MNT", "").trim());
				}
				else if(SCBean.getAgeFrom().contains("YR"))
				{
					SCBean.setAgeType("1");//Year
					SCBean.setAgeFrom(SCBean.getAgeFrom().replace("YR", "").trim());
					SCBean.setAgeUpTo(SCBean.getAgeUpTo().replace("YR", "").trim());
				}
				else
				{
					SCBean.setAgeType("0");
					SCBean.setAgeFrom("0");
					SCBean.setAgeUpTo("0");
				}
				SCBean.setMinimumValue(JUtil.validateString(rsUsr.getString("MinimumValue")));
				SCBean.setMaximumValue(JUtil.validateString(rsUsr.getString("MaximumValue")));

				if(SCBean.getMinimumValue().contains("-") ||SCBean.getMaximumValue().contains("-")){
					SCBean.setSymbol("-");
					SCBean.setMinimumValue(SCBean.getMinimumValue().replace("-", ""));
					SCBean.setMaximumValue(SCBean.getMaximumValue().replace("-", ""));
				}
				else if(SCBean.getMinimumValue().contains("<") ||SCBean.getMaximumValue().contains("<")){
					SCBean.setSymbol("<=");

					SCBean.setMinimumValue(SCBean.getMinimumValue().replace("<", ""));
					SCBean.setMaximumValue(SCBean.getMaximumValue().replace("<", ""));
				}
				else if(SCBean.getMinimumValue().contains(">") ||SCBean.getMaximumValue().contains(">")){
					SCBean.setSymbol("=>");

					SCBean.setMinimumValue(SCBean.getMinimumValue().replace(">", ""));
					SCBean.setMaximumValue(SCBean.getMaximumValue().replace(">", ""));
				}else{
					SCBean.setSymbol("-"); // Default Symbol is Mandatory 
				}
				//}// Numeric


				/*SCBean.setMinimumValue(SCBean.getMinimumValue());
				SCBean.setMaximumValue(SCBean.getMaximumValue());*/
				SCBean.setServiceNameReferanceCodePrev(JUtil.validateString(rsUsr.getString("ServiceNameReferanceCodePrev")));


				objMstLabInsert.insertData(SCBean, connSrc, connDest);
				objUI.displayStatus("Master Lab: Added: " + SCBean.getAddCount() + " , Duplicate: " + SCBean.getDupCount() + " , Invalid: " + SCBean.getInvCount());

			}



		}catch(Exception e) {
			e.printStackTrace();
			objUI.displayProgress("MasterLab : " + e.toString());
			JUtil.logExceptions(e);
		}
		finally {
			rsUsr.close();
			stmt.close();
		}
		JUtil.appendToFile("Report.csv", "MasterLab: Added: " + SCBean.getAddCount() + " , Duplicate: " + SCBean.getDupCount() + " , Invalid: " + SCBean.getInvCount());
		objUI.displayStatus("MasterLab: Added: " + SCBean.getAddCount() + " , Duplicate: " + SCBean.getDupCount() + " , Invalid: " + SCBean.getInvCount());

	}
	/*private void addVisitType(Connection connSrc, Connection connDest,PMMigUI objUI) throws SQLException {

			//This method is used to create new visit Type

			String strSQL = "";
			Statement stmt = null;
			ResultSet rsVst = null;
			stmt = connSrc.createStatement();

			VisitTypeBean objVisitTypeBean = new VisitTypeBean();
			VisitType objVisttype = new VisitType();

			try
			{

				Users objUsr = new Users();
				Provider objPrv = new Provider();
				strSQL = "Select * from Visit_Type where Create_new = '1'";

				rsVst = stmt.executeQuery(strSQL);			

				while (rsVst.next()) 
				{	
					objVisitTypeBean.clearAll();

					String name = rsVst.getString("ClientVisitCode");
					name = JLib.Left(name, 10);System.out.println(name);
					String description =rsVst.getString("Description");
					description = "Mig- " + description;
					objVisitTypeBean.setStrVName(name);
					objVisitTypeBean.setStrVDescription(JUtil.validateString(description));

					objVisttype.insertData(objVisitTypeBean, connSrc, connDest);

					objUI.displayStatus("VisitType: Added: " + objVisitTypeBean.getAddCount() + " , Duplicate: " + objVisitTypeBean.getDupCount() + " , Invalid: " + objVisitTypeBean.getInvCount());

				}

			}catch(Exception e) {
				e.printStackTrace();
				objUI.displayProgress("VisitType: " + e.toString());
				JUtil.logExceptions(e);
			}
			finally {
				rsVst.close();
				stmt.close();
			}

			objUI.displayStatus("VisitType: Added: " + objVisitTypeBean.getAddCount() + " , Duplicate: " + objVisitTypeBean.getDupCount() + " , Invalid: " + objVisitTypeBean.getInvCount());

		}

	 */





	//Visit Status


	/*private void addVisitStatus(Connection connSrc, Connection connDest,PMMigUI objUI) throws SQLException {
			//This method is used to create new visit Status

			String strSQL = "";
			Statement stmt = null;
			ResultSet rsVst = null;
			stmt = connSrc.createStatement();

			VisitStatusBean objVisitStatusBean = new VisitStatusBean();
			VisitStatus objVisitStatus = new VisitStatus();

			try
			{

				Users objUsr = new Users();
				Provider objPrv = new Provider();
				strSQL = "Select * from Visit_Status where Create_new = '1'";

				rsVst = stmt.executeQuery(strSQL);			

				while (rsVst.next()) 
				{	
					System.out.println("hi");
					objVisitStatusBean.clearAll();

					String code = rsVst.getString("ClientVisitStatusCode");
					String Status =rsVst.getString("Description");
					Status = "Mig- " + Status;
					objVisitStatusBean.setStrVisitCode(JUtil.validateString(code));
					objVisitStatusBean.setStrVisitstatus(JUtil.validateString(Status));

					objVisitStatus.insertData(objVisitStatusBean, connSrc, connDest);

					objUI.displayStatus("Visit Status: Added: " + objVisitStatusBean.getAddCount() + " , Duplicate: " + objVisitStatusBean.getDupCount() + " , Invalid: " + objVisitStatusBean.getInvCount());
				}

			}catch(Exception e) {
				e.printStackTrace();
				objUI.displayProgress("Visit Status: " + e.toString());
				JUtil.logExceptions(e);
			}
			finally {
				rsVst.close();
				stmt.close();
			}

			objUI.displayStatus("Visit Status: Added: " + objVisitStatusBean.getAddCount() + " , Duplicate: " + objVisitStatusBean.getDupCount() + " , Invalid: " + objVisitStatusBean.getInvCount());


		}


	 */

















	//Add Guarantor Employer
	/*private void addGuarantorEmployers(Connection connSrc, Connection connDest,PMMigUI objUI) throws SQLException {
			String strSQL = "";
			String strSQL2 = "";

			String employer="";
			String name="";
			String[] flname=null;
			Statement stmt = null;
			Statement stmt2 = null;
			Statement stmt3 = null;
			Statement stmt4 = null;
			Statement stmt5 = null;
			Statement stmt6 = null;
			PreparedStatement stmt7 = null;
			PreparedStatement pstmt=null;

			ResultSet rsUsr = null;
			ResultSet rsUsr2 = null;
			ResultSet rsUsr3 = null;
			ResultSet rsUsr4 = null;
			ResultSet rsUsr5 = null;
			ResultSet rsUsr6 = null;
			ResultSet rs = null;

			//SOURCE
			stmt = connSrc.createStatement();
			stmt2 = connSrc.createStatement();
			stmt3 = connSrc.createStatement();

			//DESTINATION
			stmt4 = connDest.createStatement();
			stmt5 = connDest.createStatement();
			stmt6 = connDest.createStatement();
			//stmt7 = connDest.createStatement();
			int i=0,j=0,k=0;
			System.out.println("hereee");

			EmployerBean objEmpBean=new EmployerBean();
			try{


				String empyrName="";
				String empyrAddress="";
				String empyrAddress2="";
				String empyrCity="";
				String empyrState="";
				String empyrZip="";
				String empPhone="";
				strSQL = "SELECT * FROM Guarantor where [Employer Name]<>''";
				rsUsr = stmt.executeQuery(strSQL);
				String Lang="";
				Employer objEmp=new Employer();

				String empName="";
				while (rsUsr.next()) {
					empName=JUtil.validateString(rsUsr.getString("Employer Name"));
					objEmpBean.setStrEmpName(empName);
					objEmpBean.setStrempAddress1(JUtil.validateString(rsUsr.getString("Employer Address 1")));
					objEmpBean.setStrempAddress2(JUtil.validateString(rsUsr.getString("Employer Address 2")));
					objEmpBean.setStrempCity(JUtil.validateString(rsUsr.getString("Employer City")));
					objEmpBean.setStrempState(JUtil.validateString(rsUsr.getString("Employer State")));
					objEmpBean.setStrempZip(JUtil.validateString(rsUsr.getString("Employer Zip")));

					objEmp.insertData(objEmpBean, connSrc, connDest);
					objUI.displayStatus("Employers: Added: " + i + " ; Duplicates: " + j + " ; Invalid: " + k);
					i++;
				}{
					j++;
				}


			}catch(Exception e){
				e.printStackTrace();
				JUtil.logExceptions(e);

			}finally{
				rsUsr.close();


			}
			objUI.displayStatus("Employers: Added: " + i + " ; Duplicates: " + j + " ; Invalid: " + k);		



		}
	 */

	//Add Employer
	/*private void addEmployer(Connection connSrc, Connection connDest,PMMigUI objUI) throws SQLException {
			String strSQL = "";
			String strSQL2 = "";

			String employer="";
			String name="";
			String[] flname=null;
			Statement stmt = null;
			Statement stmt2 = null;
			Statement stmt3 = null;
			Statement stmt4 = null;
			Statement stmt5 = null;
			Statement stmt6 = null;
			PreparedStatement stmt7 = null;
			PreparedStatement pstmt=null;

			ResultSet rsUsr = null;
			ResultSet rsUsr2 = null;
			ResultSet rsUsr3 = null;
			ResultSet rsUsr4 = null;
			ResultSet rsUsr5 = null;
			ResultSet rsUsr6 = null;
			ResultSet rs = null;

			//SOURCE
			stmt = connSrc.createStatement();
			stmt2 = connSrc.createStatement();
			stmt3 = connSrc.createStatement();

			//DESTINATION
			stmt4 = connDest.createStatement();
			stmt5 = connDest.createStatement();
			stmt6 = connDest.createStatement();
			//stmt7 = connDest.createStatement();
			int i=0,j=0,k=0;
			System.out.println("hereee");

			EmployerBean objEmpBean=new EmployerBean();
			try{



				strSQL = "SELECT * FROM Employer where name<>''";
				rsUsr = stmt.executeQuery(strSQL);
				String Lang="";
				Employer objEmp=new Employer();

				String empName="";
				while (rsUsr.next()) {
					empName=JUtil.validateString(rsUsr.getString("name"));
					objEmpBean.setStrEmpName(empName);


						objEmpBean.setStrempAddress1(JUtil.validateString(rsUsr.getString("Address1")));
						objEmpBean.setStrempAddress2(JUtil.validateString(rsUsr.getString("Address2")));
						objEmpBean.setStrempCity(JUtil.validateString(rsUsr.getString("City")));
						objEmpBean.setStrempState(JUtil.validateString(rsUsr.getString("State")));
						objEmpBean.setStrempZip(JUtil.validateString(rsUsr.getString("Zip")));
						objEmpBean.setStrempPhone(JUtil.validateString(rsUsr.getString("Phone1")));


					objEmp.insertData(objEmpBean, connSrc, connDest);
					objUI.displayStatus("Employers: Added: " + i + " ; Duplicates: " + j + " ; Invalid: " + k);
					i++;
				}{
					j++;
				}


			}catch(Exception e){
				e.printStackTrace();
				JUtil.logExceptions(e);

			}finally{
				rsUsr.close();


			}
			objUI.displayStatus("Employers: Added: " + i + " ; Duplicates: " + j + " ; Invalid: " + k);		



		}
	 */






	//Add Relation
	/*private void addRelation(Connection connSrc, Connection connDest,PMMigUI objUI) throws SQLException 
		{
			String strSQL = "";
			String strSQL2 = "";
			String strSQL3 = "";
			String strSQL4 = "";

			Statement stmt = null;
			Statement stmt2 = null;
			Statement stmt3 = null;
			Statement stmt4 = null;

			ResultSet rsUsr = null;
			ResultSet rsUsr2 = null;
			ResultSet rsUsr3 = null;
			ResultSet rsUsr4 = null;

			stmt = connSrc.createStatement();
			stmt2 = connDest.createStatement();
			stmt3 = connDest.createStatement();

			String chartNo="";
			String guarantor="";
			int grid=0;
			int pid=0;
			int isGrPt=0;
			int userType=0;
			int i=0,j=0;
			//stmt2 = connSrc.createStatement();
			//stmt3 = connSrc.createStatement();
			stmt4 = connDest.createStatement();
			System.out.println("ADD RELATION");
			PatientsBean SCBean = new PatientsBean();
			//select distinct[chart number],[Guarantor]  from mwcas where [chart number]<>[Guarantor]
			String relation="";
			try{
				//strSQL="SELECT * FROM dbo_uvPatientDemographics WHERE  PatientSameAsGuarantor=0 and PatientRelationToGuarantor<>'Self'";

				strSQL="SELECT * FROM PatientDemographics WHERE [Relation to Guarantor]<>''";
				//strSQL="SELECT * FROM dbo_uvPatientDemographics where [PatientProfileId]='1454'";
				//strSQL="select *  from Patient where [Chart Number]='100200'";  1454
				rsUsr=stmt.executeQuery(strSQL);
				while(rsUsr.next())
				{

					chartNo="";
					guarantor="";
					grid=0;
					pid=0;
					isGrPt=0;
					userType=0;

					chartNo=rsUsr.getString("Patient ID");

					//guarantor=rsUsr.getString("GuarantorId");

					relation=JUtil.validateString(rsUsr.getString("Relation to Guarantor"));

					String relConvert=JUtil.convertRel(relation);


					grid = JLib.getUidByVmid("Gr-"+chartNo, connDest);
					if(grid==0){
						grid = JLib.getUidByVmidFromMdb(chartNo, connSrc);
						//System.out.println("GRID for Guarantor= "+guarantor+" FROM MDB= "+grid);
					}
					if(grid==0){
						grid=JLib.getUidByVmid("Pat-"+chartNo, connDest);
					}

					pid = JLib.getUidByVmid("Pat-"+chartNo, connDest);




					//System.out.println(grid+"=GRID , PID="+pid);


					userType=JLib.getUserTypeByUid(grid, connDest);
					System.out.println("UT="+userType);
					if(grid!=0 && grid!=pid){
						if(userType==4){
							System.out.println("here");

							strSQL3="UPDATE patients SET isgrpt=0,GrRel='"+relConvert+"' , Grid='"+grid+"' where pid='"+pid+"'";
							System.out.println(strSQL3);
							stmt3.executeUpdate(strSQL3);
							i++;

						}else{
							strSQL2="UPDATE patients SET GrRel='"+relConvert+"', isgrpt=0,Grid="+grid+" where pid='"+pid+"'";
							System.out.println(strSQL2);
							stmt4.executeUpdate(strSQL2);

							i++;
						}

					}
					else
					{
						j++;
						System.out.println( "Not Addes: " + j + " , chartNo: " + chartNo+ " , GUARANTOR: " +guarantor);
					}

					objUI.displayStatus("Relation: Added: " + i + " , Not Addes: " + j);

				}


			}
			catch(Exception e){
				e.printStackTrace();
			}

		}

	 */


	/*private void addFacility (Connection connSrc, Connection connDest, PMMigUI objUI) throws SQLException {

			String strSQL = "";
			Statement stmt = null;
			ResultSet rsFac = null;
			stmt = connSrc.createStatement();


			String strSQL1 = "";
			Statement stmt1 = null;
			ResultSet rsFac1 = null;
			stmt1 = connSrc.createStatement();



			FacilityBean objFacBean = new FacilityBean();

			try {

				Facility  objFac = new Facility();

				strSQL = "select * from Facility where [name]<>''";

				int i = 0;

				rsFac = stmt.executeQuery(strSQL);

				while (rsFac.next()) {

					objFacBean.clearAll();

					String facId=JUtil.validateString(rsFac.getString("facility_id"));
					objFacBean.setStrvmid("Fac-"+facId );
					objFacBean.setStrName(JUtil.validateString(rsFac.getString("name")));
					objFacBean.setStrTel(JUtil.validateString(rsFac.getString("phone")));


					objFacBean.setStrAddressLine1(JUtil.validateString(rsFac.getString("Address1")));
					objFacBean.setStrAddressLine2(JUtil.validateString(rsFac.getString("Address2")));
					objFacBean.setStrCity(JUtil.validateString(rsFac.getString("City")));
					objFacBean.setStrState(JUtil.validateString(rsFac.getString("State")));
					objFacBean.setStrZip(JUtil.validateString(rsFac.getString("Zip")));

					objFacBean.setStrFax(JUtil.validateString(rsFac.getString("Phone2")));
					objFacBean.setStrFederalTaxID(JUtil.validateString(rsFac.getString("FederalTaxId")));
					objFacBean.setStrNPI(rsFac.getString("NPI"));




					//objFacBean.setPOS(rsFac.getInt("LOC_POS_NUMBER"));
					//objFacBean.setStrCliaId(JUtil.validateString(rsFac.getString("Extra 2")));

					//Fedral Tax id
					//objFacBean.setStrFederalTaxID(JUtil.validateString(rsFac.getString("FederalTaxId")));
					//objFacBean.setStrNPI(rsFac.getString("National Provider Identifier"));
					//objFacBean.setStrTaxonomyCode(rsFac.getString("taxonomy_code"));

					objFac.insertData(objFacBean, connSrc, connDest);
					objUI.displayStatus("Facility: Added: " + objFacBean.getAddCount() + " , Duplicate: " + objFacBean.getDupCount() + " , Invalid: " + objFacBean.getInvCount());

				}



				strSQL1 = "select * from mwpra";
				rsFac1 = stmt1.executeQuery(strSQL1);

				while (rsFac1.next()) {
					objFacBean.clearAll();
					objFacBean.setStrvmid("Fac-" + rsFac1.getString("ID"));


					objFacBean.setStrName(JUtil.validateString(rsFac1.getString("Practice Name")));
					objFacBean.setStrCity(JUtil.validateString(rsFac1.getString("City")));
					objFacBean.setStrState(JUtil.validateString(rsFac1.getString("State")));
					objFacBean.setStrAddressLine1(JUtil.validateString(rsFac1.getString("Street 1")));
					objFacBean.setStrAddressLine2(JUtil.validateString(rsFac1.getString("Street 2")));
					objFacBean.setStrTel(JUtil.validateString(rsFac1.getString("Phone"))); 
					objFacBean.setStrZip(JUtil.validateString(rsFac1.getString("Zip Code")));
					objFacBean.setStrFax(JUtil.validateString(rsFac1.getString("Fax")));
					objFacBean.setStrFederalTaxID(JUtil.validateString(rsFac1.getString("Federal Tax ID")));



					//objFacBean.setPOS(rsFac1.getInt("LOC_POS_NUMBER"));
					//objFacBean.setStrCliaId(JUtil.validateString(rsFac1.getString("Extra 2")));

					//objFacBean.setStrFederalTaxID(JUtil.validateString(rsFac1.getString("LOC_TAX_ID_2")));
					//objFacBean.setStrNPI(rsFac1.getString("National Provider Identifier"));
					//objFacBean.setStrTaxonomyCode(rsFac1.getString("taxonomy_code"));

					objFac.insertData(objFacBean, connSrc, connDest);
				}



			} catch(Exception e) {
				e.printStackTrace();
				objUI.displayProgress("Facility : " + e.toString());
				JUtil.logExceptions(e);
			}
			finally {
				rsFac.close();
				stmt.close();
			}

			objUI.displayStatus("Facility: " + objFacBean.getAddCount() + "-" + objFacBean.getDupCount() + "-" + objFacBean.getInvCount());




		}

	 */
	/*private void addDoctors(Connection connSrc, Connection connDest,PMMigUI objUI) throws SQLException {
			// TODO Auto-generated method stub	

			String strSQL = "";

			String strSQL2 = "";

			Statement stmt = null;

			Statement stmt2 = null;

			ResultSet rsUsr = null;

			ResultSet rsUsr2 = null;

			stmt = connSrc.createStatement();

			stmt2 = connSrc.createStatement();

			ProviderBean SCBean = new ProviderBean();
			try
			{

				Users objUsr = new Users();
				Provider objPrv = new Provider();
				strSQL="";


				strSQL = "Select * from User where isprovider='1' and isinactive='0'";

				rsUsr = stmt.executeQuery(strSQL);			
				//int c=1;
				while (rsUsr.next()) {	
					SCBean.clearall();
					SCBean.clearallUsers();
					//SCBean.set
					//SCBean.setFacVmid(rsUsr.getString("code"));

					String c=rsUsr.getString("user_id");
					SCBean.setVmid("Dr-" + c);

					SCBean.setUfname(JUtil.validateString(rsUsr.getString("firstname")));

					SCBean.setUlname(JUtil.validateString(rsUsr.getString("lastname")));


					SCBean.setSuffix(JUtil.validateString(rsUsr.getString("suffix")));
					SCBean.setUname(SCBean.getUfname() + JLib.Left(SCBean.getUlname(),1));
					SCBean.setSpecialty(JUtil.validateString(rsUsr.getString("speciality"))); 
					SCBean.setDeano(JUtil.validateString(rsUsr.getString("dea")));
					SCBean.setStLicNo(JUtil.validateString(rsUsr.getString("state_license")));
					SCBean.setNPI(JUtil.validateString(rsUsr.getString("national_provider_id")));
					SCBean.setTaxid(JUtil.validateString(rsUsr.getString("federal")));


					SCBean.setUfname(JUtil.validateString(rsUsr.getString("First")));
					SCBean.setUminitial(JUtil.validateString(rsUsr.getString("Middle")));
					SCBean.setUlname(JUtil.validateString(rsUsr.getString("Last")));

					SCBean.setSuffix(JUtil.validateString(rsUsr.getString("Suffix")));




					SCBean.setUpaddress(JUtil.validateString(rsUsr.getString("Address1")));
					SCBean.setUpcity(JUtil.validateString(rsUsr.getString("City")));
					SCBean.setUpstate(JUtil.validateString(rsUsr.getString("State")));
					SCBean.setZipcode(JUtil.validateString(rsUsr.getString("Zip")));
					SCBean.setUpphone(JUtil.validateString(rsUsr.getString("Phone1")));
					SCBean.setFaxno(JUtil.validateString(rsUsr.getString("Phone2")));

					SCBean.setTaxidtype(JUtil.validateString(rsUsr.getString("FederalTaxIdType")));
					SCBean.setSpLicNo(JUtil.validateString(rsUsr.getString("Ledger")));


					//SCBean.setSsn(rsUsr.getString("SSN or Fed Tax ID").intern());
					//SCBean.setSsn(JUtil.validateString(SCBean.getTaxid()));
					//SCBean.setUpin(JUtil.validateString(rsUsr.getString("UPIN")));
					//
					//SCBean.setTaxonomycode(JUtil.validateString(rsUsr.getString("Taxonomy_Code")));


					objUsr.insertData(SCBean, connSrc, connDest, 1);
					if (!(SCBean.getUID()==0)){
						objPrv.insertData(SCBean, connSrc, connDest, SCBean.getUID());	            	            
					}
					objUI.displayStatus("Providers: Added: " + SCBean.getAddCount() + " , Duplicate: " + SCBean.getDupCount() + " , Invalid: " + SCBean.getInvCount());

				}



			}catch(Exception e) {
				e.printStackTrace();
				objUI.displayProgress("Providers : " + e.toString());
				JUtil.logExceptions(e);
			}
			finally {
				rsUsr.close();
				stmt.close();
			}

			objUI.displayStatus("Providers: Added: " + SCBean.getAddCount() + " , Duplicate: " + SCBean.getDupCount() + " , Invalid: " + SCBean.getInvCount());

		}

	 */




	/*private void addResource(Connection connSrc, Connection connDest,PMMigUI objUI) throws SQLException {
			String strSQL = "";
			Statement stmt = null;
			ResultSet rsUsr = null;
			stmt = connSrc.createStatement();

			ProviderBean SCBean = new ProviderBean();

			try
			{

				Users objUsr = new Users();
				Provider objPrv = new Provider();
				strSQL = "Select * from Resource";

				rsUsr = stmt.executeQuery(strSQL);			

				while (rsUsr.next()) {	
					SCBean.clearall();
					SCBean.clearallUsers();

					SCBean.setVmid("Res-" + rsUsr.getString("resource_id"));

					SCBean.setUfname(JUtil.validateString(rsUsr.getString("name")));
					SCBean.setUlname("Resource");

					SCBean.setUname(SCBean.getUfname());

					objUsr.insertData(SCBean, connSrc, connDest, 9);
					if (!(SCBean.getUID()==0))
					{
						objPrv.insertData(SCBean, connSrc, connDest, SCBean.getUID());	            	            
					}
					objUI.displayStatus("Resources: Added: " + SCBean.getAddCount() + " , Duplicate: " + SCBean.getDupCount() + " , Invalid: " + SCBean.getInvCount());

				}

			}catch(Exception e) {
				e.printStackTrace();
				objUI.displayProgress("Resources: " + e.toString());
				JUtil.logExceptions(e);
			}
			finally {
				rsUsr.close();
				stmt.close();
			}

			objUI.displayStatus("Resources: Added: " + SCBean.getAddCount() + " , Duplicate: " + SCBean.getDupCount() + " , Invalid: " + SCBean.getInvCount());

		}

	 */









	/*private void addRefProviders(Connection connSrc, Connection connDest,PMMigUI objUI) throws SQLException {
			// TODO Auto-generated method stub	
			String strSQL = "";
			Statement stmt = null;
			ResultSet rsUsr = null;
			stmt = connSrc.createStatement();


			String strSQL1 = "";
			Statement stmt1 = null;
			ResultSet rsUsr1 = null;
			stmt1 = connSrc.createStatement();


			ProviderBean SCBean = new ProviderBean();

			String temp2[];
			String temp[];
			String licno[];



			try
			{

				Users objUsr = new Users();
				Provider objPrv = new Provider();
				strSQL="";


				strSQL = "Select * from referralsAddress";  
				//strSQL = "Select * from dbo_DoctorFacility where DoctorFacilityId='215'";
				rsUsr = stmt.executeQuery(strSQL);			

				while (rsUsr.next()) {	
					SCBean.clearall();
					SCBean.clearallUsers();

					String c="";
					String upin[];
					String notes = "";

					c=JUtil.validateString(rsUsr.getString("referrals_id"));
					SCBean.setVmid("Ref-" + c);


					SCBean.setUfname(JUtil.validateString(rsUsr.getString("first")));
					//SCBean.setUminitial(JUtil.validateString(rsUsr.getString("Middle Name")));
					SCBean.setUlname(JUtil.validateString(rsUsr.getString("last")));
					SCBean.setUname(SCBean.getUfname() + JLib.Left(SCBean.getUlname(),1));
					SCBean.setSuffix(JUtil.validateString(rsUsr.getString("suffix"))); 
					//
					//SCBean.setUpaddress2(JUtil.validateString(rsUsr.getString("address2")));

					SCBean.setUpphone(JUtil.validateString(rsUsr.getString("phone2")));
					SCBean.setTaxonomycode(JUtil.validateString(rsUsr.getString("taxonomy")));
					SCBean.setMedicareNo(JUtil.validateString(rsUsr.getString("id_medicare")));
					//SCBean.setFaxno(JUtil.validateString(rsUsr.getString("Fax")));
					//SCBean.setTaxid(JUtil.validateString(rsUsr.getString("FederalTaxId")));
					//SCBean.setTaxidtype(JUtil.validateString(rsUsr.getString("FederalTaxIdType")));
					//SCBean.setSpLicNo(JUtil.validateString(rsUsr.getString("Ledger")));
					//SCBean.setNPI(JUtil.validateString(rsUsr.getString("NPI")));

					SCBean.setUpaddress(JUtil.validateString(rsUsr.getString("address1")));
					SCBean.setUpaddress2(JUtil.validateString(rsUsr.getString("address2")));




					SCBean.setNPI(JUtil.validateString(rsUsr.getString("id_nationalprovider")));
					//SCBean.setTaxid(JUtil.validateString(rsUsr.getString("SSN or Fed Tax ID")));
					//SCBean.setSsn(rsUsr.getString("SSN or Fed Tax ID").intern());
					//SCBean.setSsn(JUtil.validateString(SCBean.getTaxid()));


					//SCBean.setDeano(JUtil.validateString(rsUsr.getString("DEA Registration")));

					String citystatezip_id=JUtil.validateString(rsUsr.getString("citystatezip_id"));
					strSQL1="select * from Citystatezip where [citystatezip_id]='"+citystatezip_id+"'";
					rsUsr1=stmt1.executeQuery(strSQL1);
					if(rsUsr1!=null){
						if(rsUsr1.next()){

							SCBean.setUpcity(JUtil.validateString(rsUsr1.getString("city")));
							SCBean.setUpstate(JUtil.validateString(rsUsr1.getString("state")));
							SCBean.setZipcode(JUtil.validateString(rsUsr1.getString("zip")));
						}
					}

					SCBean.setUpcity(JUtil.validateString(rsUsr.getString("city")));
					SCBean.setUpstate(JUtil.validateString(rsUsr.getString("state")));
					SCBean.setZipcode(JUtil.validateString(rsUsr.getString("zip")));


					objUsr.insertData(SCBean, connSrc, connDest, 5);
					if (!(SCBean.getUID()==0)){
						objPrv.insertData(SCBean, connSrc, connDest, SCBean.getUID());	            	            
					}
					objUI.displayStatus("Referring Provider: Added: " + SCBean.getAddCount() + " , Duplicate: " + SCBean.getDupCount() + " , Invalid: " + SCBean.getInvCount());

				}



			}catch(Exception e) {
				//e.printStackTrace();
				objUI.displayProgress("Referring Provider : " + e.toString());
				JUtil.logExceptions(e);
			}
			finally {
				rsUsr.close();
				stmt.close();
			}

			objUI.displayStatus("Referring Provider: Added: " + SCBean.getAddCount() + " , Duplicate: " + SCBean.getDupCount() + " , Invalid: " + SCBean.getInvCount());

		}
	 */

	/*private void addInsurance(Connection connSrc, Connection connDest, PMMigUI objUI) throws Exception {
			String strSQL = "";
			Statement stmt = null;
			ResultSet rsIns = null;
			stmt = connSrc.createStatement();
			InsuranceBean objInsBean = new InsuranceBean();

			try
			{

				Insurance  objIns = new Insurance();

				strSQL ="Select * from Insurance where insurance_id<>'1'";

				rsIns = stmt.executeQuery(strSQL);

				while (rsIns.next())
				{

					objInsBean.clearAll();
					String c=JUtil.validateString(rsIns.getString("insurance_id"));
					System.out.println(c);
					objInsBean.setStrInsVMID("Ins-" +c );
					objInsBean.setStrName(JUtil.validateString(rsIns.getString("carrier")));
					//objInsBean.setStrAddress1(JUtil.validateString(rsIns.getString("Insurance Address")));
					//objInsBean.setStrAddress2(JUtil.validateString(rsIns.getString("Address2")));
					//objInsBean.setStrCity(JUtil.validateString(rsIns.getString("Insurance City")));
					//objInsBean.setStrState(JUtil.validateString(rsIns.getString("Insurance State")));
					//objInsBean.setStrZip(JUtil.validateString(rsIns.getString("Insurance Zip Code")));
					objInsBean.setStrPhone(JUtil.validateString(rsIns.getString("phone")));
					objInsBean.setStrPayorID(JUtil.validateString(rsIns.getString("payer_id")));
					objInsBean.setStrMediGapID(JUtil.validateString(rsIns.getString("medigap")));



					objIns.insertData(objInsBean, connSrc, connDest);
					objUI.displayStatus("Insurance: Added: " + objInsBean.getAddCount() + " , Duplicate: " + objInsBean.getDupCount() + " , Invalid: " + objInsBean.getInvCount());

				}

			}
			catch(Exception e)
			{
				e.printStackTrace();
				objUI.displayProgress("Insurance : " + e.toString());
				JUtil.logExceptions(e);

			}
			finally
			{
				rsIns.close();
				stmt.close();
			}
			objUI.displayStatus("Insurance: " + objInsBean.getAddCount() + "-" + objInsBean.getDupCount() + "-" + objInsBean.getInvCount());
		}
	 */

	/*private void addPatients (Connection connSrc, Connection connDest,PMMigUI objUI) throws SQLException {

			String strSQL = "";
			String strSQL2 = "";
			String strSQL3 = "";
			String strSQL4 = "";
			String strSql5="";
			String asgndPrSQL="";
			String pcpSQL="";

			String assignedProvider="";
			String pcp="";
			String employer="";
			java.sql.PreparedStatement stmtPr =null;

			int assignedPrId = 0;
			int pcpId = 0;
			int defFeeschid=0;
			Statement stmt = null;
			Statement destStmt = null;
			Statement stmt2 = null;
			Statement stmt3 = null;
			Statement stmt4 = null;
			Statement stmt5 = null;
			Statement stmt6 = null;

			ResultSet rsUsr = null;
			ResultSet destUsr = null;
			ResultSet rsUsr2 = null;
			ResultSet rsUsr3 = null;
			ResultSet rsUsr4 = null;
			ResultSet rsUsr5 = null;
			ResultSet rsUsr6 = null;

			//SOURCE
			stmt = connSrc.createStatement();
			destStmt = connDest.createStatement();
			stmt2 = connSrc.createStatement();
			stmt3 = connSrc.createStatement();
			stmt4 = connSrc.createStatement();
			stmt5 = connSrc.createStatement();

			//DESTINATION


			stmt6 = connDest.createStatement();
			PatientsBean SCBean = new PatientsBean();

			String facility="";
			String patEmployer="";


			String insNotes="";
			String insTemp="";




			String strSQL10 = "";
			Statement stmt10 = null;
			ResultSet rs10 = null;
			stmt10 = connSrc.createStatement();

			String strSQL11="";
			Statement stmt11 = null;
			ResultSet rs11 = null;
			stmt11 = connSrc.createStatement();


			String strSQL12 = "";
			Statement stmt12 = null;
			ResultSet rs12 = null;
			stmt12 = connSrc.createStatement();


			String strSQL13 = "";
			Statement stmt13 = null;
			ResultSet rs13 = null;
			stmt13 = connSrc.createStatement();




			String notes="";
			String temp="";


			stmt.executeUpdate("DELETE from duppat");
			try {

				Users objUsr = new Users();
				Patients objPat = new Patients();
				strSQL = "";
				String strSQL1 = "";
				int contNo=10000; //control number if new ecw account numbers has to be set

				strSQL = "SELECT  * from PatPersonJoinTable";  // 7992
				//strSQL = "SELECT  * from PatPersonJoinTable where [patient_id]='2'";




				rsUsr = stmt.executeQuery(strSQL);
				String sexValue="";
				String sex="";
				String dob="";
				String[]  dateBirth=null;
				String DateOfBirth="";
				while (rsUsr.next()) {

					SCBean.clearall();
					SCBean.clearallUsers();
					String patid= rsUsr.getString("patient_id").intern(); //Patient ID
					System.out.println("Patient: "+patid);



					//Inactive
					String Inactive=JUtil.validateString(rsUsr.getString("PatientInactive"));
					if(Inactive=="1" || Inactive.equals("1")){
						SCBean.setStatus("1");
					} else if(Inactive=="0" || Inactive.equals("0")){
						SCBean.setStatus("0");
					}else{
						SCBean.setStatus("0");
					}



					//Control Number
					SCBean.setControlNo(""+contNo);
					contNo++;


					//Vmid
					SCBean.setVmid("Pat-" + patid); //VMID




					//MRN
					SCBean.setMrn(JUtil.validateString(rsUsr.getString("chart_num"))); //old patient id goes to MRN in front-end  cos we didnt find mrn


					//Deceased

					String deathDate=JUtil.validateString(rsUsr.getString("PatientDeathDate"));
					if(deathDate==null || deathDate=="" || deathDate.equals("") || deathDate.equals("NULL")){

					}else{
						SCBean.setDeceased("1");
					}



					//Patient fnamme,lname,mname

					String lname =JUtil.validateString(rsUsr.getString("last"));
					String fname = JUtil.validateString(rsUsr.getString("first"));
					String mname = JUtil.validateString(rsUsr.getString("middle"));

					if (fname != null)
						SCBean.setUfname(fname);
					if (lname != null)
						SCBean.setUlname(lname);
					if (mname != null)
						SCBean.setUminitial(mname);

					//suffix
					//SCBean.setSuffix(JUtil.validateString(rsUsr.getString("PatientSuffix")));


					//Address
					String address_id=JUtil.validateString(rsUsr.getString("address_id"));
					strSQL2="select * from Address where address_id='"+address_id+"'";
					rsUsr2=stmt2.executeQuery(strSQL2);
					if(rsUsr2!=null){
						if(rsUsr2.next()){
							SCBean.setUpaddress(JUtil.validateString(rsUsr2.getString("address1")));
							SCBean.setUpaddress2(JUtil.validateString(rsUsr2.getString("address2")));
							String cityStateZip=JUtil.validateString(rsUsr2.getString("citystatezip_id"));
							strSQL3="select * from Citystatezip where citystatezip_id='"+cityStateZip+"'";
							rsUsr3=stmt3.executeQuery(strSQL3);
							if(rsUsr3!=null){
								if(rsUsr3.next()){
									String city=JUtil.validateString(rsUsr3.getString("city"));
									if(city.length()>24){
										city=city.substring(0,24);
										SCBean.setUpcity(city);
									}else{
										SCBean.setUpcity(city);
									}
									SCBean.setUpstate(JUtil.validateString(rsUsr3.getString("state")));
									SCBean.setZipcode(JUtil.validateString(rsUsr3.getString("zip")));
								}
							}

						}
					}




					//Country

					String country=JUtil.validateString(rsUsr.getString("PatientCountry"));
					if(country=="" || country==null || country.equals("") || country.equals("null")){
						SCBean.setCountryCode("US");
					}else

					SCBean.setCountryCode("US");


					// Gender
					String gender=JUtil.validateString(rsUsr.getString("pop_sex"));
					SCBean.setSex(JUtil.convertSex(gender));





					// Date Of Birth
					dob = JUtil.validateString(rsUsr.getString("birthday"));

					System.out.println(dob);
					if(dob==null || dob.equals("NULL")){
						dob="";
					}
					if(dob!=""){
						System.out.println(dob);
						String dobValue=dob.substring(5,7)+"/"+dob.substring(8, 10)+"/"+dob.substring(0, 4);
						System.out.println(dobValue);
						SCBean.setDob(dobValue, "MM/dd/yyyy");
						SCBean.setPtDob(dobValue, "MM/dd/yyyy");
					}else{
						SCBean.setDob("", "MM/dd/yyyy");
						SCBean.setPtDob("", "MM/dd/yyyy");
					}




					//UpPhone
					String phone1=JUtil.validateString(rsUsr.getString("phone1")).intern();
					SCBean.setUpphone(phone1);


					//UMObile
					SCBean.setUmobileno(JUtil.validateString(rsUsr.getString("phone2")));

					//Work Phone
					SCBean.setEmployerphone(CommonFunction.convertPhone(JUtil.validateString(rsUsr.getString("phone3")).intern()));


					//SSN
					SCBean.setSsn(CommonFunction.convertSSN(JUtil.validateString(rsUsr.getString("ssn")).intern()));


					//Marital Status

					String mStatus=JUtil.validateString(rsUsr.getString("pop_marital_status"));
					SCBean.setMaritalstatus(JUtil.convertMaritalStatus(mStatus));




					//Email
					SCBean.setUemail(JUtil.validateString(rsUsr.getString("email")));


					// Rendering Provider

					String rendProvider=JUtil.validateString(rsUsr.getString("provider_id"));
					int uid=JLib.getUidByVmid("Dr-"+rendProvider, connDest);
					SCBean.setRendprid(""+uid);


					//PCP   No Data



					//Refering Provider
					//String refProvider=JUtil.validateString(rsUsr.getString("Referring Physician"));

					String refProvider=JUtil.validateString(rsUsr.getString("Referring Physician"));
					if(refProvider==null || refProvider=="" || refProvider.equals("") || refProvider.equals(null)){
					}else{
					String[] refProviderSplited=refProvider.split(",");

					String refLName=refProviderSplited[0];
					String refFName=refProviderSplited[1];

					if(refLName.contains(" ")){
						String refLNameSplited[]=refLName.split(" ");
						refLName=refLNameSplited[0];
					}

					if(refFName.contains(" ")){
						String refFNameSplited[]=refFName.split(" ");
						refFName=refFNameSplited[0];
						if(refFName.equals("")){
							refFName=refFNameSplited[1];
						}else if(refFName.equals("")){
							refFName=refFNameSplited[2];
						}
					}

					int uid=JLib.getRefProviderUidByFname(refFName,connDest);

					if(uid==0){
						 uid=JLib.getProviderUidByFname(refFName,connDest);
					}

					SCBean.setRefPrID(""+uid);
					}


					//Race

					//String race=JUtil.validateString(rsUsr.getString("Race"));
					//SCBean.setRace(JUtil.convertRace(race));

					//Language

					//String language=JUtil.validateString(rsUsr.getString("Preffered Language"));
					//SCBean.setLanguage(JUtil.convertLanguage(language));
					SCBean.setLanguage("English");	


					//Ethnicity
					String ethnicity=JUtil.validateString(rsUsr.getString("ethnicity_id"));
					SCBean.setEthnicity(JUtil.convertEthnicityStatus(ethnicity));



					SCBean.setRelinfo("Y");
					SCBean.setRelinfodate("1900-01-01");
					SCBean.setGrrel("1");


					// Facilities

					SCBean.setDefaultFacility(119);		

					// Notes
					//String patNote=JUtil.validateString(rsUsr.getString("Notes"));
					//SCBean.setNotes("Ref-Provider: "+refProvider+"\n"+patNote);


					// Employers

					//SCBean.setEmployername(rsUsr.getString("Employer Details"));



					objUsr.insertData(SCBean, connSrc, connDest, 3);

					if (!(SCBean.getUID()==0)){

						objPat.insertData(SCBean, connSrc, connDest, SCBean.getUID());	            	            
					}
					objUI.displayStatus("Patients: Added: " + SCBean.getAddCount() + " , Duplicate: " + SCBean.getDupCount() + " , Invalid: " + SCBean.getInvCount());
				}

			} catch (Exception e) {
				e.printStackTrace();
				objUI.displayProgress("Patients : " + e.toString());
				JUtil.logExceptions(e);
			} finally {
				rsUsr.close();
				//			stmt.close();
			}

			objUI.displayStatus("Patients: Added: " + SCBean.getAddCount() + " , Duplicate: " + SCBean.getDupCount() + " , Invalid: " + SCBean.getInvCount());

			long total = SCBean.getDupCount() + SCBean.getAddCount() + SCBean.getInvCount();
			strSQL2 = "insert into pm_mig_status (tot_read,tot_add,tot_inv,tot_dup) values ('" + String.valueOf(total) + "', '" + SCBean.getAddCount() + "', '" + SCBean.getInvCount() + "', '" + SCBean.getDupCount() + "')";
			stmtPr = connDest.prepareStatement(strSQL2);
			stmtPr.executeUpdate();
			SCBean.incrInvCount();
			stmtPr.close();

		}
	 */


	/*private void addGuarantors (Connection connSrc, Connection connDest,PMMigUI objUI) throws SQLException {

			String strSQL = "";
			String strSQL2 = "";
			String strSQL3 = "";
			Statement stmt = null;
			Statement stmt2 = null;
			Statement stmt3 = null;
			ResultSet rsUsr = null;
			ResultSet rsUsr2 = null;
			ResultSet rsUsr3 = null;

			stmt = connSrc.createStatement();
			stmt2 = connSrc.createStatement();
			stmt3 = connSrc.createStatement();
			PatientsBean SCBean = new PatientsBean();

			try {

				String dob="";
				Users objUsr = new Users();
				Patients objPat = new Patients();
				strSQL = "";
				String arr[]=null;
				strSQL = "SELECT  * from PatientDemographics";
				rsUsr = stmt.executeQuery(strSQL);

				while (rsUsr.next()) {

					SCBean.clearall();
					SCBean.clearallUsers();


					String GuarantorId = rsUsr.getString("Patient ID");
					SCBean.setVmid("Gr-" + GuarantorId);

					String lname =JUtil.validateString(rsUsr.getString("Guarantor Last Name"));
					String fname = JUtil.validateString(rsUsr.getString("Guarantor First Name"));


					if (fname != null)
						SCBean.setUfname(fname);
					if (lname != null)
						SCBean.setUlname(lname);



					SCBean.setUpcity(JUtil.validateString(rsUsr.getString("Guarantor City")));
					SCBean.setUpstate(JUtil.validateString(rsUsr.getString("Guarantor State")));
					SCBean.setZipcode(JUtil.validateString(rsUsr.getString("Guarantor Zipcode")));
					SCBean.setCountryCode("US");

					// Date Of Birth
					dob = JUtil.validateString(rsUsr.getString("Guarantor DOB"));
					System.out.println(dob);
					if(dob==null || dob.equals("NULL")){
						dob="";
					}
					if(dob!=""){
						System.out.println(dob);
						SCBean.setDob(dob, "MM/dd/yyyy");
						SCBean.setPtDob(dob, "MM/dd/yyyy");
					}else{
						SCBean.setDob("", "MM/dd/yyyy");
						SCBean.setPtDob("", "MM/dd/yyyy");
					}




					objUsr.insertData(SCBean, connSrc, connDest, 4);
					if (!(SCBean.getUID()==0)){
						objPat.insertData(SCBean, connSrc, connDest, SCBean.getUID());	            	            
					}	
					objUI.displayStatus("Guarantors: Added: " + SCBean.getAddCount() + " , Duplicate: " + SCBean.getDupCount() + " , Invalid: " + SCBean.getInvCount());
				}

			} catch (Exception e) {
				e.printStackTrace();
				objUI.displayProgress("Guarantors : " + e.toString());
				JUtil.logExceptions(e);
			} finally {
				rsUsr.close();
				//			stmt.close();
			}

			objUI.displayStatus("Guarantors: Added: " + SCBean.getAddCount() + " , Duplicate: " + SCBean.getDupCount() + " , Invalid: " + SCBean.getInvCount());

		}
	 */

	/*private void addPatientInsuredGuarantors (Connection connSrc, Connection connDest,PMMigUI objUI) throws SQLException {

			String strSQL = "";
			String strSQL2 = "";
			String strSQL3="";
			Statement stmt = null;
			Statement stmt2 = null;
			Statement stmt3 = null;
			ResultSet rsUsr = null;
			ResultSet rsUsr2 = null;
			ResultSet rsUsr3 = null;
			int cntNo=30000;
			String chartNo = "";
			String maritalStatus = "";
			String refProvider = "";
			int refProviderId = 0;
			String phone3="",phone5="";
			String notes="";
			String employer = "";


			stmt = connSrc.createStatement();
			stmt2 = connSrc.createStatement();
			stmt3 = connSrc.createStatement();
			PatientsBean SCBean = new PatientsBean();
			String dob = "";
			String guatEmployer="";

			String strSQL13="";
			ResultSet rs13=null;
			Statement stmt13=null;
			stmt13=connSrc.createStatement();
			try {

				Users objUsr = new Users();
				Patients objPat = new Patients();
				strSQL = "";

				//strSQL = "SELECT * FROM PatientInsurance where [Primary Insurance Subscriber Relation]='child' or [Primary Insurance Subscriber Relation]='spouse'"; 
				//strSQL="SELECT * FROM PatientInsurance where [Secondary Insurance Subscriber Relation]='child' or [Secondary Insurance Subscriber Relation]='spouse'";
				strSQL = "SELECT * FROM PatientInsurance where [Tertiary Insurance Subscriber Relation]='child' or [Tertiary Insurance Subscriber Relation]='spouse'"; 


				rsUsr = stmt.executeQuery(strSQL);

				while (rsUsr.next()) {

					SCBean.clearall();
					SCBean.clearallUsers();

					//SCBean.setVmid("GrIns-" + rsUsr.getString("Patient ID")+"PI");   //PI Primary Insured
					//SCBean.setVmid("GrIns-" + rsUsr.getString("Patient ID")+"SI");   //SI Secondary Insured
					SCBean.setVmid("GrIns-" + rsUsr.getString("Patient ID")+"TI");   //TI Tertary Insured



					String lName="";
					String fName="";
					String mName="";
					String fMName="";



					//String guarName=JUtil.validateString(rsUsr.getString("Primary Insurance Subscriber Name"));
					//String guarName=JUtil.validateString(rsUsr.getString("Secondary Insurance Subscriber Name"));
					String guarName=JUtil.validateString(rsUsr.getString("Tertiary Insurance Subscriber Name"));


					if( guarName==null  || guarName.equals("") ){

					}else{
						String[] gNameSplited=guarName.split(",");

						if(gNameSplited.length==1){
							lName=gNameSplited[0];
						}else if(gNameSplited.length==2){
							lName=gNameSplited[0];
							fMName=gNameSplited[1];
						}



						fMName=fMName.trim();

						if(fMName.contains(" ")){
							String[] fMNameSplited=fMName.split(" ");
							fMName=fMNameSplited[0];
							if(fName.contains(" ")){
								fName=fName.replaceAll(" ", "");
							}
							mName=fMNameSplited[1];
						}

						System.out.println(lName+" "+fMName+" "+mName);

					}




					System.out.println(SCBean.getVmid());
					SCBean.setUlname(lName);
					SCBean.setUfname(fMName);
					SCBean.setUminitial(mName);			



					objUsr.insertData(SCBean, connSrc, connDest, 4);
					if (!(SCBean.getUID()==0)){
						objPat.insertData(SCBean, connSrc, connDest, SCBean.getUID());	            	            
					}
					objUI.displayStatus("Patient Insured Guarantors: Added: " + SCBean.getAddCount() + " , Duplicate: " + SCBean.getDupCount() + " , Invalid: " + SCBean.getInvCount());
				}

			} catch (Exception e) {
				e.printStackTrace();
				objUI.displayProgress("Guarantors : " + e.toString());
				JUtil.logExceptions(e);
			} finally {
				rsUsr.close();
				//			stmt.close();
			}

			objUI.displayStatus("Patient Insured Guarantors:: Added: " + SCBean.getAddCount() + " , Duplicate: " + SCBean.getDupCount() + " , Invalid: " + SCBean.getInvCount());

		}
	 */


	/*private void addContacts(Connection connSrc, Connection connDest, PMMigUI objUI) throws SQLException {

			String strSQL = "";
			Statement stmt = null;
			ResultSet rsCont = null;
			stmt = connSrc.createStatement();
			ContactsBean objContBean = new ContactsBean();

			try	{			

				Contacts objCont = new Contacts();

				strSQL = "Select * from PatientDemographics where [Emergency Contact Name]<>''";
				rsCont = stmt.executeQuery(strSQL);

				while (rsCont.next()) {

					objContBean.incrReadCount(); 

					objContBean.clearAll();


					//Contact Name
					String conName=JUtil.validateString(rsCont.getString("Emergency Contact Name"));
					objContBean.setStrName(conName);
					//Contact Address
					objContBean.setStrAddress(rsCont.getString("Emergency Contact Address"));

					//Contact City
					objContBean.setStrCity(rsCont.getString("Emergency Contact City"));

					//Contact State

					//Contact Zip
					objContBean.setStrZipcode(rsCont.getString("Emergency Contact Zip"));

					//Contact Phone
					//objContBean.setStrWorkPhone(rsCont.getString("Contact Phone 1"));
					objContBean.setStrHomePhone(rsCont.getString("Emergency Contact Phone"));

					//Relation
					objContBean.setStrRelation(rsCont.getString("Emergency Contact Relation"));


					objContBean.setStrPatVMID(rsCont.getString("Patient ID"));

					objContBean.setStrVMID("Cont-" + objContBean.getStrPatVMID());


					objCont.insertData(objContBean, connSrc, connDest);

				}

				//System.out.println("Total records Read:" + objContBean.getReadCount());
				objUI.displayStatus("Contacts Added: " + objContBean.getAddCount() + ", Duplicate: " + objContBean.getDupCount() + " , Invalid: " + objContBean.getInvCount());


			} catch(Exception e) {
				objUI.displayProgress("Contacts:" + e.toString());
				JUtil.logExceptions(e);
			}
			finally {
				rsCont.close();
				stmt.close();			
			}

			objUI.displayProgress("Contacts Added: " + objContBean.getAddCount() + " , Duplicate: " + objContBean.getDupCount() + " , Invalid: " + objContBean.getInvCount());
		}
	 */
	/*private void addInsuranceDetail (Connection connSrc, Connection connDest, PMMigUI objUI) throws SQLException {

			String strSQL = "";
			String strSQL2 = "";
			Statement stmt = null;
			Statement stmt2 = null;
			ResultSet rsInsDet = null;
			ResultSet rsInsDet2 = null;
			stmt = connSrc.createStatement();
			stmt2 = connSrc.createStatement();
			InsDetBean objInsDetBean = new InsDetBean();

			String strSQL3="";
			ResultSet rs3=null;
			Statement stmt3=null;
			stmt3=connSrc.createStatement();

			String strSQL4="";
			ResultSet rs4=null;
			Statement stmt4=null;
			stmt4=connSrc.createStatement();


			String strSQL5="";
			ResultSet rs5=null;
			Statement stmt5=null;
			stmt5=connSrc.createStatement();


			String patid="";
			String arr[]=null;
			try {

				InsuranceDetail  objInsDet = new InsuranceDetail();


				//strSQL = "SELECT * FROM MWCAS where [Chart Number] is Not Null order by [Chart Number], [Date Created] desc";
				strSQL="SELECT  *  FROM Person_ins_tie";  //3359
				//strSQL="SELECT  *  FROM Person_ins_tie where [person_id]='7'";



				//JONDE000
				String previousPat ="";


				int i = 0;
				int j = 0;
				Boolean skip1 =false;


				rsInsDet = stmt.executeQuery(strSQL);


				previousPat="";
				patid="";

				while (rsInsDet.next()) {
					j = 0;

					String vmid="";
					String personId=JUtil.validateString(rsInsDet.getString("person_id"));

					strSQL3="select * from Person where person_id='"+personId+"'";
					rs3=stmt3.executeQuery(strSQL3);
					if(rs3!=null){
						if(rs3.next()){

							String fname=JUtil.validateString(rs3.getString("first"));
							String lname=JUtil.validateString(rs3.getString("last"));
							String dob=JUtil.validateString(rs3.getString("birthday"));
							System.out.println(dob);
							String dobValue="";
							if(dob==null || dob.equals("")){
								dobValue="";
							}
							if(dob!=""){
								System.out.println(dob);
								dobValue=dob.substring(5,7)+"/"+dob.substring(8, 10)+"/"+dob.substring(0, 4);
								System.out.println(dobValue);
							}

							vmid=JLib.getVmidPatientByNameDOB(lname, fname, dobValue, connDest);


						}
					}
					//System.out.println( vmid);
					objInsDetBean.setStrPatvmid(vmid);


					System.out.println("chart no: "+objInsDetBean.getStrPatvmid());

					//Copay
					String person_ins_tie_id=JUtil.validateString(rsInsDet.getString("person_ins_tie_id"));
					strSQL5="select copay from Patient_person_ins_tie where person_ins_tie_id="+person_ins_tie_id+"";
					rs5=stmt5.executeQuery(strSQL5);
					if(rs5!=null){
						if(rs5.next()){
							objInsDetBean.setStrCopay(rs5.getString("copay"));
						}
					}

					//String person_ins_tie_id=JUtil.validateString(rsInsDet.getString("person_ins_tie_id"));
					//strSQL4="select * from where [person_ins_tie_id]='"+person_ins_tie_id+"'";
					objInsDetBean.setStrvmid(JUtil.validateString(rsInsDet.getString("insurance_id")));


					objInsDetBean.setStrSubscriberNo(JUtil.validateString(rsInsDet.getString("subscriber_number")));
					objInsDetBean.setStrGroupNo(JUtil.validateString(rsInsDet.getString("group_number")));
					//objInsDetBean.setStrGrRel(JUtil.validateString(rsInsDet.getString("Primary Insurance Subscriber Relation")));
					//objInsDetBean.setGuarName(rsInsDet.getString("Primary Insurance Subscriber Name"));


					//objInsDetBean.setStrGuarVmid(primaryGuarantorVmid);
					objInsDetBean.setStrStartDate(JUtil.validateString(rsInsDet.getString("person_start_date")));
					objInsDetBean.setStrEndDate(JUtil.validateString(rsInsDet.getString("person_end_date")));
					//objInsDetBean.setStrSeqNo("1");





					System.out.println(objInsDetBean.getStrvmid());
					if (objInsDetBean.getStrvmid() != ""){

						strSQL2 = "select [carrier] from Insurance where insurance_id='" + objInsDetBean.getStrvmid() + "'";
						rsInsDet2 = stmt2.executeQuery(strSQL2);
						while (rsInsDet2.next()) {
							objInsDetBean.setStrName(JUtil.validateString(rsInsDet2.getString("carrier")));
							System.out.println(objInsDetBean.getStrName());
						}	
						objInsDet.insertData(objInsDetBean, connSrc, connDest);

					}
					else {
						System.out.println("Insurance not found," + objInsDetBean.getStrvmid());
						//objInsDetBean.incrInvCount();
					}
					objUI.displayStatus("InsuranceDetail: Added: " + objInsDetBean.getAddCount() + " , Duplicate: " + objInsDetBean.getDupCount() + " , Invalid: " + objInsDetBean.getInvCount());

				}

			} catch(Exception e) {
				objUI.displayProgress("InsuranceDetail : " + e.toString());
				JUtil.logExceptions(e);
			}
			finally {
				rsInsDet.close();
				stmt.close();
			}

			objUI.displayStatus("InsuranceDetail: " + objInsDetBean.getAddCount() + "-" + objInsDetBean.getDupCount() + "-" + objInsDetBean.getInvCount());



		}
	 */


	/*public String AMPM(String time)
		{
			String[] times = time.split(" ");
			time = times[2];

			String[] tim = time.split(":");
			String hh = tim[0];
			int h = Integer.parseInt(hh);
			String AMPM = times[3];
			if(AMPM.contains("PM"))
			{
				if(h !=12)
				{
					h = h + 12;
					time = h + ":" + tim[1] + ":" + tim[2];
				}
				else if(h ==12)
				{

					time = h + ":" + tim[1] + ":" + tim[2];
				}

			}
			return time;
		}*/




	/*private void addAppointments(Connection connSrc, Connection connDest, PMMigUI objUI) throws SQLException {
			Statement st = null;

			JUtil.PROCESS_startTime = new Date();

			String    strInsertSql = "";		
			String    strSQL       = "";
			Statement stmt         = null;
			ResultSet rsApt        = null;

			stmt = connSrc.createStatement();
			AppointmentsBean objAptBean = new AppointmentsBean();

			try	{
				st = connSrc.createStatement();
				Appointments objApt = new Appointments();


				strSQL= "SELECT *  FROM Appointment";  

				//strSQL= "SELECT *  FROM Appointment where [appointment_id]=9930";


				rsApt = stmt.executeQuery(strSQL);

				while (rsApt.next()) {
					objAptBean.clearAll();
					objAptBean.incrReadCount(); 

					//Appointment ID
					objAptBean.setLngApt_RecordID_Source(rsApt.getLong("appointment_id"));

					//Facilities
					objAptBean.setStrFacilityID_Source("2");



					//Doctors and resource

					String doc=JUtil.validateString(rsApt.getString("resource_id"));

					if(doc.equals("5") || doc.contains("5")){
						objAptBean.setStrDoctorID_Source("5");
					}else if(doc.equals("4") || doc.contains("4")){
						objAptBean.setStrResourceID_Source("4");
					} 





					//Patient
					String PID = JUtil.validateString(rsApt.getString("patient_id"));
					System.out.println("PID: "+PID);
					objAptBean.setStrPatientID_Source(PID);


					//Date 
					String apptDate=JUtil.validateString(rsApt.getString("start"));
					if(apptDate==null || apptDate=="NULL" || apptDate.equals("") || apptDate.equals("NULL")){

					}else{
						String dateSplited[]=apptDate.split(" ");

						String dateValue=dateSplited[0];
						String startTimeValue=dateSplited[1];
						objAptBean.setStrAptDate_Source(dateValue.substring(5,7)+"/"+dateValue.substring(8,10)+"/"+dateValue.substring(0,4));
						objAptBean.setStrStartTime_Source(startTimeValue);
						System.out.println(objAptBean.getStrAptDate_Source());
					}



					//start time

		         	String startTime=rsApt.getString("Appointment Start Time");
		         	String startTimeSAplit[]=startTime.split(" ");
		         	String startTimeValue=startTimeSAplit[2];
		         	System.out.println(startTimeValue);
		         	objAptBean.setStrStartTime_Source(startTimeValue);






					//objAptBean.setStrAptDate_Source(rsApt.getString("Date"));
					//String time=rsApt.getString("Start Time");
					//String newTime=JLib.AMPM(time);
					//objAptBean.setStrStartTime_Source(newTime);
					//String[] TimeSep=objAptBean.getStrStartTime_Source().split(" ");
					//objAptBean.setStrStartTime_Source(TimeSep[0]);
					//objAptBean.setAMPM(TimeSep[1]);
					//objAptBean.setStrReason_Source(rsApt.getString("Reason Code"));


					//Notes
					//objAptBean.setStrGeneralNotes_Source(rsApt.getString("Notes"));



					//Duration or End Time

					String endTime=JUtil.validateString(rsApt.getString("end"));
					if(endTime==null || endTime=="NULL" || endTime.equals("") || endTime.equals("NULL")){

					}else{
						String endArray[]=endTime.split(" ");
						String endTimeValue=endArray[1];
						objAptBean.setStrEndTime_Source(endTimeValue);
					}


					//String endArray
					//objAptBean.setDuration(rsApt.getString("Duration"));



					//Visit Type

					String visitType=JUtil.validateString(rsApt.getString("Reason Code"));
					if(visitType.equals("")){
						objAptBean.setStrVisitType_Source("Migrated");
					}else{
					objAptBean.setStrVisitType_Source(visitType);
					}

					objAptBean.setStrVisitType_Source("Migrated");




					//Visit Status

					String status=JUtil.validateString(rsApt.getString("Appointment Status"));
					String visitStatus="";
					if(status.equals("Cancelled")){
						visitStatus="CANCS";
					}else if(status.equals("Check In")){
						visitStatus="ARR";
					}else if(status.equals("Check Out")){
						visitStatus="CHK";
					}else if(status.equals("Completed")){
						visitStatus="CHK";
					}else if(status.equals("No show")){
						visitStatus="N/S";
					}else if(status.equals("pending")){
						visitStatus="PEN";
					}else if(status.equals("Rescheduled")){
						visitStatus="R/S";
					} else{
						visitStatus="Migrated";
					}

					objAptBean.setStrStatus_Source("Migrated");






					objAptBean.setStrNotes_Source(JUtil.validateString(rsApt.getString("notes")));

					objApt.insertData(objAptBean, connSrc, connDest);
					objUI.displayStatus("Appointments Read: " + objAptBean.getCntRead() + " ; Added: " + objAptBean.getCntAdd() + " ; Duplicate: " + objAptBean.getCntDup() + " ; Pat not found: " + objAptBean.getCntNoPat() + " ; No Dr: " + objAptBean.getCntNoDr() + " ; No Fac: " + objAptBean.getCntNoFac() + " ; Invalid: " + objAptBean.getCntInv());



				}


				//Excel start...
				try{


					java.io.File file = new java.io.File("AppointmentsCount.xls");
					//file.createNewFile(); //Niteesh
					WorkbookSettings wbs = new WorkbookSettings();
					wbs.setInitialFileSize((int)file.length());		    

					// Workbook workbook = Workbook.getWorkbook(file,wbs);				
					WritableWorkbook workbook = Workbook.createWorkbook(file, wbs);

					workbook.createSheet("Apt", 0);

					WritableSheet excelsheet = workbook.getSheet(0);


					WritableFont cellFont1 = new WritableFont(WritableFont.TIMES, 12);
					cellFont1.setColour(Colour.BLUE);

					WritableCellFormat cellFormat1 = new WritableCellFormat(cellFont1);
					cellFormat1.setBackground(Colour.LIGHT_GREEN);
					cellFormat1.setBorder(Border.ALL, BorderLineStyle.THIN);


					WritableFont cellFont2 = new WritableFont(WritableFont.TIMES, 12);			    
					WritableCellFormat cellFormat2 = new WritableCellFormat(cellFont2);			    
					cellFormat2.setBorder(Border.ALL, BorderLineStyle.THIN);

					WritableFont cellFont3 = new WritableFont(WritableFont.TIMES, 14);			    
					WritableCellFormat cellFormat3 = new WritableCellFormat(cellFont3);		

					excelsheet.setColumnView(1, 50);
					excelsheet.setColumnView(2, 20);


					Calendar currentDate = Calendar.getInstance();
					SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy HH:mm");
					String dateNow = formatter.format(currentDate.getTime());

					excelsheet.addCell(new Label(1,3,"Appointments loading Statistics",cellFormat3));
					excelsheet.addCell(new Label(2,3,dateNow,cellFormat3));


					excelsheet.addCell(new Label(1,5,"Description",cellFormat1));
					excelsheet.addCell(new Label(2,5,"Total Records",cellFormat1));

					excelsheet.addCell(new Label(1,6," Appointments Read: ",cellFormat2));
					excelsheet.addCell(new Number(2,6, objAptBean.getCntRead(),cellFormat2));

					excelsheet.addCell(new Label(1,7," Appointments Migrated: ",cellFormat2));
					excelsheet.addCell(new Number(2,7, objAptBean.getCntAdd(),cellFormat2));

					excelsheet.addCell(new Label(1,8," Patient not found: ",cellFormat2));
					excelsheet.addCell(new Number(2,8, objAptBean.getCntNoPat(),cellFormat2));

					excelsheet.addCell(new Label(1,9," Doctor not found: ",cellFormat2));
					excelsheet.addCell(new Number(2,9, objAptBean.getCntNoDr(),cellFormat2));

					excelsheet.addCell(new Label(1,10," Duplicate Appointments: ",cellFormat2));
					excelsheet.addCell(new Number(2,10, objAptBean.getCntDup(),cellFormat2));

					workbook.write();
					workbook.close();

				}
				catch(Exception e)	{
					System.err.println(e.toString());
					// return(e.getMessage());
					//throw e;
				}
				finally	{

				}

				//Excel End ...


			}catch(Exception e)	{
				objUI.displayProgress("Appointments:" + e.toString());
				JUtil.logExceptions(e);
			}
			finally	{
				rsApt.close();
				stmt.close();	

			}

			JUtil.PROCESS_EndTime = new Date();

			System.out.println("Start Time: " + JUtil.PROCESS_startTime );
			System.out.println("End Time: " + JUtil.PROCESS_EndTime );


			objUI.displayProgress( "AppointmentsRead: " + objAptBean.getCntRead() + "; Added: " + objAptBean.getCntAdd() + "; Duplicate: " + objAptBean.getCntDup() + "; Pat not found: " + objAptBean.getCntNoPat() + "; No Dr: " + objAptBean.getCntNoDr() + "; No Fac: " + objAptBean.getCntNoFac() + " ; Invalid: " + objAptBean.getCntInv());
		}
	 */


	/*private void addVisitType(Connection connSrc, Connection connDest,PMMigUI objUI) throws SQLException {

				//This method is used to create new visit Type

				String strSQL = "";
				Statement stmt = null;
				ResultSet rsVst = null;
				stmt = connSrc.createStatement();

				VisitTypeBean objVisitTypeBean = new VisitTypeBean();
				VisitType objVisttype = new VisitType();

				try
				{

					Users objUsr = new Users();
					Provider objPrv = new Provider();
					strSQL = "Select * from Visit_Type where Create_new = '1'";

					rsVst = stmt.executeQuery(strSQL);			

					while (rsVst.next()) 
					{	
						objVisitTypeBean.clearAll();

						String name = rsVst.getString("ClientVisitCode");
						name = JLib.Left(name, 10);System.out.println(name);
						String description =rsVst.getString("Description");
						description = "Mig- " + description;
						objVisitTypeBean.setStrVName(name);
						objVisitTypeBean.setStrVDescription(JUtil.validateString(description));

						objVisttype.insertData(objVisitTypeBean, connSrc, connDest);

						objUI.displayStatus("VisitType: Added: " + objVisitTypeBean.getAddCount() + " , Duplicate: " + objVisitTypeBean.getDupCount() + " , Invalid: " + objVisitTypeBean.getInvCount());

					}

				}catch(Exception e) {
					e.printStackTrace();
					objUI.displayProgress("VisitType: " + e.toString());
					JUtil.logExceptions(e);
				}
				finally {
					rsVst.close();
					stmt.close();
				}

				objUI.displayStatus("VisitType: Added: " + objVisitTypeBean.getAddCount() + " , Duplicate: " + objVisitTypeBean.getDupCount() + " , Invalid: " + objVisitTypeBean.getInvCount());

			}

	 */





	//Visit Status


	/*private void addVisitStatus(Connection connSrc, Connection connDest,PMMigUI objUI) throws SQLException {
				//This method is used to create new visit Status

				String strSQL = "";
				Statement stmt = null;
				ResultSet rsVst = null;
				stmt = connSrc.createStatement();

				VisitStatusBean objVisitStatusBean = new VisitStatusBean();
				VisitStatus objVisitStatus = new VisitStatus();

				try
				{

					Users objUsr = new Users();
					Provider objPrv = new Provider();
					strSQL = "Select * from Visit_Status where Create_new = '1'";

					rsVst = stmt.executeQuery(strSQL);			

					while (rsVst.next()) 
					{	
						System.out.println("hi");
						objVisitStatusBean.clearAll();

						String code = rsVst.getString("ClientVisitStatusCode");
						String Status =rsVst.getString("Description");
						Status = "Mig- " + Status;
						objVisitStatusBean.setStrVisitCode(JUtil.validateString(code));
						objVisitStatusBean.setStrVisitstatus(JUtil.validateString(Status));

						objVisitStatus.insertData(objVisitStatusBean, connSrc, connDest);

						objUI.displayStatus("Visit Status: Added: " + objVisitStatusBean.getAddCount() + " , Duplicate: " + objVisitStatusBean.getDupCount() + " , Invalid: " + objVisitStatusBean.getInvCount());
					}

				}catch(Exception e) {
					e.printStackTrace();
					objUI.displayProgress("Visit Status: " + e.toString());
					JUtil.logExceptions(e);
				}
				finally {
					rsVst.close();
					stmt.close();
				}

				objUI.displayStatus("Visit Status: Added: " + objVisitStatusBean.getAddCount() + " , Duplicate: " + objVisitStatusBean.getDupCount() + " , Invalid: " + objVisitStatusBean.getInvCount());


			}


	 */

















	//Add Guarantor Employer
	/*private void addGuarantorEmployers(Connection connSrc, Connection connDest,PMMigUI objUI) throws SQLException {
				String strSQL = "";
				String strSQL2 = "";

				String employer="";
				String name="";
				String[] flname=null;
				Statement stmt = null;
				Statement stmt2 = null;
				Statement stmt3 = null;
				Statement stmt4 = null;
				Statement stmt5 = null;
				Statement stmt6 = null;
				PreparedStatement stmt7 = null;
				PreparedStatement pstmt=null;

				ResultSet rsUsr = null;
				ResultSet rsUsr2 = null;
				ResultSet rsUsr3 = null;
				ResultSet rsUsr4 = null;
				ResultSet rsUsr5 = null;
				ResultSet rsUsr6 = null;
				ResultSet rs = null;

				//SOURCE
				stmt = connSrc.createStatement();
				stmt2 = connSrc.createStatement();
				stmt3 = connSrc.createStatement();

				//DESTINATION
				stmt4 = connDest.createStatement();
				stmt5 = connDest.createStatement();
				stmt6 = connDest.createStatement();
				//stmt7 = connDest.createStatement();
				int i=0,j=0,k=0;
				System.out.println("hereee");

				EmployerBean objEmpBean=new EmployerBean();
				try{


					String empyrName="";
					String empyrAddress="";
					String empyrAddress2="";
					String empyrCity="";
					String empyrState="";
					String empyrZip="";
					String empPhone="";
					strSQL = "SELECT * FROM Guarantor where [Employer Name]<>''";
					rsUsr = stmt.executeQuery(strSQL);
					String Lang="";
					Employer objEmp=new Employer();

					String empName="";
					while (rsUsr.next()) {
						empName=JUtil.validateString(rsUsr.getString("Employer Name"));
						objEmpBean.setStrEmpName(empName);
						objEmpBean.setStrempAddress1(JUtil.validateString(rsUsr.getString("Employer Address 1")));
						objEmpBean.setStrempAddress2(JUtil.validateString(rsUsr.getString("Employer Address 2")));
						objEmpBean.setStrempCity(JUtil.validateString(rsUsr.getString("Employer City")));
						objEmpBean.setStrempState(JUtil.validateString(rsUsr.getString("Employer State")));
						objEmpBean.setStrempZip(JUtil.validateString(rsUsr.getString("Employer Zip")));

						objEmp.insertData(objEmpBean, connSrc, connDest);
						objUI.displayStatus("Employers: Added: " + i + " ; Duplicates: " + j + " ; Invalid: " + k);
						i++;
					}{
						j++;
					}


				}catch(Exception e){
					e.printStackTrace();
					JUtil.logExceptions(e);

				}finally{
					rsUsr.close();


				}
				objUI.displayStatus("Employers: Added: " + i + " ; Duplicates: " + j + " ; Invalid: " + k);		



			}
	 */

	//Add Employer
	/*private void addEmployer(Connection connSrc, Connection connDest,PMMigUI objUI) throws SQLException {
				String strSQL = "";
				String strSQL2 = "";

				String employer="";
				String name="";
				String[] flname=null;
				Statement stmt = null;
				Statement stmt2 = null;
				Statement stmt3 = null;
				Statement stmt4 = null;
				Statement stmt5 = null;
				Statement stmt6 = null;
				PreparedStatement stmt7 = null;
				PreparedStatement pstmt=null;

				ResultSet rsUsr = null;
				ResultSet rsUsr2 = null;
				ResultSet rsUsr3 = null;
				ResultSet rsUsr4 = null;
				ResultSet rsUsr5 = null;
				ResultSet rsUsr6 = null;
				ResultSet rs = null;

				//SOURCE
				stmt = connSrc.createStatement();
				stmt2 = connSrc.createStatement();
				stmt3 = connSrc.createStatement();

				//DESTINATION
				stmt4 = connDest.createStatement();
				stmt5 = connDest.createStatement();
				stmt6 = connDest.createStatement();
				//stmt7 = connDest.createStatement();
				int i=0,j=0,k=0;
				System.out.println("hereee");

				EmployerBean objEmpBean=new EmployerBean();
				try{



					strSQL = "SELECT * FROM Employer where name<>''";
					rsUsr = stmt.executeQuery(strSQL);
					String Lang="";
					Employer objEmp=new Employer();

					String empName="";
					while (rsUsr.next()) {
						empName=JUtil.validateString(rsUsr.getString("name"));
						objEmpBean.setStrEmpName(empName);


							objEmpBean.setStrempAddress1(JUtil.validateString(rsUsr.getString("Address1")));
							objEmpBean.setStrempAddress2(JUtil.validateString(rsUsr.getString("Address2")));
							objEmpBean.setStrempCity(JUtil.validateString(rsUsr.getString("City")));
							objEmpBean.setStrempState(JUtil.validateString(rsUsr.getString("State")));
							objEmpBean.setStrempZip(JUtil.validateString(rsUsr.getString("Zip")));
							objEmpBean.setStrempPhone(JUtil.validateString(rsUsr.getString("Phone1")));


						objEmp.insertData(objEmpBean, connSrc, connDest);
						objUI.displayStatus("Employers: Added: " + i + " ; Duplicates: " + j + " ; Invalid: " + k);
						i++;
					}{
						j++;
					}


				}catch(Exception e){
					e.printStackTrace();
					JUtil.logExceptions(e);

				}finally{
					rsUsr.close();


				}
				objUI.displayStatus("Employers: Added: " + i + " ; Duplicates: " + j + " ; Invalid: " + k);		



			}
	 */






	//Add Relation
	/*private void addRelation(Connection connSrc, Connection connDest,PMMigUI objUI) throws SQLException 
			{
				String strSQL = "";
				String strSQL2 = "";
				String strSQL3 = "";
				String strSQL4 = "";

				Statement stmt = null;
				Statement stmt2 = null;
				Statement stmt3 = null;
				Statement stmt4 = null;

				ResultSet rsUsr = null;
				ResultSet rsUsr2 = null;
				ResultSet rsUsr3 = null;
				ResultSet rsUsr4 = null;

				stmt = connSrc.createStatement();
				stmt2 = connDest.createStatement();
				stmt3 = connDest.createStatement();

				String chartNo="";
				String guarantor="";
				int grid=0;
				int pid=0;
				int isGrPt=0;
				int userType=0;
				int i=0,j=0;
				//stmt2 = connSrc.createStatement();
				//stmt3 = connSrc.createStatement();
				stmt4 = connDest.createStatement();
				System.out.println("ADD RELATION");
				PatientsBean SCBean = new PatientsBean();
				//select distinct[chart number],[Guarantor]  from mwcas where [chart number]<>[Guarantor]
				String relation="";
				try{
					//strSQL="SELECT * FROM dbo_uvPatientDemographics WHERE  PatientSameAsGuarantor=0 and PatientRelationToGuarantor<>'Self'";

					strSQL="SELECT * FROM PatientDemographics WHERE [Relation to Guarantor]<>''";
					//strSQL="SELECT * FROM dbo_uvPatientDemographics where [PatientProfileId]='1454'";
					//strSQL="select *  from Patient where [Chart Number]='100200'";  1454
					rsUsr=stmt.executeQuery(strSQL);
					while(rsUsr.next())
					{

						chartNo="";
						guarantor="";
						grid=0;
						pid=0;
						isGrPt=0;
						userType=0;

						chartNo=rsUsr.getString("Patient ID");

						//guarantor=rsUsr.getString("GuarantorId");

						relation=JUtil.validateString(rsUsr.getString("Relation to Guarantor"));

						String relConvert=JUtil.convertRel(relation);


						grid = JLib.getUidByVmid("Gr-"+chartNo, connDest);
						if(grid==0){
							grid = JLib.getUidByVmidFromMdb(chartNo, connSrc);
							//System.out.println("GRID for Guarantor= "+guarantor+" FROM MDB= "+grid);
						}
						if(grid==0){
							grid=JLib.getUidByVmid("Pat-"+chartNo, connDest);
						}

						pid = JLib.getUidByVmid("Pat-"+chartNo, connDest);




						//System.out.println(grid+"=GRID , PID="+pid);


						userType=JLib.getUserTypeByUid(grid, connDest);
						System.out.println("UT="+userType);
						if(grid!=0 && grid!=pid){
							if(userType==4){
								System.out.println("here");

								strSQL3="UPDATE patients SET isgrpt=0,GrRel='"+relConvert+"' , Grid='"+grid+"' where pid='"+pid+"'";
								System.out.println(strSQL3);
								stmt3.executeUpdate(strSQL3);
								i++;

							}else{
								strSQL2="UPDATE patients SET GrRel='"+relConvert+"', isgrpt=0,Grid="+grid+" where pid='"+pid+"'";
								System.out.println(strSQL2);
								stmt4.executeUpdate(strSQL2);

								i++;
							}

						}
						else
						{
							j++;
							System.out.println( "Not Addes: " + j + " , chartNo: " + chartNo+ " , GUARANTOR: " +guarantor);
						}

						objUI.displayStatus("Relation: Added: " + i + " , Not Addes: " + j);

					}


				}
				catch(Exception e){
					e.printStackTrace();
				}

			}

	 */


	/*private void addFacility (Connection connSrc, Connection connDest, PMMigUI objUI) throws SQLException {

				String strSQL = "";
				Statement stmt = null;
				ResultSet rsFac = null;
				stmt = connSrc.createStatement();


				String strSQL1 = "";
				Statement stmt1 = null;
				ResultSet rsFac1 = null;
				stmt1 = connSrc.createStatement();



				FacilityBean objFacBean = new FacilityBean();

				try {

					Facility  objFac = new Facility();

					strSQL = "select * from Facility where [name]<>''";

					int i = 0;

					rsFac = stmt.executeQuery(strSQL);

					while (rsFac.next()) {

						objFacBean.clearAll();

						String facId=JUtil.validateString(rsFac.getString("facility_id"));
						objFacBean.setStrvmid("Fac-"+facId );
						objFacBean.setStrName(JUtil.validateString(rsFac.getString("name")));
						objFacBean.setStrTel(JUtil.validateString(rsFac.getString("phone")));


						objFacBean.setStrAddressLine1(JUtil.validateString(rsFac.getString("Address1")));
						objFacBean.setStrAddressLine2(JUtil.validateString(rsFac.getString("Address2")));
						objFacBean.setStrCity(JUtil.validateString(rsFac.getString("City")));
						objFacBean.setStrState(JUtil.validateString(rsFac.getString("State")));
						objFacBean.setStrZip(JUtil.validateString(rsFac.getString("Zip")));

						objFacBean.setStrFax(JUtil.validateString(rsFac.getString("Phone2")));
						objFacBean.setStrFederalTaxID(JUtil.validateString(rsFac.getString("FederalTaxId")));
						objFacBean.setStrNPI(rsFac.getString("NPI"));




						//objFacBean.setPOS(rsFac.getInt("LOC_POS_NUMBER"));
						//objFacBean.setStrCliaId(JUtil.validateString(rsFac.getString("Extra 2")));

						//Fedral Tax id
						//objFacBean.setStrFederalTaxID(JUtil.validateString(rsFac.getString("FederalTaxId")));
						//objFacBean.setStrNPI(rsFac.getString("National Provider Identifier"));
						//objFacBean.setStrTaxonomyCode(rsFac.getString("taxonomy_code"));

						objFac.insertData(objFacBean, connSrc, connDest);
						objUI.displayStatus("Facility: Added: " + objFacBean.getAddCount() + " , Duplicate: " + objFacBean.getDupCount() + " , Invalid: " + objFacBean.getInvCount());

					}



					strSQL1 = "select * from mwpra";
					rsFac1 = stmt1.executeQuery(strSQL1);

					while (rsFac1.next()) {
						objFacBean.clearAll();
						objFacBean.setStrvmid("Fac-" + rsFac1.getString("ID"));


						objFacBean.setStrName(JUtil.validateString(rsFac1.getString("Practice Name")));
						objFacBean.setStrCity(JUtil.validateString(rsFac1.getString("City")));
						objFacBean.setStrState(JUtil.validateString(rsFac1.getString("State")));
						objFacBean.setStrAddressLine1(JUtil.validateString(rsFac1.getString("Street 1")));
						objFacBean.setStrAddressLine2(JUtil.validateString(rsFac1.getString("Street 2")));
						objFacBean.setStrTel(JUtil.validateString(rsFac1.getString("Phone"))); 
						objFacBean.setStrZip(JUtil.validateString(rsFac1.getString("Zip Code")));
						objFacBean.setStrFax(JUtil.validateString(rsFac1.getString("Fax")));
						objFacBean.setStrFederalTaxID(JUtil.validateString(rsFac1.getString("Federal Tax ID")));



						//objFacBean.setPOS(rsFac1.getInt("LOC_POS_NUMBER"));
						//objFacBean.setStrCliaId(JUtil.validateString(rsFac1.getString("Extra 2")));

						//objFacBean.setStrFederalTaxID(JUtil.validateString(rsFac1.getString("LOC_TAX_ID_2")));
						//objFacBean.setStrNPI(rsFac1.getString("National Provider Identifier"));
						//objFacBean.setStrTaxonomyCode(rsFac1.getString("taxonomy_code"));

						objFac.insertData(objFacBean, connSrc, connDest);
					}



				} catch(Exception e) {
					e.printStackTrace();
					objUI.displayProgress("Facility : " + e.toString());
					JUtil.logExceptions(e);
				}
				finally {
					rsFac.close();
					stmt.close();
				}

				objUI.displayStatus("Facility: " + objFacBean.getAddCount() + "-" + objFacBean.getDupCount() + "-" + objFacBean.getInvCount());




			}

	 */
	/*private void addDoctors(Connection connSrc, Connection connDest,PMMigUI objUI) throws SQLException {
				// TODO Auto-generated method stub	

				String strSQL = "";

				String strSQL2 = "";

				Statement stmt = null;

				Statement stmt2 = null;

				ResultSet rsUsr = null;

				ResultSet rsUsr2 = null;

				stmt = connSrc.createStatement();

				stmt2 = connSrc.createStatement();

				ProviderBean SCBean = new ProviderBean();
				try
				{

					Users objUsr = new Users();
					Provider objPrv = new Provider();
					strSQL="";


					strSQL = "Select * from User where isprovider='1' and isinactive='0'";

					rsUsr = stmt.executeQuery(strSQL);			
					//int c=1;
					while (rsUsr.next()) {	
						SCBean.clearall();
						SCBean.clearallUsers();
						//SCBean.set
						//SCBean.setFacVmid(rsUsr.getString("code"));

						String c=rsUsr.getString("user_id");
						SCBean.setVmid("Dr-" + c);

						SCBean.setUfname(JUtil.validateString(rsUsr.getString("firstname")));

						SCBean.setUlname(JUtil.validateString(rsUsr.getString("lastname")));


						SCBean.setSuffix(JUtil.validateString(rsUsr.getString("suffix")));
						SCBean.setUname(SCBean.getUfname() + JLib.Left(SCBean.getUlname(),1));
						SCBean.setSpecialty(JUtil.validateString(rsUsr.getString("speciality"))); 
						SCBean.setDeano(JUtil.validateString(rsUsr.getString("dea")));
						SCBean.setStLicNo(JUtil.validateString(rsUsr.getString("state_license")));
						SCBean.setNPI(JUtil.validateString(rsUsr.getString("national_provider_id")));
						SCBean.setTaxid(JUtil.validateString(rsUsr.getString("federal")));


						SCBean.setUfname(JUtil.validateString(rsUsr.getString("First")));
						SCBean.setUminitial(JUtil.validateString(rsUsr.getString("Middle")));
						SCBean.setUlname(JUtil.validateString(rsUsr.getString("Last")));

						SCBean.setSuffix(JUtil.validateString(rsUsr.getString("Suffix")));




						SCBean.setUpaddress(JUtil.validateString(rsUsr.getString("Address1")));
						SCBean.setUpcity(JUtil.validateString(rsUsr.getString("City")));
						SCBean.setUpstate(JUtil.validateString(rsUsr.getString("State")));
						SCBean.setZipcode(JUtil.validateString(rsUsr.getString("Zip")));
						SCBean.setUpphone(JUtil.validateString(rsUsr.getString("Phone1")));
						SCBean.setFaxno(JUtil.validateString(rsUsr.getString("Phone2")));

						SCBean.setTaxidtype(JUtil.validateString(rsUsr.getString("FederalTaxIdType")));
						SCBean.setSpLicNo(JUtil.validateString(rsUsr.getString("Ledger")));


						//SCBean.setSsn(rsUsr.getString("SSN or Fed Tax ID").intern());
						//SCBean.setSsn(JUtil.validateString(SCBean.getTaxid()));
						//SCBean.setUpin(JUtil.validateString(rsUsr.getString("UPIN")));
						//
						//SCBean.setTaxonomycode(JUtil.validateString(rsUsr.getString("Taxonomy_Code")));


						objUsr.insertData(SCBean, connSrc, connDest, 1);
						if (!(SCBean.getUID()==0)){
							objPrv.insertData(SCBean, connSrc, connDest, SCBean.getUID());	            	            
						}
						objUI.displayStatus("Providers: Added: " + SCBean.getAddCount() + " , Duplicate: " + SCBean.getDupCount() + " , Invalid: " + SCBean.getInvCount());

					}



				}catch(Exception e) {
					e.printStackTrace();
					objUI.displayProgress("Providers : " + e.toString());
					JUtil.logExceptions(e);
				}
				finally {
					rsUsr.close();
					stmt.close();
				}

				objUI.displayStatus("Providers: Added: " + SCBean.getAddCount() + " , Duplicate: " + SCBean.getDupCount() + " , Invalid: " + SCBean.getInvCount());

			}

	 */




	/*private void addResource(Connection connSrc, Connection connDest,PMMigUI objUI) throws SQLException {
				String strSQL = "";
				Statement stmt = null;
				ResultSet rsUsr = null;
				stmt = connSrc.createStatement();

				ProviderBean SCBean = new ProviderBean();

				try
				{

					Users objUsr = new Users();
					Provider objPrv = new Provider();
					strSQL = "Select * from Resource";

					rsUsr = stmt.executeQuery(strSQL);			

					while (rsUsr.next()) {	
						SCBean.clearall();
						SCBean.clearallUsers();

						SCBean.setVmid("Res-" + rsUsr.getString("resource_id"));

						SCBean.setUfname(JUtil.validateString(rsUsr.getString("name")));
						SCBean.setUlname("Resource");

						SCBean.setUname(SCBean.getUfname());

						objUsr.insertData(SCBean, connSrc, connDest, 9);
						if (!(SCBean.getUID()==0))
						{
							objPrv.insertData(SCBean, connSrc, connDest, SCBean.getUID());	            	            
						}
						objUI.displayStatus("Resources: Added: " + SCBean.getAddCount() + " , Duplicate: " + SCBean.getDupCount() + " , Invalid: " + SCBean.getInvCount());

					}

				}catch(Exception e) {
					e.printStackTrace();
					objUI.displayProgress("Resources: " + e.toString());
					JUtil.logExceptions(e);
				}
				finally {
					rsUsr.close();
					stmt.close();
				}

				objUI.displayStatus("Resources: Added: " + SCBean.getAddCount() + " , Duplicate: " + SCBean.getDupCount() + " , Invalid: " + SCBean.getInvCount());

			}

	 */









	/*private void addRefProviders(Connection connSrc, Connection connDest,PMMigUI objUI) throws SQLException {
				// TODO Auto-generated method stub	
				String strSQL = "";
				Statement stmt = null;
				ResultSet rsUsr = null;
				stmt = connSrc.createStatement();


				String strSQL1 = "";
				Statement stmt1 = null;
				ResultSet rsUsr1 = null;
				stmt1 = connSrc.createStatement();


				ProviderBean SCBean = new ProviderBean();

				String temp2[];
				String temp[];
				String licno[];



				try
				{

					Users objUsr = new Users();
					Provider objPrv = new Provider();
					strSQL="";


					strSQL = "Select * from referralsAddress";  
					//strSQL = "Select * from dbo_DoctorFacility where DoctorFacilityId='215'";
					rsUsr = stmt.executeQuery(strSQL);			

					while (rsUsr.next()) {	
						SCBean.clearall();
						SCBean.clearallUsers();

						String c="";
						String upin[];
						String notes = "";

						c=JUtil.validateString(rsUsr.getString("referrals_id"));
						SCBean.setVmid("Ref-" + c);


						SCBean.setUfname(JUtil.validateString(rsUsr.getString("first")));
						//SCBean.setUminitial(JUtil.validateString(rsUsr.getString("Middle Name")));
						SCBean.setUlname(JUtil.validateString(rsUsr.getString("last")));
						SCBean.setUname(SCBean.getUfname() + JLib.Left(SCBean.getUlname(),1));
						SCBean.setSuffix(JUtil.validateString(rsUsr.getString("suffix"))); 
						//
						//SCBean.setUpaddress2(JUtil.validateString(rsUsr.getString("address2")));

						SCBean.setUpphone(JUtil.validateString(rsUsr.getString("phone2")));
						SCBean.setTaxonomycode(JUtil.validateString(rsUsr.getString("taxonomy")));
						SCBean.setMedicareNo(JUtil.validateString(rsUsr.getString("id_medicare")));
						//SCBean.setFaxno(JUtil.validateString(rsUsr.getString("Fax")));
						//SCBean.setTaxid(JUtil.validateString(rsUsr.getString("FederalTaxId")));
						//SCBean.setTaxidtype(JUtil.validateString(rsUsr.getString("FederalTaxIdType")));
						//SCBean.setSpLicNo(JUtil.validateString(rsUsr.getString("Ledger")));
						//SCBean.setNPI(JUtil.validateString(rsUsr.getString("NPI")));

						SCBean.setUpaddress(JUtil.validateString(rsUsr.getString("address1")));
						SCBean.setUpaddress2(JUtil.validateString(rsUsr.getString("address2")));




						SCBean.setNPI(JUtil.validateString(rsUsr.getString("id_nationalprovider")));
						//SCBean.setTaxid(JUtil.validateString(rsUsr.getString("SSN or Fed Tax ID")));
						//SCBean.setSsn(rsUsr.getString("SSN or Fed Tax ID").intern());
						//SCBean.setSsn(JUtil.validateString(SCBean.getTaxid()));


						//SCBean.setDeano(JUtil.validateString(rsUsr.getString("DEA Registration")));

						String citystatezip_id=JUtil.validateString(rsUsr.getString("citystatezip_id"));
						strSQL1="select * from Citystatezip where [citystatezip_id]='"+citystatezip_id+"'";
						rsUsr1=stmt1.executeQuery(strSQL1);
						if(rsUsr1!=null){
							if(rsUsr1.next()){

								SCBean.setUpcity(JUtil.validateString(rsUsr1.getString("city")));
								SCBean.setUpstate(JUtil.validateString(rsUsr1.getString("state")));
								SCBean.setZipcode(JUtil.validateString(rsUsr1.getString("zip")));
							}
						}

						SCBean.setUpcity(JUtil.validateString(rsUsr.getString("city")));
						SCBean.setUpstate(JUtil.validateString(rsUsr.getString("state")));
						SCBean.setZipcode(JUtil.validateString(rsUsr.getString("zip")));


						objUsr.insertData(SCBean, connSrc, connDest, 5);
						if (!(SCBean.getUID()==0)){
							objPrv.insertData(SCBean, connSrc, connDest, SCBean.getUID());	            	            
						}
						objUI.displayStatus("Referring Provider: Added: " + SCBean.getAddCount() + " , Duplicate: " + SCBean.getDupCount() + " , Invalid: " + SCBean.getInvCount());

					}



				}catch(Exception e) {
					//e.printStackTrace();
					objUI.displayProgress("Referring Provider : " + e.toString());
					JUtil.logExceptions(e);
				}
				finally {
					rsUsr.close();
					stmt.close();
				}

				objUI.displayStatus("Referring Provider: Added: " + SCBean.getAddCount() + " , Duplicate: " + SCBean.getDupCount() + " , Invalid: " + SCBean.getInvCount());

			}
	 */

	/*private void addInsurance(Connection connSrc, Connection connDest, PMMigUI objUI) throws Exception {
				String strSQL = "";
				Statement stmt = null;
				ResultSet rsIns = null;
				stmt = connSrc.createStatement();
				InsuranceBean objInsBean = new InsuranceBean();

				try
				{

					Insurance  objIns = new Insurance();

					strSQL ="Select * from Insurance where insurance_id<>'1'";

					rsIns = stmt.executeQuery(strSQL);

					while (rsIns.next())
					{

						objInsBean.clearAll();
						String c=JUtil.validateString(rsIns.getString("insurance_id"));
						System.out.println(c);
						objInsBean.setStrInsVMID("Ins-" +c );
						objInsBean.setStrName(JUtil.validateString(rsIns.getString("carrier")));
						//objInsBean.setStrAddress1(JUtil.validateString(rsIns.getString("Insurance Address")));
						//objInsBean.setStrAddress2(JUtil.validateString(rsIns.getString("Address2")));
						//objInsBean.setStrCity(JUtil.validateString(rsIns.getString("Insurance City")));
						//objInsBean.setStrState(JUtil.validateString(rsIns.getString("Insurance State")));
						//objInsBean.setStrZip(JUtil.validateString(rsIns.getString("Insurance Zip Code")));
						objInsBean.setStrPhone(JUtil.validateString(rsIns.getString("phone")));
						objInsBean.setStrPayorID(JUtil.validateString(rsIns.getString("payer_id")));
						objInsBean.setStrMediGapID(JUtil.validateString(rsIns.getString("medigap")));



						objIns.insertData(objInsBean, connSrc, connDest);
						objUI.displayStatus("Insurance: Added: " + objInsBean.getAddCount() + " , Duplicate: " + objInsBean.getDupCount() + " , Invalid: " + objInsBean.getInvCount());

					}

				}
				catch(Exception e)
				{
					e.printStackTrace();
					objUI.displayProgress("Insurance : " + e.toString());
					JUtil.logExceptions(e);

				}
				finally
				{
					rsIns.close();
					stmt.close();
				}
				objUI.displayStatus("Insurance: " + objInsBean.getAddCount() + "-" + objInsBean.getDupCount() + "-" + objInsBean.getInvCount());
			}
	 */

	/*private void addPatients (Connection connSrc, Connection connDest,PMMigUI objUI) throws SQLException {

				String strSQL = "";
				String strSQL2 = "";
				String strSQL3 = "";
				String strSQL4 = "";
				String strSql5="";
				String asgndPrSQL="";
				String pcpSQL="";

				String assignedProvider="";
				String pcp="";
				String employer="";
				java.sql.PreparedStatement stmtPr =null;

				int assignedPrId = 0;
				int pcpId = 0;
				int defFeeschid=0;
				Statement stmt = null;
				Statement destStmt = null;
				Statement stmt2 = null;
				Statement stmt3 = null;
				Statement stmt4 = null;
				Statement stmt5 = null;
				Statement stmt6 = null;

				ResultSet rsUsr = null;
				ResultSet destUsr = null;
				ResultSet rsUsr2 = null;
				ResultSet rsUsr3 = null;
				ResultSet rsUsr4 = null;
				ResultSet rsUsr5 = null;
				ResultSet rsUsr6 = null;

				//SOURCE
				stmt = connSrc.createStatement();
				destStmt = connDest.createStatement();
				stmt2 = connSrc.createStatement();
				stmt3 = connSrc.createStatement();
				stmt4 = connSrc.createStatement();
				stmt5 = connSrc.createStatement();

				//DESTINATION


				stmt6 = connDest.createStatement();
				PatientsBean SCBean = new PatientsBean();

				String facility="";
				String patEmployer="";


				String insNotes="";
				String insTemp="";




				String strSQL10 = "";
				Statement stmt10 = null;
				ResultSet rs10 = null;
				stmt10 = connSrc.createStatement();

				String strSQL11="";
				Statement stmt11 = null;
				ResultSet rs11 = null;
				stmt11 = connSrc.createStatement();


				String strSQL12 = "";
				Statement stmt12 = null;
				ResultSet rs12 = null;
				stmt12 = connSrc.createStatement();


				String strSQL13 = "";
				Statement stmt13 = null;
				ResultSet rs13 = null;
				stmt13 = connSrc.createStatement();




				String notes="";
				String temp="";


				stmt.executeUpdate("DELETE from duppat");
				try {

					Users objUsr = new Users();
					Patients objPat = new Patients();
					strSQL = "";
					String strSQL1 = "";
					int contNo=10000; //control number if new ecw account numbers has to be set

					strSQL = "SELECT  * from PatPersonJoinTable";  // 7992
					//strSQL = "SELECT  * from PatPersonJoinTable where [patient_id]='2'";




					rsUsr = stmt.executeQuery(strSQL);
					String sexValue="";
					String sex="";
					String dob="";
					String[]  dateBirth=null;
					String DateOfBirth="";
					while (rsUsr.next()) {

						SCBean.clearall();
						SCBean.clearallUsers();
						String patid= rsUsr.getString("patient_id").intern(); //Patient ID
						System.out.println("Patient: "+patid);



						//Inactive
						String Inactive=JUtil.validateString(rsUsr.getString("PatientInactive"));
						if(Inactive=="1" || Inactive.equals("1")){
							SCBean.setStatus("1");
						} else if(Inactive=="0" || Inactive.equals("0")){
							SCBean.setStatus("0");
						}else{
							SCBean.setStatus("0");
						}



						//Control Number
						SCBean.setControlNo(""+contNo);
						contNo++;


						//Vmid
						SCBean.setVmid("Pat-" + patid); //VMID




						//MRN
						SCBean.setMrn(JUtil.validateString(rsUsr.getString("chart_num"))); //old patient id goes to MRN in front-end  cos we didnt find mrn


						//Deceased

						String deathDate=JUtil.validateString(rsUsr.getString("PatientDeathDate"));
						if(deathDate==null || deathDate=="" || deathDate.equals("") || deathDate.equals("NULL")){

						}else{
							SCBean.setDeceased("1");
						}



						//Patient fnamme,lname,mname

						String lname =JUtil.validateString(rsUsr.getString("last"));
						String fname = JUtil.validateString(rsUsr.getString("first"));
						String mname = JUtil.validateString(rsUsr.getString("middle"));

						if (fname != null)
							SCBean.setUfname(fname);
						if (lname != null)
							SCBean.setUlname(lname);
						if (mname != null)
							SCBean.setUminitial(mname);

						//suffix
						//SCBean.setSuffix(JUtil.validateString(rsUsr.getString("PatientSuffix")));


						//Address
						String address_id=JUtil.validateString(rsUsr.getString("address_id"));
						strSQL2="select * from Address where address_id='"+address_id+"'";
						rsUsr2=stmt2.executeQuery(strSQL2);
						if(rsUsr2!=null){
							if(rsUsr2.next()){
								SCBean.setUpaddress(JUtil.validateString(rsUsr2.getString("address1")));
								SCBean.setUpaddress2(JUtil.validateString(rsUsr2.getString("address2")));
								String cityStateZip=JUtil.validateString(rsUsr2.getString("citystatezip_id"));
								strSQL3="select * from Citystatezip where citystatezip_id='"+cityStateZip+"'";
								rsUsr3=stmt3.executeQuery(strSQL3);
								if(rsUsr3!=null){
									if(rsUsr3.next()){
										String city=JUtil.validateString(rsUsr3.getString("city"));
										if(city.length()>24){
											city=city.substring(0,24);
											SCBean.setUpcity(city);
										}else{
											SCBean.setUpcity(city);
										}
										SCBean.setUpstate(JUtil.validateString(rsUsr3.getString("state")));
										SCBean.setZipcode(JUtil.validateString(rsUsr3.getString("zip")));
									}
								}

							}
						}




						//Country

						String country=JUtil.validateString(rsUsr.getString("PatientCountry"));
						if(country=="" || country==null || country.equals("") || country.equals("null")){
							SCBean.setCountryCode("US");
						}else

						SCBean.setCountryCode("US");


						// Gender
						String gender=JUtil.validateString(rsUsr.getString("pop_sex"));
						SCBean.setSex(JUtil.convertSex(gender));





						// Date Of Birth
						dob = JUtil.validateString(rsUsr.getString("birthday"));

						System.out.println(dob);
						if(dob==null || dob.equals("NULL")){
							dob="";
						}
						if(dob!=""){
							System.out.println(dob);
							String dobValue=dob.substring(5,7)+"/"+dob.substring(8, 10)+"/"+dob.substring(0, 4);
							System.out.println(dobValue);
							SCBean.setDob(dobValue, "MM/dd/yyyy");
							SCBean.setPtDob(dobValue, "MM/dd/yyyy");
						}else{
							SCBean.setDob("", "MM/dd/yyyy");
							SCBean.setPtDob("", "MM/dd/yyyy");
						}




						//UpPhone
						String phone1=JUtil.validateString(rsUsr.getString("phone1")).intern();
						SCBean.setUpphone(phone1);


						//UMObile
						SCBean.setUmobileno(JUtil.validateString(rsUsr.getString("phone2")));

						//Work Phone
						SCBean.setEmployerphone(CommonFunction.convertPhone(JUtil.validateString(rsUsr.getString("phone3")).intern()));


						//SSN
						SCBean.setSsn(CommonFunction.convertSSN(JUtil.validateString(rsUsr.getString("ssn")).intern()));


						//Marital Status

						String mStatus=JUtil.validateString(rsUsr.getString("pop_marital_status"));
						SCBean.setMaritalstatus(JUtil.convertMaritalStatus(mStatus));




						//Email
						SCBean.setUemail(JUtil.validateString(rsUsr.getString("email")));


						// Rendering Provider

						String rendProvider=JUtil.validateString(rsUsr.getString("provider_id"));
						int uid=JLib.getUidByVmid("Dr-"+rendProvider, connDest);
						SCBean.setRendprid(""+uid);


						//PCP   No Data



						//Refering Provider
						//String refProvider=JUtil.validateString(rsUsr.getString("Referring Physician"));

						String refProvider=JUtil.validateString(rsUsr.getString("Referring Physician"));
						if(refProvider==null || refProvider=="" || refProvider.equals("") || refProvider.equals(null)){
						}else{
						String[] refProviderSplited=refProvider.split(",");

						String refLName=refProviderSplited[0];
						String refFName=refProviderSplited[1];

						if(refLName.contains(" ")){
							String refLNameSplited[]=refLName.split(" ");
							refLName=refLNameSplited[0];
						}

						if(refFName.contains(" ")){
							String refFNameSplited[]=refFName.split(" ");
							refFName=refFNameSplited[0];
							if(refFName.equals("")){
								refFName=refFNameSplited[1];
							}else if(refFName.equals("")){
								refFName=refFNameSplited[2];
							}
						}

						int uid=JLib.getRefProviderUidByFname(refFName,connDest);

						if(uid==0){
							 uid=JLib.getProviderUidByFname(refFName,connDest);
						}

						SCBean.setRefPrID(""+uid);
						}


						//Race

						//String race=JUtil.validateString(rsUsr.getString("Race"));
						//SCBean.setRace(JUtil.convertRace(race));

						//Language

						//String language=JUtil.validateString(rsUsr.getString("Preffered Language"));
						//SCBean.setLanguage(JUtil.convertLanguage(language));
						SCBean.setLanguage("English");	


						//Ethnicity
						String ethnicity=JUtil.validateString(rsUsr.getString("ethnicity_id"));
						SCBean.setEthnicity(JUtil.convertEthnicityStatus(ethnicity));



						SCBean.setRelinfo("Y");
						SCBean.setRelinfodate("1900-01-01");
						SCBean.setGrrel("1");


						// Facilities

						SCBean.setDefaultFacility(119);		

						// Notes
						//String patNote=JUtil.validateString(rsUsr.getString("Notes"));
						//SCBean.setNotes("Ref-Provider: "+refProvider+"\n"+patNote);


						// Employers

						//SCBean.setEmployername(rsUsr.getString("Employer Details"));



						objUsr.insertData(SCBean, connSrc, connDest, 3);

						if (!(SCBean.getUID()==0)){

							objPat.insertData(SCBean, connSrc, connDest, SCBean.getUID());	            	            
						}
						objUI.displayStatus("Patients: Added: " + SCBean.getAddCount() + " , Duplicate: " + SCBean.getDupCount() + " , Invalid: " + SCBean.getInvCount());
					}

				} catch (Exception e) {
					e.printStackTrace();
					objUI.displayProgress("Patients : " + e.toString());
					JUtil.logExceptions(e);
				} finally {
					rsUsr.close();
					//			stmt.close();
				}

				objUI.displayStatus("Patients: Added: " + SCBean.getAddCount() + " , Duplicate: " + SCBean.getDupCount() + " , Invalid: " + SCBean.getInvCount());

				long total = SCBean.getDupCount() + SCBean.getAddCount() + SCBean.getInvCount();
				strSQL2 = "insert into pm_mig_status (tot_read,tot_add,tot_inv,tot_dup) values ('" + String.valueOf(total) + "', '" + SCBean.getAddCount() + "', '" + SCBean.getInvCount() + "', '" + SCBean.getDupCount() + "')";
				stmtPr = connDest.prepareStatement(strSQL2);
				stmtPr.executeUpdate();
				SCBean.incrInvCount();
				stmtPr.close();

			}
	 */


	/*private void addGuarantors (Connection connSrc, Connection connDest,PMMigUI objUI) throws SQLException {

				String strSQL = "";
				String strSQL2 = "";
				String strSQL3 = "";
				Statement stmt = null;
				Statement stmt2 = null;
				Statement stmt3 = null;
				ResultSet rsUsr = null;
				ResultSet rsUsr2 = null;
				ResultSet rsUsr3 = null;

				stmt = connSrc.createStatement();
				stmt2 = connSrc.createStatement();
				stmt3 = connSrc.createStatement();
				PatientsBean SCBean = new PatientsBean();

				try {

					String dob="";
					Users objUsr = new Users();
					Patients objPat = new Patients();
					strSQL = "";
					String arr[]=null;
					strSQL = "SELECT  * from PatientDemographics";
					rsUsr = stmt.executeQuery(strSQL);

					while (rsUsr.next()) {

						SCBean.clearall();
						SCBean.clearallUsers();


						String GuarantorId = rsUsr.getString("Patient ID");
						SCBean.setVmid("Gr-" + GuarantorId);

						String lname =JUtil.validateString(rsUsr.getString("Guarantor Last Name"));
						String fname = JUtil.validateString(rsUsr.getString("Guarantor First Name"));


						if (fname != null)
							SCBean.setUfname(fname);
						if (lname != null)
							SCBean.setUlname(lname);



						SCBean.setUpcity(JUtil.validateString(rsUsr.getString("Guarantor City")));
						SCBean.setUpstate(JUtil.validateString(rsUsr.getString("Guarantor State")));
						SCBean.setZipcode(JUtil.validateString(rsUsr.getString("Guarantor Zipcode")));
						SCBean.setCountryCode("US");

						// Date Of Birth
						dob = JUtil.validateString(rsUsr.getString("Guarantor DOB"));
						System.out.println(dob);
						if(dob==null || dob.equals("NULL")){
							dob="";
						}
						if(dob!=""){
							System.out.println(dob);
							SCBean.setDob(dob, "MM/dd/yyyy");
							SCBean.setPtDob(dob, "MM/dd/yyyy");
						}else{
							SCBean.setDob("", "MM/dd/yyyy");
							SCBean.setPtDob("", "MM/dd/yyyy");
						}




						objUsr.insertData(SCBean, connSrc, connDest, 4);
						if (!(SCBean.getUID()==0)){
							objPat.insertData(SCBean, connSrc, connDest, SCBean.getUID());	            	            
						}	
						objUI.displayStatus("Guarantors: Added: " + SCBean.getAddCount() + " , Duplicate: " + SCBean.getDupCount() + " , Invalid: " + SCBean.getInvCount());
					}

				} catch (Exception e) {
					e.printStackTrace();
					objUI.displayProgress("Guarantors : " + e.toString());
					JUtil.logExceptions(e);
				} finally {
					rsUsr.close();
					//			stmt.close();
				}

				objUI.displayStatus("Guarantors: Added: " + SCBean.getAddCount() + " , Duplicate: " + SCBean.getDupCount() + " , Invalid: " + SCBean.getInvCount());

			}
	 */

	/*private void addPatientInsuredGuarantors (Connection connSrc, Connection connDest,PMMigUI objUI) throws SQLException {

				String strSQL = "";
				String strSQL2 = "";
				String strSQL3="";
				Statement stmt = null;
				Statement stmt2 = null;
				Statement stmt3 = null;
				ResultSet rsUsr = null;
				ResultSet rsUsr2 = null;
				ResultSet rsUsr3 = null;
				int cntNo=30000;
				String chartNo = "";
				String maritalStatus = "";
				String refProvider = "";
				int refProviderId = 0;
				String phone3="",phone5="";
				String notes="";
				String employer = "";


				stmt = connSrc.createStatement();
				stmt2 = connSrc.createStatement();
				stmt3 = connSrc.createStatement();
				PatientsBean SCBean = new PatientsBean();
				String dob = "";
				String guatEmployer="";

				String strSQL13="";
				ResultSet rs13=null;
				Statement stmt13=null;
				stmt13=connSrc.createStatement();
				try {

					Users objUsr = new Users();
					Patients objPat = new Patients();
					strSQL = "";

					//strSQL = "SELECT * FROM PatientInsurance where [Primary Insurance Subscriber Relation]='child' or [Primary Insurance Subscriber Relation]='spouse'"; 
					//strSQL="SELECT * FROM PatientInsurance where [Secondary Insurance Subscriber Relation]='child' or [Secondary Insurance Subscriber Relation]='spouse'";
					strSQL = "SELECT * FROM PatientInsurance where [Tertiary Insurance Subscriber Relation]='child' or [Tertiary Insurance Subscriber Relation]='spouse'"; 


					rsUsr = stmt.executeQuery(strSQL);

					while (rsUsr.next()) {

						SCBean.clearall();
						SCBean.clearallUsers();

						//SCBean.setVmid("GrIns-" + rsUsr.getString("Patient ID")+"PI");   //PI Primary Insured
						//SCBean.setVmid("GrIns-" + rsUsr.getString("Patient ID")+"SI");   //SI Secondary Insured
						SCBean.setVmid("GrIns-" + rsUsr.getString("Patient ID")+"TI");   //TI Tertary Insured



						String lName="";
						String fName="";
						String mName="";
						String fMName="";



						//String guarName=JUtil.validateString(rsUsr.getString("Primary Insurance Subscriber Name"));
						//String guarName=JUtil.validateString(rsUsr.getString("Secondary Insurance Subscriber Name"));
						String guarName=JUtil.validateString(rsUsr.getString("Tertiary Insurance Subscriber Name"));


						if( guarName==null  || guarName.equals("") ){

						}else{
							String[] gNameSplited=guarName.split(",");

							if(gNameSplited.length==1){
								lName=gNameSplited[0];
							}else if(gNameSplited.length==2){
								lName=gNameSplited[0];
								fMName=gNameSplited[1];
							}



							fMName=fMName.trim();

							if(fMName.contains(" ")){
								String[] fMNameSplited=fMName.split(" ");
								fMName=fMNameSplited[0];
								if(fName.contains(" ")){
									fName=fName.replaceAll(" ", "");
								}
								mName=fMNameSplited[1];
							}

							System.out.println(lName+" "+fMName+" "+mName);

						}




						System.out.println(SCBean.getVmid());
						SCBean.setUlname(lName);
						SCBean.setUfname(fMName);
						SCBean.setUminitial(mName);			



						objUsr.insertData(SCBean, connSrc, connDest, 4);
						if (!(SCBean.getUID()==0)){
							objPat.insertData(SCBean, connSrc, connDest, SCBean.getUID());	            	            
						}
						objUI.displayStatus("Patient Insured Guarantors: Added: " + SCBean.getAddCount() + " , Duplicate: " + SCBean.getDupCount() + " , Invalid: " + SCBean.getInvCount());
					}

				} catch (Exception e) {
					e.printStackTrace();
					objUI.displayProgress("Guarantors : " + e.toString());
					JUtil.logExceptions(e);
				} finally {
					rsUsr.close();
					//			stmt.close();
				}

				objUI.displayStatus("Patient Insured Guarantors:: Added: " + SCBean.getAddCount() + " , Duplicate: " + SCBean.getDupCount() + " , Invalid: " + SCBean.getInvCount());

			}
	 */


	/*private void addContacts(Connection connSrc, Connection connDest, PMMigUI objUI) throws SQLException {

				String strSQL = "";
				Statement stmt = null;
				ResultSet rsCont = null;
				stmt = connSrc.createStatement();
				ContactsBean objContBean = new ContactsBean();

				try	{			

					Contacts objCont = new Contacts();

					strSQL = "Select * from PatientDemographics where [Emergency Contact Name]<>''";
					rsCont = stmt.executeQuery(strSQL);

					while (rsCont.next()) {

						objContBean.incrReadCount(); 

						objContBean.clearAll();


						//Contact Name
						String conName=JUtil.validateString(rsCont.getString("Emergency Contact Name"));
						objContBean.setStrName(conName);
						//Contact Address
						objContBean.setStrAddress(rsCont.getString("Emergency Contact Address"));

						//Contact City
						objContBean.setStrCity(rsCont.getString("Emergency Contact City"));

						//Contact State

						//Contact Zip
						objContBean.setStrZipcode(rsCont.getString("Emergency Contact Zip"));

						//Contact Phone
						//objContBean.setStrWorkPhone(rsCont.getString("Contact Phone 1"));
						objContBean.setStrHomePhone(rsCont.getString("Emergency Contact Phone"));

						//Relation
						objContBean.setStrRelation(rsCont.getString("Emergency Contact Relation"));


						objContBean.setStrPatVMID(rsCont.getString("Patient ID"));

						objContBean.setStrVMID("Cont-" + objContBean.getStrPatVMID());


						objCont.insertData(objContBean, connSrc, connDest);

					}

					//System.out.println("Total records Read:" + objContBean.getReadCount());
					objUI.displayStatus("Contacts Added: " + objContBean.getAddCount() + ", Duplicate: " + objContBean.getDupCount() + " , Invalid: " + objContBean.getInvCount());


				} catch(Exception e) {
					objUI.displayProgress("Contacts:" + e.toString());
					JUtil.logExceptions(e);
				}
				finally {
					rsCont.close();
					stmt.close();			
				}

				objUI.displayProgress("Contacts Added: " + objContBean.getAddCount() + " , Duplicate: " + objContBean.getDupCount() + " , Invalid: " + objContBean.getInvCount());
			}
	 */
	/*private void addInsuranceDetail (Connection connSrc, Connection connDest, PMMigUI objUI) throws SQLException {

				String strSQL = "";
				String strSQL2 = "";
				Statement stmt = null;
				Statement stmt2 = null;
				ResultSet rsInsDet = null;
				ResultSet rsInsDet2 = null;
				stmt = connSrc.createStatement();
				stmt2 = connSrc.createStatement();
				InsDetBean objInsDetBean = new InsDetBean();

				String strSQL3="";
				ResultSet rs3=null;
				Statement stmt3=null;
				stmt3=connSrc.createStatement();

				String strSQL4="";
				ResultSet rs4=null;
				Statement stmt4=null;
				stmt4=connSrc.createStatement();


				String strSQL5="";
				ResultSet rs5=null;
				Statement stmt5=null;
				stmt5=connSrc.createStatement();


				String patid="";
				String arr[]=null;
				try {

					InsuranceDetail  objInsDet = new InsuranceDetail();


					//strSQL = "SELECT * FROM MWCAS where [Chart Number] is Not Null order by [Chart Number], [Date Created] desc";
					strSQL="SELECT  *  FROM Person_ins_tie";  //3359
					//strSQL="SELECT  *  FROM Person_ins_tie where [person_id]='7'";



					//JONDE000
					String previousPat ="";


					int i = 0;
					int j = 0;
					Boolean skip1 =false;


					rsInsDet = stmt.executeQuery(strSQL);


					previousPat="";
					patid="";

					while (rsInsDet.next()) {
						j = 0;

						String vmid="";
						String personId=JUtil.validateString(rsInsDet.getString("person_id"));

						strSQL3="select * from Person where person_id='"+personId+"'";
						rs3=stmt3.executeQuery(strSQL3);
						if(rs3!=null){
							if(rs3.next()){

								String fname=JUtil.validateString(rs3.getString("first"));
								String lname=JUtil.validateString(rs3.getString("last"));
								String dob=JUtil.validateString(rs3.getString("birthday"));
								System.out.println(dob);
								String dobValue="";
								if(dob==null || dob.equals("")){
									dobValue="";
								}
								if(dob!=""){
									System.out.println(dob);
									dobValue=dob.substring(5,7)+"/"+dob.substring(8, 10)+"/"+dob.substring(0, 4);
									System.out.println(dobValue);
								}

								vmid=JLib.getVmidPatientByNameDOB(lname, fname, dobValue, connDest);


							}
						}
						//System.out.println( vmid);
						objInsDetBean.setStrPatvmid(vmid);


						System.out.println("chart no: "+objInsDetBean.getStrPatvmid());

						//Copay
						String person_ins_tie_id=JUtil.validateString(rsInsDet.getString("person_ins_tie_id"));
						strSQL5="select copay from Patient_person_ins_tie where person_ins_tie_id="+person_ins_tie_id+"";
						rs5=stmt5.executeQuery(strSQL5);
						if(rs5!=null){
							if(rs5.next()){
								objInsDetBean.setStrCopay(rs5.getString("copay"));
							}
						}

						//String person_ins_tie_id=JUtil.validateString(rsInsDet.getString("person_ins_tie_id"));
						//strSQL4="select * from where [person_ins_tie_id]='"+person_ins_tie_id+"'";
						objInsDetBean.setStrvmid(JUtil.validateString(rsInsDet.getString("insurance_id")));


						objInsDetBean.setStrSubscriberNo(JUtil.validateString(rsInsDet.getString("subscriber_number")));
						objInsDetBean.setStrGroupNo(JUtil.validateString(rsInsDet.getString("group_number")));
						//objInsDetBean.setStrGrRel(JUtil.validateString(rsInsDet.getString("Primary Insurance Subscriber Relation")));
						//objInsDetBean.setGuarName(rsInsDet.getString("Primary Insurance Subscriber Name"));


						//objInsDetBean.setStrGuarVmid(primaryGuarantorVmid);
						objInsDetBean.setStrStartDate(JUtil.validateString(rsInsDet.getString("person_start_date")));
						objInsDetBean.setStrEndDate(JUtil.validateString(rsInsDet.getString("person_end_date")));
						//objInsDetBean.setStrSeqNo("1");





						System.out.println(objInsDetBean.getStrvmid());
						if (objInsDetBean.getStrvmid() != ""){

							strSQL2 = "select [carrier] from Insurance where insurance_id='" + objInsDetBean.getStrvmid() + "'";
							rsInsDet2 = stmt2.executeQuery(strSQL2);
							while (rsInsDet2.next()) {
								objInsDetBean.setStrName(JUtil.validateString(rsInsDet2.getString("carrier")));
								System.out.println(objInsDetBean.getStrName());
							}	
							objInsDet.insertData(objInsDetBean, connSrc, connDest);

						}
						else {
							System.out.println("Insurance not found," + objInsDetBean.getStrvmid());
							//objInsDetBean.incrInvCount();
						}
						objUI.displayStatus("InsuranceDetail: Added: " + objInsDetBean.getAddCount() + " , Duplicate: " + objInsDetBean.getDupCount() + " , Invalid: " + objInsDetBean.getInvCount());

					}

				} catch(Exception e) {
					objUI.displayProgress("InsuranceDetail : " + e.toString());
					JUtil.logExceptions(e);
				}
				finally {
					rsInsDet.close();
					stmt.close();
				}

				objUI.displayStatus("InsuranceDetail: " + objInsDetBean.getAddCount() + "-" + objInsDetBean.getDupCount() + "-" + objInsDetBean.getInvCount());



			}
	 */


	/*public String AMPM(String time)
			{
				String[] times = time.split(" ");
				time = times[2];

				String[] tim = time.split(":");
				String hh = tim[0];
				int h = Integer.parseInt(hh);
				String AMPM = times[3];
				if(AMPM.contains("PM"))
				{
					if(h !=12)
					{
						h = h + 12;
						time = h + ":" + tim[1] + ":" + tim[2];
					}
					else if(h ==12)
					{

						time = h + ":" + tim[1] + ":" + tim[2];
					}

				}
				return time;
			}*/




	/*private void addAppointments(Connection connSrc, Connection connDest, PMMigUI objUI) throws SQLException {
				Statement st = null;

				JUtil.PROCESS_startTime = new Date();

				String    strInsertSql = "";		
				String    strSQL       = "";
				Statement stmt         = null;
				ResultSet rsApt        = null;

				stmt = connSrc.createStatement();
				AppointmentsBean objAptBean = new AppointmentsBean();

				try	{
					st = connSrc.createStatement();
					Appointments objApt = new Appointments();


					strSQL= "SELECT *  FROM Appointment";  

					//strSQL= "SELECT *  FROM Appointment where [appointment_id]=9930";


					rsApt = stmt.executeQuery(strSQL);

					while (rsApt.next()) {
						objAptBean.clearAll();
						objAptBean.incrReadCount(); 

						//Appointment ID
						objAptBean.setLngApt_RecordID_Source(rsApt.getLong("appointment_id"));

						//Facilities
						objAptBean.setStrFacilityID_Source("2");



						//Doctors and resource

						String doc=JUtil.validateString(rsApt.getString("resource_id"));

						if(doc.equals("5") || doc.contains("5")){
							objAptBean.setStrDoctorID_Source("5");
						}else if(doc.equals("4") || doc.contains("4")){
							objAptBean.setStrResourceID_Source("4");
						} 





						//Patient
						String PID = JUtil.validateString(rsApt.getString("patient_id"));
						System.out.println("PID: "+PID);
						objAptBean.setStrPatientID_Source(PID);


						//Date 
						String apptDate=JUtil.validateString(rsApt.getString("start"));
						if(apptDate==null || apptDate=="NULL" || apptDate.equals("") || apptDate.equals("NULL")){

						}else{
							String dateSplited[]=apptDate.split(" ");

							String dateValue=dateSplited[0];
							String startTimeValue=dateSplited[1];
							objAptBean.setStrAptDate_Source(dateValue.substring(5,7)+"/"+dateValue.substring(8,10)+"/"+dateValue.substring(0,4));
							objAptBean.setStrStartTime_Source(startTimeValue);
							System.out.println(objAptBean.getStrAptDate_Source());
						}



						//start time

			         	String startTime=rsApt.getString("Appointment Start Time");
			         	String startTimeSAplit[]=startTime.split(" ");
			         	String startTimeValue=startTimeSAplit[2];
			         	System.out.println(startTimeValue);
			         	objAptBean.setStrStartTime_Source(startTimeValue);






						//objAptBean.setStrAptDate_Source(rsApt.getString("Date"));
						//String time=rsApt.getString("Start Time");
						//String newTime=JLib.AMPM(time);
						//objAptBean.setStrStartTime_Source(newTime);
						//String[] TimeSep=objAptBean.getStrStartTime_Source().split(" ");
						//objAptBean.setStrStartTime_Source(TimeSep[0]);
						//objAptBean.setAMPM(TimeSep[1]);
						//objAptBean.setStrReason_Source(rsApt.getString("Reason Code"));


						//Notes
						//objAptBean.setStrGeneralNotes_Source(rsApt.getString("Notes"));



						//Duration or End Time

						String endTime=JUtil.validateString(rsApt.getString("end"));
						if(endTime==null || endTime=="NULL" || endTime.equals("") || endTime.equals("NULL")){

						}else{
							String endArray[]=endTime.split(" ");
							String endTimeValue=endArray[1];
							objAptBean.setStrEndTime_Source(endTimeValue);
						}


						//String endArray
						//objAptBean.setDuration(rsApt.getString("Duration"));



						//Visit Type

						String visitType=JUtil.validateString(rsApt.getString("Reason Code"));
						if(visitType.equals("")){
							objAptBean.setStrVisitType_Source("Migrated");
						}else{
						objAptBean.setStrVisitType_Source(visitType);
						}

						objAptBean.setStrVisitType_Source("Migrated");




						//Visit Status

						String status=JUtil.validateString(rsApt.getString("Appointment Status"));
						String visitStatus="";
						if(status.equals("Cancelled")){
							visitStatus="CANCS";
						}else if(status.equals("Check In")){
							visitStatus="ARR";
						}else if(status.equals("Check Out")){
							visitStatus="CHK";
						}else if(status.equals("Completed")){
							visitStatus="CHK";
						}else if(status.equals("No show")){
							visitStatus="N/S";
						}else if(status.equals("pending")){
							visitStatus="PEN";
						}else if(status.equals("Rescheduled")){
							visitStatus="R/S";
						} else{
							visitStatus="Migrated";
						}

						objAptBean.setStrStatus_Source("Migrated");






						objAptBean.setStrNotes_Source(JUtil.validateString(rsApt.getString("notes")));

						objApt.insertData(objAptBean, connSrc, connDest);
						objUI.displayStatus("Appointments Read: " + objAptBean.getCntRead() + " ; Added: " + objAptBean.getCntAdd() + " ; Duplicate: " + objAptBean.getCntDup() + " ; Pat not found: " + objAptBean.getCntNoPat() + " ; No Dr: " + objAptBean.getCntNoDr() + " ; No Fac: " + objAptBean.getCntNoFac() + " ; Invalid: " + objAptBean.getCntInv());



					}


					//Excel start...
					try{


						java.io.File file = new java.io.File("AppointmentsCount.xls");
						//file.createNewFile(); //Niteesh
						WorkbookSettings wbs = new WorkbookSettings();
						wbs.setInitialFileSize((int)file.length());		    

						// Workbook workbook = Workbook.getWorkbook(file,wbs);				
						WritableWorkbook workbook = Workbook.createWorkbook(file, wbs);

						workbook.createSheet("Apt", 0);

						WritableSheet excelsheet = workbook.getSheet(0);


						WritableFont cellFont1 = new WritableFont(WritableFont.TIMES, 12);
						cellFont1.setColour(Colour.BLUE);

						WritableCellFormat cellFormat1 = new WritableCellFormat(cellFont1);
						cellFormat1.setBackground(Colour.LIGHT_GREEN);
						cellFormat1.setBorder(Border.ALL, BorderLineStyle.THIN);


						WritableFont cellFont2 = new WritableFont(WritableFont.TIMES, 12);			    
						WritableCellFormat cellFormat2 = new WritableCellFormat(cellFont2);			    
						cellFormat2.setBorder(Border.ALL, BorderLineStyle.THIN);

						WritableFont cellFont3 = new WritableFont(WritableFont.TIMES, 14);			    
						WritableCellFormat cellFormat3 = new WritableCellFormat(cellFont3);		

						excelsheet.setColumnView(1, 50);
						excelsheet.setColumnView(2, 20);


						Calendar currentDate = Calendar.getInstance();
						SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy HH:mm");
						String dateNow = formatter.format(currentDate.getTime());

						excelsheet.addCell(new Label(1,3,"Appointments loading Statistics",cellFormat3));
						excelsheet.addCell(new Label(2,3,dateNow,cellFormat3));


						excelsheet.addCell(new Label(1,5,"Description",cellFormat1));
						excelsheet.addCell(new Label(2,5,"Total Records",cellFormat1));

						excelsheet.addCell(new Label(1,6," Appointments Read: ",cellFormat2));
						excelsheet.addCell(new Number(2,6, objAptBean.getCntRead(),cellFormat2));

						excelsheet.addCell(new Label(1,7," Appointments Migrated: ",cellFormat2));
						excelsheet.addCell(new Number(2,7, objAptBean.getCntAdd(),cellFormat2));

						excelsheet.addCell(new Label(1,8," Patient not found: ",cellFormat2));
						excelsheet.addCell(new Number(2,8, objAptBean.getCntNoPat(),cellFormat2));

						excelsheet.addCell(new Label(1,9," Doctor not found: ",cellFormat2));
						excelsheet.addCell(new Number(2,9, objAptBean.getCntNoDr(),cellFormat2));

						excelsheet.addCell(new Label(1,10," Duplicate Appointments: ",cellFormat2));
						excelsheet.addCell(new Number(2,10, objAptBean.getCntDup(),cellFormat2));

						workbook.write();
						workbook.close();

					}
					catch(Exception e)	{
						System.err.println(e.toString());
						// return(e.getMessage());
						//throw e;
					}
					finally	{

					}

					//Excel End ...


				}catch(Exception e)	{
					objUI.displayProgress("Appointments:" + e.toString());
					JUtil.logExceptions(e);
				}
				finally	{
					rsApt.close();
					stmt.close();	

				}

				JUtil.PROCESS_EndTime = new Date();

				System.out.println("Start Time: " + JUtil.PROCESS_startTime );
				System.out.println("End Time: " + JUtil.PROCESS_EndTime );


				objUI.displayProgress( "AppointmentsRead: " + objAptBean.getCntRead() + "; Added: " + objAptBean.getCntAdd() + "; Duplicate: " + objAptBean.getCntDup() + "; Pat not found: " + objAptBean.getCntNoPat() + "; No Dr: " + objAptBean.getCntNoDr() + "; No Fac: " + objAptBean.getCntNoFac() + " ; Invalid: " + objAptBean.getCntInv());
			}
	 */

	private void addServicePackage(Connection connSrc, Connection connDest,PMMigUI objUI) throws SQLException, IOException {
		String strSQL = "";
		String strSQL2 = "";
		Statement stmt = null;
		Statement stmt2 = null;
		ResultSet rsUsr = null;
		ResultSet rsUsr2 = null;
		stmt = connSrc.createStatement();
		stmt2 = connSrc.createStatement();
		ArrayList<String> BedList =null;
		InsertSponsorMaster sponsorService =  new InsertSponsorMaster();
		ServiceChargesBean SCBean = new ServiceChargesBean();
		try
		{
			objUI.displayProgress("Started at: "+new Date());

			strSQL = "Select * from SponsorMaster Order by ID";

			rsUsr = stmt.executeQuery(strSQL);			
			//int c=1;
			while (rsUsr.next()) {
				SCBean.clearall();
				System.out.println(rsUsr.getString("ID"));
				SCBean.setSponsorName(JUtil.validateString(rsUsr.getString("SponsorName")));
				SCBean.setSponsorID(JLib.getSponsorIdByName(SCBean.getSponsorName(), connDest)+"");
				SCBean.setServiceName(JUtil.validateString(rsUsr.getString("ServiceName")));
				SCBean.setServiceId(JLib.getServiceIdByName(SCBean.getServiceName(), connDest)+"");
				SCBean.setSponsorServiceName(JUtil.validateString(rsUsr.getString("SponsorServiceName")));
				SCBean.setSponsorServiceCode(JUtil.validateString(rsUsr.getString("SponsorServiceCode")));
				//Insert
				sponsorService.insertData(SCBean, connSrc, connDest);
				objUI.displayStatus("SponsorServiceName: Added: " + SCBean.getAddCount() + " , Duplicate: " + SCBean.getDupCount() + " , Invalid: " + SCBean.getInvCount());
			}



		}catch(Exception e) {
			e.printStackTrace();
			JUtil.logExceptions(e);
		}
		finally {
			rsUsr.close();
			stmt.close();
		}
		objUI.displayProgress("Ended at: "+new Date());
		JUtil.appendToFile("Report.csv", "SponsorServiceName: Added: " + SCBean.getAddCount() + " , Duplicate: " + SCBean.getDupCount() + " , Invalid: " + SCBean.getInvCount());
		objUI.displayStatus("SponsorServiceName: Added: " + SCBean.getAddCount() + " , Duplicate: " + SCBean.getDupCount() + " , Invalid: " + SCBean.getInvCount());

	}
	/*private void addVisitType(Connection connSrc, Connection connDest,PMMigUI objUI) throws SQLException {

			//This method is used to create new visit Type

			String strSQL = "";
			Statement stmt = null;
			ResultSet rsVst = null;
			stmt = connSrc.createStatement();

			VisitTypeBean objVisitTypeBean = new VisitTypeBean();
			VisitType objVisttype = new VisitType();

			try
			{

				Users objUsr = new Users();
				Provider objPrv = new Provider();
				strSQL = "Select * from Visit_Type where Create_new = '1'";

				rsVst = stmt.executeQuery(strSQL);			

				while (rsVst.next()) 
				{	
					objVisitTypeBean.clearAll();

					String name = rsVst.getString("ClientVisitCode");
					name = JLib.Left(name, 10);System.out.println(name);
					String description =rsVst.getString("Description");
					description = "Mig- " + description;
					objVisitTypeBean.setStrVName(name);
					objVisitTypeBean.setStrVDescription(JUtil.validateString(description));

					objVisttype.insertData(objVisitTypeBean, connSrc, connDest);

					objUI.displayStatus("VisitType: Added: " + objVisitTypeBean.getAddCount() + " , Duplicate: " + objVisitTypeBean.getDupCount() + " , Invalid: " + objVisitTypeBean.getInvCount());

				}

			}catch(Exception e) {
				e.printStackTrace();
				objUI.displayProgress("VisitType: " + e.toString());
				JUtil.logExceptions(e);
			}
			finally {
				rsVst.close();
				stmt.close();
			}

			objUI.displayStatus("VisitType: Added: " + objVisitTypeBean.getAddCount() + " , Duplicate: " + objVisitTypeBean.getDupCount() + " , Invalid: " + objVisitTypeBean.getInvCount());

		}

	 */





	//Visit Status


	/*private void addVisitStatus(Connection connSrc, Connection connDest,PMMigUI objUI) throws SQLException {
			//This method is used to create new visit Status

			String strSQL = "";
			Statement stmt = null;
			ResultSet rsVst = null;
			stmt = connSrc.createStatement();

			VisitStatusBean objVisitStatusBean = new VisitStatusBean();
			VisitStatus objVisitStatus = new VisitStatus();

			try
			{

				Users objUsr = new Users();
				Provider objPrv = new Provider();
				strSQL = "Select * from Visit_Status where Create_new = '1'";

				rsVst = stmt.executeQuery(strSQL);			

				while (rsVst.next()) 
				{	
					System.out.println("hi");
					objVisitStatusBean.clearAll();

					String code = rsVst.getString("ClientVisitStatusCode");
					String Status =rsVst.getString("Description");
					Status = "Mig- " + Status;
					objVisitStatusBean.setStrVisitCode(JUtil.validateString(code));
					objVisitStatusBean.setStrVisitstatus(JUtil.validateString(Status));

					objVisitStatus.insertData(objVisitStatusBean, connSrc, connDest);

					objUI.displayStatus("Visit Status: Added: " + objVisitStatusBean.getAddCount() + " , Duplicate: " + objVisitStatusBean.getDupCount() + " , Invalid: " + objVisitStatusBean.getInvCount());
				}

			}catch(Exception e) {
				e.printStackTrace();
				objUI.displayProgress("Visit Status: " + e.toString());
				JUtil.logExceptions(e);
			}
			finally {
				rsVst.close();
				stmt.close();
			}

			objUI.displayStatus("Visit Status: Added: " + objVisitStatusBean.getAddCount() + " , Duplicate: " + objVisitStatusBean.getDupCount() + " , Invalid: " + objVisitStatusBean.getInvCount());


		}


	 */

















	//Add Guarantor Employer
	/*private void addGuarantorEmployers(Connection connSrc, Connection connDest,PMMigUI objUI) throws SQLException {
			String strSQL = "";
			String strSQL2 = "";

			String employer="";
			String name="";
			String[] flname=null;
			Statement stmt = null;
			Statement stmt2 = null;
			Statement stmt3 = null;
			Statement stmt4 = null;
			Statement stmt5 = null;
			Statement stmt6 = null;
			PreparedStatement stmt7 = null;
			PreparedStatement pstmt=null;

			ResultSet rsUsr = null;
			ResultSet rsUsr2 = null;
			ResultSet rsUsr3 = null;
			ResultSet rsUsr4 = null;
			ResultSet rsUsr5 = null;
			ResultSet rsUsr6 = null;
			ResultSet rs = null;

			//SOURCE
			stmt = connSrc.createStatement();
			stmt2 = connSrc.createStatement();
			stmt3 = connSrc.createStatement();

			//DESTINATION
			stmt4 = connDest.createStatement();
			stmt5 = connDest.createStatement();
			stmt6 = connDest.createStatement();
			//stmt7 = connDest.createStatement();
			int i=0,j=0,k=0;
			System.out.println("hereee");

			EmployerBean objEmpBean=new EmployerBean();
			try{


				String empyrName="";
				String empyrAddress="";
				String empyrAddress2="";
				String empyrCity="";
				String empyrState="";
				String empyrZip="";
				String empPhone="";
				strSQL = "SELECT * FROM Guarantor where [Employer Name]<>''";
				rsUsr = stmt.executeQuery(strSQL);
				String Lang="";
				Employer objEmp=new Employer();

				String empName="";
				while (rsUsr.next()) {
					empName=JUtil.validateString(rsUsr.getString("Employer Name"));
					objEmpBean.setStrEmpName(empName);
					objEmpBean.setStrempAddress1(JUtil.validateString(rsUsr.getString("Employer Address 1")));
					objEmpBean.setStrempAddress2(JUtil.validateString(rsUsr.getString("Employer Address 2")));
					objEmpBean.setStrempCity(JUtil.validateString(rsUsr.getString("Employer City")));
					objEmpBean.setStrempState(JUtil.validateString(rsUsr.getString("Employer State")));
					objEmpBean.setStrempZip(JUtil.validateString(rsUsr.getString("Employer Zip")));

					objEmp.insertData(objEmpBean, connSrc, connDest);
					objUI.displayStatus("Employers: Added: " + i + " ; Duplicates: " + j + " ; Invalid: " + k);
					i++;
				}{
					j++;
				}


			}catch(Exception e){
				e.printStackTrace();
				JUtil.logExceptions(e);

			}finally{
				rsUsr.close();


			}
			objUI.displayStatus("Employers: Added: " + i + " ; Duplicates: " + j + " ; Invalid: " + k);		



		}
	 */

	//Add Employer
	/*private void addEmployer(Connection connSrc, Connection connDest,PMMigUI objUI) throws SQLException {
			String strSQL = "";
			String strSQL2 = "";

			String employer="";
			String name="";
			String[] flname=null;
			Statement stmt = null;
			Statement stmt2 = null;
			Statement stmt3 = null;
			Statement stmt4 = null;
			Statement stmt5 = null;
			Statement stmt6 = null;
			PreparedStatement stmt7 = null;
			PreparedStatement pstmt=null;

			ResultSet rsUsr = null;
			ResultSet rsUsr2 = null;
			ResultSet rsUsr3 = null;
			ResultSet rsUsr4 = null;
			ResultSet rsUsr5 = null;
			ResultSet rsUsr6 = null;
			ResultSet rs = null;

			//SOURCE
			stmt = connSrc.createStatement();
			stmt2 = connSrc.createStatement();
			stmt3 = connSrc.createStatement();

			//DESTINATION
			stmt4 = connDest.createStatement();
			stmt5 = connDest.createStatement();
			stmt6 = connDest.createStatement();
			//stmt7 = connDest.createStatement();
			int i=0,j=0,k=0;
			System.out.println("hereee");

			EmployerBean objEmpBean=new EmployerBean();
			try{



				strSQL = "SELECT * FROM Employer where name<>''";
				rsUsr = stmt.executeQuery(strSQL);
				String Lang="";
				Employer objEmp=new Employer();

				String empName="";
				while (rsUsr.next()) {
					empName=JUtil.validateString(rsUsr.getString("name"));
					objEmpBean.setStrEmpName(empName);


						objEmpBean.setStrempAddress1(JUtil.validateString(rsUsr.getString("Address1")));
						objEmpBean.setStrempAddress2(JUtil.validateString(rsUsr.getString("Address2")));
						objEmpBean.setStrempCity(JUtil.validateString(rsUsr.getString("City")));
						objEmpBean.setStrempState(JUtil.validateString(rsUsr.getString("State")));
						objEmpBean.setStrempZip(JUtil.validateString(rsUsr.getString("Zip")));
						objEmpBean.setStrempPhone(JUtil.validateString(rsUsr.getString("Phone1")));


					objEmp.insertData(objEmpBean, connSrc, connDest);
					objUI.displayStatus("Employers: Added: " + i + " ; Duplicates: " + j + " ; Invalid: " + k);
					i++;
				}{
					j++;
				}


			}catch(Exception e){
				e.printStackTrace();
				JUtil.logExceptions(e);

			}finally{
				rsUsr.close();


			}
			objUI.displayStatus("Employers: Added: " + i + " ; Duplicates: " + j + " ; Invalid: " + k);		



		}
	 */






	//Add Relation
	/*private void addRelation(Connection connSrc, Connection connDest,PMMigUI objUI) throws SQLException 
		{
			String strSQL = "";
			String strSQL2 = "";
			String strSQL3 = "";
			String strSQL4 = "";

			Statement stmt = null;
			Statement stmt2 = null;
			Statement stmt3 = null;
			Statement stmt4 = null;

			ResultSet rsUsr = null;
			ResultSet rsUsr2 = null;
			ResultSet rsUsr3 = null;
			ResultSet rsUsr4 = null;

			stmt = connSrc.createStatement();
			stmt2 = connDest.createStatement();
			stmt3 = connDest.createStatement();

			String chartNo="";
			String guarantor="";
			int grid=0;
			int pid=0;
			int isGrPt=0;
			int userType=0;
			int i=0,j=0;
			//stmt2 = connSrc.createStatement();
			//stmt3 = connSrc.createStatement();
			stmt4 = connDest.createStatement();
			System.out.println("ADD RELATION");
			PatientsBean SCBean = new PatientsBean();
			//select distinct[chart number],[Guarantor]  from mwcas where [chart number]<>[Guarantor]
			String relation="";
			try{
				//strSQL="SELECT * FROM dbo_uvPatientDemographics WHERE  PatientSameAsGuarantor=0 and PatientRelationToGuarantor<>'Self'";

				strSQL="SELECT * FROM PatientDemographics WHERE [Relation to Guarantor]<>''";
				//strSQL="SELECT * FROM dbo_uvPatientDemographics where [PatientProfileId]='1454'";
				//strSQL="select *  from Patient where [Chart Number]='100200'";  1454
				rsUsr=stmt.executeQuery(strSQL);
				while(rsUsr.next())
				{

					chartNo="";
					guarantor="";
					grid=0;
					pid=0;
					isGrPt=0;
					userType=0;

					chartNo=rsUsr.getString("Patient ID");

					//guarantor=rsUsr.getString("GuarantorId");

					relation=JUtil.validateString(rsUsr.getString("Relation to Guarantor"));

					String relConvert=JUtil.convertRel(relation);


					grid = JLib.getUidByVmid("Gr-"+chartNo, connDest);
					if(grid==0){
						grid = JLib.getUidByVmidFromMdb(chartNo, connSrc);
						//System.out.println("GRID for Guarantor= "+guarantor+" FROM MDB= "+grid);
					}
					if(grid==0){
						grid=JLib.getUidByVmid("Pat-"+chartNo, connDest);
					}

					pid = JLib.getUidByVmid("Pat-"+chartNo, connDest);




					//System.out.println(grid+"=GRID , PID="+pid);


					userType=JLib.getUserTypeByUid(grid, connDest);
					System.out.println("UT="+userType);
					if(grid!=0 && grid!=pid){
						if(userType==4){
							System.out.println("here");

							strSQL3="UPDATE patients SET isgrpt=0,GrRel='"+relConvert+"' , Grid='"+grid+"' where pid='"+pid+"'";
							System.out.println(strSQL3);
							stmt3.executeUpdate(strSQL3);
							i++;

						}else{
							strSQL2="UPDATE patients SET GrRel='"+relConvert+"', isgrpt=0,Grid="+grid+" where pid='"+pid+"'";
							System.out.println(strSQL2);
							stmt4.executeUpdate(strSQL2);

							i++;
						}

					}
					else
					{
						j++;
						System.out.println( "Not Addes: " + j + " , chartNo: " + chartNo+ " , GUARANTOR: " +guarantor);
					}

					objUI.displayStatus("Relation: Added: " + i + " , Not Addes: " + j);

				}


			}
			catch(Exception e){
				e.printStackTrace();
			}

		}

	 */


	/*private void addFacility (Connection connSrc, Connection connDest, PMMigUI objUI) throws SQLException {

			String strSQL = "";
			Statement stmt = null;
			ResultSet rsFac = null;
			stmt = connSrc.createStatement();


			String strSQL1 = "";
			Statement stmt1 = null;
			ResultSet rsFac1 = null;
			stmt1 = connSrc.createStatement();



			FacilityBean objFacBean = new FacilityBean();

			try {

				Facility  objFac = new Facility();

				strSQL = "select * from Facility where [name]<>''";

				int i = 0;

				rsFac = stmt.executeQuery(strSQL);

				while (rsFac.next()) {

					objFacBean.clearAll();

					String facId=JUtil.validateString(rsFac.getString("facility_id"));
					objFacBean.setStrvmid("Fac-"+facId );
					objFacBean.setStrName(JUtil.validateString(rsFac.getString("name")));
					objFacBean.setStrTel(JUtil.validateString(rsFac.getString("phone")));


					objFacBean.setStrAddressLine1(JUtil.validateString(rsFac.getString("Address1")));
					objFacBean.setStrAddressLine2(JUtil.validateString(rsFac.getString("Address2")));
					objFacBean.setStrCity(JUtil.validateString(rsFac.getString("City")));
					objFacBean.setStrState(JUtil.validateString(rsFac.getString("State")));
					objFacBean.setStrZip(JUtil.validateString(rsFac.getString("Zip")));

					objFacBean.setStrFax(JUtil.validateString(rsFac.getString("Phone2")));
					objFacBean.setStrFederalTaxID(JUtil.validateString(rsFac.getString("FederalTaxId")));
					objFacBean.setStrNPI(rsFac.getString("NPI"));




					//objFacBean.setPOS(rsFac.getInt("LOC_POS_NUMBER"));
					//objFacBean.setStrCliaId(JUtil.validateString(rsFac.getString("Extra 2")));

					//Fedral Tax id
					//objFacBean.setStrFederalTaxID(JUtil.validateString(rsFac.getString("FederalTaxId")));
					//objFacBean.setStrNPI(rsFac.getString("National Provider Identifier"));
					//objFacBean.setStrTaxonomyCode(rsFac.getString("taxonomy_code"));

					objFac.insertData(objFacBean, connSrc, connDest);
					objUI.displayStatus("Facility: Added: " + objFacBean.getAddCount() + " , Duplicate: " + objFacBean.getDupCount() + " , Invalid: " + objFacBean.getInvCount());

				}



				strSQL1 = "select * from mwpra";
				rsFac1 = stmt1.executeQuery(strSQL1);

				while (rsFac1.next()) {
					objFacBean.clearAll();
					objFacBean.setStrvmid("Fac-" + rsFac1.getString("ID"));


					objFacBean.setStrName(JUtil.validateString(rsFac1.getString("Practice Name")));
					objFacBean.setStrCity(JUtil.validateString(rsFac1.getString("City")));
					objFacBean.setStrState(JUtil.validateString(rsFac1.getString("State")));
					objFacBean.setStrAddressLine1(JUtil.validateString(rsFac1.getString("Street 1")));
					objFacBean.setStrAddressLine2(JUtil.validateString(rsFac1.getString("Street 2")));
					objFacBean.setStrTel(JUtil.validateString(rsFac1.getString("Phone"))); 
					objFacBean.setStrZip(JUtil.validateString(rsFac1.getString("Zip Code")));
					objFacBean.setStrFax(JUtil.validateString(rsFac1.getString("Fax")));
					objFacBean.setStrFederalTaxID(JUtil.validateString(rsFac1.getString("Federal Tax ID")));



					//objFacBean.setPOS(rsFac1.getInt("LOC_POS_NUMBER"));
					//objFacBean.setStrCliaId(JUtil.validateString(rsFac1.getString("Extra 2")));

					//objFacBean.setStrFederalTaxID(JUtil.validateString(rsFac1.getString("LOC_TAX_ID_2")));
					//objFacBean.setStrNPI(rsFac1.getString("National Provider Identifier"));
					//objFacBean.setStrTaxonomyCode(rsFac1.getString("taxonomy_code"));

					objFac.insertData(objFacBean, connSrc, connDest);
				}



			} catch(Exception e) {
				e.printStackTrace();
				objUI.displayProgress("Facility : " + e.toString());
				JUtil.logExceptions(e);
			}
			finally {
				rsFac.close();
				stmt.close();
			}

			objUI.displayStatus("Facility: " + objFacBean.getAddCount() + "-" + objFacBean.getDupCount() + "-" + objFacBean.getInvCount());




		}

	 */
	/*private void addDoctors(Connection connSrc, Connection connDest,PMMigUI objUI) throws SQLException {
			// TODO Auto-generated method stub	

			String strSQL = "";

			String strSQL2 = "";

			Statement stmt = null;

			Statement stmt2 = null;

			ResultSet rsUsr = null;

			ResultSet rsUsr2 = null;

			stmt = connSrc.createStatement();

			stmt2 = connSrc.createStatement();

			ProviderBean SCBean = new ProviderBean();
			try
			{

				Users objUsr = new Users();
				Provider objPrv = new Provider();
				strSQL="";


				strSQL = "Select * from User where isprovider='1' and isinactive='0'";

				rsUsr = stmt.executeQuery(strSQL);			
				//int c=1;
				while (rsUsr.next()) {	
					SCBean.clearall();
					SCBean.clearallUsers();
					//SCBean.set
					//SCBean.setFacVmid(rsUsr.getString("code"));

					String c=rsUsr.getString("user_id");
					SCBean.setVmid("Dr-" + c);

					SCBean.setUfname(JUtil.validateString(rsUsr.getString("firstname")));

					SCBean.setUlname(JUtil.validateString(rsUsr.getString("lastname")));


					SCBean.setSuffix(JUtil.validateString(rsUsr.getString("suffix")));
					SCBean.setUname(SCBean.getUfname() + JLib.Left(SCBean.getUlname(),1));
					SCBean.setSpecialty(JUtil.validateString(rsUsr.getString("speciality"))); 
					SCBean.setDeano(JUtil.validateString(rsUsr.getString("dea")));
					SCBean.setStLicNo(JUtil.validateString(rsUsr.getString("state_license")));
					SCBean.setNPI(JUtil.validateString(rsUsr.getString("national_provider_id")));
					SCBean.setTaxid(JUtil.validateString(rsUsr.getString("federal")));


					SCBean.setUfname(JUtil.validateString(rsUsr.getString("First")));
					SCBean.setUminitial(JUtil.validateString(rsUsr.getString("Middle")));
					SCBean.setUlname(JUtil.validateString(rsUsr.getString("Last")));

					SCBean.setSuffix(JUtil.validateString(rsUsr.getString("Suffix")));




					SCBean.setUpaddress(JUtil.validateString(rsUsr.getString("Address1")));
					SCBean.setUpcity(JUtil.validateString(rsUsr.getString("City")));
					SCBean.setUpstate(JUtil.validateString(rsUsr.getString("State")));
					SCBean.setZipcode(JUtil.validateString(rsUsr.getString("Zip")));
					SCBean.setUpphone(JUtil.validateString(rsUsr.getString("Phone1")));
					SCBean.setFaxno(JUtil.validateString(rsUsr.getString("Phone2")));

					SCBean.setTaxidtype(JUtil.validateString(rsUsr.getString("FederalTaxIdType")));
					SCBean.setSpLicNo(JUtil.validateString(rsUsr.getString("Ledger")));


					//SCBean.setSsn(rsUsr.getString("SSN or Fed Tax ID").intern());
					//SCBean.setSsn(JUtil.validateString(SCBean.getTaxid()));
					//SCBean.setUpin(JUtil.validateString(rsUsr.getString("UPIN")));
					//
					//SCBean.setTaxonomycode(JUtil.validateString(rsUsr.getString("Taxonomy_Code")));


					objUsr.insertData(SCBean, connSrc, connDest, 1);
					if (!(SCBean.getUID()==0)){
						objPrv.insertData(SCBean, connSrc, connDest, SCBean.getUID());	            	            
					}
					objUI.displayStatus("Providers: Added: " + SCBean.getAddCount() + " , Duplicate: " + SCBean.getDupCount() + " , Invalid: " + SCBean.getInvCount());

				}



			}catch(Exception e) {
				e.printStackTrace();
				objUI.displayProgress("Providers : " + e.toString());
				JUtil.logExceptions(e);
			}
			finally {
				rsUsr.close();
				stmt.close();
			}

			objUI.displayStatus("Providers: Added: " + SCBean.getAddCount() + " , Duplicate: " + SCBean.getDupCount() + " , Invalid: " + SCBean.getInvCount());

		}

	 */




	/*private void addResource(Connection connSrc, Connection connDest,PMMigUI objUI) throws SQLException {
			String strSQL = "";
			Statement stmt = null;
			ResultSet rsUsr = null;
			stmt = connSrc.createStatement();

			ProviderBean SCBean = new ProviderBean();

			try
			{

				Users objUsr = new Users();
				Provider objPrv = new Provider();
				strSQL = "Select * from Resource";

				rsUsr = stmt.executeQuery(strSQL);			

				while (rsUsr.next()) {	
					SCBean.clearall();
					SCBean.clearallUsers();

					SCBean.setVmid("Res-" + rsUsr.getString("resource_id"));

					SCBean.setUfname(JUtil.validateString(rsUsr.getString("name")));
					SCBean.setUlname("Resource");

					SCBean.setUname(SCBean.getUfname());

					objUsr.insertData(SCBean, connSrc, connDest, 9);
					if (!(SCBean.getUID()==0))
					{
						objPrv.insertData(SCBean, connSrc, connDest, SCBean.getUID());	            	            
					}
					objUI.displayStatus("Resources: Added: " + SCBean.getAddCount() + " , Duplicate: " + SCBean.getDupCount() + " , Invalid: " + SCBean.getInvCount());

				}

			}catch(Exception e) {
				e.printStackTrace();
				objUI.displayProgress("Resources: " + e.toString());
				JUtil.logExceptions(e);
			}
			finally {
				rsUsr.close();
				stmt.close();
			}

			objUI.displayStatus("Resources: Added: " + SCBean.getAddCount() + " , Duplicate: " + SCBean.getDupCount() + " , Invalid: " + SCBean.getInvCount());

		}

	 */









	/*private void addRefProviders(Connection connSrc, Connection connDest,PMMigUI objUI) throws SQLException {
			// TODO Auto-generated method stub	
			String strSQL = "";
			Statement stmt = null;
			ResultSet rsUsr = null;
			stmt = connSrc.createStatement();


			String strSQL1 = "";
			Statement stmt1 = null;
			ResultSet rsUsr1 = null;
			stmt1 = connSrc.createStatement();


			ProviderBean SCBean = new ProviderBean();

			String temp2[];
			String temp[];
			String licno[];



			try
			{

				Users objUsr = new Users();
				Provider objPrv = new Provider();
				strSQL="";


				strSQL = "Select * from referralsAddress";  
				//strSQL = "Select * from dbo_DoctorFacility where DoctorFacilityId='215'";
				rsUsr = stmt.executeQuery(strSQL);			

				while (rsUsr.next()) {	
					SCBean.clearall();
					SCBean.clearallUsers();

					String c="";
					String upin[];
					String notes = "";

					c=JUtil.validateString(rsUsr.getString("referrals_id"));
					SCBean.setVmid("Ref-" + c);


					SCBean.setUfname(JUtil.validateString(rsUsr.getString("first")));
					//SCBean.setUminitial(JUtil.validateString(rsUsr.getString("Middle Name")));
					SCBean.setUlname(JUtil.validateString(rsUsr.getString("last")));
					SCBean.setUname(SCBean.getUfname() + JLib.Left(SCBean.getUlname(),1));
					SCBean.setSuffix(JUtil.validateString(rsUsr.getString("suffix"))); 
					//
					//SCBean.setUpaddress2(JUtil.validateString(rsUsr.getString("address2")));

					SCBean.setUpphone(JUtil.validateString(rsUsr.getString("phone2")));
					SCBean.setTaxonomycode(JUtil.validateString(rsUsr.getString("taxonomy")));
					SCBean.setMedicareNo(JUtil.validateString(rsUsr.getString("id_medicare")));
					//SCBean.setFaxno(JUtil.validateString(rsUsr.getString("Fax")));
					//SCBean.setTaxid(JUtil.validateString(rsUsr.getString("FederalTaxId")));
					//SCBean.setTaxidtype(JUtil.validateString(rsUsr.getString("FederalTaxIdType")));
					//SCBean.setSpLicNo(JUtil.validateString(rsUsr.getString("Ledger")));
					//SCBean.setNPI(JUtil.validateString(rsUsr.getString("NPI")));

					SCBean.setUpaddress(JUtil.validateString(rsUsr.getString("address1")));
					SCBean.setUpaddress2(JUtil.validateString(rsUsr.getString("address2")));




					SCBean.setNPI(JUtil.validateString(rsUsr.getString("id_nationalprovider")));
					//SCBean.setTaxid(JUtil.validateString(rsUsr.getString("SSN or Fed Tax ID")));
					//SCBean.setSsn(rsUsr.getString("SSN or Fed Tax ID").intern());
					//SCBean.setSsn(JUtil.validateString(SCBean.getTaxid()));


					//SCBean.setDeano(JUtil.validateString(rsUsr.getString("DEA Registration")));

					String citystatezip_id=JUtil.validateString(rsUsr.getString("citystatezip_id"));
					strSQL1="select * from Citystatezip where [citystatezip_id]='"+citystatezip_id+"'";
					rsUsr1=stmt1.executeQuery(strSQL1);
					if(rsUsr1!=null){
						if(rsUsr1.next()){

							SCBean.setUpcity(JUtil.validateString(rsUsr1.getString("city")));
							SCBean.setUpstate(JUtil.validateString(rsUsr1.getString("state")));
							SCBean.setZipcode(JUtil.validateString(rsUsr1.getString("zip")));
						}
					}

					SCBean.setUpcity(JUtil.validateString(rsUsr.getString("city")));
					SCBean.setUpstate(JUtil.validateString(rsUsr.getString("state")));
					SCBean.setZipcode(JUtil.validateString(rsUsr.getString("zip")));


					objUsr.insertData(SCBean, connSrc, connDest, 5);
					if (!(SCBean.getUID()==0)){
						objPrv.insertData(SCBean, connSrc, connDest, SCBean.getUID());	            	            
					}
					objUI.displayStatus("Referring Provider: Added: " + SCBean.getAddCount() + " , Duplicate: " + SCBean.getDupCount() + " , Invalid: " + SCBean.getInvCount());

				}



			}catch(Exception e) {
				//e.printStackTrace();
				objUI.displayProgress("Referring Provider : " + e.toString());
				JUtil.logExceptions(e);
			}
			finally {
				rsUsr.close();
				stmt.close();
			}

			objUI.displayStatus("Referring Provider: Added: " + SCBean.getAddCount() + " , Duplicate: " + SCBean.getDupCount() + " , Invalid: " + SCBean.getInvCount());

		}
	 */

	/*private void addInsurance(Connection connSrc, Connection connDest, PMMigUI objUI) throws Exception {
			String strSQL = "";
			Statement stmt = null;
			ResultSet rsIns = null;
			stmt = connSrc.createStatement();
			InsuranceBean objInsBean = new InsuranceBean();

			try
			{

				Insurance  objIns = new Insurance();

				strSQL ="Select * from Insurance where insurance_id<>'1'";

				rsIns = stmt.executeQuery(strSQL);

				while (rsIns.next())
				{

					objInsBean.clearAll();
					String c=JUtil.validateString(rsIns.getString("insurance_id"));
					System.out.println(c);
					objInsBean.setStrInsVMID("Ins-" +c );
					objInsBean.setStrName(JUtil.validateString(rsIns.getString("carrier")));
					//objInsBean.setStrAddress1(JUtil.validateString(rsIns.getString("Insurance Address")));
					//objInsBean.setStrAddress2(JUtil.validateString(rsIns.getString("Address2")));
					//objInsBean.setStrCity(JUtil.validateString(rsIns.getString("Insurance City")));
					//objInsBean.setStrState(JUtil.validateString(rsIns.getString("Insurance State")));
					//objInsBean.setStrZip(JUtil.validateString(rsIns.getString("Insurance Zip Code")));
					objInsBean.setStrPhone(JUtil.validateString(rsIns.getString("phone")));
					objInsBean.setStrPayorID(JUtil.validateString(rsIns.getString("payer_id")));
					objInsBean.setStrMediGapID(JUtil.validateString(rsIns.getString("medigap")));



					objIns.insertData(objInsBean, connSrc, connDest);
					objUI.displayStatus("Insurance: Added: " + objInsBean.getAddCount() + " , Duplicate: " + objInsBean.getDupCount() + " , Invalid: " + objInsBean.getInvCount());

				}

			}
			catch(Exception e)
			{
				e.printStackTrace();
				objUI.displayProgress("Insurance : " + e.toString());
				JUtil.logExceptions(e);

			}
			finally
			{
				rsIns.close();
				stmt.close();
			}
			objUI.displayStatus("Insurance: " + objInsBean.getAddCount() + "-" + objInsBean.getDupCount() + "-" + objInsBean.getInvCount());
		}
	 */

	/*private void addPatients (Connection connSrc, Connection connDest,PMMigUI objUI) throws SQLException {

			String strSQL = "";
			String strSQL2 = "";
			String strSQL3 = "";
			String strSQL4 = "";
			String strSql5="";
			String asgndPrSQL="";
			String pcpSQL="";

			String assignedProvider="";
			String pcp="";
			String employer="";
			java.sql.PreparedStatement stmtPr =null;

			int assignedPrId = 0;
			int pcpId = 0;
			int defFeeschid=0;
			Statement stmt = null;
			Statement destStmt = null;
			Statement stmt2 = null;
			Statement stmt3 = null;
			Statement stmt4 = null;
			Statement stmt5 = null;
			Statement stmt6 = null;

			ResultSet rsUsr = null;
			ResultSet destUsr = null;
			ResultSet rsUsr2 = null;
			ResultSet rsUsr3 = null;
			ResultSet rsUsr4 = null;
			ResultSet rsUsr5 = null;
			ResultSet rsUsr6 = null;

			//SOURCE
			stmt = connSrc.createStatement();
			destStmt = connDest.createStatement();
			stmt2 = connSrc.createStatement();
			stmt3 = connSrc.createStatement();
			stmt4 = connSrc.createStatement();
			stmt5 = connSrc.createStatement();

			//DESTINATION


			stmt6 = connDest.createStatement();
			PatientsBean SCBean = new PatientsBean();

			String facility="";
			String patEmployer="";


			String insNotes="";
			String insTemp="";




			String strSQL10 = "";
			Statement stmt10 = null;
			ResultSet rs10 = null;
			stmt10 = connSrc.createStatement();

			String strSQL11="";
			Statement stmt11 = null;
			ResultSet rs11 = null;
			stmt11 = connSrc.createStatement();


			String strSQL12 = "";
			Statement stmt12 = null;
			ResultSet rs12 = null;
			stmt12 = connSrc.createStatement();


			String strSQL13 = "";
			Statement stmt13 = null;
			ResultSet rs13 = null;
			stmt13 = connSrc.createStatement();




			String notes="";
			String temp="";


			stmt.executeUpdate("DELETE from duppat");
			try {

				Users objUsr = new Users();
				Patients objPat = new Patients();
				strSQL = "";
				String strSQL1 = "";
				int contNo=10000; //control number if new ecw account numbers has to be set

				strSQL = "SELECT  * from PatPersonJoinTable";  // 7992
				//strSQL = "SELECT  * from PatPersonJoinTable where [patient_id]='2'";




				rsUsr = stmt.executeQuery(strSQL);
				String sexValue="";
				String sex="";
				String dob="";
				String[]  dateBirth=null;
				String DateOfBirth="";
				while (rsUsr.next()) {

					SCBean.clearall();
					SCBean.clearallUsers();
					String patid= rsUsr.getString("patient_id").intern(); //Patient ID
					System.out.println("Patient: "+patid);



					//Inactive
					String Inactive=JUtil.validateString(rsUsr.getString("PatientInactive"));
					if(Inactive=="1" || Inactive.equals("1")){
						SCBean.setStatus("1");
					} else if(Inactive=="0" || Inactive.equals("0")){
						SCBean.setStatus("0");
					}else{
						SCBean.setStatus("0");
					}



					//Control Number
					SCBean.setControlNo(""+contNo);
					contNo++;


					//Vmid
					SCBean.setVmid("Pat-" + patid); //VMID




					//MRN
					SCBean.setMrn(JUtil.validateString(rsUsr.getString("chart_num"))); //old patient id goes to MRN in front-end  cos we didnt find mrn


					//Deceased

					String deathDate=JUtil.validateString(rsUsr.getString("PatientDeathDate"));
					if(deathDate==null || deathDate=="" || deathDate.equals("") || deathDate.equals("NULL")){

					}else{
						SCBean.setDeceased("1");
					}



					//Patient fnamme,lname,mname

					String lname =JUtil.validateString(rsUsr.getString("last"));
					String fname = JUtil.validateString(rsUsr.getString("first"));
					String mname = JUtil.validateString(rsUsr.getString("middle"));

					if (fname != null)
						SCBean.setUfname(fname);
					if (lname != null)
						SCBean.setUlname(lname);
					if (mname != null)
						SCBean.setUminitial(mname);

					//suffix
					//SCBean.setSuffix(JUtil.validateString(rsUsr.getString("PatientSuffix")));


					//Address
					String address_id=JUtil.validateString(rsUsr.getString("address_id"));
					strSQL2="select * from Address where address_id='"+address_id+"'";
					rsUsr2=stmt2.executeQuery(strSQL2);
					if(rsUsr2!=null){
						if(rsUsr2.next()){
							SCBean.setUpaddress(JUtil.validateString(rsUsr2.getString("address1")));
							SCBean.setUpaddress2(JUtil.validateString(rsUsr2.getString("address2")));
							String cityStateZip=JUtil.validateString(rsUsr2.getString("citystatezip_id"));
							strSQL3="select * from Citystatezip where citystatezip_id='"+cityStateZip+"'";
							rsUsr3=stmt3.executeQuery(strSQL3);
							if(rsUsr3!=null){
								if(rsUsr3.next()){
									String city=JUtil.validateString(rsUsr3.getString("city"));
									if(city.length()>24){
										city=city.substring(0,24);
										SCBean.setUpcity(city);
									}else{
										SCBean.setUpcity(city);
									}
									SCBean.setUpstate(JUtil.validateString(rsUsr3.getString("state")));
									SCBean.setZipcode(JUtil.validateString(rsUsr3.getString("zip")));
								}
							}

						}
					}




					//Country

					String country=JUtil.validateString(rsUsr.getString("PatientCountry"));
					if(country=="" || country==null || country.equals("") || country.equals("null")){
						SCBean.setCountryCode("US");
					}else

					SCBean.setCountryCode("US");


					// Gender
					String gender=JUtil.validateString(rsUsr.getString("pop_sex"));
					SCBean.setSex(JUtil.convertSex(gender));





					// Date Of Birth
					dob = JUtil.validateString(rsUsr.getString("birthday"));

					System.out.println(dob);
					if(dob==null || dob.equals("NULL")){
						dob="";
					}
					if(dob!=""){
						System.out.println(dob);
						String dobValue=dob.substring(5,7)+"/"+dob.substring(8, 10)+"/"+dob.substring(0, 4);
						System.out.println(dobValue);
						SCBean.setDob(dobValue, "MM/dd/yyyy");
						SCBean.setPtDob(dobValue, "MM/dd/yyyy");
					}else{
						SCBean.setDob("", "MM/dd/yyyy");
						SCBean.setPtDob("", "MM/dd/yyyy");
					}




					//UpPhone
					String phone1=JUtil.validateString(rsUsr.getString("phone1")).intern();
					SCBean.setUpphone(phone1);


					//UMObile
					SCBean.setUmobileno(JUtil.validateString(rsUsr.getString("phone2")));

					//Work Phone
					SCBean.setEmployerphone(CommonFunction.convertPhone(JUtil.validateString(rsUsr.getString("phone3")).intern()));


					//SSN
					SCBean.setSsn(CommonFunction.convertSSN(JUtil.validateString(rsUsr.getString("ssn")).intern()));


					//Marital Status

					String mStatus=JUtil.validateString(rsUsr.getString("pop_marital_status"));
					SCBean.setMaritalstatus(JUtil.convertMaritalStatus(mStatus));




					//Email
					SCBean.setUemail(JUtil.validateString(rsUsr.getString("email")));


					// Rendering Provider

					String rendProvider=JUtil.validateString(rsUsr.getString("provider_id"));
					int uid=JLib.getUidByVmid("Dr-"+rendProvider, connDest);
					SCBean.setRendprid(""+uid);


					//PCP   No Data



					//Refering Provider
					//String refProvider=JUtil.validateString(rsUsr.getString("Referring Physician"));

					String refProvider=JUtil.validateString(rsUsr.getString("Referring Physician"));
					if(refProvider==null || refProvider=="" || refProvider.equals("") || refProvider.equals(null)){
					}else{
					String[] refProviderSplited=refProvider.split(",");

					String refLName=refProviderSplited[0];
					String refFName=refProviderSplited[1];

					if(refLName.contains(" ")){
						String refLNameSplited[]=refLName.split(" ");
						refLName=refLNameSplited[0];
					}

					if(refFName.contains(" ")){
						String refFNameSplited[]=refFName.split(" ");
						refFName=refFNameSplited[0];
						if(refFName.equals("")){
							refFName=refFNameSplited[1];
						}else if(refFName.equals("")){
							refFName=refFNameSplited[2];
						}
					}

					int uid=JLib.getRefProviderUidByFname(refFName,connDest);

					if(uid==0){
						 uid=JLib.getProviderUidByFname(refFName,connDest);
					}

					SCBean.setRefPrID(""+uid);
					}


					//Race

					//String race=JUtil.validateString(rsUsr.getString("Race"));
					//SCBean.setRace(JUtil.convertRace(race));

					//Language

					//String language=JUtil.validateString(rsUsr.getString("Preffered Language"));
					//SCBean.setLanguage(JUtil.convertLanguage(language));
					SCBean.setLanguage("English");	


					//Ethnicity
					String ethnicity=JUtil.validateString(rsUsr.getString("ethnicity_id"));
					SCBean.setEthnicity(JUtil.convertEthnicityStatus(ethnicity));



					SCBean.setRelinfo("Y");
					SCBean.setRelinfodate("1900-01-01");
					SCBean.setGrrel("1");


					// Facilities

					SCBean.setDefaultFacility(119);		

					// Notes
					//String patNote=JUtil.validateString(rsUsr.getString("Notes"));
					//SCBean.setNotes("Ref-Provider: "+refProvider+"\n"+patNote);


					// Employers

					//SCBean.setEmployername(rsUsr.getString("Employer Details"));



					objUsr.insertData(SCBean, connSrc, connDest, 3);

					if (!(SCBean.getUID()==0)){

						objPat.insertData(SCBean, connSrc, connDest, SCBean.getUID());	            	            
					}
					objUI.displayStatus("Patients: Added: " + SCBean.getAddCount() + " , Duplicate: " + SCBean.getDupCount() + " , Invalid: " + SCBean.getInvCount());
				}

			} catch (Exception e) {
				e.printStackTrace();
				objUI.displayProgress("Patients : " + e.toString());
				JUtil.logExceptions(e);
			} finally {
				rsUsr.close();
				//			stmt.close();
			}

			objUI.displayStatus("Patients: Added: " + SCBean.getAddCount() + " , Duplicate: " + SCBean.getDupCount() + " , Invalid: " + SCBean.getInvCount());

			long total = SCBean.getDupCount() + SCBean.getAddCount() + SCBean.getInvCount();
			strSQL2 = "insert into pm_mig_status (tot_read,tot_add,tot_inv,tot_dup) values ('" + String.valueOf(total) + "', '" + SCBean.getAddCount() + "', '" + SCBean.getInvCount() + "', '" + SCBean.getDupCount() + "')";
			stmtPr = connDest.prepareStatement(strSQL2);
			stmtPr.executeUpdate();
			SCBean.incrInvCount();
			stmtPr.close();

		}
	 */


	/*private void addGuarantors (Connection connSrc, Connection connDest,PMMigUI objUI) throws SQLException {

			String strSQL = "";
			String strSQL2 = "";
			String strSQL3 = "";
			Statement stmt = null;
			Statement stmt2 = null;
			Statement stmt3 = null;
			ResultSet rsUsr = null;
			ResultSet rsUsr2 = null;
			ResultSet rsUsr3 = null;

			stmt = connSrc.createStatement();
			stmt2 = connSrc.createStatement();
			stmt3 = connSrc.createStatement();
			PatientsBean SCBean = new PatientsBean();

			try {

				String dob="";
				Users objUsr = new Users();
				Patients objPat = new Patients();
				strSQL = "";
				String arr[]=null;
				strSQL = "SELECT  * from PatientDemographics";
				rsUsr = stmt.executeQuery(strSQL);

				while (rsUsr.next()) {

					SCBean.clearall();
					SCBean.clearallUsers();


					String GuarantorId = rsUsr.getString("Patient ID");
					SCBean.setVmid("Gr-" + GuarantorId);

					String lname =JUtil.validateString(rsUsr.getString("Guarantor Last Name"));
					String fname = JUtil.validateString(rsUsr.getString("Guarantor First Name"));


					if (fname != null)
						SCBean.setUfname(fname);
					if (lname != null)
						SCBean.setUlname(lname);



					SCBean.setUpcity(JUtil.validateString(rsUsr.getString("Guarantor City")));
					SCBean.setUpstate(JUtil.validateString(rsUsr.getString("Guarantor State")));
					SCBean.setZipcode(JUtil.validateString(rsUsr.getString("Guarantor Zipcode")));
					SCBean.setCountryCode("US");

					// Date Of Birth
					dob = JUtil.validateString(rsUsr.getString("Guarantor DOB"));
					System.out.println(dob);
					if(dob==null || dob.equals("NULL")){
						dob="";
					}
					if(dob!=""){
						System.out.println(dob);
						SCBean.setDob(dob, "MM/dd/yyyy");
						SCBean.setPtDob(dob, "MM/dd/yyyy");
					}else{
						SCBean.setDob("", "MM/dd/yyyy");
						SCBean.setPtDob("", "MM/dd/yyyy");
					}




					objUsr.insertData(SCBean, connSrc, connDest, 4);
					if (!(SCBean.getUID()==0)){
						objPat.insertData(SCBean, connSrc, connDest, SCBean.getUID());	            	            
					}	
					objUI.displayStatus("Guarantors: Added: " + SCBean.getAddCount() + " , Duplicate: " + SCBean.getDupCount() + " , Invalid: " + SCBean.getInvCount());
				}

			} catch (Exception e) {
				e.printStackTrace();
				objUI.displayProgress("Guarantors : " + e.toString());
				JUtil.logExceptions(e);
			} finally {
				rsUsr.close();
				//			stmt.close();
			}

			objUI.displayStatus("Guarantors: Added: " + SCBean.getAddCount() + " , Duplicate: " + SCBean.getDupCount() + " , Invalid: " + SCBean.getInvCount());

		}
	 */

	/*private void addPatientInsuredGuarantors (Connection connSrc, Connection connDest,PMMigUI objUI) throws SQLException {

			String strSQL = "";
			String strSQL2 = "";
			String strSQL3="";
			Statement stmt = null;
			Statement stmt2 = null;
			Statement stmt3 = null;
			ResultSet rsUsr = null;
			ResultSet rsUsr2 = null;
			ResultSet rsUsr3 = null;
			int cntNo=30000;
			String chartNo = "";
			String maritalStatus = "";
			String refProvider = "";
			int refProviderId = 0;
			String phone3="",phone5="";
			String notes="";
			String employer = "";


			stmt = connSrc.createStatement();
			stmt2 = connSrc.createStatement();
			stmt3 = connSrc.createStatement();
			PatientsBean SCBean = new PatientsBean();
			String dob = "";
			String guatEmployer="";

			String strSQL13="";
			ResultSet rs13=null;
			Statement stmt13=null;
			stmt13=connSrc.createStatement();
			try {

				Users objUsr = new Users();
				Patients objPat = new Patients();
				strSQL = "";

				//strSQL = "SELECT * FROM PatientInsurance where [Primary Insurance Subscriber Relation]='child' or [Primary Insurance Subscriber Relation]='spouse'"; 
				//strSQL="SELECT * FROM PatientInsurance where [Secondary Insurance Subscriber Relation]='child' or [Secondary Insurance Subscriber Relation]='spouse'";
				strSQL = "SELECT * FROM PatientInsurance where [Tertiary Insurance Subscriber Relation]='child' or [Tertiary Insurance Subscriber Relation]='spouse'"; 


				rsUsr = stmt.executeQuery(strSQL);

				while (rsUsr.next()) {

					SCBean.clearall();
					SCBean.clearallUsers();

					//SCBean.setVmid("GrIns-" + rsUsr.getString("Patient ID")+"PI");   //PI Primary Insured
					//SCBean.setVmid("GrIns-" + rsUsr.getString("Patient ID")+"SI");   //SI Secondary Insured
					SCBean.setVmid("GrIns-" + rsUsr.getString("Patient ID")+"TI");   //TI Tertary Insured



					String lName="";
					String fName="";
					String mName="";
					String fMName="";



					//String guarName=JUtil.validateString(rsUsr.getString("Primary Insurance Subscriber Name"));
					//String guarName=JUtil.validateString(rsUsr.getString("Secondary Insurance Subscriber Name"));
					String guarName=JUtil.validateString(rsUsr.getString("Tertiary Insurance Subscriber Name"));


					if( guarName==null  || guarName.equals("") ){

					}else{
						String[] gNameSplited=guarName.split(",");

						if(gNameSplited.length==1){
							lName=gNameSplited[0];
						}else if(gNameSplited.length==2){
							lName=gNameSplited[0];
							fMName=gNameSplited[1];
						}



						fMName=fMName.trim();

						if(fMName.contains(" ")){
							String[] fMNameSplited=fMName.split(" ");
							fMName=fMNameSplited[0];
							if(fName.contains(" ")){
								fName=fName.replaceAll(" ", "");
							}
							mName=fMNameSplited[1];
						}

						System.out.println(lName+" "+fMName+" "+mName);

					}




					System.out.println(SCBean.getVmid());
					SCBean.setUlname(lName);
					SCBean.setUfname(fMName);
					SCBean.setUminitial(mName);			



					objUsr.insertData(SCBean, connSrc, connDest, 4);
					if (!(SCBean.getUID()==0)){
						objPat.insertData(SCBean, connSrc, connDest, SCBean.getUID());	            	            
					}
					objUI.displayStatus("Patient Insured Guarantors: Added: " + SCBean.getAddCount() + " , Duplicate: " + SCBean.getDupCount() + " , Invalid: " + SCBean.getInvCount());
				}

			} catch (Exception e) {
				e.printStackTrace();
				objUI.displayProgress("Guarantors : " + e.toString());
				JUtil.logExceptions(e);
			} finally {
				rsUsr.close();
				//			stmt.close();
			}

			objUI.displayStatus("Patient Insured Guarantors:: Added: " + SCBean.getAddCount() + " , Duplicate: " + SCBean.getDupCount() + " , Invalid: " + SCBean.getInvCount());

		}
	 */


	/*private void addContacts(Connection connSrc, Connection connDest, PMMigUI objUI) throws SQLException {

			String strSQL = "";
			Statement stmt = null;
			ResultSet rsCont = null;
			stmt = connSrc.createStatement();
			ContactsBean objContBean = new ContactsBean();

			try	{			

				Contacts objCont = new Contacts();

				strSQL = "Select * from PatientDemographics where [Emergency Contact Name]<>''";
				rsCont = stmt.executeQuery(strSQL);

				while (rsCont.next()) {

					objContBean.incrReadCount(); 

					objContBean.clearAll();


					//Contact Name
					String conName=JUtil.validateString(rsCont.getString("Emergency Contact Name"));
					objContBean.setStrName(conName);
					//Contact Address
					objContBean.setStrAddress(rsCont.getString("Emergency Contact Address"));

					//Contact City
					objContBean.setStrCity(rsCont.getString("Emergency Contact City"));

					//Contact State

					//Contact Zip
					objContBean.setStrZipcode(rsCont.getString("Emergency Contact Zip"));

					//Contact Phone
					//objContBean.setStrWorkPhone(rsCont.getString("Contact Phone 1"));
					objContBean.setStrHomePhone(rsCont.getString("Emergency Contact Phone"));

					//Relation
					objContBean.setStrRelation(rsCont.getString("Emergency Contact Relation"));


					objContBean.setStrPatVMID(rsCont.getString("Patient ID"));

					objContBean.setStrVMID("Cont-" + objContBean.getStrPatVMID());


					objCont.insertData(objContBean, connSrc, connDest);

				}

				//System.out.println("Total records Read:" + objContBean.getReadCount());
				objUI.displayStatus("Contacts Added: " + objContBean.getAddCount() + ", Duplicate: " + objContBean.getDupCount() + " , Invalid: " + objContBean.getInvCount());


			} catch(Exception e) {
				objUI.displayProgress("Contacts:" + e.toString());
				JUtil.logExceptions(e);
			}
			finally {
				rsCont.close();
				stmt.close();			
			}

			objUI.displayProgress("Contacts Added: " + objContBean.getAddCount() + " , Duplicate: " + objContBean.getDupCount() + " , Invalid: " + objContBean.getInvCount());
		}
	 */
	/*private void addInsuranceDetail (Connection connSrc, Connection connDest, PMMigUI objUI) throws SQLException {

			String strSQL = "";
			String strSQL2 = "";
			Statement stmt = null;
			Statement stmt2 = null;
			ResultSet rsInsDet = null;
			ResultSet rsInsDet2 = null;
			stmt = connSrc.createStatement();
			stmt2 = connSrc.createStatement();
			InsDetBean objInsDetBean = new InsDetBean();

			String strSQL3="";
			ResultSet rs3=null;
			Statement stmt3=null;
			stmt3=connSrc.createStatement();

			String strSQL4="";
			ResultSet rs4=null;
			Statement stmt4=null;
			stmt4=connSrc.createStatement();


			String strSQL5="";
			ResultSet rs5=null;
			Statement stmt5=null;
			stmt5=connSrc.createStatement();


			String patid="";
			String arr[]=null;
			try {

				InsuranceDetail  objInsDet = new InsuranceDetail();


				//strSQL = "SELECT * FROM MWCAS where [Chart Number] is Not Null order by [Chart Number], [Date Created] desc";
				strSQL="SELECT  *  FROM Person_ins_tie";  //3359
				//strSQL="SELECT  *  FROM Person_ins_tie where [person_id]='7'";



				//JONDE000
				String previousPat ="";


				int i = 0;
				int j = 0;
				Boolean skip1 =false;


				rsInsDet = stmt.executeQuery(strSQL);


				previousPat="";
				patid="";

				while (rsInsDet.next()) {
					j = 0;

					String vmid="";
					String personId=JUtil.validateString(rsInsDet.getString("person_id"));

					strSQL3="select * from Person where person_id='"+personId+"'";
					rs3=stmt3.executeQuery(strSQL3);
					if(rs3!=null){
						if(rs3.next()){

							String fname=JUtil.validateString(rs3.getString("first"));
							String lname=JUtil.validateString(rs3.getString("last"));
							String dob=JUtil.validateString(rs3.getString("birthday"));
							System.out.println(dob);
							String dobValue="";
							if(dob==null || dob.equals("")){
								dobValue="";
							}
							if(dob!=""){
								System.out.println(dob);
								dobValue=dob.substring(5,7)+"/"+dob.substring(8, 10)+"/"+dob.substring(0, 4);
								System.out.println(dobValue);
							}

							vmid=JLib.getVmidPatientByNameDOB(lname, fname, dobValue, connDest);


						}
					}
					//System.out.println( vmid);
					objInsDetBean.setStrPatvmid(vmid);


					System.out.println("chart no: "+objInsDetBean.getStrPatvmid());

					//Copay
					String person_ins_tie_id=JUtil.validateString(rsInsDet.getString("person_ins_tie_id"));
					strSQL5="select copay from Patient_person_ins_tie where person_ins_tie_id="+person_ins_tie_id+"";
					rs5=stmt5.executeQuery(strSQL5);
					if(rs5!=null){
						if(rs5.next()){
							objInsDetBean.setStrCopay(rs5.getString("copay"));
						}
					}

					//String person_ins_tie_id=JUtil.validateString(rsInsDet.getString("person_ins_tie_id"));
					//strSQL4="select * from where [person_ins_tie_id]='"+person_ins_tie_id+"'";
					objInsDetBean.setStrvmid(JUtil.validateString(rsInsDet.getString("insurance_id")));


					objInsDetBean.setStrSubscriberNo(JUtil.validateString(rsInsDet.getString("subscriber_number")));
					objInsDetBean.setStrGroupNo(JUtil.validateString(rsInsDet.getString("group_number")));
					//objInsDetBean.setStrGrRel(JUtil.validateString(rsInsDet.getString("Primary Insurance Subscriber Relation")));
					//objInsDetBean.setGuarName(rsInsDet.getString("Primary Insurance Subscriber Name"));


					//objInsDetBean.setStrGuarVmid(primaryGuarantorVmid);
					objInsDetBean.setStrStartDate(JUtil.validateString(rsInsDet.getString("person_start_date")));
					objInsDetBean.setStrEndDate(JUtil.validateString(rsInsDet.getString("person_end_date")));
					//objInsDetBean.setStrSeqNo("1");





					System.out.println(objInsDetBean.getStrvmid());
					if (objInsDetBean.getStrvmid() != ""){

						strSQL2 = "select [carrier] from Insurance where insurance_id='" + objInsDetBean.getStrvmid() + "'";
						rsInsDet2 = stmt2.executeQuery(strSQL2);
						while (rsInsDet2.next()) {
							objInsDetBean.setStrName(JUtil.validateString(rsInsDet2.getString("carrier")));
							System.out.println(objInsDetBean.getStrName());
						}	
						objInsDet.insertData(objInsDetBean, connSrc, connDest);

					}
					else {
						System.out.println("Insurance not found," + objInsDetBean.getStrvmid());
						//objInsDetBean.incrInvCount();
					}
					objUI.displayStatus("InsuranceDetail: Added: " + objInsDetBean.getAddCount() + " , Duplicate: " + objInsDetBean.getDupCount() + " , Invalid: " + objInsDetBean.getInvCount());

				}

			} catch(Exception e) {
				objUI.displayProgress("InsuranceDetail : " + e.toString());
				JUtil.logExceptions(e);
			}
			finally {
				rsInsDet.close();
				stmt.close();
			}

			objUI.displayStatus("InsuranceDetail: " + objInsDetBean.getAddCount() + "-" + objInsDetBean.getDupCount() + "-" + objInsDetBean.getInvCount());



		}
	 */


	/*public String AMPM(String time)
		{
			String[] times = time.split(" ");
			time = times[2];

			String[] tim = time.split(":");
			String hh = tim[0];
			int h = Integer.parseInt(hh);
			String AMPM = times[3];
			if(AMPM.contains("PM"))
			{
				if(h !=12)
				{
					h = h + 12;
					time = h + ":" + tim[1] + ":" + tim[2];
				}
				else if(h ==12)
				{

					time = h + ":" + tim[1] + ":" + tim[2];
				}

			}
			return time;
		}*/




	/*private void addAppointments(Connection connSrc, Connection connDest, PMMigUI objUI) throws SQLException {
			Statement st = null;

			JUtil.PROCESS_startTime = new Date();

			String    strInsertSql = "";		
			String    strSQL       = "";
			Statement stmt         = null;
			ResultSet rsApt        = null;

			stmt = connSrc.createStatement();
			AppointmentsBean objAptBean = new AppointmentsBean();

			try	{
				st = connSrc.createStatement();
				Appointments objApt = new Appointments();


				strSQL= "SELECT *  FROM Appointment";  

				//strSQL= "SELECT *  FROM Appointment where [appointment_id]=9930";


				rsApt = stmt.executeQuery(strSQL);

				while (rsApt.next()) {
					objAptBean.clearAll();
					objAptBean.incrReadCount(); 

					//Appointment ID
					objAptBean.setLngApt_RecordID_Source(rsApt.getLong("appointment_id"));

					//Facilities
					objAptBean.setStrFacilityID_Source("2");



					//Doctors and resource

					String doc=JUtil.validateString(rsApt.getString("resource_id"));

					if(doc.equals("5") || doc.contains("5")){
						objAptBean.setStrDoctorID_Source("5");
					}else if(doc.equals("4") || doc.contains("4")){
						objAptBean.setStrResourceID_Source("4");
					} 





					//Patient
					String PID = JUtil.validateString(rsApt.getString("patient_id"));
					System.out.println("PID: "+PID);
					objAptBean.setStrPatientID_Source(PID);


					//Date 
					String apptDate=JUtil.validateString(rsApt.getString("start"));
					if(apptDate==null || apptDate=="NULL" || apptDate.equals("") || apptDate.equals("NULL")){

					}else{
						String dateSplited[]=apptDate.split(" ");

						String dateValue=dateSplited[0];
						String startTimeValue=dateSplited[1];
						objAptBean.setStrAptDate_Source(dateValue.substring(5,7)+"/"+dateValue.substring(8,10)+"/"+dateValue.substring(0,4));
						objAptBean.setStrStartTime_Source(startTimeValue);
						System.out.println(objAptBean.getStrAptDate_Source());
					}



					//start time

		         	String startTime=rsApt.getString("Appointment Start Time");
		         	String startTimeSAplit[]=startTime.split(" ");
		         	String startTimeValue=startTimeSAplit[2];
		         	System.out.println(startTimeValue);
		         	objAptBean.setStrStartTime_Source(startTimeValue);






					//objAptBean.setStrAptDate_Source(rsApt.getString("Date"));
					//String time=rsApt.getString("Start Time");
					//String newTime=JLib.AMPM(time);
					//objAptBean.setStrStartTime_Source(newTime);
					//String[] TimeSep=objAptBean.getStrStartTime_Source().split(" ");
					//objAptBean.setStrStartTime_Source(TimeSep[0]);
					//objAptBean.setAMPM(TimeSep[1]);
					//objAptBean.setStrReason_Source(rsApt.getString("Reason Code"));


					//Notes
					//objAptBean.setStrGeneralNotes_Source(rsApt.getString("Notes"));



					//Duration or End Time

					String endTime=JUtil.validateString(rsApt.getString("end"));
					if(endTime==null || endTime=="NULL" || endTime.equals("") || endTime.equals("NULL")){

					}else{
						String endArray[]=endTime.split(" ");
						String endTimeValue=endArray[1];
						objAptBean.setStrEndTime_Source(endTimeValue);
					}


					//String endArray
					//objAptBean.setDuration(rsApt.getString("Duration"));



					//Visit Type

					String visitType=JUtil.validateString(rsApt.getString("Reason Code"));
					if(visitType.equals("")){
						objAptBean.setStrVisitType_Source("Migrated");
					}else{
					objAptBean.setStrVisitType_Source(visitType);
					}

					objAptBean.setStrVisitType_Source("Migrated");




					//Visit Status

					String status=JUtil.validateString(rsApt.getString("Appointment Status"));
					String visitStatus="";
					if(status.equals("Cancelled")){
						visitStatus="CANCS";
					}else if(status.equals("Check In")){
						visitStatus="ARR";
					}else if(status.equals("Check Out")){
						visitStatus="CHK";
					}else if(status.equals("Completed")){
						visitStatus="CHK";
					}else if(status.equals("No show")){
						visitStatus="N/S";
					}else if(status.equals("pending")){
						visitStatus="PEN";
					}else if(status.equals("Rescheduled")){
						visitStatus="R/S";
					} else{
						visitStatus="Migrated";
					}

					objAptBean.setStrStatus_Source("Migrated");






					objAptBean.setStrNotes_Source(JUtil.validateString(rsApt.getString("notes")));

					objApt.insertData(objAptBean, connSrc, connDest);
					objUI.displayStatus("Appointments Read: " + objAptBean.getCntRead() + " ; Added: " + objAptBean.getCntAdd() + " ; Duplicate: " + objAptBean.getCntDup() + " ; Pat not found: " + objAptBean.getCntNoPat() + " ; No Dr: " + objAptBean.getCntNoDr() + " ; No Fac: " + objAptBean.getCntNoFac() + " ; Invalid: " + objAptBean.getCntInv());



				}


				//Excel start...
				try{


					java.io.File file = new java.io.File("AppointmentsCount.xls");
					//file.createNewFile(); //Niteesh
					WorkbookSettings wbs = new WorkbookSettings();
					wbs.setInitialFileSize((int)file.length());		    

					// Workbook workbook = Workbook.getWorkbook(file,wbs);				
					WritableWorkbook workbook = Workbook.createWorkbook(file, wbs);

					workbook.createSheet("Apt", 0);

					WritableSheet excelsheet = workbook.getSheet(0);


					WritableFont cellFont1 = new WritableFont(WritableFont.TIMES, 12);
					cellFont1.setColour(Colour.BLUE);

					WritableCellFormat cellFormat1 = new WritableCellFormat(cellFont1);
					cellFormat1.setBackground(Colour.LIGHT_GREEN);
					cellFormat1.setBorder(Border.ALL, BorderLineStyle.THIN);


					WritableFont cellFont2 = new WritableFont(WritableFont.TIMES, 12);			    
					WritableCellFormat cellFormat2 = new WritableCellFormat(cellFont2);			    
					cellFormat2.setBorder(Border.ALL, BorderLineStyle.THIN);

					WritableFont cellFont3 = new WritableFont(WritableFont.TIMES, 14);			    
					WritableCellFormat cellFormat3 = new WritableCellFormat(cellFont3);		

					excelsheet.setColumnView(1, 50);
					excelsheet.setColumnView(2, 20);


					Calendar currentDate = Calendar.getInstance();
					SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy HH:mm");
					String dateNow = formatter.format(currentDate.getTime());

					excelsheet.addCell(new Label(1,3,"Appointments loading Statistics",cellFormat3));
					excelsheet.addCell(new Label(2,3,dateNow,cellFormat3));


					excelsheet.addCell(new Label(1,5,"Description",cellFormat1));
					excelsheet.addCell(new Label(2,5,"Total Records",cellFormat1));

					excelsheet.addCell(new Label(1,6," Appointments Read: ",cellFormat2));
					excelsheet.addCell(new Number(2,6, objAptBean.getCntRead(),cellFormat2));

					excelsheet.addCell(new Label(1,7," Appointments Migrated: ",cellFormat2));
					excelsheet.addCell(new Number(2,7, objAptBean.getCntAdd(),cellFormat2));

					excelsheet.addCell(new Label(1,8," Patient not found: ",cellFormat2));
					excelsheet.addCell(new Number(2,8, objAptBean.getCntNoPat(),cellFormat2));

					excelsheet.addCell(new Label(1,9," Doctor not found: ",cellFormat2));
					excelsheet.addCell(new Number(2,9, objAptBean.getCntNoDr(),cellFormat2));

					excelsheet.addCell(new Label(1,10," Duplicate Appointments: ",cellFormat2));
					excelsheet.addCell(new Number(2,10, objAptBean.getCntDup(),cellFormat2));

					workbook.write();
					workbook.close();

				}
				catch(Exception e)	{
					System.err.println(e.toString());
					// return(e.getMessage());
					//throw e;
				}
				finally	{

				}

				//Excel End ...


			}catch(Exception e)	{
				objUI.displayProgress("Appointments:" + e.toString());
				JUtil.logExceptions(e);
			}
			finally	{
				rsApt.close();
				stmt.close();	

			}

			JUtil.PROCESS_EndTime = new Date();

			System.out.println("Start Time: " + JUtil.PROCESS_startTime );
			System.out.println("End Time: " + JUtil.PROCESS_EndTime );


			objUI.displayProgress( "AppointmentsRead: " + objAptBean.getCntRead() + "; Added: " + objAptBean.getCntAdd() + "; Duplicate: " + objAptBean.getCntDup() + "; Pat not found: " + objAptBean.getCntNoPat() + "; No Dr: " + objAptBean.getCntNoDr() + "; No Fac: " + objAptBean.getCntNoFac() + " ; Invalid: " + objAptBean.getCntInv());
		}
	 */

	/*private void addServices(Connection connSrc, Connection connDest,PMMigUI objUI) throws SQLException {
		// TODO Auto-generated method stub	

		String strSQL = "";

		String strSQL2 = "";

		Statement stmt = null;

		Statement stmt2 = null;

		ResultSet rsUsr = null;

		ResultSet rsUsr2 = null;

		stmt = connSrc.createStatement();

		stmt2 = connSrc.createStatement();

		try
		{

			Users objUsr = new Users();
			strSQL="";


			strSQL = "Select * from User where isprovider='1' and isinactive='0'";

			rsUsr = stmt.executeQuery(strSQL);			
			//int c=1;
			while (rsUsr.next()) {	
				SCBean.clearall();
				SCBean.clearallUsers();
				//SCBean.set
				//SCBean.setFacVmid(rsUsr.getString("code"));

				String c=rsUsr.getString("user_id");
				SCBean.setVmid("Dr-" + c);

				SCBean.setUfname(JUtil.validateString(rsUsr.getString("firstname")));

				SCBean.setUlname(JUtil.validateString(rsUsr.getString("lastname")));


				SCBean.setSuffix(JUtil.validateString(rsUsr.getString("suffix")));
				SCBean.setUname(SCBean.getUfname() + JLib.Left(SCBean.getUlname(),1));
				SCBean.setSpecialty(JUtil.validateString(rsUsr.getString("speciality"))); 
				SCBean.setDeano(JUtil.validateString(rsUsr.getString("dea")));
				SCBean.setStLicNo(JUtil.validateString(rsUsr.getString("state_license")));
				SCBean.setNPI(JUtil.validateString(rsUsr.getString("national_provider_id")));
				SCBean.setTaxid(JUtil.validateString(rsUsr.getString("federal")));


					SCBean.setUfname(JUtil.validateString(rsUsr.getString("First")));
					SCBean.setUminitial(JUtil.validateString(rsUsr.getString("Middle")));
					SCBean.setUlname(JUtil.validateString(rsUsr.getString("Last")));

					SCBean.setSuffix(JUtil.validateString(rsUsr.getString("Suffix")));




					SCBean.setUpaddress(JUtil.validateString(rsUsr.getString("Address1")));
					SCBean.setUpcity(JUtil.validateString(rsUsr.getString("City")));
					SCBean.setUpstate(JUtil.validateString(rsUsr.getString("State")));
					SCBean.setZipcode(JUtil.validateString(rsUsr.getString("Zip")));
					SCBean.setUpphone(JUtil.validateString(rsUsr.getString("Phone1")));
					SCBean.setFaxno(JUtil.validateString(rsUsr.getString("Phone2")));

					SCBean.setTaxidtype(JUtil.validateString(rsUsr.getString("FederalTaxIdType")));
					SCBean.setSpLicNo(JUtil.validateString(rsUsr.getString("Ledger")));


				//SCBean.setSsn(rsUsr.getString("SSN or Fed Tax ID").intern());
				//SCBean.setSsn(JUtil.validateString(SCBean.getTaxid()));
				//SCBean.setUpin(JUtil.validateString(rsUsr.getString("UPIN")));
				//
				//SCBean.setTaxonomycode(JUtil.validateString(rsUsr.getString("Taxonomy_Code")));


				objUsr.insertData(SCBean, connSrc, connDest, 1);
				if (!(SCBean.getUID()==0)){
					objPrv.insertData(SCBean, connSrc, connDest, SCBean.getUID());	            	            
				}
				objUI.displayStatus("Providers: Added: " + SCBean.getAddCount() + " , Duplicate: " + SCBean.getDupCount() + " , Invalid: " + SCBean.getInvCount());

			}



		}catch(Exception e) {
			e.printStackTrace();
			objUI.displayProgress("Providers : " + e.toString());
			JUtil.logExceptions(e);
		}
		finally {
			rsUsr.close();
			stmt.close();
		}

		objUI.displayStatus("Providers: Added: " + SCBean.getAddCount() + " , Duplicate: " + SCBean.getDupCount() + " , Invalid: " + SCBean.getInvCount());

	}*/
}
