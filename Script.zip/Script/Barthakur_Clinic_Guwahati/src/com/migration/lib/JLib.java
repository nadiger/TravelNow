/**
 * 
 */
package com.migration.lib;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;

import com.migration.form.DBConnection;
import com.migration.form.PMMigUI;
import com.migration.model.MasterLabBean;
import com.migration.model.ServiceChargesBean;



public class JLib 
{
	private static Connection getConnection() throws Exception{
		Connection connDes2 = DBConnection.getDSNConnection(PMMigUI.destDNSName,PMMigUI.destUname,PMMigUI.destPwd);
		return connDes2;
	}

	// 10i Methods
	
	public static String getActualServiceName(String SponsorName,Connection conSrc) throws SQLException {
		String strSQL = "";
		ResultSet rsDept212 = null;
		String serviceName = "";
		Statement stmt34 = conSrc.createStatement(); 
		
		strSQL = "Select * from SponsorMaster where SponsorServiceName='" + SponsorName + "'";
		rsDept212 = stmt34.executeQuery(strSQL);
		if(rsDept212.next())
		{
			serviceName = rsDept212.getString("ServiceName");

		}
		
		rsDept212.close();
		stmt34.close();
		return serviceName;
	}

	
	public static int getSponsorIdByName(String SponsorName,Connection con) throws Exception
	{
		String strSQL = "";
		ResultSet rsDept2 = null;
		int sdid = 0 ;
		con=getConnection();
		Statement stmt3 = con.createStatement();
		SponsorName = JLib.Left(SponsorName, 60);
		strSQL = "Select * from Sponsor where SponsorName='" + SponsorName + "' and Status='A'";
		rsDept2 = stmt3.executeQuery(strSQL);
		if(rsDept2.next())
		{
			sdid = rsDept2.getInt("SponsorID");

		}

		if(sdid==0)
			JUtil.appendToFile("SponsorNameException.csv", SponsorName+"|Sponsor Name not found");

		rsDept2.close();
		stmt3.close();
		return sdid;
	}
	
	public static ArrayList<String> getBedCategories() throws Exception {
		ArrayList<String> AL = new ArrayList<String>();
		String strSQL = "";
		ResultSet rsDept01 = null;
		int did = 0 ;
		Connection con=null;
		con=getConnection();
		Statement stmt12 = con.createStatement();
		
		strSQL = "select * from BedCategories Where Status='A'";
		rsDept01 = stmt12.executeQuery(strSQL);
		while(rsDept01.next())
		{
			AL.add(rsDept01.getString("BedCategoryID"));

		}
		rsDept01.close();
		stmt12.close();
		con.close();
		return AL;
	}
	
	public static int getDepartmentIDByName(String departmentName, Connection con) throws Exception
	{
		String strSQL = "";
		ResultSet rsDept0 = null;
		int did = 0 ;
		con=getConnection();
		Statement stmt1 = con.createStatement();
		

		strSQL = "select * from Department where departmentName='" + departmentName + "' and Status='A'";
		rsDept0 = stmt1.executeQuery(strSQL);
		if(rsDept0.next())
		{
			did = rsDept0.getInt("DepartmentID");

		}

		if(did==0)
			JUtil.appendToFile("departmentNameException.csv", departmentName+"|Department Name not found");

		rsDept0.close();
		stmt1.close();
		return did;
	}

	public static int getSubDepartmentIDByName(String subDepartmentName,String departmentID, Connection con) throws Exception
	{
		String strSQL = "";
		ResultSet rsDept1 = null;
		int sdid = 0 ;
		con=getConnection();
		Statement stmt2 = con.createStatement(); 

		strSQL = "select * from SubDepartment where SubDepartmentName='" + subDepartmentName + "' and departmentID="+departmentID+" and Status='A'";
		rsDept1 = stmt2.executeQuery(strSQL);
		if(rsDept1.next())
		{
			sdid = rsDept1.getInt("SubDepartmentID");

		}

		if(sdid==0)
			JUtil.appendToFile("subDepartmentNameException.csv", subDepartmentName+"|Sub Department Name not found");
		rsDept1.close();
		stmt2.close();
		return sdid;
	}

	public static int getServiceIdByName(String ServiceName,Connection con) throws Exception
	{
		String strSQL = "";
		ResultSet rsDept2 = null;
		int sdid = 0 ;
		con=getConnection();
		Statement stmt3 = con.createStatement(); 

		strSQL = "select * from itemofservice where ServiceName='" + ServiceName + "' and Status='A'";
		rsDept2 = stmt3.executeQuery(strSQL);
		if(rsDept2.next())
		{
			sdid = rsDept2.getInt("ServiceID");

		}

		if(sdid==0)
			JUtil.appendToFile("ServiceNameException.csv", ServiceName+"|Service Name not found");

		rsDept2.close();
		stmt3.close();
		return sdid;
	}

	public static int getUnitIdByName(String UnitName,Connection con) throws Exception
	{
		String strSQL = "";
		ResultSet rsDept3 = null;
		int sdid = 0 ;
		con=getConnection();
		Statement stmt4 = con.createStatement(); 

		strSQL = "select * from LabUnits where UnitDesc='" + UnitName + "' and Status='A'";
		rsDept3 = stmt4.executeQuery(strSQL);
		if(rsDept3.next())
		{
			sdid = rsDept3.getInt("UnitId");

		}
		if(sdid==0)
			JUtil.appendToFile("UnitException.csv", UnitName+"|Unit not found");
		rsDept3.close();
		stmt4.close();
		return sdid;
	}

	public static int getSampleIdByName(String SampleName,Connection con) throws Exception
	{
		String strSQL = "";
		ResultSet rsDept4 = null;
		int sdid = 0,i=0 ;
		con=getConnection();
		Statement stmt5 = con.createStatement(); 
		PreparedStatement pstmt121=null;
		String sqlInsert="";

		strSQL = "select * from SampleMaster where SampleDescription='" + SampleName + "' and Status='A'";
		rsDept4 = stmt5.executeQuery(strSQL);
		if(rsDept4.next())
		{
			sdid = rsDept4.getInt("SampleID");
		}

		if(sdid==0)
			JUtil.appendToFile("SampleNameException.csv", SampleName+"|Sample Name not found");
		
		
		sqlInsert="INSERT INTO SampleMaster (SampleDescription,Status,EncodedBy," +
				"EncodedDate) VALUES(?,?,?,?)";
		i=0;
		pstmt121 = getConnection().prepareStatement(sqlInsert);

		pstmt121.setString(++i, SampleName);
		pstmt121.setString(++i, "A");
		pstmt121.setString(++i, "2");
		pstmt121.setString(++i, "2016-05-01");
		pstmt121.executeUpdate();
		
		strSQL = "select * from SampleMaster where SampleDescription='" + SampleName + "' and Status='A'";
		rsDept4 = stmt5.executeQuery(strSQL);
		if(rsDept4.next())
		{
			sdid = rsDept4.getInt("SampleID");
		}
		
		rsDept4.close();
		stmt5.close();
		pstmt121.close();
		return sdid;
	}

	public static int getMethodIdByName(String MethodName,Connection con) throws Exception
	{
		String strSQL = "";
		String strSQL2 = "";
		ResultSet rsDept6 = null;
		ResultSet rsDept5 = null;
		int sdid = 0,i=0;
		con=getConnection();
		Statement stmt6 = con.createStatement(); 
		Statement stmt61 = con.createStatement();
		PreparedStatement pstmt=null;

		strSQL = "select * from SampleMethods where MethodName='" + MethodName + "' and Status='A'";
		rsDept6 = stmt6.executeQuery(strSQL);
		if(rsDept6.next())
		{
			sdid = rsDept6.getInt("MethodID");
		}

		if(sdid==0){
			JUtil.appendToFile("MethodNameException.csv", MethodName+",Method Name not found");

			strSQL2= "INSERT INTO  SampleMethods(MethodName,Status,EncodedBy,Encodeddate,LocationID)  VALUES(?,?,?,?,?)";
			pstmt = con.prepareStatement(strSQL2);
			pstmt.setString(++i, JLib.Left(MethodName,100));
			pstmt.setString(++i, "A");
			pstmt.setString(++i, "2");
			pstmt.setString(++i, "2016-05-01");
			pstmt.setString(++i, "1");
			pstmt.executeUpdate();

			strSQL = "select * from SampleMethods where MethodName='" + MethodName + "' and Status='A'";
			rsDept5 = stmt61.executeQuery(strSQL);
			if(rsDept5.next())
			{
				sdid = rsDept5.getInt("MethodID");
			}

		}

		if(rsDept5!=null)
			rsDept5.close();
		rsDept6.close();
		stmt6.close();
		stmt61.close();

		return sdid;
	}

	public static String [] findSubServiceName(String ServiceName,Connection con) throws Exception
	{
		// To get the subservice name from the mdb. Connection to source.
		String strSQL = "";
		ResultSet rsDept7 = null;
		String subserviceName [] = new String[2] ;
		Statement stmt7 = con.createStatement(); 

		strSQL = "select * from ServiceProfileDetail where ServiceName='" + ServiceName + "'";
		rsDept7 = stmt7.executeQuery(strSQL);
		if(rsDept7.next())
		{
			subserviceName[0] = rsDept7.getString("SubServiceName");
			subserviceName[1] = rsDept7.getString("Sequence");
		}
		rsDept7.close();
		stmt7.close();

		return subserviceName;
	}

	public static int getSubServiceId(String subServiceName,Connection con) throws Exception
	{
		// To get the Sub Service ID from the database. Connection to Destination.
		String strSQL = "";
		ResultSet rsDept8 = null;
		int sdid = 0 ;
		con=getConnection();
		Statement stmt8 = con.createStatement(); 

		strSQL = "select * from itemofservice where ServiceName='" + subServiceName + "' and Status='A'";
		rsDept8 = stmt8.executeQuery(strSQL);
		if(rsDept8.next())
		{
			sdid = rsDept8.getInt("ServiceID");
		}
		rsDept8.close();
		stmt8.close();
		//con.close();
		return sdid;
	}


	public static int getRangeId(MasterLabBean objMasterLabBean,Connection con) throws Exception {

		String strSQL = "";
		ResultSet rsDept9 = null;
		int rangeId = 0,i=0 ;
		con=getConnection();
		PreparedStatement stmt9 = null; 

		strSQL = "select * from investrangemain_New where ServiceID=? and UnitId=? and SampleId=? and "+
				"MethodId=? and ReportType=? and CategoryType=? and Status='A'";


		stmt9 = con.prepareStatement(strSQL);
		stmt9.setString(++i, objMasterLabBean.getServiceId());
		stmt9.setString(++i, objMasterLabBean.getUnitId());
		stmt9.setString(++i, objMasterLabBean.getSampleId());
		stmt9.setString(++i, objMasterLabBean.getMethodId());
		stmt9.setString(++i, objMasterLabBean.getReportType());
		stmt9.setString(++i, objMasterLabBean.getCategoryType());

		rsDept9 = stmt9.executeQuery();
		if(rsDept9.next())
		{
			rangeId = rsDept9.getInt("RangeId");
		}
		rsDept9.close();
		stmt9.close();
		return rangeId;


	}
	
	public static int getChargeId(ServiceChargesBean serviceChargesBean) throws Exception {

		Connection con=null;
		String strSQL = "";
		ResultSet rsDept90 = null;
		int chargeID = 0,i=0 ;
		con=getConnection();
		PreparedStatement stmt90 = null; 

		strSQL = "select * from ServiceCharges where ServiceID=? and SponsorID=? and BedCategoryID=? and "+
				"ServiceCharges=?";


		stmt90 = con.prepareStatement(strSQL);
		stmt90.setString(++i, serviceChargesBean.getServiceId());
		stmt90.setString(++i, serviceChargesBean.getSponsorID());
		stmt90.setString(++i, serviceChargesBean.getBedCategoryId());
		stmt90.setString(++i, serviceChargesBean.getServiceCharges());

		rsDept90 = stmt90.executeQuery();
		if(rsDept90.next())
		{
			chargeID = rsDept90.getInt("ChargesID");
		}
		rsDept90.close();
		stmt90.close();
		return chargeID;

		
	}

	
	public static int getRangeDetailId(MasterLabBean objMasterLabBean,int RangeId,Connection con) throws Exception {

		String strSQL = "";
		ResultSet rsDept9 = null;
		int rangeId = 0,i=0 ;
		con=getConnection();
		PreparedStatement stmt9 = null; 

		strSQL = "select * from InvestrangeDetail_New where rangeID=? and Gender=? and AgeFrom=? and AgeUpto=?";


		stmt9 = con.prepareStatement(strSQL);
		stmt9.setInt(++i, RangeId);
		stmt9.setString(++i, objMasterLabBean.getGender());
		stmt9.setString(++i, objMasterLabBean.getAgeFrom());
		stmt9.setString(++i, objMasterLabBean.getAgeUpTo());

		rsDept9 = stmt9.executeQuery();
		if(rsDept9.next())
		{
			rangeId = rsDept9.getInt("RangeDetailId");
		}
		rsDept9.close();
		stmt9.close();
		return rangeId;


	}

	/**********************************************************************************************************
	 *  Users Related Functions
	 * 
	 **********************************************************************************************************/


	public static int getUsersByVMID(String strVMID, Connection con) throws Exception
	{
		String strSQL = "";
		//strVMID = strVMID.substring(0,strVMID.indexOf('.'));
		ResultSet rsUsers = null;
		int uid = 0 ;
		Statement stmt = con.createStatement();

		strSQL = "Select uid, usertype from users where vmid= '" + strVMID + "' and vmid <> '' and delflag = 0";
		rsUsers = stmt.executeQuery(strSQL);
		if(rsUsers.next())
		{
			uid = rsUsers.getInt("UID");
		}

		stmt.close();
		return uid;
	}

	public static int getInsByVMID(String strVMID, Connection con) throws Exception {

		String strSQL = "";
		ResultSet rsUsers = null;
		int uid = 0 ;
		Statement stmt = con.createStatement();

		strSQL = "SELECT insid FROM insurance WHERE vmid = '" + strVMID + "' AND vmid <> '' AND deleteflag = 0";
		rsUsers = stmt.executeQuery(strSQL);
		if (rsUsers.next()) {
			uid = rsUsers.getInt("insid");
		}

		stmt.close();
		return uid;
	}


	public static int getUserByName(String strLast,String strFirst, Connection con, int userType ) throws Exception
	{
		String strSQL = "";
		ResultSet rsUsr = null;
		int uid = 0 ;
		Statement stmt = con.createStatement();

		strSQL = "select uid, usertype from users where  ulname='" + strLast + "' and "; 
		strSQL += " ufname='" + strFirst  + "' and delflag = 0 and usertype = " + userType;

		rsUsr = stmt.executeQuery(strSQL);
		if(rsUsr.next())
		{
			uid = rsUsr.getInt("UID");
		}

		return uid;
	}

	/**********************************************************************************************************
	 *  Patients Related Functions
	 * 
	 **********************************************************************************************************/


	/* Find Patient By Name & DOB */

	public static int getPatientByNameDOB(String strLast,String strFirst, String strDOB, Connection con) throws Exception
	{
		String strSQL = "";
		ResultSet rsPat = null;
		int uid = 0 ;
		Statement stmt = con.createStatement();

		strSQL = "select UHID from PatientRegistration  where  [last name]='" + strLast + "' and "; 
		strSQL += " [first name]='" + strFirst + "' and " ;
		strSQL += " dob='" + strDOB + "' and status='A'";
		System.out.println(strSQL);
		rsPat = stmt.executeQuery(strSQL);
		if(rsPat.next())
		{
			uid = rsPat.getInt("UHID");
		}

		return uid;
	}

	public static int getUHIDByRegistractioNo(String registractioNo, Connection con) throws Exception
	{
		String strSQL = "";
		ResultSet rsPat = null;
		int uid = 0 ;
		Statement stmt = con.createStatement();

		strSQL = "select UHID from PatientRegistration where RegistrationNo='"+registractioNo+"'";
		System.out.println(strSQL);
		rsPat = stmt.executeQuery(strSQL);
		if(rsPat.next())
		{
			uid = rsPat.getInt("UHID");
		}

		return uid;
	}


	public static String getVmidPatientByNameDOB(String strLast,String strFirst, String strDOB, Connection con) throws Exception
	{
		String strSQL = "";
		ResultSet rsPat = null;
		String vmid="";
		Statement stmt = con.createStatement();

		strSQL = "select vmid from users where  ulname='" + strLast + "' and  ufname='" + strFirst + "' and  dob='" + strDOB + "' and usertype =3 ";
		System.out.println(strSQL);
		rsPat = stmt.executeQuery(strSQL);
		if(rsPat.next())
		{
			vmid = rsPat.getString("vmid");
		}

		return vmid;
	}



	/* Find Patient By Name, Address1 & ZipCode */
	public static int getPatientsByNameAddrZip(String strLast,String strFirst, String strAddr1, String strZip, Connection con) throws Exception
	{
		String strSQL = "";
		ResultSet rsUsr = null;
		int uid = 0 ;
		Statement stmt = con.createStatement();

		strSQL = "select uid,usertype from users where  ulname='" + strLast + "' and "; 
		strSQL += " ufname='" + strFirst + "' and upaddress='" + strAddr1 + "' ";
		strSQL += " and zipcode = '" + strZip  +  "' and delflag = 0 and usertype= 3 " ;

		rsUsr = stmt.executeQuery(strSQL);
		if(rsUsr.next())
		{
			uid = rsUsr.getInt("UID");
		}

		return uid;
	}

	/* Find Patient By Name & ZipCode */
	public static int getPatientsByNameZip(String strLast,String strFirst, String strZip, Connection con) throws Exception
	{
		String strSQL = "";
		ResultSet rsUsr = null;
		int uid = 0 ;
		Statement stmt = con.createStatement();

		strSQL = "select uid,usertype from users where  ulname='" + strLast + "' and "; 
		strSQL += " ufname='" + strFirst + "' and " ;
		strSQL += " zipcode='" + strZip + "' and delflag = 0 and usertype= 3 " ;

		rsUsr = stmt.executeQuery(strSQL);
		if(rsUsr.next())
		{
			uid = rsUsr.getInt("UID");
		}

		return uid;
	}

	/* Find Patient By Name & SSN */
	public static int getPatientsByNameSSN(String strLast,String strFirst, String strSSN, Connection con) throws Exception
	{
		String strSQL = "";
		ResultSet rsUsr = null;
		int uid = 0 ;
		Statement stmt = con.createStatement();

		strSQL = "select uid,usertype from users where  ulname='" + strLast + "' and "; 
		strSQL += " ufname='" + strFirst + "' and " ;
		strSQL += " ssn='" + strSSN + "' and delflag = 0 and usertype= 3" ;

		rsUsr = stmt.executeQuery(strSQL);
		if(rsUsr.next())
		{
			uid = rsUsr.getInt("UID");
		}

		return uid;
	}


	/* Find Patient By Name & Phone */
	public static int getPatientsByNamePhone(String strLast,String strFirst, String strPhone, Connection con) throws Exception
	{
		String strSQL = "";
		ResultSet rsUsr = null;
		int uid = 0 ;
		Statement stmt = con.createStatement();

		strSQL = "select uid,usertype from users where  ulname='" + strLast + "' and "; 
		strSQL += " ufname='" + strFirst + "' and " ;
		strSQL += " upPhone='" + strPhone + "' and delflag = 0 and usertype= 3 "  ;

		rsUsr = stmt.executeQuery(strSQL);
		if(rsUsr.next())
		{
			uid = rsUsr.getInt("UID");
		}

		return uid;
	}

	/*Find uid by VMID ***************-by Niteesh*/
	public static int getUidByVmid(String vmid,Connection con) throws SQLException
	{
		String strSQL = "";
		ResultSet rsUsers = null;
		int uid = 0 ;
		Statement stmt = con.createStatement();

		strSQL = "Select uid from users where vmid = '" + vmid + "'";
		rsUsers = stmt.executeQuery(strSQL);
		if(rsUsers.next())
		{
			uid = rsUsers.getInt("UID");
		}

		stmt.close();
		return uid;
	}


	public static int getFacUidByVmid(String vmid,Connection con) throws SQLException
	{
		String strSQL = "";
		ResultSet rsUsers = null;
		int uid = 0 ;
		Statement stmt = con.createStatement();

		strSQL = "Select id from edi_facilities where vmid like '" + vmid + "'";
		rsUsers = stmt.executeQuery(strSQL);
		if(rsUsers.next())
		{
			uid = rsUsers.getInt("ID");
		}

		stmt.close();
		return uid;
	}






	/*Find duplicate uid by VMID From MDB  ***************-by Niteesh*/
	public static int getUidByVmidFromMdb(String vmid,Connection con) throws SQLException
	{
		String strSQL = "";
		ResultSet rsUsers = null;
		int uid = 0 ;
		Statement stmt = con.createStatement();
		//System.out.println("VMID="+vmid);
		strSQL = "Select uid from duppat where vmid = 'Gr-"+vmid+"' or vmid ='Pat-"+vmid+"'or vmid ='Ref-"+vmid+"'";
		//System.out.println(strSQL);

		rsUsers = stmt.executeQuery(strSQL);
		if(rsUsers!=null){
			if(rsUsers.next())
			{
				uid = rsUsers.getInt("UID");
			}
		}else{
			uid=0;
		}
		stmt.close();
		return uid;
	}



	/*Find uid by VMID  ***************-by Niteesh*/
	public static String getProvIdByVmid(String vmid,Connection con) throws SQLException
	{
		String strSQL = "";
		ResultSet rsUsers = null;
		String uid = "" ;
		Statement stmt = con.createStatement();
		//System.out.println("VMID="+vmid);
		strSQL = "Select uid from users where vmid = '"+vmid+"' and delflag=0";
		//System.out.println(strSQL);
		rsUsers = stmt.executeQuery(strSQL);
		if(rsUsers.next())
		{
			uid = rsUsers.getString("UID");
		}

		stmt.close();
		return uid;
	}

	public static String getRefProvIdByVmid(String vmid,Connection con) throws SQLException
	{
		String strSQL = "";
		ResultSet rsUsers = null;
		String uid = "" ;
		Statement stmt = con.createStatement();
		//System.out.println("VMID="+vmid);
		strSQL = "Select uid from users where vmid = '"+vmid+"' and delflag=0";
		//System.out.println(strSQL);
		rsUsers = stmt.executeQuery(strSQL);
		if(rsUsers.next())
		{
			uid = rsUsers.getString("UID");
		}

		stmt.close();
		return uid;
	}

	/*Find userType by uid ***************-by Niteesh*/
	public static int getUserTypeByUid(int uid,Connection conDest) throws SQLException
	{
		String strSQL = "";
		ResultSet rsUsers = null;
		int userType = 0 ;
		Statement stmt = conDest.createStatement();
		//System.out.println("VMID="+vmid);
		strSQL = "Select userType from users where uid ="+uid;
		//System.out.println(strSQL);
		rsUsers = stmt.executeQuery(strSQL);
		if(rsUsers.next())
		{
			userType = rsUsers.getInt("userType");
		}

		stmt.close();
		return userType;
	}



	/**********************************************************************************************************
	 *  Guarantor Related Functions
	 * 
	 **********************************************************************************************************/

	/* 
	 * Standard Guarantor Function that searches for Guarantor or Patient duplicates in certain patter 
	 * Generally you would need to call this function for checking duplicates before adding guarantors
	 * 
	 * */


	public static int getPatOrGuarStandardSearch(String strLast,String strFirst, String strDOB, String strAddr1, String strZip, Connection con) throws Exception
	{

		int uid = 0 ;

		//Search by Name & DOB First
		uid = getPatOrGurByNameDOB(strLast, strFirst, strDOB, con);

		if (uid ==0 )
		{
			//Search by Name,Address1 & ZIp
			uid = getPatOrGurByNameAddrZip(strLast, strFirst, strAddr1, strZip, con);
		}

		if (uid ==0)
		{
			//Search by Name & ZipCode
			uid = getPatOrGurByNameZip(strLast, strFirst, strZip, con);
		}

		return uid;
	}

	public static int getPatOrGurByNameDOB(String strLast,String strFirst, String strDOB, Connection con) throws Exception
	{
		String strSQL = "";
		ResultSet rsPat = null;
		int uid = 0 ;
		Statement stmt = con.createStatement();

		if (strLast.equals("")) 
		{
			return 0;
		}

		strSQL = "select uid,usertype from users where  ulname='" + strLast + "' and "; 
		strSQL += " ufname='" + strFirst + "' and " ;
		strSQL += " dob='" + strDOB + "' and delflag = 0 and usertype in (3,4) ";

		rsPat = stmt.executeQuery(strSQL);
		if(rsPat.next())
		{
			uid = rsPat.getInt("UID");
		}

		return uid;
	}

	/* Find Patient/Gurantors By Name, Address1 & ZipCode */
	public static int getPatOrGurByNameAddrZip(String strLast,String strFirst, String strAddr1, String strZip, Connection con) throws Exception
	{
		String strSQL = "";
		ResultSet rsUsr = null;
		int uid = 0 ;
		Statement stmt = con.createStatement();

		strSQL = "select uid,usertype from users where  ulname='" + strLast + "' and "; 
		strSQL += " ufname='" + strFirst + "' and upaddress='" + strAddr1 + "' ";
		strSQL += " and zipcode = '" + strZip  +  "' and delflag = 0 and usertype in (3,4) " ;

		rsUsr = stmt.executeQuery(strSQL);
		if(rsUsr.next())
		{
			uid = rsUsr.getInt("UID");
		}

		return uid;
	}

	/* Find Patient/Gurantors By Name & ZipCode */
	public static int getPatOrGurByNameZip(String strLast,String strFirst, String strZip, Connection con) throws Exception
	{
		String strSQL = "";
		ResultSet rsUsr = null;
		int uid = 0 ;
		Statement stmt = con.createStatement();

		strSQL = "select uid,usertype from users where  ulname='" + strLast + "' and "; 
		strSQL += " ufname='" + strFirst + "' and " ;
		strSQL += " zipcode='" + strZip + "' and delflag = 0 and usertype in (3,4) " ;

		rsUsr = stmt.executeQuery(strSQL);
		if(rsUsr.next())
		{
			uid = rsUsr.getInt("UID");
		}

		return uid;
	}

	/* Find Patient/Guarantors By Name & SSN */
	public static int getPatOrGurByNameSSN(String strLast,String strFirst, String strSSN, Connection con) throws Exception
	{
		String strSQL = "";
		ResultSet rsUsr = null;
		int uid = 0 ;
		Statement stmt = con.createStatement();

		strSQL = "select uid,usertype from users where  ulname='" + strLast + "' and "; 
		strSQL += " ufname='" + strFirst + "' and " ;
		strSQL += " ssn='" + strSSN + "' and delflag = 0 and usertype in (3,4)" ;

		rsUsr = stmt.executeQuery(strSQL);
		if(rsUsr.next())
		{
			uid = rsUsr.getInt("UID");
		}

		return uid;
	}


	/**********************************************************************************************************
	 *  Facility Related Functions
	 * 
	 **********************************************************************************************************/
	//----------------------------------kashif-----------------------

	public static int getFacilityByVMID(String strVMID, Connection con) throws Exception
	{
		String strSQL = "";
		ResultSet rsUsers = null;
		Statement stmt = con.createStatement();
		int id = 0 ;


		strSQL = "Select id from edi_facilities where vmid= '" + strVMID + "' and vmid <> '' and deleteflag = 0";
		rsUsers = stmt.executeQuery(strSQL);
		if(rsUsers.next())
		{
			id = rsUsers.getInt("ID");
		}

		stmt.close();
		return id;
	}


	public static int getPharmByVMID(String strVMID, Connection con) throws Exception
	{
		String strSQL = "";
		ResultSet rsUsers = null;
		Statement stmt = con.createStatement();
		int id = 0 ;

		strSQL = "Select pmcid from pharmacy where vmid= '" + strVMID + "' and vmid <> '' and delflag = 0";
		rsUsers = stmt.executeQuery(strSQL);
		if(rsUsers.next())
		{
			id = rsUsers.getInt("pmcid");
		}

		stmt.close();
		return id;
	}


	public static int getZipByVMID(String strVMID, Connection con) throws Exception
	{
		String strSQL = "";
		ResultSet rsUsers = null;
		Statement stmt = con.createStatement();
		int id = 0 ;


		strSQL = "Select zipid from zipcodes where vmid= '" + strVMID + "' and vmid <> '' and deleteflag = 0";
		rsUsers = stmt.executeQuery(strSQL);
		if(rsUsers.next())
		{
			id = rsUsers.getInt("zipid");
		}

		stmt.close();
		return id;
	}

	public static String Left(String str, int n){
		if (n <= 0)
			return "";
		else if (n > str.length())
			return str;
		else
			return str.substring(0,n);
	}

	public static String Right(String str, int n){
		if (n <= 0)
			return "";
		else if (n > str.length())
			return str;
		else
			return str.substring(0,n);
	}

	/*
	 * Get Primary Facility Details
	 * It returns a hashtable with key as ID, and value as Name
	 */


	public static Hashtable<Integer, String> getPrimaryFacility(Connection con) throws Exception
	{
		String strSQL = "";
		ResultSet rsUsers = null;
		Statement stmt = con.createStatement();
		int id = 0 ;
		String strFacName = "";

		Hashtable<Integer, String> htFacility = new Hashtable<Integer, String>();

		strSQL = "Select id,name from edi_facilities where primaryfacility=1  and deleteflag = 0";
		rsUsers = stmt.executeQuery(strSQL);
		if(rsUsers.next())
		{
			id = rsUsers.getInt("ID");
			strFacName = rsUsers.getString("name");
			htFacility.put(id, strFacName);

		}

		stmt.close();
		return htFacility;
	}




	/**********************************************************************************************************
	 *  Appointments Related Functions
	 * 
	 **********************************************************************************************************/


	/** 
	 * Created by   : Ravi 
	 * Date Created : Oct/28/2012
	 * Purpose      : method for Appointments
	 * Comments     : Status - under development
	 * Date Modified:
	 * Modified by  :  
	 * */

	public static int getEncByVMID(String strVMID, Connection con) throws Exception	{
		String strSQL = "";
		ResultSet rsEnc = null;
		Statement stmt = con.createStatement();
		int id = 0 ;

		strSQL = "Select EncounterID From Enc where vmid= '" + strVMID + "' and vmid <> '' and deleteflag = 0";

		rsEnc = stmt.executeQuery(strSQL);
		if(rsEnc.next()) {
			id = rsEnc.getInt("EncounterID");
		}

		stmt.close();
		return id;
	}


	public static int getEncByPatID(long strPatID, long strDrID, long strResourceID, String strDate, String strStartTime, Connection con) throws Exception	{
		String strSQL = "";
		ResultSet rsEnc = null;
		Statement stmt = con.createStatement();
		int id = 0 ;

		strSQL = "Select EncounterID From Enc where patientid = '" + strPatID + "' And doctorid = '" + strDrID + "' And resourceid = '" + strResourceID + "' And Date='" + strDate + "' And starttime= '" + strStartTime + "' And deleteflag = 0";

		rsEnc = stmt.executeQuery(strSQL);
		if(rsEnc.next()) {
			id = rsEnc.getInt("EncounterID");
		}

		stmt.close();
		return id;
	}



	/**********************************************************************************************************
	 *  Contacts Related Functions
	 * 
	 **********************************************************************************************************/


	/** 
	 * Created by   : Ravi 
	 * Date Created : Aug/18/2011
	 * Purpose      : method for contacts
	 * Comments     : Status - working
	 * Date Modified:
	 * Modified by  :  
	 * */

	public static int getContactsByVMID(String strVMID, Connection con) throws Exception {
		String strSQL = "";
		ResultSet rsUsers = null;
		Statement stmt = con.createStatement();
		int id = 0 ;

		strSQL = "Select contactid from Contacts where vmid= '" + strVMID + "' and vmid <> '' and delflag = 0";

		rsUsers = stmt.executeQuery(strSQL);
		if(rsUsers.next())	{
			id = rsUsers.getInt("contactid");
		}

		stmt.close();
		return id;
	}

	public static int getEmployerByName(String StrEmpName, Connection con) throws Exception	{
		String strSQL = "";
		ResultSet rsUsers = null;
		Statement stmt = con.createStatement();
		int id = 0 ;


		strSQL = "Select ID from Employer where EmpName= '" + StrEmpName + "'";
		rsUsers = stmt.executeQuery(strSQL);
		if(rsUsers.next())	{
			id = rsUsers.getInt("ID");
		}

		stmt.close();
		return id;
	}

	public static int getInsuranceByVMID(String strVMID, Connection con) throws Exception {
		String strSQL = "";
		ResultSet rsUsers = null;
		Statement stmt = con.createStatement();
		int id = 0 ;


		strSQL = "Select InsID from Insurance where vmid= '" + strVMID + "' and vmid <> '' and deleteflag = 0";
		rsUsers = stmt.executeQuery(strSQL);
		if(rsUsers.next())	{
			id = rsUsers.getInt("InsID");
		}

		stmt.close();
		return id;
	}

	public static int getDefaultFeeschid(Connection con) throws Exception {
		String strSQL = "";
		ResultSet rsUsers = null;
		Statement stmt = con.createStatement();
		int id = 0 ;


		strSQL = "Select id from feeschlist where masterFeeSch=1";
		rsUsers = stmt.executeQuery(strSQL);
		if(rsUsers.next())	{
			id = rsUsers.getInt("id");
		}

		stmt.close();
		return id;
	}


	public static String AMPM(String time)
	{
		String[] times = time.split(" ");
		time = times[0];

		String[] tim = time.split(":");
		String hh = tim[0];
		int h = Integer.parseInt(hh);
		String AMPM = times[1];
		if(AMPM.contains("PM"))
		{
			if(h !=12)
			{
				h = h + 12;
				time = h + ":" + tim[1] + ":" + tim[2];
				//time = h + ":" + tim[1];
			}
			/*else if(h ==12)
			{

				time = h + ":" + tim[1] + ":" + tim[2];
			}*/

		}
		return time;
	}


	public static String getVmidByInsNameAddressCityStateZip(String name,String address , String city , String state , String zip , Connection con) throws Exception{
		String sql4="";
		Statement stmt4 = null;
		ResultSet rs4=null; 
		stmt4=con.createStatement();

		sql4="select * from InsuranceList where [Insurance Name]='"+name+"' and [Insurance Address]='"+address+"' and [Insurance City]='"+city+"' and [Insurance State]='"+state+"' and [Insurance Zip Code]='"+zip+"'";
		// sql4="SELECT Id FROM InsuranceList where   InsuranceList.[Insurance Name]='HUMANA CLAIMS OFFICE'  and  InsuranceList.[Insurance Address]='P.O Box 14635,' and  InsuranceList.[Insurance City]='Lexington' and  InsuranceList.[Insurance State]='KY' and  InsuranceList.[Insurance Zip Code]='40512'";
		System.out.println("query: "+sql4);
		rs4=stmt4.executeQuery(sql4);

		String id="";
		if(rs4!=null){
			while(rs4.next()){
				id=JUtil.validateString(rs4.getString("Id"));
				System.out.println("Ins VMID: "+id);
			}


		}


		return id;
	}



	public static String getVmidByInsNameAddressCityState(String name,String address , String city , String state , Connection con) throws Exception{
		String sql4="";
		Statement stmt4 = null;
		ResultSet rs4=null; 
		stmt4=con.createStatement();

		sql4="select * from InsuranceList where [Insurance Name]='"+name+"' and [Insurance Address]='"+address+"' and [Insurance City]='"+city+"' and [Insurance State]='"+state+"'";
		// sql4="SELECT Id FROM InsuranceList where   InsuranceList.[Insurance Name]='HUMANA CLAIMS OFFICE'  and  InsuranceList.[Insurance Address]='P.O Box 14635,' and  InsuranceList.[Insurance City]='Lexington' and  InsuranceList.[Insurance State]='KY' and  InsuranceList.[Insurance Zip Code]='40512'";
		System.out.println("query: "+sql4);
		rs4=stmt4.executeQuery(sql4);

		String id="";
		if(rs4!=null){
			while(rs4.next()){
				id=JUtil.validateString(rs4.getString("Id"));
				System.out.println("Ins VMID: "+id);
			}


		}


		return id;
	}

	public static int getRefProviderUidByFname(String refFName, Connection connDest) throws SQLException {
		String strSQL="";
		ResultSet rs1=null;
		Statement stmt1=null;
		stmt1=connDest.createStatement();

		int uid=0;

		strSQL="select uid from users where usertype=5 and ufname like '"+refFName+"'";
		rs1=stmt1.executeQuery(strSQL);
		if(rs1!=null){
			while(rs1.next()){
				uid=rs1.getInt("uid");
			}
		}

		return uid;
	}

	public static int getProviderUidByFname(String refFName, Connection connDest) throws SQLException {

		String strSQL="";
		ResultSet rs1=null;
		Statement stmt1=null;
		stmt1=connDest.createStatement();

		int uid=0;

		strSQL="select uid from users where usertype=3 and ufname like '"+refFName+"'";
		rs1=stmt1.executeQuery(strSQL);
		if(rs1!=null){
			while(rs1.next()){
				uid=rs1.getInt("uid");
			}
		}

		return uid;
	}

	public static int getUidGuarByFnameLName(String fName, String lName, Connection connDest) throws SQLException {

		String strSQL="";
		ResultSet rs1=null;
		Statement stmt1=null;
		stmt1=connDest.createStatement();
		int uid=0;
		strSQL="select * from users where usertype=3 and ufname='"+fName+"' and ulname='"+lName+"'";
		rs1=stmt1.executeQuery(strSQL);
		if(rs1!=null){
			while(rs1.next()){
				uid=rs1.getInt("uid");
			}
		}
		return uid;

	}

	public static int getUidGUarPatByFnameLName(String fName, String lName, Connection connDest) throws SQLException {

		String strSQL="";
		ResultSet rs1=null;
		Statement stmt1=null;
		stmt1=connDest.createStatement();
		int uid=0;
		strSQL="select * from users where usertype=4 and ufname='"+fName+"' and ulname='"+lName+"'";
		rs1=stmt1.executeQuery(strSQL);
		if(rs1!=null){
			while(rs1.next()){
				uid=rs1.getInt("uid");
			}
		}
		return uid;

	}

	public static String getuidByDocFName(String docFName, Connection connDest) throws SQLException {

		String strSQL="";
		ResultSet rs1=null;
		Statement stmt1=null;
		stmt1=connDest.createStatement();

		String uid="";
		strSQL="select vmid from users where usertype=1 and ufname='"+docFName+"'";
		rs1=stmt1.executeQuery(strSQL);
		if(rs1!=null){
			while(rs1.next()){
				uid=rs1.getString("uid");
			}
		}

		return uid;
	}

}







