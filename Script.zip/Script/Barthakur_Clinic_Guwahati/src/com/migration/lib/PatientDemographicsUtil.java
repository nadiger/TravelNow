
package com.migration.lib;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;


/**
 * @author jay.shah
 *
 */
public class PatientDemographicsUtil {

	
	public static Date PROCESS_startTime=null;
	public static Date PROCESS_EndTime=null;
		
	/* write all utility functions here which doesn't require DB Connection
	 * 
	 */
	
		 /**
		 * @param strFileName
		 * @param strContent
		 * @throws IOException
		 * @author jay
		 * @DateCreated Oct-01-2011
		 */
		
	    
		public static void appendToFile(String strFileName, String strContent) throws IOException
		{
			 FileWriter fw = new FileWriter(strFileName,true);
			 BufferedWriter out = new BufferedWriter(fw);
			 out.write(strContent);
			 out.newLine();
			 out.close();
		 }
    
		
		
		public static String convertTitle(String title)
		{
			
			String strResult = "";
			
			if (title.equalsIgnoreCase("Mister") || title.equalsIgnoreCase("MR"))
			{
				strResult = "1";
			}
			else if (title.equalsIgnoreCase("MISS")  || title.equalsIgnoreCase("MS"))
			{
				strResult = "2";
			}
			else if (title.equalsIgnoreCase("Mistress") || title.equalsIgnoreCase("MRS"))
			{
				strResult = "3";
			}
			else if (title.equalsIgnoreCase("Baby Girl") || title.equalsIgnoreCase("FEMALE"))
			{
				strResult = "5";
			}
			else if (title.equalsIgnoreCase("MASTER") || title.equalsIgnoreCase("Master"))
			{
				strResult = "6";
			}
			else if (title.equalsIgnoreCase("Doctor") || title.equalsIgnoreCase("DR"))
			{
				strResult = "7";
			}
			else if (title.equalsIgnoreCase("Baby Boy") || title.equalsIgnoreCase("BABY"))
			{
				strResult = "53";
			}
			else
				strResult="";
			
			
			return strResult;
		}
		
		
		
		public static String convertRel (String strRelation) {
			String strResult = "";
			
			strRelation = removeSplChars(strRelation);

			if (strRelation.equalsIgnoreCase("Father") || strRelation.equalsIgnoreCase("FATHER")) {
				strResult  = "3";
			}
			else if (strRelation.equalsIgnoreCase("Mother") || strRelation.equalsIgnoreCase("MOTHER")) {
				strResult  = "5";
			}
			else if (strRelation.equalsIgnoreCase("Co-brother")) {
				strResult  = "8";
			}
			else if (strRelation.equalsIgnoreCase("Spouce") || strRelation.equalsIgnoreCase("SPOUSE")) {
				strResult  = "14";
			}
			else if (strRelation.equalsIgnoreCase("Husband") || strRelation.equalsIgnoreCase("HUSBAND")) {
				strResult  = "15";
			}
			else if (strRelation.equalsIgnoreCase("Mother-in-law")) {
				strResult  = "16";
			}
			else if (strRelation.equalsIgnoreCase("Cousin")) {
				strResult  = "17";
			}
			else if (strRelation.equalsIgnoreCase("Sister-in-law")) {
				strResult  = "18";
			}
			else if (strRelation.equalsIgnoreCase("Brother-in-law")  || strRelation.equalsIgnoreCase("SOBL")) {
				strResult  = "19";
			}
			else if (strRelation.equalsIgnoreCase("Father-in-law") || strRelation.equalsIgnoreCase("FATHER-IN-LAW")) {
				strResult  = "20";
			}
			else if (strRelation.equalsIgnoreCase("Daughter-in-law") || strRelation.equalsIgnoreCase("DOUGHTER IN LAW")) {
				strResult  = "21";
			}
			else if (strRelation.equalsIgnoreCase("Son-in-law ") || strRelation.equalsIgnoreCase("SON IN LAW")) {
				strResult  = "22";
			}
			else if (strRelation.equalsIgnoreCase("Daughter") || strRelation.equalsIgnoreCase("DAUGHTER")) {
				strResult  = "23";
			}
			else if (strRelation.equalsIgnoreCase("Friend") ) {
				strResult  = "24";
			}
			else if (strRelation.equalsIgnoreCase("Grand Father")) {
				strResult  = "25";
			}
			else if (strRelation.equalsIgnoreCase("Grand Son")) {
				strResult  = "26";
			}
			else if (strRelation.equalsIgnoreCase("Grand Mother")) {
				strResult  = "27";
			}
			else if (strRelation.equalsIgnoreCase("Grand Daughter") ) {
				strResult  = "28";
			}
			else if (strRelation.equalsIgnoreCase("Brother") || strRelation.equalsIgnoreCase("BROTHER")) {
				strResult  = "29";
			}
			else if (strRelation.equalsIgnoreCase("Fiancee") ) {
				strResult  = "30";
			}
			else if (strRelation.equalsIgnoreCase("Niece") ) {
				strResult  = "34";
			}
			else if (strRelation.equalsIgnoreCase("Nephew") ) {
				strResult  = "35";
			}
			else if (strRelation.equalsIgnoreCase("Self") ) {
				strResult  = "37";
			}
			else if (strRelation.equalsIgnoreCase("others") ) {
				strResult  = "41";
			}
			else if (strRelation.equalsIgnoreCase("sister") || strRelation.equalsIgnoreCase("SISTER")) {
				strResult  = "43";
			}
			else if (strRelation.equalsIgnoreCase("Step Daughter") ) {
				strResult  = "44";
			}
			else if (strRelation.equalsIgnoreCase("Step Mother") ) {
				strResult  = "45";
			}
			else if (strRelation.equalsIgnoreCase("wife") || strRelation.equalsIgnoreCase("WIFE")) {
				strResult  = "46";
			}
			else if (strRelation.equalsIgnoreCase("Son") || strRelation.equalsIgnoreCase("SON")) {
				strResult  = "53";
			}
			else if(strRelation.equalsIgnoreCase("OTHERS") || strRelation.equalsIgnoreCase("other")){
				strResult="41";
			}
			else {
				strResult = "41";  //others
			}
			return strResult;
		}
		
		
		
		/**
		 * @param strSex
		 * @return  male or female
		 * @author Vishwanath
		 */
		public static String convertSex(String strSex)
		{
			String strResult = "";
			
			if (strSex.equalsIgnoreCase("MALE") || strSex.equalsIgnoreCase("Male"))
			{
				strResult = "M";
			}
			else if (strSex.equalsIgnoreCase("Female") || strSex.equalsIgnoreCase("FEMALE"))
			{
				strResult = "F";
			}
			else
			{
				strResult = "A";
			}
			
			return strResult;
		}
		
		
		
		
		/**
		 * @param strMaritalStatus
		 * @return
		 * @author Vishwanath
		 */
		
		public static String convertMaritalStatus(String strMaritalStatus)
		{
			String strResult = "";
			
			
			if (strMaritalStatus.equalsIgnoreCase("Married") || strMaritalStatus.equalsIgnoreCase("MSMA"))
			{
				strResult  = "1";
			}
			else if (strMaritalStatus.equalsIgnoreCase("Unmarried")  )
			{
				strResult  = "2";
			}
			else if (strMaritalStatus.equalsIgnoreCase("Widow"))
			{
				strResult  = "3";
			}
			else if (strMaritalStatus.equalsIgnoreCase("Single") || strMaritalStatus.equalsIgnoreCase("MSSI"))
			{
				strResult  = "4";
			}
			else if (strMaritalStatus.equalsIgnoreCase("Divorced"))
			{
				strResult  = "16";
			}else{
				strResult="4";
			}
			return strResult;
			
		}
		
		
		
		
		
		 public static String convertReligion(String religion)
			{
				String strResult="";
				

				if (religion.equalsIgnoreCase("Hindu") || religion.equalsIgnoreCase("HINDU"))
				{
					strResult  = "1";
				}
				else if (religion.equalsIgnoreCase("Christian")  || religion.equalsIgnoreCase("CHRISTIAN"))
				{
					strResult  = "3";
				}
				else if (religion.equalsIgnoreCase("Sikhisms") || religion.equalsIgnoreCase("SIKH"))
				{
					strResult  = "4";
				}
				else if (religion.equalsIgnoreCase("Buddhism")  || religion.equalsIgnoreCase("Buddhist"))
				{
					strResult  = "5";
				}
				else if (religion.equalsIgnoreCase("Jain") || religion.equalsIgnoreCase("JAIN"))
				{
					strResult  = "6";
				}
				else if (religion.equalsIgnoreCase("African"))
				{
					strResult  = "41";
				}
				else if (religion.equalsIgnoreCase("Un-Known") )
				{
					strResult  = "57";
				}
				else if (religion.equalsIgnoreCase("musilm") || religion.equalsIgnoreCase("Muslim"))
				{
					strResult  = "59";
				}
				else if (religion.equalsIgnoreCase("Zorastian"))
				{
					strResult  = "71";
				}
				else
				{
					strResult = "";
				}

				return strResult;
				
			}
		
		
		 
		 
		 

			/**
			 * @param strLanguage
			 * @return
			 * @author vishwanath.maity
			 */
			 
			 
			 public static String convertBloodGroup(String bloodGroup)
				{
					String strbloodGroup="";
					

					if (bloodGroup.equalsIgnoreCase("A+")  || bloodGroup.equalsIgnoreCase("BGAP"))
					{
						strbloodGroup  = "1";
					}
					else if (bloodGroup.equalsIgnoreCase("A-") || bloodGroup.equalsIgnoreCase("BGAN"))
					{
						strbloodGroup  = "2";
					}
					else if (bloodGroup.equalsIgnoreCase("B+")  || bloodGroup.equalsIgnoreCase("BGBP"))
					{
						strbloodGroup  = "3";
					}
					else if (bloodGroup.equalsIgnoreCase("B-")  || bloodGroup.equalsIgnoreCase("BGBN"))
					{
						strbloodGroup  = "4";
					}
					else if (bloodGroup.equalsIgnoreCase("AB+")  || bloodGroup.equalsIgnoreCase("BGAB"))
					{
						strbloodGroup  = "5";
					}
					else if (bloodGroup.equalsIgnoreCase("AB-") || bloodGroup.equalsIgnoreCase("BABN"))
					{
						strbloodGroup  = "6";
					}
					else if (bloodGroup.equalsIgnoreCase("O+")  || bloodGroup.equalsIgnoreCase("BGOP"))
					{
						strbloodGroup  = "7";
					}
					else if (bloodGroup.equalsIgnoreCase("O-") || bloodGroup.equalsIgnoreCase("BGON"))
					{
						strbloodGroup  = "8";
					}
					return strbloodGroup;
					
				}
			
		 
		 
		 
			 public static String convertreferralTypes(String referralTypes)
				{
					String strResult = "";
					
					if (referralTypes.equalsIgnoreCase("Internal"))
					{
						strResult = "1";
					}
					else if (referralTypes.equalsIgnoreCase("External"))
					{
						strResult = "2";
					}
					else if (referralTypes.equalsIgnoreCase("Self"))
					{
						strResult = "3";
					}
					else if (referralTypes.equalsIgnoreCase("Hospital_consultant"))
					{
						strResult = "4";
					}
					else if (referralTypes.equalsIgnoreCase("Hospital"))
					{
						strResult = "5";
					}
					else if (referralTypes.equalsIgnoreCase("Doctor"))
					{
						strResult = "6";
					}
					else
					{
						strResult = "3";
					}
					
					return strResult;
				}
			 
		 
		
			 
			 public static String convertVip(String strVip)
				{
					String strResult = "";
					
					if (strVip.equalsIgnoreCase("1") || strVip.equalsIgnoreCase("YES"))
					{
						strResult = "Y";
					}
					else if (strVip.equalsIgnoreCase("0") || strVip.equalsIgnoreCase("NO"))
					{
						strResult = "N";
					}
					return strResult;
				}
			 
			 
			 
			 
			 
		
		public static String convertName(String userName)
		{
			System.out.println(userName);
			if(userName !=null)
			{
				String one  = userName.substring(0, 1);
				one = one.toUpperCase();
				userName = userName.substring(1, userName.length());
				userName = one + userName;
			}	
			return userName;
		}
		
		public static int getUserType(int strVMID, Connection con) throws Exception {
			
			String strSQL = "";
			ResultSet rsUsers = null;
			int uid = 0 ;
			Statement stmt3 = con.createStatement();
			
			strSQL = "Select usertype from users where uid = '" + strVMID + "'";
			rsUsers = stmt3.executeQuery(strSQL);
			if (rsUsers.next()) {
				uid = rsUsers.getInt("usertype");
			}
			
			stmt3.close();
			return uid;
		}
		  
		
		
		
		
		
		 public static void logExceptions(Exception e) 
		 {
			 try
			 {
				 FileWriter fw = new FileWriter("Exceptions.txt",true);
				 BufferedWriter out = new BufferedWriter(fw);
				 out.write(e.toString());
				 out.newLine();
				 out.close();
			 }catch(IOException e1)
			 {
				 e1.printStackTrace();
			 }
		 }
	 
	 
	 
		/**
		 * @param str
		 * @return Validation of String
		 * @author Ravi
		 * @DateCreated aug-21-2011
		 * 
		 */
	 
		public static String validateString(String str) throws Exception
		{
		    String strRet = "";
		    if (str == null || str=="NULL" ||str.equals("NULL"))
		    	str = "";

		    strRet = str.trim();
		    strRet = str.replaceAll("'", "");
		    return strRet;
		}

		
		/**
		 * @param str: Phone number 
		 * @return Validation for Special characters
		 * @author Ravi
		 * @Date aug-21-2011
		 * 
		 */
		
		/*public static String formatPhone(String str)
		{		
			String s=str;
			String s2="";
			final StringBuilder result = new StringBuilder();
			
			for (int i = 0; i < s.length(); i++) {
				if (Character.isDigit(s.charAt(i)))
					result.append(s.charAt(i));
				}
			s2=result.toString();
				
			if (s2.length() == 10)
				return s2.substring(0, 3) + "-" + s2.substring(3, 6)  + "-" + s2.substring(6, 10);
			else
				return "";		
			}*/
			
        
		/**
		 * @param str: Any String 
		 * @return Returns True if the given String is numeric
		 * @author Ravi
		 * @DateCreated aug-21-2011
		 * 
		 */
		
		public static boolean isNumeric(String str)
		{
			//Return false if we find a non-digit character.
			String s=str;
			for (int i = 0; i < s.length(); i++) {
			if (!Character.isDigit(s.charAt(i)))
				return false;
			}
			return true;
		}
        
		
		/**
		 * @param str: Any String 
		 * @return Returns True if the given String has no digit, else False
		 * @author Ravi
		 * @Date aug-21-2011
		 * 
		 */
	
		public static boolean isAlpha(String str)
		{
			//Return false if we find a non-digit character.
			String s=str;
			for (int i = 0; i < s.length(); i++) {
			if (s.charAt(i) >= 'A' && s.charAt(i) <= 'Z'|| s.charAt(i) >= 'a' && s.charAt(i) <= 'z') 			
				return false;
			}
			return true;
		}
		

		
		/**
		 * @param str: Any String 
		 * @return String removing special characters
		 * @author Ravi
		 * @DateCreated aug-21-2011
		 * 
		 */
		
		public static String removeSplChars(String str)
		{
			//remove special character.				
			String s=str;
			final StringBuilder result = new StringBuilder();
		     
			for (int i = 0; i < s.length(); i++) {
				if (s.charAt(i) == '?' || s.charAt(i) == '!' || s.charAt(i) == '&' || s.charAt(i) == '>' || +
					s.charAt(i) == '<' || s.charAt(i) == '#' || s.charAt(i) == '$' || s.charAt(i) == '(' || +
					s.charAt(i) == ')' || s.charAt(i) == '[' || s.charAt(i) == ']' || s.charAt(i) == '{' || +
					s.charAt(i) == '}' || s.charAt(i) == '%' || s.charAt(i) == '*' || s.charAt(i) == '+' || +
					s.charAt(i) == '-' || s.charAt(i) == ',' || s.charAt(i) == ';' || s.charAt(i) == ':' || + 			
				    s.charAt(i) == '/' || s.charAt(i) == '=' || s.charAt(i) == '@' || s.charAt(i) == '.' || +			
				    s.charAt(i) == '^' || s.charAt(i) == '_' || s.charAt(i) == '"' || s.charAt(i) == '`' || +
				    s.charAt(i) == '~' || s.charAt(i) == '|' || s.charAt(i) == '\\' || s.charAt(i) == '\'' || +
				    s.charAt(i) == '\t') {}
				else
					result.append(s.charAt(i));
			}  //end of for loop
			return result.toString();
		}
		
	
		/**
		 * @param str: Any String 
		 * @return Formatted SSN
		 * @author Mihir
		 * @DateCreated : Oct-04-2011
		 * 
		 */
		
		public static String formatSSN(String str)
		{		
			String s=str;
			String s2="";
			StringBuilder result = new StringBuilder();

			for (int i = 0; i < s.length(); i++) {
				if (Character.isDigit(s.charAt(i)))
					result.append(s.charAt(i));
			}
			s2=result.toString();

			if (s2.length() == 9)
				return s2.substring(0, 3) + "-" + s2.substring(3,5)  + "-" + s2.substring(5, 9);
			else
				return "";	
			}
		


		/**
		 * @param strDate: String format of Date
		 * @param strDatePattern: Pattern of String date without special character 
		 * 				(Supported format: MMDDYY, YYMMDD,MMDDYYYY,YYYYDDMM,YYYYMMDD  )
		 * @return String Containing Formatted DOB
		 * @throws Exception
		 * @author Mihir
		 * @ModifiedBy Jay
		 */
		
		public static String formatDateTo_MMDDYYYY(String strDOB, String strDatePattern)  throws Exception
		{		
			String s=removeSplChars(strDOB);
					
			if (strDatePattern.equals("MMDDYY"))
			{
				return s.substring(0,2) + "/" + s.substring(2,4) + "/" + s.substring(4,6);
			}
			else if (strDatePattern.equals("YYMMDD"))
			{
				return s.substring(2,4) + "/" + s.substring(4,6) + "/" + s.substring(0,2);
			}
			else if (strDatePattern.equals("MMDDYYYY"))
			{
				return s.substring(0,2) + "/" + s.substring(2,4) + "/" + s.substring(4,8);
			}
			else if (strDatePattern.equals("YYYYDDMM"))
			{
				return s.substring(6,8) + "/" + s.substring(4,6) + "/" + s.substring(0,4);
			}
			else if (strDatePattern.equals("YYYYMMDD")){
				return s.substring(4,6) + "/" + s.substring(6,8) + "/" + s.substring(0,4);
			}
			else if (strDatePattern.equals("MM/DD/YYYY")){
				return s;
			}
			
			else
			{
				return "";
			}		
		}


		/**
		 * @param strDate: String format of Date
		 * @param strDatePattern: Pattern of String date (Provide the pattern in which the String is formatted - M or d or y )
		 *  					M = Month, d= Day (Small d), y (Small y) = Year , for ex. 01/01/2000 -> MM/dd/yyyy, 
		 *  					 20101005 -> yyyyMMdd ;   1/1/2000 -> MM/dd/YYYY,
		 * @return  Date in YYYY-MM-DD format, used by PTDOB field
		 * @throws Exception
		 * @author jay
		 */
		
		public static String formatDate_PTDOB_YYYYMMDD(String strDate, String strDateInputPattern) throws Exception
		{	
			DateFormat formatterInput;
			DateFormat formatterOutput;
			
			if (strDate.equals(""))
				return "";
			
			if ( strDateInputPattern == "")
			{
				strDateInputPattern = "MM/DD/yyyy";
			}
			
			formatterInput = new SimpleDateFormat(strDateInputPattern);
			Date date = formatterInput.parse(strDate);
			
			formatterOutput = new SimpleDateFormat("yyyy-MM-DD");
			
			return formatterOutput.format(date);		
		}

		/**
		 * @param strDate: String format of Date
		 * @param strDatePattern: Pattern of String date (Provide the pattern in which the String is formatted - M or d or y )
		 *  					M = Month, d= Day (Small d), y (Small y) = Year , for ex. 01/01/2000 -> MM/dd/yyyy, 
		 *  					 20101005 -> yyyyMMdd ;   1/11/2000 -> MM/dd/YYYY,
		 * @return  Date in MM/DD/YYYY format, used by DOB field
		 * @throws Exception
		 * @author jay
		 */
		
		public static String formatDate_DOB_MMDDYYYY(String strDate, String strDateInputPattern) throws Exception
		{	
			DateFormat formatterInput;
			DateFormat formatterOutput;
			
			
			if (strDate.equals("") || strDate==null)
				return "";
			
			if ( strDateInputPattern == "")
			{
				strDateInputPattern = "MM/dd/yyyy";
			}
			
			formatterInput = new SimpleDateFormat(strDateInputPattern);
			Date date = formatterInput.parse(strDate);
			
			formatterOutput = new SimpleDateFormat("MM/dd/yyyy");
			
			return formatterOutput.format(date);		
		}
		
		
		

		/**
		 * @param  <<strStartTime>>          String format of TIME
		 * @param  <<strDatePattern>>        "HH:mm:ss"
		 * @return <<Time>>  in HH:mm:ss format, used Appointment start time
		 * @throws Exception
		 * author: Ravi
		 * Date  : Nov/1/2012    UNDER TESTING - DONT USE
		 */
		
		public static String getTime_from_Duration(String strStartTime, String strMinutes, String strDateInputPattern) throws Exception
		{	
			// String strEndTime = "";

			String[] splitsTime = strStartTime.split(":");
			
			
			String min = splitsTime[1];
			String hrs = splitsTime[0];
			String time = hrs + ":" + min;
			if (strStartTime.equals(""))
				return "";
				
			if ( strDateInputPattern == "")
			{
					strDateInputPattern = "HH:mm:ss";
					//strDateInputPattern = "HHmm";
			}
			  
			SimpleDateFormat format = new SimpleDateFormat(strDateInputPattern);
			Date startDate = format.parse(time);
			Calendar calendar = new GregorianCalendar();
			calendar.setTime(startDate);
			calendar.add(Calendar.MINUTE, Integer.parseInt(strMinutes));
			return format.format(calendar.getTime());
		}
		
		
	

		
		
		
		/**
		 * @param strZip
		 * @return
		 * @author Jay
		 */
		public static String convertZip(String strZip)
		{
			if(strZip.equals("")) return "";
			strZip = removeSplChars(strZip);
			
			StringBuffer sbResult = new StringBuffer();
			strZip = strZip.trim();
			
			if(strZip.length() >=9 )
			{
				sbResult.append(strZip.substring(0, 4)).append("-").append(strZip.substring(5, 8));
			}
			else if (strZip.length()> 5  && strZip.length()< 9)
			{
				sbResult.append(strZip.substring(0, 4));
			}
			else if (strZip.length() <=5)
			{
				//Prefix 0
				int i = 0;
				for(i=0 ;i < 5 - strZip.length(); i++)
				{
					sbResult.append("0");
				}
				sbResult.append(strZip);
			}
			
			return sbResult.toString();
			
		}
		
		
		
		
		
		
		
		
		
		
		 
		
		 
		 
		 
		 
		
		
		
		
		
		
		
		
		/**
		 * @param strEmpStatus
		 * @return
		 * @author Jay
		 */
		
		public static  String convertEmpStatus1(String strEmpStatus)
		{
			String strResult = "";
			strEmpStatus = removeSplChars(strEmpStatus);
			
			if (strEmpStatus.equalsIgnoreCase("F") || strEmpStatus.equalsIgnoreCase("E")|| strEmpStatus.equalsIgnoreCase("FULL TIME EMPLOYED")
				|| strEmpStatus.equalsIgnoreCase("Y") || strEmpStatus.equalsIgnoreCase("YES")|| strEmpStatus.equalsIgnoreCase("EMP")	)
			{
				strResult  = "1";
			}
			else if (strEmpStatus.equalsIgnoreCase("P") || strEmpStatus.equalsIgnoreCase("PART TIME") || strEmpStatus.equalsIgnoreCase("PART-TIME EMPLOYE") )
			{
				strResult  = "2";
			}
			else if (strEmpStatus.equalsIgnoreCase("N") || strEmpStatus.equalsIgnoreCase("NOT EMPLOYED") || strEmpStatus.equalsIgnoreCase("UNEMPLOYED")
					|| strEmpStatus.equalsIgnoreCase("NO") || strEmpStatus.equalsIgnoreCase("UNE"))
			{
				strResult  = "3";
			}
			else if (strEmpStatus.equalsIgnoreCase("S") || strEmpStatus.equalsIgnoreCase("SELF EMPLOYED") || strEmpStatus.equalsIgnoreCase("SELF EMPLOYED") )
			{
				strResult  = "4";
			}
			else if (strEmpStatus.equalsIgnoreCase("R") || strEmpStatus.equalsIgnoreCase("RETIRED") || strEmpStatus.equalsIgnoreCase("RET") )
			{
				strResult  = "5";
			}
			else if (strEmpStatus.equalsIgnoreCase("MILITARY") || strEmpStatus.equalsIgnoreCase("ACTIVE MILITARY DUTY") )
			{
				strResult  = "6";
			}
			else
			{
				strResult = "9";
			}
		        
			return strResult;
		}
		
		
		
		
		
		
		public static  String convertEmpStatus(String strEmpStatus)
		{
			String strResult = "";
			strEmpStatus = removeSplChars(strEmpStatus);
			
			if (strEmpStatus.equalsIgnoreCase("F") || strEmpStatus.equalsIgnoreCase("2178")|| strEmpStatus.equalsIgnoreCase("246")
				|| strEmpStatus.equalsIgnoreCase("Full time") || strEmpStatus.equalsIgnoreCase("YES")|| strEmpStatus.equalsIgnoreCase("-1")	)
			{
				strResult  = "1";
			}
			else if (strEmpStatus.equalsIgnoreCase("2") || strEmpStatus.equalsIgnoreCase("Part time") || strEmpStatus.equalsIgnoreCase("PART-TIME EMPLOYE") )
			{
				strResult  = "2";
			}
			else if (strEmpStatus.equalsIgnoreCase("N") || strEmpStatus.equalsIgnoreCase("NOT EMPLOYED") || strEmpStatus.equalsIgnoreCase("Not employed")
					|| strEmpStatus.equalsIgnoreCase("NO") || strEmpStatus.equalsIgnoreCase("247"))
			{
				strResult  = "3";
			}
			else if (strEmpStatus.equalsIgnoreCase("S") || strEmpStatus.equalsIgnoreCase("SELF EMPLOYED") || strEmpStatus.equalsIgnoreCase("SELF EMPLOYED") )
			{
				strResult  = "4";
			}
			else if (strEmpStatus.equalsIgnoreCase("R") || strEmpStatus.equalsIgnoreCase("RETIRED") || strEmpStatus.equalsIgnoreCase("245") )
			{
				strResult  = "5";
			}
			else if (strEmpStatus.equalsIgnoreCase("MILITARY") || strEmpStatus.equalsIgnoreCase("ACTIVE MILITARY DUTY") )
			{
				strResult  = "6";
			}
			else
			{
				strResult = "9";
			}
		        
			return strResult;
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		/**
		 * @param strStudentStatus
		 * @return
		 * @author Jay
		 */
		
		public static  String convertStudentStatus1(String strStudentStatus)
		{
			String strResult = "";
			//strStudentStatus = removeSplChars(strStudentStatus);
			
			if (strStudentStatus.equalsIgnoreCase("F") || strStudentStatus.equalsIgnoreCase("Full time")
				|| strStudentStatus.equalsIgnoreCase("FULLTIMESTUDENT") || strStudentStatus.equalsIgnoreCase("FTS"))
			{
				strResult  = "F";
			}
			else if (strStudentStatus.equalsIgnoreCase("P") || strStudentStatus.equalsIgnoreCase("Part time")
					|| strStudentStatus.equalsIgnoreCase("PARTTIMESTUDENT") || strStudentStatus.equalsIgnoreCase("PTS"))
			{
				strResult  = "P";
			}
			else if (strStudentStatus.equalsIgnoreCase("N") || strStudentStatus.equalsIgnoreCase("Non-student"))
			{
				strResult  = "N";
			}
			else
			{
				strResult = "";
			}
	        System.out.println("Convert Student Status="+strResult);
			return strResult;
		}
		
		
		
		
		
		
		public static  String convertStudentStatus(String strStudentStatus)
		{
			String strResult = "";
			//strStudentStatus = removeSplChars(strStudentStatus);
			
			if (strStudentStatus.equalsIgnoreCase("F") || strStudentStatus.equalsIgnoreCase("FULL TIME")
				|| strStudentStatus.equalsIgnoreCase("FULLTIMESTUDENT") || strStudentStatus.equalsIgnoreCase("276"))
			{
				strResult  = "F";
			}
			else if (strStudentStatus.equalsIgnoreCase("P") || strStudentStatus.equalsIgnoreCase("PART TIME")
					|| strStudentStatus.equalsIgnoreCase("PARTTIMESTUDENT") || strStudentStatus.equalsIgnoreCase("0"))
			{
				strResult  = "P";
			}
			else if (strStudentStatus.equalsIgnoreCase("N") || strStudentStatus.equalsIgnoreCase("1"))
			{
				strResult  = "N";
			}
			else
			{
				strResult = "";
			}
	       // System.out.println("Convert Student Status="+strResult);
			return strResult;
		}
		
		
		
		public static String convertReleseOfInfo(String str){
			String strResult="";
			if(str.equals("-1")){
				strResult="Y";
			}else{
				strResult="N";
			}
			return strResult;
		}
		
		
		
		
		
		
		
		
		
		

		
		public static String convertToProperCase(String name) {
			return name.toLowerCase().substring(0, 1).toUpperCase()+name.toLowerCase().substring(1);
		}
		
		public static String convertEthnicityStatus(String strEthnicity)
		{
			String strResult = "";
			
			strEthnicity = removeSplChars(strEthnicity);
			
			if (strEthnicity.equalsIgnoreCase("3")||strEthnicity.equalsIgnoreCase("NOT HISPANIC OR LATINO"))
			{
				strResult  = "2186-5";
			}
			else if (strEthnicity.equalsIgnoreCase("H") ||  strEthnicity.equalsIgnoreCase("HISPANIC OR LATINO") )
			{
				strResult  = "2135-2";
			}
			
			else if (strEthnicity.equalsIgnoreCase("PATIENT DECLINED"))
			{
				strResult = "2145-2";
			}
			else
			{
				strResult = "";
			}
		
			return strResult;
			
		}
				
		
}
