/**
 * 
 */
package com.migration.lib;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Hashtable;

import com.migration.form.DBConnection;
import com.migration.form.PMMigUI;
import com.mysql.jdbc.PreparedStatement;

/**
 * @author jay.shah
 *
 */

public class PatientDemographicsLib 
{


	/**********************************************************************************************************
	 *  Users Related Functions
	 * 
	 **********************************************************************************************************/
	private static Connection getConnection() throws Exception{
		Connection connDes2 = DBConnection.getDSNConnection(PMMigUI.destDNSName,PMMigUI.destUname,PMMigUI.destPwd);
		return connDes2;
	}

	public static int getOccupationByName(String strVMID, Connection con) throws Exception
	{
		String strSQL = "";
		//strVMID = strVMID.substring(0,strVMID.indexOf('.'));
		ResultSet rsUsers = null;
		int uid = 0 ;
		Statement stmt = getConnection().createStatement();
		
		java.sql.PreparedStatement pstmt=null;
		String strSQL2="";
		int i=0;
		strSQL = "Select OccupationID from Occupation where OccupationDescription='"+strVMID+"' and status='A'";
		rsUsers = stmt.executeQuery(strSQL);
		if(rsUsers.next())
		{
			uid = rsUsers.getInt("OccupationID");
		}
		if(uid==0){
			strSQL2="insert into Occupation(OccupationDescription,Status,EncodedBy,EncodedDate,LastChangedBy,LastChangedDate) values(?,?,?,?,?,?)";
			pstmt= getConnection().prepareStatement(strSQL2);
			pstmt.setString(++i, strVMID);
			pstmt.setString(++i, "A");
			pstmt.setString(++i, "2");
			pstmt.setString(++i, "2015-01-01 12:33:26.827");
			pstmt.setString(++i, "2");
			pstmt.setString(++i, "2015-01-01 12:33:26.827");
			pstmt.executeUpdate();
			
			strSQL = "Select OccupationID from Occupation where OccupationDescription='"+strVMID+"' and status='A'";
			rsUsers = stmt.executeQuery(strSQL);
			if(rsUsers.next())
			{
				uid = rsUsers.getInt("OccupationID");
			}
		}
		
		

		stmt.close();
		return uid;
	}

	public static int getSponsorIdByName(String sponsor, Connection con) throws Exception {

		String strSQL = "";
		ResultSet rsUsers = null;
		int uid = 0 ;
		Statement stmt = getConnection().createStatement();
		
		java.sql.PreparedStatement pstmt=null;
		String strSQL2="";

		strSQL = "SELECT SponsorID FROM Sponsor WHERE SponsorName = '" + sponsor + "' AND Status='A'";
		rsUsers = stmt.executeQuery(strSQL);
		if (rsUsers.next()) {
			uid = rsUsers.getInt("SponsorID");
		}
		stmt.close();
		return uid;
	}
	
	public static int getConsultantIdByName(String firstname,String lastname, Connection con) throws Exception {

		String strSQL = "";
		ResultSet rsUsers = null;
		int uid = 0 ;
		Statement stmt = getConnection().createStatement();

		strSQL = "SELECT EmployeeID FROM prEmployees WHERE FirstName = '" + firstname + "' AND LastName='"+lastname+"' and Status='A'";
		rsUsers = stmt.executeQuery(strSQL);
		if (rsUsers.next()) {
			uid = rsUsers.getInt("EmployeeID");
		}

		stmt.close();
		return uid;
	}
	

	
	
	public static int getReferralIdByName(String referral, Connection con) throws Exception {

		String strSQL = "";
		ResultSet rsUsers = null;
		int uid = 0 ;
		Statement stmt = getConnection().createStatement();

		strSQL = "SELECT ReferralID FROM Referrals WHERE ReferralDescription = '" + referral + "' AND  Status='A'";
		rsUsers = stmt.executeQuery(strSQL);
		if (rsUsers.next()) {
			uid = rsUsers.getInt("ReferralID");
		}

		stmt.close();
		return uid;
	}
	
	
	public static int getTitle(String title, Connection con) throws Exception {

		String strSQL = "";
		ResultSet rsUsers = null;
		int uid = 0 ;
		Statement stmt = getConnection().createStatement();
		
		java.sql.PreparedStatement pstmt=null;
		String strSQL2="";
		int i=0;
		strSQL = "SELECT * from title where ShortName='"+title+"' OR Description='"+title+"' and status='A'";
		rsUsers = stmt.executeQuery(strSQL);
		if (rsUsers.next()) {
			uid = rsUsers.getInt("titleid");
		}
		if(uid==0 && !title.equals("")){
			strSQL2="insert into title(ShortName,Description,Status,EncodedBy,EncodedDate,MinAge,MaxAge,Minagetype,Minagevalue,Maxagetype,Maxagevalue) values(?,?,?,?,?,?,?,?,?,?,?)";
			pstmt=getConnection().prepareStatement(strSQL2);
			pstmt.setString(++i, title);
			pstmt.setString(++i, title);
			pstmt.setString(++i, "A");
			pstmt.setString(++i, "2");
			pstmt.setString(++i, "2016-01-01 14:29:56.583");
			pstmt.setString(++i, "0");
			pstmt.setString(++i, "110");
			pstmt.setString(++i, "3"); //Min Age Type Must not be null
			pstmt.setString(++i, "1"); // Min Age Value
			pstmt.setString(++i, "1"); // Max Age Type Must not be null
			pstmt.setString(++i, "40150"); //Age Value
			pstmt.executeUpdate();
			
			strSQL = "SELECT * from title where ShortName='"+title+"' and status='A'";
			rsUsers = stmt.executeQuery(strSQL);
			if (rsUsers.next()) {
				uid = rsUsers.getInt("titleid");
			}
			
		}
		stmt.close();
		return uid;
	}
	
	public static int getStateByName(String state,String country, Connection con) throws Exception {

		String strSQL = "";
		ResultSet rsUsers = null;
		int uid = 0 ;
		Statement stmt = getConnection().createStatement();
		
		java.sql.PreparedStatement pstmt=null;
		String strSQL2="";
		int i=0;
		strSQL = "SELECT * from state where statename='"+state+"' and countryid='"+country+"' and status='A'";
		rsUsers = stmt.executeQuery(strSQL);
		if (rsUsers.next()) {
			uid = rsUsers.getInt("stateid");
		}
		if(uid==0){
			strSQL2="insert into state(CountryID,StateName,Status,EncodedBy,EncodedDate) values(?,?,?,?,?)";
			pstmt=getConnection().prepareStatement(strSQL2);
			pstmt.setString(++i, country);
			pstmt.setString(++i, state);
			pstmt.setString(++i, "A");
			pstmt.setString(++i, "2");
			pstmt.setString(++i, "2015-01-01 14:29:56.583");
			pstmt.executeUpdate();
			
			strSQL = "SELECT * from state where statename='"+state+"' and countryid='"+1+"' and status='A'";
			rsUsers = stmt.executeQuery(strSQL);
			if (rsUsers.next()) {
				uid = rsUsers.getInt("stateid");
			}
			
		}

		stmt.close();
		return uid;
	}
	
	
	
	
	public static int getCityByName(String city,String state, Connection con) throws Exception {

		String strSQL = "";
		ResultSet rsUsers = null;
		int uid = 0 ;
		Statement stmt = getConnection().createStatement();
		
		java.sql.PreparedStatement pstmt=null;
		String strSQL2="";
		int i=0;
		strSQL = "SELECT * from city where cityname='"+city+"' and stateid='"+state+"' and status='A'";
		//System.out.println(strSQL);
		rsUsers = stmt.executeQuery(strSQL);
		if (rsUsers.next()) {
			uid = rsUsers.getInt("cityid");
		}
		if(uid==0){
			strSQL2="insert into city(stateid,cityname,Status,EncodedBy,EncodedDate) values(?,?,?,?,?)";
			pstmt=getConnection().prepareStatement(strSQL2);
			pstmt.setString(++i, state);
			pstmt.setString(++i, city);
			pstmt.setString(++i, "A");
			pstmt.setString(++i, "2");
			pstmt.setString(++i, "2015-01-01 14:29:56.583");
			pstmt.executeUpdate();
			
			strSQL = "SELECT * from city where cityname='"+city+"' and stateid='"+state+"' and status='A'";
			rsUsers = stmt.executeQuery(strSQL);
			if (rsUsers.next()) {
				uid = rsUsers.getInt("stateid");
			}
			
		}

		stmt.close();
		return uid;
	}
	
	
	
	public static int getCountryByName(String country, Connection con) throws Exception {

		String strSQL = "";
		ResultSet rsUsers = null;
		int uid = 0 ;
		Statement stmt = getConnection().createStatement();
		
		java.sql.PreparedStatement pstmt=null;
		String strSQL2="";
		int i=0;
		strSQL = "SELECT * from country where countryname='"+country+"' and status='A'";
		rsUsers = stmt.executeQuery(strSQL);
		if (rsUsers.next()) {
			uid = rsUsers.getInt("countryid");
		}
		if(uid==0){
			strSQL2="insert into country(countryname,Status,EncodedBy,EncodedDate) values(?,?,?,?)";
			pstmt=getConnection().prepareStatement(strSQL2);
			pstmt.setString(++i, country);
			pstmt.setString(++i, "A");
			pstmt.setString(++i, "2");
			pstmt.setString(++i, "2015-01-01 14:29:56.583");
			pstmt.executeUpdate();
			
			strSQL = "SELECT * from country where countryname='"+country+"' and status='A'";
			rsUsers = stmt.executeQuery(strSQL);
			if (rsUsers.next()) {
				uid = rsUsers.getInt("countryid");
			}
			
		}

		stmt.close();
		return uid;
	}
	
	
	
	
	public static String getRelation(String relation, Connection con) throws Exception {

		String strSQL = "";
		ResultSet rsUsers = null;
		String uid = "" ;
		Statement stmt = getConnection().createStatement();
		
		java.sql.PreparedStatement pstmt=null;
		String strSQL2="";
		int i=0;
		strSQL = "select * from Relations where RelationDescription='"+relation+"' and status='A'";
		rsUsers = stmt.executeQuery(strSQL);
		if (rsUsers.next()) {
			uid = rsUsers.getString("RelationID");
		}
		if(uid.equals("")){
			strSQL2="insert into Relations(RelationDescription,Status,EncodedBy,EncodedDate) values(?,?,?,?)";
			pstmt=getConnection().prepareStatement(strSQL2);
			pstmt.setString(++i, relation);
			pstmt.setString(++i, "A");
			pstmt.setString(++i, "2");
			pstmt.setString(++i, "2015-01-01 14:29:56.583");
			pstmt.executeUpdate();
			
			strSQL = "SELECT * from Relations where RelationDescription='"+relation+"' and status='A'";
			rsUsers = stmt.executeQuery(strSQL);
			if (rsUsers.next()) {
				uid = rsUsers.getString("RelationID");
			}
			
		}

		stmt.close();
		return uid;
	}

	
	public static String getReligionByName(String religion, Connection con) throws Exception {

		String strSQL = "";
		ResultSet rsUsers = null;
		String uid = "" ;
		Statement stmt = getConnection().createStatement();
		
		java.sql.PreparedStatement pstmt=null;
		String strSQL2="";
		int i=0;
		strSQL = "select * from religion where ReligionDescription='"+religion+"' and status='A'";
		rsUsers = stmt.executeQuery(strSQL);
		if (rsUsers.next()) {
			uid = rsUsers.getString("ReligionID");
		}
		if(uid.equals("") && uid.equals("")){
			strSQL2="insert into religion(ReligionDescription,Status,EncodedBy,EncodedDate) values(?,?,?,?)";
			pstmt=getConnection().prepareStatement(strSQL2);
			pstmt.setString(++i, religion);
			pstmt.setString(++i, "A");
			pstmt.setString(++i, "2");
			pstmt.setString(++i, "2015-01-01 14:29:56.583");
			pstmt.executeUpdate();
			
			strSQL = "SELECT * from religion where ReligionDescription='"+religion+"' and status='A'";
			rsUsers = stmt.executeQuery(strSQL);
			if (rsUsers.next()) {
				uid = rsUsers.getString("Religionid");
			}
			
		}

		stmt.close();
		return uid;
	}

	

	public static int getUserByName(String strLast,String strFirst, Connection con, int userType ) throws Exception
	{
		String strSQL = "";
		ResultSet rsUsr = null;
		int uid = 0 ;
		Statement stmt = getConnection().createStatement();

		strSQL = "select uid, usertype from users where  ulname='" + strLast + "' and "; 
		strSQL += " ufname='" + strFirst  + "' and delflag = 0 and usertype = " + userType;

		rsUsr = stmt.executeQuery(strSQL);
		if(rsUsr.next())
		{
			uid = rsUsr.getInt("UID");
		}

		return uid;
	}

	/**********************************************************************************************************
	 *  Patients Related Functions
	 * 
	 **********************************************************************************************************/


	/* Find Patient By Name & DOB */

	public static int getPatientByNameDOB(String strLast,String strFirst, String strDOB, Connection con) throws Exception
	{
		String strSQL = "";
		ResultSet rsPat = null;
		int uid = 0 ;
		Statement stmt = getConnection().createStatement();

		strSQL = "select uid, usertype from users where  ulname='" + strLast + "' and "; 
		strSQL += " ufname='" + strFirst + "' and " ;
		strSQL += " dob='" + strDOB + "' and delflag = 0 and usertype =3 ";
		System.out.println(strSQL);
		rsPat = stmt.executeQuery(strSQL);
		if(rsPat.next())
		{
			uid = rsPat.getInt("UID");
		}

		return uid;
	}

	
	public static String getVmidPatientByNameDOB(String strLast,String strFirst, String strDOB, Connection con) throws Exception
	{
		String strSQL = "";
		ResultSet rsPat = null;
		String vmid="";
		Statement stmt = getConnection().createStatement();

		strSQL = "select vmid from users where  ulname='" + strLast + "' and  ufname='" + strFirst + "' and  dob='" + strDOB + "' and usertype =3 ";
		System.out.println(strSQL);
		rsPat = stmt.executeQuery(strSQL);
		if(rsPat.next())
		{
			vmid = rsPat.getString("vmid");
		}

		return vmid;
	}
	
	
	
	/* Find Patient By Name, Address1 & ZipCode */
	public static int getPatientsByNameAddrZip(String strLast,String strFirst, String strAddr1, String strZip, Connection con) throws Exception
	{
		String strSQL = "";
		ResultSet rsUsr = null;
		int uid = 0 ;
		Statement stmt = getConnection().createStatement();

		strSQL = "select uid,usertype from users where  ulname='" + strLast + "' and "; 
		strSQL += " ufname='" + strFirst + "' and upaddress='" + strAddr1 + "' ";
		strSQL += " and zipcode = '" + strZip  +  "' and delflag = 0 and usertype= 3 " ;

		rsUsr = stmt.executeQuery(strSQL);
		if(rsUsr.next())
		{
			uid = rsUsr.getInt("UID");
		}

		return uid;
	}

	/* Find Patient By Name & ZipCode */
	public static int getPatientsByNameZip(String strLast,String strFirst, String strZip, Connection con) throws Exception
	{
		String strSQL = "";
		ResultSet rsUsr = null;
		int uid = 0 ;
		Statement stmt = getConnection().createStatement();

		strSQL = "select uid,usertype from users where  ulname='" + strLast + "' and "; 
		strSQL += " ufname='" + strFirst + "' and " ;
		strSQL += " zipcode='" + strZip + "' and delflag = 0 and usertype= 3 " ;

		rsUsr = stmt.executeQuery(strSQL);
		if(rsUsr.next())
		{
			uid = rsUsr.getInt("UID");
		}

		return uid;
	}

	/* Find Patient By Name & SSN */
	public static int getPatientsByNameSSN(String strLast,String strFirst, String strSSN, Connection con) throws Exception
	{
		String strSQL = "";
		ResultSet rsUsr = null;
		int uid = 0 ;
		Statement stmt = getConnection().createStatement();

		strSQL = "select uid,usertype from users where  ulname='" + strLast + "' and "; 
		strSQL += " ufname='" + strFirst + "' and " ;
		strSQL += " ssn='" + strSSN + "' and delflag = 0 and usertype= 3" ;

		rsUsr = stmt.executeQuery(strSQL);
		if(rsUsr.next())
		{
			uid = rsUsr.getInt("UID");
		}

		return uid;
	}


	/* Find Patient By Name & Phone */
	public static int getPatientsByNamePhone(String strLast,String strFirst, String strPhone, Connection con) throws Exception
	{
		String strSQL = "";
		ResultSet rsUsr = null;
		int uid = 0 ;
		Statement stmt = getConnection().createStatement();

		strSQL = "select uid,usertype from users where  ulname='" + strLast + "' and "; 
		strSQL += " ufname='" + strFirst + "' and " ;
		strSQL += " upPhone='" + strPhone + "' and delflag = 0 and usertype= 3 "  ;

		rsUsr = stmt.executeQuery(strSQL);
		if(rsUsr.next())
		{
			uid = rsUsr.getInt("UID");
		}

		return uid;
	}

	/*Find uid by VMID ***************-by Niteesh*/
	public static int getUidByVmid(String vmid,Connection con) throws Exception
	{
		String strSQL = "";
		ResultSet rsUsers = null;
		int uid = 0 ;
		Statement stmt = getConnection().createStatement();

		strSQL = "Select uid from users where vmid = '" + vmid + "'";
		rsUsers = stmt.executeQuery(strSQL);
		if(rsUsers.next())
		{
			uid = rsUsers.getInt("UID");
		}

		stmt.close();
		return uid;
	}
	
	
	public static int getFacUidByVmid(String vmid,Connection con) throws Exception
	{
		String strSQL = "";
		ResultSet rsUsers = null;
		int uid = 0 ;
		Statement stmt = getConnection().createStatement();

		strSQL = "Select id from edi_facilities where vmid like '" + vmid + "'";
		rsUsers = stmt.executeQuery(strSQL);
		if(rsUsers.next())
		{
			uid = rsUsers.getInt("ID");
		}

		stmt.close();
		return uid;
	}
	
	
	
	
	
	
	/*Find duplicate uid by VMID From MDB  ***************-by Niteesh*/
	public static int getUidByVmidFromMdb(String vmid,Connection con) throws Exception
	{
		String strSQL = "";
		ResultSet rsUsers = null;
		int uid = 0 ;
		Statement stmt = getConnection().createStatement();
		//System.out.println("VMID="+vmid);
		strSQL = "Select uid from duppat where vmid = 'Gr-"+vmid+"' or vmid ='Pat-"+vmid+"'or vmid ='Ref-"+vmid+"'";
		//System.out.println(strSQL);
		
		rsUsers = stmt.executeQuery(strSQL);
		if(rsUsers!=null){
		if(rsUsers.next())
		{
			uid = rsUsers.getInt("UID");
		}
		}else{
			uid=0;
		}
		stmt.close();
		return uid;
	}
	
	
	
	/*Find uid by VMID  ***************-by Niteesh*/
	public static String getProvIdByVmid(String vmid,Connection con) throws Exception
	{
		String strSQL = "";
		ResultSet rsUsers = null;
		String uid = "" ;
		Statement stmt = getConnection().createStatement();
		//System.out.println("VMID="+vmid);
		strSQL = "Select uid from users where vmid = '"+vmid+"' and delflag=0";
		//System.out.println(strSQL);
		rsUsers = stmt.executeQuery(strSQL);
		if(rsUsers.next())
		{
			uid = rsUsers.getString("UID");
		}

		stmt.close();
		return uid;
	}
	
	public static String getRefProvIdByVmid(String vmid,Connection con) throws Exception
	{
		String strSQL = "";
		ResultSet rsUsers = null;
		String uid = "" ;
		Statement stmt = getConnection().createStatement();
		//System.out.println("VMID="+vmid);
		strSQL = "Select uid from users where vmid = '"+vmid+"' and delflag=0";
		//System.out.println(strSQL);
		rsUsers = stmt.executeQuery(strSQL);
		if(rsUsers.next())
		{
			uid = rsUsers.getString("UID");
		}

		stmt.close();
		return uid;
	}
	
	/*Find userType by uid ***************-by Niteesh*/
	public static int getUserTypeByUid(int uid,Connection conDest) throws SQLException
	{
		String strSQL = "";
		ResultSet rsUsers = null;
		int userType = 0 ;
		Statement stmt = conDest.createStatement();
		//System.out.println("VMID="+vmid);
		strSQL = "Select userType from users where uid ="+uid;
		//System.out.println(strSQL);
		rsUsers = stmt.executeQuery(strSQL);
		if(rsUsers.next())
		{
			userType = rsUsers.getInt("userType");
		}

		stmt.close();
		return userType;
	}



	/**********************************************************************************************************
	 *  Guarantor Related Functions
	 * 
	 **********************************************************************************************************/

	/* 
	 * Standard Guarantor Function that searches for Guarantor or Patient duplicates in certain patter 
	 * Generally you would need to call this function for checking duplicates before adding guarantors
	 * 
	 * */


	public static int getPatOrGuarStandardSearch(String strLast,String strFirst, String strDOB, String strAddr1, String strZip, Connection con) throws Exception
	{

		int uid = 0 ;

		//Search by Name & DOB First
		uid = getPatOrGurByNameDOB(strLast, strFirst, strDOB, con);

		if (uid ==0 )
		{
			//Search by Name,Address1 & ZIp
			uid = getPatOrGurByNameAddrZip(strLast, strFirst, strAddr1, strZip, con);
		}

		if (uid ==0)
		{
			//Search by Name & ZipCode
			uid = getPatOrGurByNameZip(strLast, strFirst, strZip, con);
		}

		return uid;
	}

	public static int getPatOrGurByNameDOB(String strLast,String strFirst, String strDOB, Connection con) throws Exception
	{
		String strSQL = "";
		ResultSet rsPat = null;
		int uid = 0 ;
		Statement stmt = getConnection().createStatement();

		if (strLast.equals("")) 
		{
			return 0;
		}

		strSQL = "select uid,usertype from users where  ulname='" + strLast + "' and "; 
		strSQL += " ufname='" + strFirst + "' and " ;
		strSQL += " dob='" + strDOB + "' and delflag = 0 and usertype in (3,4) ";

		rsPat = stmt.executeQuery(strSQL);
		if(rsPat.next())
		{
			uid = rsPat.getInt("UID");
		}

		return uid;
	}

	/* Find Patient/Gurantors By Name, Address1 & ZipCode */
	public static int getPatOrGurByNameAddrZip(String strLast,String strFirst, String strAddr1, String strZip, Connection con) throws Exception
	{
		String strSQL = "";
		ResultSet rsUsr = null;
		int uid = 0 ;
		Statement stmt = getConnection().createStatement();

		strSQL = "select uid,usertype from users where  ulname='" + strLast + "' and "; 
		strSQL += " ufname='" + strFirst + "' and upaddress='" + strAddr1 + "' ";
		strSQL += " and zipcode = '" + strZip  +  "' and delflag = 0 and usertype in (3,4) " ;

		rsUsr = stmt.executeQuery(strSQL);
		if(rsUsr.next())
		{
			uid = rsUsr.getInt("UID");
		}

		return uid;
	}

	/* Find Patient/Gurantors By Name & ZipCode */
	public static int getPatOrGurByNameZip(String strLast,String strFirst, String strZip, Connection con) throws Exception
	{
		String strSQL = "";
		ResultSet rsUsr = null;
		int uid = 0 ;
		Statement stmt = getConnection().createStatement();

		strSQL = "select uid,usertype from users where  ulname='" + strLast + "' and "; 
		strSQL += " ufname='" + strFirst + "' and " ;
		strSQL += " zipcode='" + strZip + "' and delflag = 0 and usertype in (3,4) " ;

		rsUsr = stmt.executeQuery(strSQL);
		if(rsUsr.next())
		{
			uid = rsUsr.getInt("UID");
		}

		return uid;
	}

	/* Find Patient/Guarantors By Name & SSN */
	public static int getPatOrGurByNameSSN(String strLast,String strFirst, String strSSN, Connection con) throws Exception
	{
		String strSQL = "";
		ResultSet rsUsr = null;
		int uid = 0 ;
		Statement stmt = getConnection().createStatement();

		strSQL = "select uid,usertype from users where  ulname='" + strLast + "' and "; 
		strSQL += " ufname='" + strFirst + "' and " ;
		strSQL += " ssn='" + strSSN + "' and delflag = 0 and usertype in (3,4)" ;

		rsUsr = stmt.executeQuery(strSQL);
		if(rsUsr.next())
		{
			uid = rsUsr.getInt("UID");
		}

		return uid;
	}


	/**********************************************************************************************************
	 *  Facility Related Functions
	 * 
	 **********************************************************************************************************/
	//----------------------------------kashif-----------------------

	public static int getFacilityByVMID(String strVMID, Connection con) throws Exception
	{
		String strSQL = "";
		ResultSet rsUsers = null;
		Statement stmt = getConnection().createStatement();
		int id = 0 ;


		strSQL = "Select id from edi_facilities where vmid= '" + strVMID + "' and vmid <> '' and deleteflag = 0";
		rsUsers = stmt.executeQuery(strSQL);
		if(rsUsers.next())
		{
			id = rsUsers.getInt("ID");
		}

		stmt.close();
		return id;
	}


	public static int getPharmByVMID(String strVMID, Connection con) throws Exception
	{
		String strSQL = "";
		ResultSet rsUsers = null;
		Statement stmt = getConnection().createStatement();
		int id = 0 ;

		strSQL = "Select pmcid from pharmacy where vmid= '" + strVMID + "' and vmid <> '' and delflag = 0";
		rsUsers = stmt.executeQuery(strSQL);
		if(rsUsers.next())
		{
			id = rsUsers.getInt("pmcid");
		}

		stmt.close();
		return id;
	}


	public static int getZipByVMID(String strVMID, Connection con) throws Exception
	{
		String strSQL = "";
		ResultSet rsUsers = null;
		Statement stmt = getConnection().createStatement();
		int id = 0 ;


		strSQL = "Select zipid from zipcodes where vmid= '" + strVMID + "' and vmid <> '' and deleteflag = 0";
		rsUsers = stmt.executeQuery(strSQL);
		if(rsUsers.next())
		{
			id = rsUsers.getInt("zipid");
		}

		stmt.close();
		return id;
	}

	public static String Left(String str, int n){
		if (n <= 0)
			return "";
		else if (n > str.length())
			return str;
		else
			return str.substring(0,n);
	}

	public static String Right(String str, int n){
		if (n <= 0)
			return "";
		else if (n > str.length())
			return str;
		else
			return str.substring(0,n);
	}

	/*
	 * Get Primary Facility Details
	 * It returns a hashtable with key as ID, and value as Name
	 */


	public static Hashtable<Integer, String> getPrimaryFacility(Connection con) throws Exception
	{
		String strSQL = "";
		ResultSet rsUsers = null;
		Statement stmt = getConnection().createStatement();
		int id = 0 ;
		String strFacName = "";

		Hashtable<Integer, String> htFacility = new Hashtable<Integer, String>();

		strSQL = "Select id,name from edi_facilities where primaryfacility=1  and deleteflag = 0";
		rsUsers = stmt.executeQuery(strSQL);
		if(rsUsers.next())
		{
			id = rsUsers.getInt("ID");
			strFacName = rsUsers.getString("name");
			htFacility.put(id, strFacName);

		}

		stmt.close();
		return htFacility;
	}




	/**********************************************************************************************************
	 *  Appointments Related Functions
	 * 
	 **********************************************************************************************************/


	/** 
	 * Created by   : Ravi 
	 * Date Created : Oct/28/2012
	 * Purpose      : method for Appointments
	 * Comments     : Status - under development
	 * Date Modified:
	 * Modified by  :  
	 * */

	public static int getEncByVMID(String strVMID, Connection con) throws Exception	{
		String strSQL = "";
		ResultSet rsEnc = null;
		Statement stmt = getConnection().createStatement();
		int id = 0 ;

		strSQL = "Select EncounterID From Enc where vmid= '" + strVMID + "' and vmid <> '' and deleteflag = 0";

		rsEnc = stmt.executeQuery(strSQL);
		if(rsEnc.next()) {
			id = rsEnc.getInt("EncounterID");
		}

		stmt.close();
		return id;
	}


	public static int getEncByPatID(long strPatID, long strDrID, long strResourceID, String strDate, String strStartTime, Connection con) throws Exception	{
		String strSQL = "";
		ResultSet rsEnc = null;
		Statement stmt = getConnection().createStatement();
		int id = 0 ;

		strSQL = "Select EncounterID From Enc where patientid = '" + strPatID + "' And doctorid = '" + strDrID + "' And resourceid = '" + strResourceID + "' And Date='" + strDate + "' And starttime= '" + strStartTime + "' And deleteflag = 0";

		rsEnc = stmt.executeQuery(strSQL);
		if(rsEnc.next()) {
			id = rsEnc.getInt("EncounterID");
		}

		stmt.close();
		return id;
	}



	/**********************************************************************************************************
	 *  Contacts Related Functions
	 * 
	 **********************************************************************************************************/


	/** 
	 * Created by   : Ravi 
	 * Date Created : Aug/18/2011
	 * Purpose      : method for contacts
	 * Comments     : Status - working
	 * Date Modified:
	 * Modified by  :  
	 * */

	public static int getContactsByVMID(String strVMID, Connection con) throws Exception {
		String strSQL = "";
		ResultSet rsUsers = null;
		Statement stmt = getConnection().createStatement();
		int id = 0 ;

		strSQL = "Select contactid from Contacts where vmid= '" + strVMID + "' and vmid <> '' and delflag = 0";

		rsUsers = stmt.executeQuery(strSQL);
		if(rsUsers.next())	{
			id = rsUsers.getInt("contactid");
		}

		stmt.close();
		return id;
	}

	public static int getEmployerByName(String StrEmpName, Connection con) throws Exception	{
		String strSQL = "";
		ResultSet rsUsers = null;
		Statement stmt = getConnection().createStatement();
		int id = 0 ;


		strSQL = "Select ID from Employer where EmpName= '" + StrEmpName + "'";
		rsUsers = stmt.executeQuery(strSQL);
		if(rsUsers.next())	{
			id = rsUsers.getInt("ID");
		}

		stmt.close();
		return id;
	}

	public static int getInsuranceByVMID(String strVMID, Connection con) throws Exception {
		String strSQL = "";
		ResultSet rsUsers = null;
		Statement stmt = getConnection().createStatement();
		int id = 0 ;


		strSQL = "Select InsID from Insurance where vmid= '" + strVMID + "' and vmid <> '' and deleteflag = 0";
		rsUsers = stmt.executeQuery(strSQL);
		if(rsUsers.next())	{
			id = rsUsers.getInt("InsID");
		}

		stmt.close();
		return id;
	}
	
	public static int getDefaultFeeschid(Connection con) throws Exception {
		String strSQL = "";
		ResultSet rsUsers = null;
		Statement stmt = getConnection().createStatement();
		int id = 0 ;


		strSQL = "Select id from feeschlist where masterFeeSch=1";
		rsUsers = stmt.executeQuery(strSQL);
		if(rsUsers.next())	{
			id = rsUsers.getInt("id");
		}

		stmt.close();
		return id;
	}
	
	
	public static String AMPM(String time)
	{
		String[] times = time.split(" ");
		time = times[0];
		
		String[] tim = time.split(":");
		String hh = tim[0];
		int h = Integer.parseInt(hh);
		String AMPM = times[1];
		if(AMPM.contains("PM"))
		{
			if(h !=12)
			{
				h = h + 12;
				time = h + ":" + tim[1] + ":" + tim[2];
				//time = h + ":" + tim[1];
			}
			/*else if(h ==12)
			{
				
				time = h + ":" + tim[1] + ":" + tim[2];
			}*/
			
		}
		return time;
	}
	
	
	public static String getVmidByInsNameAddressCityStateZip(String name,String address , String city , String state , String zip , Connection con) throws Exception{
		String sql4="";
		Statement stmt4 = null;
		ResultSet rs4=null; 
		stmt4=getConnection().createStatement();
		
		sql4="select * from InsuranceList where [Insurance Name]='"+name+"' and [Insurance Address]='"+address+"' and [Insurance City]='"+city+"' and [Insurance State]='"+state+"' and [Insurance Zip Code]='"+zip+"'";
	   // sql4="SELECT Id FROM InsuranceList where   InsuranceList.[Insurance Name]='HUMANA CLAIMS OFFICE'  and  InsuranceList.[Insurance Address]='P.O Box 14635,' and  InsuranceList.[Insurance City]='Lexington' and  InsuranceList.[Insurance State]='KY' and  InsuranceList.[Insurance Zip Code]='40512'";
		System.out.println("query: "+sql4);
		rs4=stmt4.executeQuery(sql4);
		
		String id="";
		if(rs4!=null){
			while(rs4.next()){
				id=JUtil.validateString(rs4.getString("Id"));
				System.out.println("Ins VMID: "+id);
			}
			
			
		}
		
		 
		return id;
	}
	
	
	
	public static String getVmidByInsNameAddressCityState(String name,String address , String city , String state , Connection con) throws Exception{
		String sql4="";
		Statement stmt4 = null;
		ResultSet rs4=null; 
		stmt4=getConnection().createStatement();
		
		sql4="select * from InsuranceList where [Insurance Name]='"+name+"' and [Insurance Address]='"+address+"' and [Insurance City]='"+city+"' and [Insurance State]='"+state+"'";
	   // sql4="SELECT Id FROM InsuranceList where   InsuranceList.[Insurance Name]='HUMANA CLAIMS OFFICE'  and  InsuranceList.[Insurance Address]='P.O Box 14635,' and  InsuranceList.[Insurance City]='Lexington' and  InsuranceList.[Insurance State]='KY' and  InsuranceList.[Insurance Zip Code]='40512'";
		System.out.println("query: "+sql4);
		rs4=stmt4.executeQuery(sql4);
		
		String id="";
		if(rs4!=null){
			while(rs4.next()){
				id=JUtil.validateString(rs4.getString("Id"));
				System.out.println("Ins VMID: "+id);
			}
			
			
		}
		
		 
		return id;
	}

	public static int getRefProviderUidByFname(String refFName, Connection connDest) throws SQLException {
		String strSQL="";
		ResultSet rs1=null;
		Statement stmt1=null;
		stmt1=connDest.createStatement();
		
		int uid=0;
		
		strSQL="select uid from users where usertype=5 and ufname like '"+refFName+"'";
		rs1=stmt1.executeQuery(strSQL);
		if(rs1!=null){
			while(rs1.next()){
				uid=rs1.getInt("uid");
			}
		}
		
		return uid;
	}

	public static int getProviderUidByFname(String refFName, Connection connDest) throws SQLException {
		
		String strSQL="";
		ResultSet rs1=null;
		Statement stmt1=null;
		stmt1=connDest.createStatement();
		
		int uid=0;
		
		strSQL="select uid from users where usertype=3 and ufname like '"+refFName+"'";
		rs1=stmt1.executeQuery(strSQL);
		if(rs1!=null){
			while(rs1.next()){
				uid=rs1.getInt("uid");
			}
		}
		
		return uid;
	}

	public static int getUidGuarByFnameLName(String fName, String lName, Connection connDest) throws SQLException {
		 
		String strSQL="";
		ResultSet rs1=null;
		Statement stmt1=null;
		stmt1=connDest.createStatement();
		int uid=0;
		strSQL="select * from users where usertype=3 and ufname='"+fName+"' and ulname='"+lName+"'";
		rs1=stmt1.executeQuery(strSQL);
		if(rs1!=null){
			while(rs1.next()){
				uid=rs1.getInt("uid");
			}
		}
		return uid;
		
	}
	
	public static int getUidGUarPatByFnameLName(String fName, String lName, Connection connDest) throws SQLException {
		 
		String strSQL="";
		ResultSet rs1=null;
		Statement stmt1=null;
		stmt1=connDest.createStatement();
		int uid=0;
		strSQL="select * from users where usertype=4 and ufname='"+fName+"' and ulname='"+lName+"'";
		rs1=stmt1.executeQuery(strSQL);
		if(rs1!=null){
			while(rs1.next()){
				uid=rs1.getInt("uid");
			}
		}
		return uid;
		
	}

	public static String getuidByDocFName(String docFName, Connection connDest) throws SQLException {
		 
		String strSQL="";
		ResultSet rs1=null;
		Statement stmt1=null;
		stmt1=connDest.createStatement();
		
		String uid="";
		strSQL="select vmid from users where usertype=1 and ufname='"+docFName+"'";
		rs1=stmt1.executeQuery(strSQL);
		if(rs1!=null){
			while(rs1.next()){
				uid=rs1.getString("uid");
			}
		}
		
		return uid;
	}
	
	
}







