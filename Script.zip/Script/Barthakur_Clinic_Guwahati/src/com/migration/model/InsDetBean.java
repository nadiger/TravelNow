/**
 * 
 */
package com.migration.model;

/**
 * @author jay.shah
 *
 */
public class InsDetBean 
{
	private String Strvmid = "";
	private String StrPatvmid = "";
	private String StrPriority = "";
	private String strSubscriberNo = "";
	private String strGroupNo = "";
	private String strCopay = "";
	private String strGuarVmid = "";
	private String strGrRel = "";
	private String strStartDate = "";
	private String strEndDate = "";
	private String strName = "";
	private String strSeqNo="";
	

	
	private int addCount =0;
	private int dupCount =0;
	private int invCount =0;
	private String strGroupName="";
	
	private String  strGrid="";
	
	private String guarName="";
	public String getGuarName() {
		return guarName;
	}


	public void setGuarName(String guarName) {
		this.guarName = guarName;
	}


	public String getStrGrid() {
		return strGrid;
	}


	public void setStrGrid(String strGrid) {
		this.strGrid = strGrid;
	}


	public String getStrIsGrPat() {
		return strIsGrPat;
	}


	public void setStrIsGrPat(String strIsGrPat) {
		this.strIsGrPat = strIsGrPat;
	}
	private String  strIsGrPat="";
	
	
	public String getStrGroupName() {
		return strGroupName;
	}


	public void setStrGroupName(String strGroupName) {
		this.strGroupName = strGroupName;
	}


	public void clearAll()
	{
	Strvmid = "";
	StrPriority = "";
	strSubscriberNo = "";
	strGroupNo = "";
//	strCopay = "";
	strGuarVmid = "";
	strGrRel = "";
	strStartDate = "";
	strEndDate = "";
	strName = "";
	strGroupName="";
	}
	
	
	public String getStrSeqNo() {
		return strSeqNo;
	}
	
	public void setStrSeqNo(String strSeqNo) {
		this.strSeqNo = strSeqNo;
	}
	
	
	public String getStrPatvmid() {
		return StrPatvmid;
	}

	public void setStrPatvmid(String strPatvmid) {
		StrPatvmid = strPatvmid;
	}

	/**
	 * @param strAddCount the strAddCount to set
	 */
	public void setAddCount(int addCount) {
		this.addCount = addCount;
	}
	/**
	 * @return the strAddCount
	 */
	public int getAddCount() {
		return addCount;
	}
	
	public void incrAddCount() {
		addCount = addCount + 1;
	}
	
	/**
	 * @param strDupCount the strDupCount to set
	 */
	public void setDupCount(int dupCount) {
		this.dupCount =dupCount;
	}
	
	public void incrDupCount() {
		dupCount = dupCount + 1;
	}
	
	/**
	 * @return the strDupCount
	 */
	public int getDupCount() {
		return dupCount;
	}
	
	/**
	 * @param strInvCount the strInvCount to set
	 */
	public void setInvCount(int invCount) {
		this.invCount = invCount;
	}
	
	public void incrInvCount() {
		invCount = invCount + 1;
	}
	
	/**
	 * @return the strInvCount
	 */
	public int getInvCount() {
		return invCount;
	}
	

	public String getStrvmid() {
		return Strvmid;
	}
	public void setStrvmid(String strvmid) {
		Strvmid = strvmid;
	}
	public String getStrPriority() {
		return StrPriority;
	}
	public void setStrPriority(String strPriority) {
		StrPriority = strPriority;
	}
	public String getStrSubscriberNo() {
		return strSubscriberNo;
	}
	public void setStrSubscriberNo(String strSubscriberNo) {
		this.strSubscriberNo = strSubscriberNo;
	}
	public String getStrGroupNo() {
		return strGroupNo;
	}
	public void setStrGroupNo(String strGroupNo) {
		this.strGroupNo = strGroupNo;
	}
	public String getStrCopay() {
		return strCopay;
	}
	public void setStrCopay(String strCopay) {
		this.strCopay = strCopay;
	}
	public String getStrGuarVmid() {
		return strGuarVmid;
	}
	public void setStrGuarVmid(String strGuarVmid) {
		this.strGuarVmid = strGuarVmid;
	}
	public String getStrGrRel() {
		return strGrRel;
	}
	public void setStrGrRel(String strGrRel) {
		this.strGrRel = strGrRel;
	}
	public String getStrStartDate() {
		return strStartDate;
	}
	public void setStrStartDate(String strStartDate) {
		this.strStartDate = strStartDate;
	}
	public String getStrEndDate() {
		return strEndDate;
	}
	public void setStrEndDate(String strEndDate) {
		this.strEndDate = strEndDate;
	}
	public String getStrName() {
		return strName;
	}
	public void setStrName(String strName) {
		this.strName = strName;
	}
	
}
