/**
 * Users.java 
 */
package com.migration.model;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;



import com.migration.lib.CommonFunction;
import com.migration.lib.JLib;
import com.migration.lib.*;

/**
 * @author mihir.patel
 *
 */
public class PatientDemographics 
{
	public String dob = "";
	public String ptdob = "";
	public String ssn = "";
	public String upphone = "";
	public String umobileno="";
	public String upagerno = "";
	public String sex = "";
	public String zipcode="";
	public String countrycode = "";
	public String uname = "";
	public String upwd = "";
	public String psl = "";
	public PatientDemographics()
	{

	}

	// Throws exception to outer class as well, so error can be displayed in form	
	public int insertData(PatientDemographicsBean objPatientDemographicsBean,Connection connSrc, Connection connDest, int userType) throws Exception {
		PreparedStatement stmtPr =null;
		Boolean insertFlag = true;
		String strException = "";

		String strSQL = "";
		int resultUID = 0;
		int i = 0;

		try {
			

				//Find out the duplicate patients
			
				//resultUID = JLib.getPatientByNameDOB(objPatientDemographicsBean.getLastName(), objPatientDemographicsBean.getFirstName(), objPatientDemographicsBean.getDOB(), connDest) ;
				 
				resultUID=JLib.getUHIDByRegistractioNo(objPatientDemographicsBean.getRegistrationNo(),connDest);
				
				if(resultUID!=0){
					String patientRegistrationNo=objPatientDemographicsBean.getFirstName()+","+objPatientDemographicsBean.getLastName()+","+objPatientDemographicsBean.getDOB()+","+objPatientDemographicsBean.getRegistrationNo();
					JUtil.appendToFile("DuplicateRegistrationNo.csv", patientRegistrationNo);
					insertFlag=false;
					objPatientDemographicsBean.incrDupCount();
				}
				
				/*if(resultUID!=0)
				{	
					String vmid = objPatientDemographicsBean.getRegistrationNo();
					insertFlag = false;
					objPatientDemographicsBean.incrDupCount();
					
					strException = objPatientDemographicsBean.getVmid() + "," + objPatientDemographicsBean.getUlname() + "," + objPatientDemographicsBean.getUfname() + "," + objPatientDemographicsBean.getDob() ;
					strException +=  objPatientDemographicsBean.getSsn() + "," + "duplicate Records";
					
					if (userType == 3)
					{

						JUtil.appendToFile("DuplicatePatients.csv", strException);
						String strRemark = "Duplicate Patient";
						strSQL = "insert into Exp_Patients(DupPatAccount, PatAccount, LastName,FirstName,DOB,Exception_Description,Exception_Code) values ('" + resultUID + "','" + objPatientDemographicsBean.getVmid() + "', '" + objPatientDemographicsBean.getUlname() + "', '" + objPatientDemographicsBean.getUfname() + "', '" + objPatientDemographicsBean.getDob() + "', '" + strRemark + "', '1')";
			            stmtPr = connDest.prepareStatement(strSQL);
						stmtPr.executeUpdate();
						objPatientDemographicsBean.incrInvCount();
						stmtPr.close();
						
						
						String strSQL1 = "";
						Statement stmt = null;
						ResultSet rsUsr = null;
						stmt = connSrc.createStatement();

						try{
							strSQL1="INSERT INTO duppat VALUES('"+vmid+"','"+resultUID+"')";
							stmt.executeUpdate(strSQL1);

						}
						catch(Exception e)
						{
							e.printStackTrace();
						}
					}
					
					
				}
				
				if(objPatientDemographicsBean.getUlname().equals("") || objPatientDemographicsBean.getUfname().equals("")){
					insertFlag = false;
					String strRemark = "Invalid PatientName";
					strSQL = "insert into Exp_Patients (PatAccount,LastName,FirstName,Exception_Description, Exception_Code) values ('" + objPatientDemographicsBean.getVmid() + "', '" + objPatientDemographicsBean.getUlname() + "', '" + objPatientDemographicsBean.getUfname() + "', '" + strRemark + "', '2')";
					stmtPr = connDest.prepareStatement(strSQL);
					stmtPr.executeUpdate();
					objPatientDemographicsBean.incrInvCount();
					stmtPr.close();
//					con = connDest.createStatement();
//					con.executeQuery(strSQL);
				}
				
				if(objPatientDemographicsBean.getUlname().toUpperCase().equals("DON'T USE") || objPatientDemographicsBean.getUlname().toUpperCase().equals("DO NOT USE") || objPatientDemographicsBean.getUlname().toUpperCase().equals("DONT USE") 
						|| objPatientDemographicsBean.getUfname().toUpperCase().equals("DON'T USE") || objPatientDemographicsBean.getUfname().toUpperCase().equals("DO NOT USE") || objPatientDemographicsBean.getUfname().toUpperCase().equals("DONT USE")
						|| objPatientDemographicsBean.getUpaddress().toUpperCase().equals("DON'T USE") || objPatientDemographicsBean.getUpaddress().toUpperCase().equals("DONT USE") || objPatientDemographicsBean.getUpaddress().toUpperCase().equals("DO NOT USE")
						|| objPatientDemographicsBean.getUpaddress2().toUpperCase().equals("DON'T USE") || objPatientDemographicsBean.getUpaddress2().toUpperCase().equals("DO NOT USE") || objPatientDemographicsBean.getUpaddress2().toUpperCase().equals("DONT USE")){
					insertFlag = false;
					String strRemark = "Do not use mentioned";
					strSQL = "insert into Exp_Patients (PatAccount,LastName,FirstName,Exception_Description, Exception_Code) values " +
					"('" + objPatientDemographicsBean.getVmid() + "', '" + objPatientDemographicsBean.getUlname() + "', '" + objPatientDemographicsBean.getUfname() + "', '" + 
					strRemark + "', '3')";
					stmtPr = connDest.prepareStatement(strSQL);
					stmtPr.executeUpdate();
					objPatientDemographicsBean.incrInvCount();
					stmtPr.close();
//					con = connDest.createStatement();
//					con.executeQuery(strSQL);
				}
*/

			if (insertFlag) 
			{
				strSQL="INSERT INTO PatientRegistration (Category,RegistrationNo,RegistrationDate,TitleID,FirstName,MiddleName,LastName,DOB,AgeYear,AgeMonth,AgeDay,Gender,status,EncodedBy,EncodedDate,uhidnew,ConsultantID,localcityid,localareaId,NationalityID,LocationID,dobstatus,MaritalStatusID,LocalAddress1,LocalAddress2,ContactPerson,RelationID,LocalPostalCode,ReligionID,OccupationID,mobile,tor,SponsorID,ReferralType_ID,SpecialNote,father,mother,BloodGroupID,ContactPersonMobile) ";
				strSQL +=" Values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
				stmtPr = connDest.prepareStatement(strSQL);
				
				
				
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getCategory()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getRegistrationNo()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getRegistrationDate()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getTitleID()));
				stmtPr.setString(++i, JLib.Left(JUtil.validateString(objPatientDemographicsBean.getFirstName()),20));
				stmtPr.setString(++i, JLib.Left(JUtil.validateString(objPatientDemographicsBean.getMiddleName()),20));
				stmtPr.setString(++i, JLib.Left(JUtil.validateString(objPatientDemographicsBean.getLastName()),20));
				
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getDOB()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getAgeYear()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getAgeMonth()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getAgeDay()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getGender()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getStatus()));
				stmtPr.setString(++i, "2");  //encodedBy   //2015-11-24 05:33:16.350
				stmtPr.setString(++i, "2016-06-10 09:00:00.000");
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getUHIDNew()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getConsultantID()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getLocalCityID()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getLocalAreaID()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getNationalityID()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getLocationID()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getDobStatus()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getMaritalStatusID()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getLocalAddress1()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getLocalAddress2()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getContactPerson()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getRelationID()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getLocalPostalCode()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getReligionID()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getOccupationID()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getMobile()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getTOR()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getSponsorID()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getReferralType_ID()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getSpecialNote()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getFather()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getMother()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getBloodGroupID()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getContactPersonMobile()));
			

				stmtPr.executeUpdate();
				
				
				
				
				
				 
				
				objPatientDemographicsBean.incrAddCount();	            
			}

		}
		catch (Exception e) 
		{
			e.printStackTrace();
			throw e;
		}finally
		{
			if (stmtPr != null)
				stmtPr.close();
		}	

		return resultUID;


	} 



}
