/**
 * Users.java 
 */
package com.migration.model;
import java.sql.Connection;
import java.sql.PreparedStatement;


import java.sql.ResultSet;
import java.sql.Statement;

import com.migration.lib.CommonFunction;
import com.migration.lib.JLib;
import com.migration.lib.JUtil;

/**
 * @author mihir.patel
 *
 */
public class Patients 
{

	public Patients()
	{

	}
	/*//**********************************Niteesh Nadiger*****************************************
	public int UpdateGrIdRel(PatientsBean objPatBean,Connection connSrc, Connection connDest, int ResultUID) throws Exception {
		PreparedStatement stmtPr =null;
		Boolean insertFlag = true;
		String strException = "";

		String strSQL = "";
		int i = 0;



		return ResultUID;
	}
	 */

	// Throws exception to outer class as well, so error can be displayed in form	
	public int insertData(PatientsBean objPatBean,Connection connSrc, Connection connDest, int ResultUID) throws Exception {
		PreparedStatement stmtPr =null;
		Boolean insertFlag = true;
		String strException = "";
		ResultSet rsInsDet2 = null;
		String strSQL = "";
		String strSQL2 = "";
		Statement stmt2 = null;
		stmt2 = connSrc.createStatement();
		int i = 0;

		try {

			if(ResultUID!=0)
			{
				if (insertFlag) 
				{
					objPatBean.setGrid(objPatBean.getPid());
					
					//objPatBean.setRendprid(JLib.getProvIdByVmid("Dr-" + objPatBean.getRendprid(), connDest));
					//int refProv = JLib.getProvIdByVmid("Ref-" + objPatBean.getRefPrID(), connDest);
					//String refProvID = JLib.getRefProvIdByVmid("Ref-" + objPatBean.getRefPrID(), connDest);
					//objPatBean.setRefPrID(refProvID);
					
					

					strSQL = "INSERT INTO Patients (pid, employername, employeraddress, employeraddress2, employercity, employerstate, employerzip, employerphone,doctorID,";
					strSQL+= "maritalstatus, studentstatus, empstatus, notes, controlno, hl7ID, selfpay,";
					strSQL+= "defFeeschid, race, ethnicity, grid, grrel, isgrpt, deceased, DeceasedNotes, refPrID,";
					strSQL+= "BillingAlertNotes, empid, relinfo, relinfodate, rendprid, RxConsent,language,billingalert) Values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)" ;

					stmtPr = connDest.prepareStatement(strSQL);
					stmtPr.setInt(++i, ResultUID);
					stmtPr.setString(++i, JUtil.validateString(objPatBean.getEmployername()));
					stmtPr.setString(++i, JUtil.validateString(objPatBean.getEmployeraddress()));
					stmtPr.setString(++i, JUtil.validateString(objPatBean.getEmployeraddress2()));
					stmtPr.setString(++i, JUtil.validateString(objPatBean.getEmployercity()));
					stmtPr.setString(++i, JUtil.validateString(objPatBean.getEmployerstate()));
					stmtPr.setString(++i, JUtil.validateString(objPatBean.getEmployerzip()));
					stmtPr.setString(++i, JUtil.validateString(objPatBean.getEmployerphone()));
					System.out.println("patient.java "+objPatBean.getEmployerphone());
					stmtPr.setInt(++i, objPatBean.getDoctorID());
					stmtPr.setString(++i, JUtil.validateString(objPatBean.getMaritalstatus()));
					stmtPr.setString(++i, JUtil.validateString(objPatBean.getStudentstatus()));
					stmtPr.setString(++i, JUtil.validateString(objPatBean.getEmpstatus()));
					stmtPr.setString(++i, JUtil.validateString(objPatBean.getNotes()));
					stmtPr.setString(++i, objPatBean.getControlNo());//Control Number
					stmtPr.setString(++i, objPatBean.getMrn());// hl7id is MRN in front end
					stmtPr.setString(++i, JUtil.validateString(objPatBean.getSelfpay()));
					stmtPr.setString(++i, JUtil.validateString(objPatBean.getDefFeeschid()));
					stmtPr.setString(++i, JUtil.validateString(objPatBean.getRace()));
					stmtPr.setString(++i, JUtil.validateString(objPatBean.getEthnicity()));
					stmtPr.setInt(++i, ResultUID);//grid
					stmtPr.setString(++i, JUtil.validateString(objPatBean.getGrrel()));
					stmtPr.setString(++i, "1");//Isgrpt
					stmtPr.setString(++i, JUtil.validateString(objPatBean.getDeceased()));
					stmtPr.setString(++i, JUtil.validateString(objPatBean.getDeceasedNotes()));
					String refProviderId=JUtil.validateString(objPatBean.getRefPrID());
					System.out.println("refProviderId: "+refProviderId);
					stmtPr.setString(++i, refProviderId);
					
					String billingAlerts=objPatBean.getBillingAlertNotes();
					//System.out.println(billingAlerts);
					stmtPr.setString(++i, billingAlerts );
					stmtPr.setInt(++i, objPatBean.getEmpId());
					stmtPr.setString(++i, JUtil.validateString(objPatBean.getRelinfo()));
					stmtPr.setString(++i, JUtil.validateString(objPatBean.getRelinfodate()));
					System.out.println(objPatBean.getRelinfodate());
					stmtPr.setString(++i, objPatBean.getRendprid());
					stmtPr.setString(++i, "U");
					stmtPr.setString(++i, objPatBean.getPatLanguage());
					int billingAlertFlag=objPatBean.getBillingAlert();
					System.out.println(billingAlertFlag);
					stmtPr.setInt(++i, billingAlertFlag);

					stmtPr.executeUpdate();	            
				}

			}
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			throw e;
		}finally
		{
			if (stmtPr != null)
				stmtPr.close();
		}	

		return ResultUID;
	}
}
