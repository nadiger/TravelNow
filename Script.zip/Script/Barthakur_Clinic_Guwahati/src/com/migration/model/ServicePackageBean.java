package com.migration.model;

public class ServicePackageBean extends ServiceBean {
	private static int addCount;
	private static int dupCount;
	private static int invCount;
	
	public ServicePackageBean() {

	}
	
	public int getAddCount() {
		return addCount;
	}

	public int getDupCount() {
		return dupCount;
	}

	public int getInvCount() {
		return invCount;
	}

	public void setAddCount() {
		addCount = addCount+1;
	}

	public void setDupCount() {
		dupCount = dupCount+1;
	}

	public void setInvCount() {
		invCount = invCount+1;
	}
	
}
