/**
 * Users.java 
 */
package com.migration.model;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;



import com.migration.lib.CommonFunction;
import com.migration.lib.JLib;
import com.migration.lib.JUtil;

/**
 * @author mihir.patel
 *
 */
public class Users 
{
	public String dob = "";
	public String ptdob = "";
	public String ssn = "";
	public String upphone = "";
	public String umobileno="";
	public String upagerno = "";
	public String sex = "";
	public String zipcode="";
	public String countrycode = "";
	public String uname = "";
	public String upwd = "";
	public String psl = "";
	public Users()
	{

	}

	// Throws exception to outer class as well, so error can be displayed in form	
	public int insertData(UsersBean objUsrBean,Connection connSrc, Connection connDest, int userType) throws Exception {
		PreparedStatement stmtPr =null;
		Boolean insertFlag = true;
		String strException = "";

		String strSQL = "";
		int resultUID = 0;
		int i = 0;

		try {
			dob=objUsrBean.getDob();
			dob = CommonFunction.convertDOB(dob);
			ptdob = CommonFunction.convertPtDob(dob);
			ssn=objUsrBean.getSsn();
			ssn = CommonFunction.convertSSN(ssn);
			upphone=objUsrBean.getUpphone();
			upphone = CommonFunction.convertPhone(upphone);
			umobileno=objUsrBean.getUmobileno();
			umobileno = CommonFunction.convertPhone(umobileno);
			upagerno=objUsrBean.getUpagerno();
			upagerno = CommonFunction.convertPhone(upagerno);
			sex=objUsrBean.getSex();
			sex = CommonFunction.convertSex(sex);
			zipcode=objUsrBean.getZipcode();
			zipcode = CommonFunction.convertzip(zipcode);

			//System.out.println("VMID= "+objUsrBean.getVmid());
			//resultUID = JLib.getUsersByVMID(objUsrBean.getVmid(), connDest);


			//System.out.println("UID = "+resultUID);
			/*if(resultUID!=0)
			{*/
				if (userType ==3) // Patients
				{
					resultUID = JLib.getPatientByNameDOB(objUsrBean.getUlname(), objUsrBean.getUfname(), objUsrBean.getDob(), connDest) ;
					
				}
				else if (userType==4 ) //Guarantors
				{
					//resultUID = JLib.getPatOrGuarStandardSearch(objUsrBean.getUlname(), objUsrBean.getUfname(), objUsrBean.getDob(), objUsrBean.getUpaddress(), objUsrBean.getZipcode(), connDest);
	/*HERE*/		resultUID = JLib.getPatOrGurByNameDOB(objUsrBean.getUlname(), objUsrBean.getUfname(), objUsrBean.getDob(),connDest);
				
				}
				else // Any other Users
				{
					resultUID = JLib.getUserByName(objUsrBean.getUlname(), objUsrBean.getUfname(), connDest,userType);
				}	

				if(resultUID!=0)
				{	
					String vmid = objUsrBean.getVmid();
					insertFlag = false;
					objUsrBean.incrDupCount();
					
					strException = objUsrBean.getVmid() + "," + objUsrBean.getUlname() + "," + objUsrBean.getUfname() + "," + objUsrBean.getDob() ;
					strException +=  objUsrBean.getSsn() + "," + "duplicate Records";
					
					if (userType == 3)
					{

						JUtil.appendToFile("DuplicatePatients.csv", strException);
						String strRemark = "Duplicate Patient";
						strSQL = "insert into Exp_Patients(DupPatAccount, PatAccount, LastName,FirstName,DOB,Exception_Description,Exception_Code) values ('" + resultUID + "','" + objUsrBean.getVmid() + "', '" + objUsrBean.getUlname() + "', '" + objUsrBean.getUfname() + "', '" + objUsrBean.getDob() + "', '" + strRemark + "', '1')";
			            stmtPr = connDest.prepareStatement(strSQL);
						stmtPr.executeUpdate();
						objUsrBean.incrInvCount();
						stmtPr.close();
						
						
						String strSQL1 = "";
						Statement stmt = null;
						ResultSet rsUsr = null;
						stmt = connSrc.createStatement();

						try{
							strSQL1="INSERT INTO duppat VALUES('"+vmid+"','"+resultUID+"')";
							stmt.executeUpdate(strSQL1);

						}
						catch(Exception e)
						{
							e.printStackTrace();
						}
					}
					else if(userType==4)
					{
						JUtil.appendToFile("DuplicateGurantors.csv", strException);
						String strSQL1 = "";
						Statement stmt = null;
						ResultSet rsUsr = null;
						stmt = connSrc.createStatement();

						try{
							strSQL1="INSERT INTO duppat VALUES('"+vmid+"','"+resultUID+"')";
							stmt.executeUpdate(strSQL1);

						}
						catch(Exception e)
						{
							e.printStackTrace();
						}
					}
					else 
					{
						JUtil.appendToFile("DuplicateProviders_Staff.csv", strException);
					}
					
				}
				
				if(objUsrBean.getUlname().equals("") || objUsrBean.getUfname().equals("")){
					insertFlag = false;
					String strRemark = "Invalid PatientName";
					strSQL = "insert into Exp_Patients (PatAccount,LastName,FirstName,Exception_Description, Exception_Code) values ('" + objUsrBean.getVmid() + "', '" + objUsrBean.getUlname() + "', '" + objUsrBean.getUfname() + "', '" + strRemark + "', '2')";
					stmtPr = connDest.prepareStatement(strSQL);
					stmtPr.executeUpdate();
					objUsrBean.incrInvCount();
					stmtPr.close();
//					con = connDest.createStatement();
//					con.executeQuery(strSQL);
				}
				
				if(objUsrBean.getUlname().toUpperCase().equals("DON'T USE") || objUsrBean.getUlname().toUpperCase().equals("DO NOT USE") || objUsrBean.getUlname().toUpperCase().equals("DONT USE") 
						|| objUsrBean.getUfname().toUpperCase().equals("DON'T USE") || objUsrBean.getUfname().toUpperCase().equals("DO NOT USE") || objUsrBean.getUfname().toUpperCase().equals("DONT USE")
						|| objUsrBean.getUpaddress().toUpperCase().equals("DON'T USE") || objUsrBean.getUpaddress().toUpperCase().equals("DONT USE") || objUsrBean.getUpaddress().toUpperCase().equals("DO NOT USE")
						|| objUsrBean.getUpaddress2().toUpperCase().equals("DON'T USE") || objUsrBean.getUpaddress2().toUpperCase().equals("DO NOT USE") || objUsrBean.getUpaddress2().toUpperCase().equals("DONT USE")){
					insertFlag = false;
					String strRemark = "Do not use mentioned";
					strSQL = "insert into Exp_Patients (PatAccount,LastName,FirstName,Exception_Description, Exception_Code) values " +
					"('" + objUsrBean.getVmid() + "', '" + objUsrBean.getUlname() + "', '" + objUsrBean.getUfname() + "', '" + 
					strRemark + "', '3')";
					stmtPr = connDest.prepareStatement(strSQL);
					stmtPr.executeUpdate();
					objUsrBean.incrInvCount();
					stmtPr.close();
//					con = connDest.createStatement();
//					con.executeQuery(strSQL);
				}


			if (insertFlag) 
			{

				strSQL = "INSERT INTO users (uname, upwd, ufname, uminitial, ulname, dob,ssn," ;
				strSQL += " upaddress, upcity,upstate, zipcode, upphone,umobileno, upagerno,uemail, " ;
				strSQL += " usertype, upreviousname, sex, upaddress2, suffix, prefix, initials, ptdob, " ;
				strSQL += " primaryservicelocation, vmid,status,language, countrycode) Values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)" ;

				stmtPr = connDest.prepareStatement(strSQL);
				stmtPr.setString(++i, JUtil.validateString(objUsrBean.getUname()));
				stmtPr.setString(++i, JUtil.validateString(objUsrBean.getUpwd()));
				stmtPr.setString(++i, JUtil.validateString(objUsrBean.getUfname()));
				stmtPr.setString(++i, JUtil.validateString(objUsrBean.getUminitial()));
				stmtPr.setString(++i, JUtil.validateString(objUsrBean.getUlname()));
				stmtPr.setString(++i, JUtil.validateString(objUsrBean.getDob()));
				stmtPr.setString(++i, JUtil.validateString(objUsrBean.getSsn()));
				stmtPr.setString(++i, JUtil.validateString(objUsrBean.getUpaddress()));
				stmtPr.setString(++i, JUtil.validateString(objUsrBean.getUpcity()));
				stmtPr.setString(++i, JUtil.validateString(objUsrBean.getUpstate()));
				stmtPr.setString(++i, JUtil.validateString(objUsrBean.getZipcode()));
				stmtPr.setString(++i, JUtil.validateString(objUsrBean.getUpphone()));
				 
				stmtPr.setString(++i, JUtil.validateString(objUsrBean.getUmobileno()));
				stmtPr.setString(++i, JUtil.validateString(objUsrBean.getUpagerno()));
				stmtPr.setString(++i, JUtil.validateString(objUsrBean.getUemail()));
				stmtPr.setInt(++i, userType);
				stmtPr.setString(++i, JUtil.validateString(objUsrBean.getPrevname()));
				stmtPr.setString(++i, JUtil.validateString(objUsrBean.getSex()));
				stmtPr.setString(++i, JUtil.validateString(objUsrBean.getUpaddress2()));
				stmtPr.setString(++i, JUtil.validateString(objUsrBean.getSuffix()));
				stmtPr.setString(++i, JUtil.validateString(objUsrBean.getPrefix()));
				stmtPr.setString(++i, JUtil.validateString(objUsrBean.getInitials()));
				stmtPr.setString(++i, JUtil.validateString(objUsrBean.getPtDob()));
				//stmtPr.setInt(++i, objUsrBean.getPSL()); // For the Default facility only

				stmtPr.setInt(++i, objUsrBean.getDefaultFacility());
				stmtPr.setString(++i, JUtil.validateString(objUsrBean.getVmid()));
				stmtPr.setString(++i, JUtil.validateString(objUsrBean.getStatus()));
				stmtPr.setString(++i, objUsrBean.getLanguage());
				stmtPr.setString(++i, objUsrBean.getCountryCode());
				stmtPr.executeUpdate();
				resultUID = JLib.getUsersByVMID(objUsrBean.getVmid(),connDest);
				objUsrBean.setUID(resultUID);
				objUsrBean.incrAddCount();	            
			}

		}
		catch (Exception e) 
		{
			e.printStackTrace();
			throw e;
		}finally
		{
			if (stmtPr != null)
				stmtPr.close();
		}	

		return resultUID;


	} 



}
