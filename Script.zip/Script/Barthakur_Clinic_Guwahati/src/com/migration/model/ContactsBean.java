/**
 * 
 */
package com.migration.model;

import com.migration.lib.*;

/** 
* Created by   : Ravi 
* Date created : Aug/18/2011
* Purpose      : Bean Class [ContactsBean.java] for Emergency Contact details for the Patients
* Comments     : 
* Date Modified:   
* Modified by  :
*/

public class ContactsBean {
	
	private long lngPID=0;
	private String strName = "";
	private String strRelation = "";
	private String strAddress = "";
	private String strAddress2 = "";
	private String strCity = "";
	private String strState = "";
	private String strZipcode = "";
	private String strHomePhone = "";
	private String strWorkPhone = "";
	private String strVMID = "";
	private String strPatVMID="";
	
	private int cntRead =0;
	private int cntAdd =0;
	private int cntDup =0;
	private int cntInv =0;
	
	public void clearAll()
	{
		lngPID=0;
		strName = "";
		strRelation = "";
		strPatVMID="";
		strAddress = "";
		strAddress2 = "";
		strCity = "";
		strState = "";
		strZipcode = "";
		strHomePhone = "";
		strWorkPhone = "";
		strVMID = "";		
	}

	public String getStrPatVMID() {
		return strPatVMID;
	}




	public void setStrPatVMID(String strPatVMID) {
		this.strPatVMID = strPatVMID;
	}




	public long getLngPID() {
		return lngPID;
	}

	public void setLngPID(long lngPID) {
		this.lngPID = lngPID;
	}

	public String getStrName() {
		return strName;
	}

	public void setStrName(String strName) throws Exception {		
		this.strName = JUtil.validateString(strName);		
	}

	public String getStrRelation() {
		return strRelation;
	}

	public void setStrRelation(String strRelation) throws Exception {
		this.strRelation = JUtil.validateString(strRelation);
	}

	public String getStrAddress() {
		return strAddress;
	}

	public void setStrAddress(String strAddress) throws Exception {
		this.strAddress = JUtil.validateString(strAddress);
	}

	public String getStrAddress2() {
		return strAddress2;
	}

	public void setStrAddress2(String strAddress2) throws Exception {
		this.strAddress2 = JUtil.validateString(strAddress2);
	}

	public String getStrCity() {
		return strCity;
	}

	public void setStrCity(String strCity) throws Exception {
		this.strCity = JUtil.validateString(strCity);
	}

	public String getStrState() {
		return strState;
	}

	public void setStrState(String strState) throws Exception {
		this.strState = JUtil.validateString(strState);
	}

	public String getStrZipcode() {
		return strZipcode;
	}

	public void setStrZipcode(String strZipcode) throws Exception {
		this.strZipcode = JUtil.validateString(strZipcode);
	}

	public String getStrHomePhone() {
		return strHomePhone;
	}

	public void setStrHomePhone(String strHomePhone) throws Exception {
        if (strHomePhone != null & strHomePhone!="")
		this.strHomePhone = CommonFunction.convertPhone(strHomePhone);
	}

	public String getStrWorkPhone() {
		return strWorkPhone;
	}

	public void setStrWorkPhone(String strWorkPhone) throws Exception {
		if (strWorkPhone != null & strWorkPhone != "")
		this.strWorkPhone = CommonFunction.convertPhone(strWorkPhone);
	}

	public String getStrVMID() {
		return strVMID;
	}

	public void setStrVMID(String strVMID) throws Exception {
		//if (!strVMID.equalsIgnoreCase(""))
			this.strVMID = JUtil.validateString(strVMID);
	}

	public int getAddCount() {
		return cntAdd;
	}

	public void setAddCount(int cntAdd) {
		this.cntAdd = cntAdd;
	}

	public void incrAddCount() {
		cntAdd = cntAdd + 1;
	}
	
	public int getDupCount() {
		return cntDup;
	}
	
	public void setDupCount(int cntDup) {
		this.cntDup = cntDup;
	}

	public void incrDupCount() {
		cntDup = cntDup + 1;
	}
	
	public int getInvCount() {
		return cntInv;
	}

	public void setInvCount(int cntInv) {
		this.cntInv = cntInv;
	}
	
	public void incrInvCount() {
		cntInv = cntInv + 1;
	}


	public int getReadCount() {
		return cntRead;
	}

	public void setCntRead(int cntRead) {
		this.cntRead = cntRead;
	}

	public void incrReadCount() {
		cntRead = cntRead + 1;
	}

	
}