package com.migration.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.ArrayList;

//import sun.org.mozilla.javascript.internal.regexp.SubString;


import com.migration.lib.CommonFunction;
import com.migration.lib.JLib;
import com.migration.lib.JUtil;
import com.mysql.jdbc.ResultSet;

public class FeeSchedule {
	
//    ArrayList<String> ors = new ArrayList<String>();
//    ArrayList<String> ors2 = new ArrayList<String>();
//    ArrayList<String> ors3 = new ArrayList<String>();

	public String POS = "";
	public String strPOS = "";
	public String strTOS = "";
	public String TOS = "";
    public String itemid = "";
    public String modifier = "";
    public String modifier2 = "";
    public String chargecode = "";
    public long Count = 0;
	public String strdes = "";
	public String ForceUpdate = "";
	public String xmlpath = "";
	public int OrsSize = 0;
	public String strCode = "";
	public String UnitFee = "";
	public String AlldFee = "";
	public String strDescription = "";
	public String RVU = "";
	public String CLIAId = "";
	public String GBD = "";
    String FeeSchID = null;
	public int IsChgCd = 0;
	
	
	public FeeSchedule() {	
	}
	
	
	public int insertData(FeeScheduleBean objFSBean,Connection connSrc, Connection connDest) throws Exception
	{
		PreparedStatement stmtPr =null;
		Boolean insertFlag = true;
		String strException = "";
		Statement stmt = null;
		ResultSet rsFS = null;
		ResultSet ors = null;
		ResultSet ors2 = null;
		ResultSet ors3 = null;
		stmt = connDest.createStatement();
		String strInsertSql = "";
		String strUpdateSql = "";
		String strSelectSql = "";
		int result = 0;
		int i = 0;
		
		FeeSchID = "FeeSchedule";
	    strSelectSql = "select id from feeschlist where name ='" + FeeSchID + "' and deleteflag=0";
	    rsFS = (ResultSet) stmt.executeQuery(strSelectSql);
	    rsFS.first();
	  
		strUpdateSql = "update cptfeesch set allowedfee = 0, fee = 0 where feeschid =?";
		stmtPr = connDest.prepareStatement(strUpdateSql);
//		stmtPr.setString(++i, objFSBean.getStrFeeSchID());
		stmtPr.setString(++i, rsFS.getString("id"));
		stmtPr.executeUpdate();	
		
		strCode = objFSBean.getStrCode();
		strCode = CommonFunction.ConvertAlphaNumberic(strCode);
		UnitFee = objFSBean.getStrUnitFee();
		UnitFee = CommonFunction.ConvertAlphaNumberic(UnitFee);
		AlldFee = objFSBean.getStrAlldFee();
		AlldFee = CommonFunction.ConvertAlphaNumberic(AlldFee);		
		strDescription = objFSBean.getStrDescription();
		strDescription = CommonFunction.ConvertAlphaNumberic(strDescription);
		modifier = objFSBean.getStrmodifer();
		modifier = CommonFunction.ConvertAlphaNumberic(modifier);
		modifier2 = objFSBean.getStrmodifer2();
		modifier2 = CommonFunction.ConvertAlphaNumberic(modifier2);
		strPOS = objFSBean.getStrPOS();
		strPOS = CommonFunction.ConvertAlphaNumberic(strPOS);
		strTOS = objFSBean.getStrTOS();
		strTOS = CommonFunction.ConvertAlphaNumberic(strTOS);	
	    RVU = objFSBean.getStrRVU();
		RVU = CommonFunction.ConvertAlphaNumberic(RVU);			
	    CLIAId = objFSBean.getStrCLIAId();
	    CLIAId = CommonFunction.ConvertAlphaNumberic(CLIAId);
	    GBD = objFSBean.getStrGBD();
	    GBD = CommonFunction.ConvertAlphaNumberic(GBD);
	    
	    if (UnitFee != ""){
	    	UnitFee = UnitFee.substring(0, 2);
	    }
	    
	    if (AlldFee != ""){
	    	AlldFee = AlldFee.substring(0, 2);
	    }
	    
	    if (CLIAId == "Yes" || CLIAId == "y" || CLIAId == "1"){
	    	CLIAId = "1";
	    }
	    else {
	    	CLIAId = "0";
	    }
	    
        if (strCode.length() > 5) {
        	if (strCode.length() == 9) {
        	modifier2 = modifier2.trim();
            modifier2 = JLib.Right(strCode, 2);
            strCode = strCode.trim();
            strCode = JLib.Left(strCode, 7);
        	}
        if (strCode.length() == 7) {
        	modifier = modifier.trim();
            modifier = JLib.Right(strCode, 2);
            strCode = strCode.trim();
            strCode = JLib.Left(strCode, 5);
         }
        }
		
        if (strCode != "" && modifier.length() <= 2){
        
		try
		{
		Count = 0;
		if (IsChgCd == 1) {
	    strSelectSql = "select i.*, j.*,k.Mod1,k.Mod2,k.meddesc,k.POS, k.TOS, k.longdesc from itemdetail i,items j, edi_cptcodes k  where (i.itemid = j.itemid and j.itemid = k.itemid and i.value = '" + objFSBean.getStrCode() + "' and i.propid=13 and j.deleteFlag = 0) and j.keyName in ('CPTCodes','VisitCodes') order by k.chargecode";
	    ors = (ResultSet) stmt.executeQuery(strSelectSql);
		}
		
		else {
        strSelectSql = "select i.*, j.*,k.Mod1,k.Mod2,k.meddesc,k.POS, k.TOS, k.longdesc from itemdetail i,items j, edi_cptcodes k  where (i.itemid = j.itemid and j.itemid = k.itemid and i.value = '" + objFSBean.getStrCode() + "' and i.propid=13 and j.deleteFlag = 0) and j.keyName in ('CPTCodes','VisitCodes') order by i.itemid";
        ors = (ResultSet) stmt.executeQuery(strSelectSql);
		}
		
        strSelectSql = "select items.ItemID from items, itemdetail where items.itemid = itemdetail.itemid and itemdetail.propid = 13 and items.keyName in ('CPTCodes','VisitCodes') and items.deleteflag = 0 and itemdetail.value = '" + objFSBean.getStrCode() + "'";
        ors3 = (ResultSet) stmt.executeQuery(strSelectSql);
		
		if (ors == null && ors3 != null){
		if (IsChgCd == 0){
		strInsertSql = "insert into edi_cptcodes set itemid = ? , POS = ?, TOS = ?, ReqCliaId= ?, GlobalBillingDays = ?";
		stmtPr = connDest.prepareStatement(strInsertSql);
		stmtPr.setString(++i,itemid);
		stmtPr.setString(++i, strPOS);
		stmtPr.setString(++i, strTOS);
		stmtPr.setString(++i, CLIAId);
		stmtPr.setString(++i, GBD);
		stmtPr.executeUpdate();
		}
		else {
		strInsertSql = "insert into edi_cptcodes set itemid = ? , POS = ?, TOS = ?, ReqCliaId= ?, GlobalBillingDays = ?, chargecode = ?";
		stmtPr = connDest.prepareStatement(strInsertSql);
		stmtPr.setString(++i,itemid);
		stmtPr.setString(++i, strPOS);
		stmtPr.setString(++i, strTOS);
		stmtPr.setString(++i, CLIAId);
		stmtPr.setString(++i, GBD);
		stmtPr.setString(++i, chargecode);
		stmtPr.executeUpdate();	
		}
		}
		else if (ors == null && ors3 == null) {

		}
		
		else if (ors != null) {
         		
		while (ors.next()) {
			modifier = ors.getString("mod1");
			modifier2 = ors.getString("mod2");
			itemid = ors.getString("itemid");
			POS = ors.getString("POS");
			TOS = ors.getString("TOS");
			
			if (strPOS.length() == 0 && POS == "11"){
				strPOS = "11";
			}
			
			if (strTOS.length() == 0 && TOS == "1"){
				strTOS = "1";
			}
			
			if (ForceUpdate == "Yes"){
	            POS = strPOS;
	            TOS = strTOS;
	            modifier = objFSBean.getStrmodifer();
	            modifier2 = objFSBean.getStrmodifer2();
			}
			
			if (modifier == objFSBean.getStrmodifer() &&  modifier2 == objFSBean.getStrmodifer2()){
				xmlpath = ors.getString("xmlpath");
			
				if (TOS == strTOS && POS == strPOS){
			        strUpdateSql = "update edi_cptcodes set Mod1 = ?,Mod2=?,POS = ?, TOS = ?, ReqCliaId= ?, GlobalBillingDays = ? where itemID =?";
					stmtPr = connDest.prepareStatement(strUpdateSql);
					stmtPr.setString(++i, objFSBean.getStrmodifer());
					stmtPr.setString(++i, objFSBean.getStrmodifer2());
					stmtPr.setString(++i, objFSBean.getStrPOS());
					stmtPr.setString(++i, objFSBean.getStrTOS());
					stmtPr.setString(++i, objFSBean.getStrCLIAId());
					stmtPr.setString(++i, objFSBean.getStrGBD());
					stmtPr.setString(++i, itemid);
					ors3 = (ResultSet) stmtPr.executeQuery(strUpdateSql);
				}
				
			}
		}
		
		if (objFSBean.getStrAlldFee() != "0.00" || objFSBean.getStrUnitFee() != "0.00"){
	        strSelectSql = "select ItemID from cptfeesch where DeleteFlag = 0 and ItemId = ? and FeeSchId = ?";
			stmtPr = connDest.prepareStatement(strSelectSql);
			stmtPr.setString(++i,itemid);
			stmtPr.setString(++i, objFSBean.getStrFeeSchID());
			stmtPr.executeQuery(strSelectSql);
			
			if (Count == 0){
			if (Count == 1){
			strInsertSql = "insert into cptfeesch Set itemId= ?,FeeSchId = ?, AllowedFee = ?, Fee = ?, RVU=?";
			stmtPr = connDest.prepareStatement(strInsertSql);
			stmtPr.setString(++i,itemid);
			stmtPr.setString(++i, objFSBean.getStrFeeSchID());
			stmtPr.setString(++i, objFSBean.getStrAlldFee());
			stmtPr.setString(++i, objFSBean.getStrUnitFee());
			stmtPr.setString(++i, objFSBean.getStrRVU());
			stmtPr.executeUpdate();
			}
			else {
				strUpdateSql = "Update cptfeesch Set AllowedFee= ?,Fee = ?, RVU=? where deleteflag = 0 and itemid = ? and FeeSchID = ?";
				stmtPr = connDest.prepareStatement(strSelectSql);
				stmtPr.setString(++i,itemid);
				stmtPr.setString(++i, objFSBean.getStrAlldFee());
				stmtPr.setString(++i, objFSBean.getStrUnitFee());
				stmtPr.setString(++i, objFSBean.getStrRVU());
				stmtPr.setString(++i, itemid);
				stmtPr.setString(++i, objFSBean.getStrFeeSchID());
				
				stmtPr.executeUpdate();
	
			}
			}
			else if (Count == 0){
				
			
			}
			else if (Count > 2){
				
			}
		}
		
		}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw e;
		}
		finally
		{
			if (stmtPr != null)
			stmtPr.close();
		}
		return result;
		
	}
		return i;
        }
}
