/**
 * 
 */
package com.migration.model;

import com.migration.lib.JUtil;

/**
 * @author jay.shah
 *
 */
public class FacilityBean 
{
	private String strName = "";
	private String strAddressLine1 = "";
	private String strAddressLine2 = "";
	private String strCity = "";
	private String strState = "";
	private String strZip = "";
	private String strTel = "";
	private String strFax = "";
	private String strEMail = "";
	
	private String strBillingAddressLine1 = "";
	private String strBillingAddressLine2 = "";
	private String strBillingCity = "";
	private String strBillingState = "";
	private String strBillingZip = "";
	private String strBillingTel = "";
	private String strBillingFax = "";
	private String strBillingEMail = "";
	private String strPracticeType = "";
	private String strPracticeOption ="Medical"; //enum('Medical','Chiropractic','Other')

	private String strPayableTo = "";
	private String strBankAccount = "";
	private String strFederalTaxID = "";
	
	private String strNotes = "";
	private int primaryFacility  = 0;
	private String strCliaId = "";
	private String strcode = "";
	private int POS = 11; //default 11
	private String strMammoCertId = "";
	private int HPSAFlag =0;
	private String strHPSAModifier ="";
	private int deleteFlag =0;
	private String strvmid ="";
	private String strHl7id ="";
	private int FeeSchedule=0;
	private int FacilityIdType=0;
	private String strNPI ="";
	private String strTaxonomyCode ="";
	
	private int addCount =0;
	private int dupCount =0;
	private int invCount =0;
	
	/* Clears all data except counter */
	
	public void clearAll() {
		strName = "";
		strAddressLine1 = "";
		strAddressLine2 = "";
		strCity = "";
		strState = "";
		strZip = "";
		strTel = "";
		strFax = "";
		strEMail = "";
		
		strBillingAddressLine1 = "";
		strBillingAddressLine2 = "";
		strBillingCity = "";
		strBillingState = "";
		strBillingZip = "";
		strBillingTel = "";
		strBillingFax = "";
		strBillingEMail = "";
		strPracticeType = "";
		strPracticeOption ="Medical"; //enum('Medical','Chiropractic','Other')

		strPayableTo = "";
		strBankAccount = "";
		strFederalTaxID = "";
		
		strNotes = "";
		primaryFacility  = 0;
		strCliaId = "";
		strcode = "";
		POS = 11; //default 11
		strMammoCertId = "";
		HPSAFlag =0;
		strHPSAModifier ="";
		deleteFlag =0;
		strvmid ="";
		strHl7id ="";
		FeeSchedule=0;
		FacilityIdType=0;
		strNPI ="";
		strTaxonomyCode ="";
		
	}
	
	/**
	 * @return the strName
	 */
	public String getStrName() {
		return strName;
	}
	/**
	 * @param strName the strName to set
	 */
	public void setStrName(String strName) {
		this.strName = strName;
	}
	/**
	 * @return the strAddressLine1
	 */
	public String getStrAddressLine1() {
	
//		if (strAddressLine1 == null){
//		return "";
//		}
//		else{
		return strAddressLine1;
//		}
	}
	/**
	 * @param strAddressLine1 the strAddressLine1 to set
	 */
	public void setStrAddressLine1(String strAddressLine1) {
			this.strAddressLine1 = 	strAddressLine1;
	}
	/**
	 * @return the strAddressLine2
	 * @throws Exception 
	 */
	public String getStrAddressLine2() {
		
//		if (strAddressLine2 == null){
//		return "";
//		}
//		else{
		return strAddressLine2;
//		}
	}
	/**
	 * @param strAddressLine2 the strAddressLine2 to set
	 */
	public void setStrAddressLine2(String strAddressLine2) {
		this.strAddressLine2 = strAddressLine2;
	}
	/**
	 * @return the strCity
	 */
	public String getStrCity() {
		return strCity;
		
	}
	/**
	 * @param strCity the strCity to set
	 */
	public void setStrCity(String strCity) {
		this.strCity = strCity;
	}
	/**
	 * @return the strState
	 */
	public String getStrState() {
			return strState;
			
	}
	/**
	 * @param strState the strState to set
	 */
	public void setStrState(String strState) {
		this.strState = strState;
	}
	/**
	 * @return the strZip
	 */
	public String getStrZip() {
			return strZip;
	}
	/**
	 * @param strZip the strZip to set
	 */
	public void setStrZip(String strZip) {
		this.strZip = strZip;
	}
	/**
	 * @return the strTel
	 */
	public String getStrTel() {
			return strTel;
			
	}
	/**
	 * @param strTel the strTel to set
	 */
	public void setStrTel(String strTel) {
		this.strTel = strTel;
	}
	/**
	 * @return the strFax
	 */
	public String getStrFax() {
			return strFax;
			
	}
	/**
	 * @param strFax the strFax to set
	 */
	public void setStrFax(String strFax) {
		this.strFax = strFax;
	}
	/**
	 * @return the strEMail
	 */
	public String getStrEMail() {
			return strEMail;
		
	}
	/**
	 * @param strEMail the strEMail to set
	 */
	public void setStrEMail(String strEMail) {
		this.strEMail = strEMail;
	}
	/**
	 * @return the strBillingAddressLine1
	 */
	public String getStrBillingAddressLine1() {
			return strBillingAddressLine1;
	}
	/**
	 * @param strBillingAddressLine1 the strBillingAddressLine1 to set
	 */
	public void setStrBillingAddressLine1(String strBillingAddressLine1) {
		this.strBillingAddressLine1 = strBillingAddressLine1;
	}
	/**
	 * @return the strBillingAddressLine2
	 */
	public String getStrBillingAddressLine2() {
			return strBillingAddressLine2;
	}
	/**
	 * @param strBillingAddressLine2 the strBillingAddressLine2 to set
	 */
	public void setStrBillingAddressLine2(String strBillingAddressLine2) {
		this.strBillingAddressLine2 = strBillingAddressLine2;
	}
	/**
	 * @return the strBillingCity
	 */
	public String getStrBillingCity() {
			return strBillingCity;
	}
	/**
	 * @param strBillingCity the strBillingCity to set
	 */
	public void setStrBillingCity(String strBillingCity) {
		this.strBillingCity = strBillingCity;
	}
	/**
	 * @return the strBillingState
	 */
	public String getStrBillingState() {
			return strBillingState;
	}
	/**
	 * @param strBillingState the strBillingState to set
	 */
	public void setStrBillingState(String strBillingState) {
		this.strBillingState = strBillingState;
	}
	/**
	 * @return the strBillingZip
	 */
	public String getStrBillingZip() {
			return strBillingZip;
	}
	/**
	 * @param strBillingZip the strBillingZip to set
	 */
	public void setStrBillingZip(String strBillingZip) {
		this.strBillingZip = strBillingZip;
	}
	/**
	 * @return the strBillingTel
	 */
	public String getStrBillingTel() {
			return strBillingTel;
			
	}
	/**
	 * @param strBillingTel the strBillingTel to set
	 */
	public void setStrBillingTel(String strBillingTel) {
		this.strBillingTel = strBillingTel;
	}
	/**
	 * @return the strBillingFax
	 */
	public String getStrBillingFax() {
			return strBillingFax;
	}
	/**
	 * @param strBillingFax the strBillingFax to set
	 */
	public void setStrBillingFax(String strBillingFax) {
		this.strBillingFax = strBillingFax;
	}
	/**
	 * @return the strBillingEMail
	 */
	public String getStrBillingEMail() {
			return strBillingEMail;
	}
	/**
	 * @param strBillingEMail the strBillingEMail to set
	 */
	public void setStrBillingEMail(String strBillingEMail) {
		this.strBillingEMail = strBillingEMail;
	}
	/**
	 * @return the strPracticeType
	 */
	public String getStrPracticeType() {
			return strPracticeType;
	}
	/**
	 * @param strPracticeType the strPracticeType to set
	 */
	public void setStrPracticeType(String strPracticeType) {
		this.strPracticeType = strPracticeType;
	}
	/**
	 * @return the strPracticeOption
	 */
	public String getStrPracticeOption() {

			return strPracticeOption;
			}
	/**
	 * @param strPracticeOption the strPracticeOption to set
	 */
	public void setStrPracticeOption(String strPracticeOption) {
		this.strPracticeOption = strPracticeOption;
	}
	/**
	 * @return the strPayableTo
	 */
	public String getStrPayableTo() {

			return strPayableTo;
			}
	/**
	 * @param strPayableTo the strPayableTo to set
	 */
	public void setStrPayableTo(String strPayableTo) {
		this.strPayableTo = strPayableTo;
	}
	/**
	 * @return the strBankAccount
	 */
	public String getStrBankAccount() {
			return strBankAccount;
	}
	/**
	 * @param strBankAccount the strBankAccount to set
	 */
	public void setStrBankAccount(String strBankAccount) {
		this.strBankAccount = strBankAccount;
	}
	/**
	 * @return the strFederalTaxID
	 */
	public String getStrFederalTaxID() {
			return strFederalTaxID;
	}
	/**
	 * @param strFederalTaxID the strFederalTaxID to set
	 */
	public void setStrFederalTaxID(String strFederalTaxID) {
		this.strFederalTaxID = strFederalTaxID;
	}
	/**
	 * @return the strNotes
	 */
	public String getStrNotes() {
			return strNotes;
	}
	/**
	 * @param strNotes the strNotes to set
	 */
	public void setStrNotes(String strNotes) {
		this.strNotes = strNotes;
	}
	/**
	 * @return the primaryFacility
	 */
	public int getPrimaryFacility() {

			return primaryFacility;
	}
	/**
	 * @param primaryFacility the primaryFacility to set
	 */
	public void setPrimaryFacility(int primaryFacility) {
		this.primaryFacility = primaryFacility;
	}
	/**
	 * @return the strCliaId
	 */
	public String getStrCliaId() {
			return strCliaId;
	}
	/**
	 * @param strCliaId the strCliaId to set
	 */
	public void setStrCliaId(String strCliaId) {
		this.strCliaId = strCliaId;
	}
	/**
	 * @return the strcode
	 */
	public String getStrcode() {
			return strcode;
	}
	/**
	 * @param strcode the strcode to set
	 */
	public void setStrcode(String strcode) {
		this.strcode = strcode;
	}
	/**
	 * @return the pOS
	 */
	public int getPOS() {
		return POS;
	}
	/**
	 * @param pos the pOS to set
	 */
	public void setPOS(int pos) {
		POS = pos;
	}
	/**
	 * @return the strMammoCertId
	 */
	public String getStrMammoCertId() {

			return strMammoCertId;
	}
	/**
	 * @param strMammoCertId the strMammoCertId to set
	 */
	public void setStrMammoCertId(String strMammoCertId) {
		this.strMammoCertId = strMammoCertId;
	}
	/**
	 * @return the hPSAFlag
	 */
	public int getHPSAFlag() {
		return HPSAFlag;
	}
	/**
	 * @param flag the hPSAFlag to set
	 */
	public void setHPSAFlag(int flag) {
		HPSAFlag = flag;
	}
	/**
	 * @return the strHPSAModifier
	 */
	public String getStrHPSAModifier() {
			return strHPSAModifier;
	}
	/**
	 * @param strHPSAModifier the strHPSAModifier to set
	 */
	public void setStrHPSAModifier(String strHPSAModifier) {
		this.strHPSAModifier = strHPSAModifier;
	}
	/**
	 * @return the deleteFlag
	 */
	public int getDeleteFlag() {
		return deleteFlag;
	}
	/**
	 * @param deleteFlag the deleteFlag to set
	 */
	public void setDeleteFlag(int deleteFlag) {
		this.deleteFlag = deleteFlag;
	}
	/**
	 * @return the strvmid
	 */
	public String getStrvmid() {
		return strvmid;
	}
	/**
	 * @param strvmid the strvmid to set
	 */
	public void setStrvmid(String strvmid) {
		if (!strvmid.equalsIgnoreCase(""))
			this.strvmid = strvmid;
	}
	/**
	 * @return the hl7id
	 */
	public String getStrHl7id() {
		return strHl7id;
	}
	/**
	 * @param hl7id the hl7id to set
	 */
	public void setStrHl7id(String strHl7id) {
		this.strHl7id = strHl7id;
	}
	/**
	 * @return the feeSchedule
	 */
	public int getFeeSchedule() {
		return FeeSchedule;
	}
	/**
	 * @param feeSchedule the feeSchedule to set
	 */
	public void setFeeSchedule(int feeSchedule) {
		FeeSchedule = feeSchedule;
	}
	/**
	 * @return the facilityIdType
	 */
	public int getFacilityIdType() {
		return FacilityIdType;
	}
	/**
	 * @param facilityIdType the facilityIdType to set
	 */
	public void setFacilityIdType(int facilityIdType) {
		FacilityIdType = facilityIdType;
	}
	/**
	 * @return the strNPI
	 */
	public String getStrNPI() {

			return strNPI;
	}
	/**
	 * @param strNPI the strNPI to set
	 */
	public void setStrNPI(String strNPI) {
		this.strNPI = strNPI;
	}
	/**
	 * @return the strTaxonomyCode
	 */
	public String getStrTaxonomyCode() {

			return strTaxonomyCode;
	}
	/**
	 * @param strTaxonomyCode the strTaxonomyCode to set
	 */
	public void setStrTaxonomyCode(String strTaxonomyCode) 
	{

			this.strTaxonomyCode = strTaxonomyCode;
	}
	/**
	 * @param strAddCount the strAddCount to set
	 */
	public void setAddCount(int addCount) {
		this.addCount = addCount;
	}
	/**
	 * @return the strAddCount
	 */
	public int getAddCount() {
		return addCount;
	}
	
	public void incrAddCount() {
		addCount = addCount + 1;
	}
	
	/**
	 * @param strDupCount the strDupCount to set
	 */
	public void setDupCount(int dupCount) {
		this.dupCount =dupCount;
	}
	
	public void incrDupCount() {
		dupCount = dupCount + 1;
	}
	
	/**
	 * @return the strDupCount
	 */
	public int getDupCount() {
		return dupCount;
	}
	
	/**
	 * @param strInvCount the strInvCount to set
	 */
	public void setInvCount(int invCount) {
		this.invCount = invCount;
	}
	
	public void incrInvCount() {
		invCount = invCount + 1;
	}
	
	/**
	 * @return the strInvCount
	 */
	public int getInvCount() {
		return invCount;
	}
	
}
