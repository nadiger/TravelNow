package com.migration.model;

public class VisitStatusBean {
	private String StrVisitCode = "";
	private String StrVisitstatus = "";

	private int addCount =0;
	private int dupCount =0;
	private int invCount =0;

	public void clearAll() {
		String StrVisitCode = "";
		String StrVisitstatus = "";
	}	
	public String getStrVisitCode() {
		return StrVisitCode;
	}
	public void setStrVisitCode(String StrVisitCode) {
		this.StrVisitCode = StrVisitCode;
	}
	public String getStrVisitstatus() {
		return StrVisitstatus;
	}
	public void setStrVisitstatus(String StrVisitstatus) {
		this.StrVisitstatus = StrVisitstatus;
	}
	/**
	 * @param strAddCount the strAddCount to set
	 */
	public void setAddCount(int addCount) {
		this.addCount = addCount;
	}
	/**
	 * @return the strAddCount
	 */
	public int getAddCount() {
		return addCount;
	}
	public void incrAddCount() {
		addCount = addCount + 1;
	}
	/**
	 * @param strDupCount the strDupCount to set
	 */
	public void setDupCount(int dupCount) {
		this.dupCount =dupCount;
	}
	public void incrDupCount() {
		dupCount = dupCount + 1;
	}
	/**
	 * @return the strDupCount
	 */
	public int getDupCount() {
		return dupCount;
	}
	/**
	 * @param strInvCount the strInvCount to set
	 */
	public void setInvCount(int invCount) {
		this.invCount = invCount;
	}
	public void incrInvCount() {
		invCount = invCount + 1;
	}
	/**
	 * @return the strInvCount
	 */
	public int getInvCount() {
		return invCount;
	}
}

