package com.migration.model;

import java.sql.Connection;
import java.sql.PreparedStatement;

//import sun.security.util.Length;

import com.migration.lib.CommonFunction;
import com.migration.lib.JLib;
import com.migration.lib.JUtil;

public class ZipCodes {
	public String Zip = "";
	public String State = "";
	
	public ZipCodes()	{
	
	}

	public int insertData(ZipCodesBean objZipBean,Connection connSrc, Connection connDest) throws Exception {
		
		
		PreparedStatement stmtPr =null;
		Boolean insertFlag = true;
		String strException = "";
		
		String strInsertSql = "";
		int result = 0;
		int i = 0;
		
		Zip = objZipBean.getStrZip();
		Zip = CommonFunction.convertzip(Zip);
		State = objZipBean.getStrState();
//		State = CommonFunction.toState(State);
		
		try
		{
			
			if (JLib.getZipByVMID(objZipBean.getStrVmid(), connDest) != 0 )
			{
				insertFlag = false;	
				objZipBean.incrDupCount();
			}
			
			if (insertFlag == true)
			{
				
				strInsertSql = " insert into ZipCodes ";
				strInsertSql += " (vmid, city, state, zip) ";
				strInsertSql += " values (?,?,?,?) ";
				
				stmtPr = connDest.prepareStatement(strInsertSql);
				stmtPr.setString(++i, Zip);
				stmtPr.setString(++i, objZipBean.getStrCity());
				stmtPr.setString(++i, State);
				stmtPr.setString(++i, objZipBean.getStrZip());
					
				stmtPr.executeUpdate();
				
				objZipBean.incrAddCount();
				
				result = JLib.getFacilityByVMID(objZipBean.getStrVmid(), connDest);
			}
			else  {
				strException = objZipBean.getStrZip() + "," + "duplicate Zip";
				JUtil.appendToFile("Zip_Exception.csv", strException);
				
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw e;
		}
		finally
		{
			if (stmtPr != null)
			stmtPr.close();
		}
		return result;
		
	}

	
}
