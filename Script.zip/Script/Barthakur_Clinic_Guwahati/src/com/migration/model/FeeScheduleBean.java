package com.migration.model;

public class FeeScheduleBean {
	private String strCode = "";
	private String strUnitFee = "";
	private String strAlldFee = "";
	private String strDescription = "";
	private String strmodifer = "";
	private String strmodifer2 = "";
	private String strPOS = "";
	private String strTOS = "";
	private String strCLIAId = "";
	private String strGBD = "";
	private String strChargeCode = "";
    private String strRVU = "";
    private String strFeeSchID = "";
    
	private int addCount =0;
	private int dupCount =0;
	private int invCount =0;
    
	public void clearAll() {
		strCode = "";
		strUnitFee = "";
		strAlldFee = "";
		strDescription = "";
		strmodifer = "";
		strmodifer2 = "";
		strPOS = "";
		strTOS = "";
		strCLIAId = "";
		strGBD = "";
		strChargeCode = "";
	    strRVU = "";
	    strFeeSchID = "";
	}
	
	
	
	public String getStrFeeSchID() {
		return strFeeSchID;
	}



	public void setStrFeeSchID(String strFeeSchID) {
		this.strFeeSchID = strFeeSchID;
	}



	public String getStrCode() {
		return strCode;
	}
	public void setStrCode(String strCode) {
		this.strCode = strCode;
	}
	public String getStrUnitFee() {
		return strUnitFee;
	}
	public void setStrUnitFee(String strUnitFee) {
		this.strUnitFee = strUnitFee;
	}
	public String getStrAlldFee() {
		return strAlldFee;
	}
	public void setStrAlldFee(String strAlldFee) {
		this.strAlldFee = strAlldFee;
	}
	public String getStrDescription() {
		return strDescription;
	}
	public void setStrDescription(String strDescription) {
		this.strDescription = strDescription;
	}
	public String getStrmodifer() {
		return strmodifer;
	}
	public void setStrmodifer(String strmodifer) {
		this.strmodifer = strmodifer;
	}
	public String getStrmodifer2() {
		return strmodifer2;
	}
	public void setStrmodifer2(String strmodifer2) {
		this.strmodifer2 = strmodifer2;
	}
	public String getStrPOS() {
		return strPOS;
	}
	public void setStrPOS(String strPOS) {
		this.strPOS = strPOS;
	}
	public String getStrTOS() {
		return strTOS;
	}
	public void setStrTOS(String strTOS) {
		this.strTOS = strTOS;
	}
	public String getStrCLIAId() {
		return strCLIAId;
	}
	public void setStrCLIAId(String strCLIAId) {
		this.strCLIAId = strCLIAId;
	}
	public String getStrGBD() {
		return strGBD;
	}
	public void setStrGBD(String strGBD) {
		this.strGBD = strGBD;
	}
	public String getStrChargeCode() {
		return strChargeCode;
	}
	public void setStrChargeCode(String strChargeCode) {
		this.strChargeCode = strChargeCode;
	}
	public String getStrRVU() {
		return strRVU;
	}
	public void setStrRVU(String strRVU) {
		this.strRVU = strRVU;
	}
    
	/**
	 * @param strAddCount the strAddCount to set
	 */
	public void setAddCount(int addCount) {
		this.addCount = addCount;
	}
	/**
	 * @return the strAddCount
	 */
	public int getAddCount() {
		return addCount;
	}
	
	public void incrAddCount() {
		addCount = addCount + 1;
	}
	
	/**
	 * @param strDupCount the strDupCount to set
	 */
	public void setDupCount(int dupCount) {
		this.dupCount =dupCount;
	}
	
	public void incrDupCount() {
		dupCount = dupCount + 1;
	}
	
	/**
	 * @return the strDupCount
	 */
	public int getDupCount() {
		return dupCount;
	}
	
	/**
	 * @param strInvCount the strInvCount to set
	 */
	public void setInvCount(int invCount) {
		this.invCount = invCount;
	}
	
	public void incrInvCount() {
		invCount = invCount + 1;
	}
	
	/**
	 * @return the strInvCount
	 */
	public int getInvCount() {
		return invCount;
	}
    
}
