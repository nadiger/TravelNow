package com.migration.model;

public class StructInfoBean 
{
	private Integer strPatientid = 0;
	private Integer strDetailid = 0;
	private String strValue ="";
	private String strNotes = "";
	
	private int addCount =0;
	private int dupCount =0;
	private int invCount =0;
	
	/* Clears all data except counter */
	public void ClearAll(){
		strPatientid =0;
		strDetailid =0;
		strValue ="";
		strNotes ="";
	}

	public int getStrDetailid() {
		return strDetailid;
	}

	public void setStrDetailid(Integer strDetailid) {
		this.strDetailid = strDetailid;
	}

	public String getStrNotes() {
		return strNotes;
	}

	public void setStrNotes(String strNotes) {
		this.strNotes = strNotes;
	}

	public int getStrPatientid() {
		return strPatientid;
	}

	public void setStrPatientid(Integer strPatientid) {
		this.strPatientid = strPatientid;
	}

	public String getStrValue() {
		return strValue;
	}

	public void setStrValue(String strValue) {
		this.strValue = strValue;
	}
	
	/**
	 * @param strAddCount the strAddCount to set
	 */
	public void setAddCount(int addCount) {
		this.addCount = addCount;
	}
	/**
	 * @return the strAddCount
	 */
	public int getAddCount() {
		return addCount;
	}
	
	public void incrAddCount() {
		addCount = addCount + 1;
	}
	
	/**
	 * @param strDupCount the strDupCount to set
	 */
	public void setDupCount(int dupCount) {
		this.dupCount =dupCount;
	}
	
	public void incrDupCount() {
		dupCount = dupCount + 1;
	}
	
	/**
	 * @return the strDupCount
	 */
	public int getDupCount() {
		return dupCount;
	}
	
	/**
	 * @param strInvCount the strInvCount to set
	 */
	public void setInvCount(int invCount) {
		this.invCount = invCount;
	}
	
	public void incrInvCount() {
		invCount = invCount + 1;
	}
	
	/**
	 * @return the strInvCount
	 */
	public int getInvCount() {
		return invCount;
	}
	
}