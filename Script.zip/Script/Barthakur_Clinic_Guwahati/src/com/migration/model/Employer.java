package com.migration.model;

import java.sql.Connection;
import java.sql.PreparedStatement;


import com.migration.lib.CommonFunction;
import com.migration.lib.JLib;

public class Employer{
	
	public String EmpPhone = "";
	public String EmpFax = "";
	public String EmpZip = "";
	public String EmpState = "";
		public Employer()
		{
			
		}
		public int insertData(EmployerBean objEmpBean,Connection connSrc, Connection connDest) throws Exception
		{
			PreparedStatement stmtPr =null;
			Boolean insertFlag = true;
			
			String strInsertSql = "";
			int result = 0;
			int i = 0;
			
			EmpPhone=objEmpBean.getStrempPhone();
	        EmpPhone = CommonFunction.convertPhone(EmpPhone);
	        EmpFax=objEmpBean.getStrempPhone();
	        EmpFax = CommonFunction.convertPhone(EmpFax);
	        EmpZip=objEmpBean.getStrempZip();
	       // EmpZip = CommonFunction.convertzip(EmpZip);
	        EmpState=objEmpBean.getStrempState();
	        if (EmpState.length() > 2){
	        EmpState = "";
	        }
			
			try
			{
				
				if (JLib.getEmployerByName(objEmpBean.getStrEmpName(), connDest) != 0)
				{
					insertFlag = false;	
					objEmpBean.incrDupCount();
				}
				
				if (insertFlag == true)
				{
					
					strInsertSql = " insert into employer";
					strInsertSql += " (EmpName, empAddress1, empAddress2, empCity, empState, empZip, empPhone, empFax, CompanyCode, EnterpriseId,Notes)"; 
					strInsertSql += " values (?,?,?,?,?,?,?,?,?,?,?) ";
					
					stmtPr = connDest.prepareStatement(strInsertSql);
					stmtPr.setString(++i, objEmpBean.getStrEmpName());
					stmtPr.setString(++i, objEmpBean.getStrempAddress1());
					stmtPr.setString(++i, objEmpBean.getStrempAddress2());
					stmtPr.setString(++i, objEmpBean.getStrempCity());
					stmtPr.setString(++i, EmpState);
					stmtPr.setString(++i, EmpZip);
					stmtPr.setString(++i, EmpPhone);
					stmtPr.setString(++i, EmpFax);
					stmtPr.setString(++i, objEmpBean.getStrCompanyCode());
					stmtPr.setInt(++i, objEmpBean.getEnterpriseId());
					stmtPr.setString(++i, "");
					
					
					
					stmtPr.executeUpdate();
					
					objEmpBean.incrAddCount();
					
					result =JLib.getEmployerByName(objEmpBean.getStrEmpName(), connDest);
				}
			}catch(Exception e)
			{
				e.printStackTrace();
				throw e;
			}
			finally
			{
				if (stmtPr != null)
				stmtPr.close();
			}
			return result;
		}
		
}