package com.migration.model;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.migration.lib.CommonFunction;
import com.migration.lib.JLib;
import com.migration.lib.JUtil;
import com.mysql.jdbc.StringUtils;
import com.sun.org.apache.xpath.internal.functions.Function;

public class Insurance {
	public String InsName = "";
	public String phone = "";
	public String phone2 = "";
	public String zip = "";
	public String fax = "";
	public String ClaimSubmitType = "";
	
	public Insurance() {
	}
	
// Throws exception to outer class as well, so error can be displayed in form
public int insertData(InsuranceBean objInsBean,Connection connSrc, Connection connDest) throws Exception {
	PreparedStatement stmtPr = null;
	Boolean insertFlag = true;
	String strException = "";
	String strInsertSql = "";
	int result = 0;
	int i = 0;
	InsName = JUtil.validateString(objInsBean.getStrName());
    InsName = JLib.Left(InsName, 40);
    phone = JUtil.validateString(objInsBean.getStrPhone());
    phone = CommonFunction.convertPhone(phone);
    phone2 = JUtil.validateString(objInsBean.getStrPhone2());
    phone2 = CommonFunction.convertPhone(phone2);
    fax = JUtil.validateString(objInsBean.getStrFax());
    fax = CommonFunction.convertPhone(fax);
    zip = JUtil.validateString(objInsBean.getStrZip());
    zip = CommonFunction.convertzip(zip);
    ClaimSubmitType = JUtil.validateString(objInsBean.getStrClaimSubmitType());
    ClaimSubmitType = CommonFunction.convertSubmitType(ClaimSubmitType);
    



	try
	{
		
		if (JLib.getInsuranceByVMID(objInsBean.getStrInsVMID(), connDest) != 0 )
		{
			insertFlag = false;	
			objInsBean.incrDupCount();
		}
		
		if (insertFlag == true)
		{
			
			strInsertSql = " insert into Insurance";
			strInsertSql += " (vmid,InsuranceName, Insuranceaddress, Insuranceaddress2, InsuranceCity, InsuranceState, InsuranceZip, InsurancePhone, insurancephone2, InsuranceFax, InsuranceEmail,"; 
			strInsertSql += "  PayorID, MediGapID, hl7id1, Notes, ClaimSubmitType, PaymentSrc)";
			strInsertSql += " values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ";
			
			stmtPr = connDest.prepareStatement(strInsertSql);
			stmtPr.setString(++i, JUtil.validateString(objInsBean.getStrInsVMID()));
			stmtPr.setString(++i, InsName);
			stmtPr.setString(++i, JUtil.validateString(objInsBean.getStrAddress1()));
			stmtPr.setString(++i, JUtil.validateString(objInsBean.getStrAddress2()));
			stmtPr.setString(++i, JUtil.validateString(objInsBean.getStrCity()));
			stmtPr.setString(++i, JUtil.validateString(objInsBean.getStrState()));
			stmtPr.setString(++i, zip);
			stmtPr.setString(++i, phone);
			stmtPr.setString(++i, phone2);
			stmtPr.setString(++i, fax);
			stmtPr.setString(++i, JUtil.validateString(objInsBean.getStrEmail()));
			stmtPr.setString(++i, JUtil.validateString(objInsBean.getStrPayorID()));
			stmtPr.setString(++i, JUtil.validateString(objInsBean.getStrMediGapID()));
			stmtPr.setString(++i, JUtil.validateString(objInsBean.getStrhl7id()));
			stmtPr.setString(++i, JUtil.validateString(objInsBean.getStrNotes()));
			stmtPr.setString(++i, ClaimSubmitType);
			stmtPr.setString(++i, JUtil.validateString(objInsBean.getStrPaymentSrc()));
			
			stmtPr.executeUpdate();
			
			objInsBean.incrAddCount();
			
			result = JLib.getInsuranceByVMID(objInsBean.getStrInsVMID(), connDest);
		}
		else  //Duplicate Insurance
		{
			strException = objInsBean.getStrName() + "," + "duplicate Insurance";
			JUtil.appendToFile("Insurance_Exception.csv", strException);
			
			
			
		}
	}
	catch(Exception e)
	{
		e.printStackTrace();
		throw e;
	}
	finally
	{
		if (stmtPr != null)
		stmtPr.close();
	}
	return result;
}	
}