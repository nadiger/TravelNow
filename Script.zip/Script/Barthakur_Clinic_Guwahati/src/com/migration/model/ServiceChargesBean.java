package com.migration.model;

public class ServiceChargesBean {
	
	private String ServiceName;//**
	private String ServiceId;//**
	private String SponsorName;//**
	private String SponsorID;//**
	private String ServiceCharges;
	private String BedCategoryId;
	
	private static int addCount;
	private static int dupCount;
	private static int invCount;
	
	public ServiceChargesBean() {

	}
	public void clearall(){
		ServiceId="0";//**
		ServiceName="";//**
		SponsorID="0";//**
		BedCategoryId="";
		SponsorName="";
		ServiceCharges="";
	}

	
	
	public String getSponsorName() {
		return SponsorName;
	}
	public String getServiceCharges() {
		return ServiceCharges;
	}
	public void setServiceId(String serviceId) {
		ServiceId = serviceId;
	}
	public void setSponsorName(String sponsorName) {
		SponsorName = sponsorName;
	}
	public void setServiceCharges(String serviceCharges) {
		ServiceCharges = serviceCharges;
	}
	public String getServiceId() {
		return ServiceId;
	}

	public String getServiceName() {
		return ServiceName;
	}

	public String getSponsorID() {
		return SponsorID;
	}

	public String getBedCategoryId() {
		return BedCategoryId;
	}

	public void setSubServiceName(String ServiceId) {
		this.ServiceId = ServiceId;
	}

	public void setServiceName(String serviceName) {
		ServiceName = serviceName;
	}

	public void setSponsorID(String SponsorID) {
		this.SponsorID = SponsorID;
	}

	public void setBedCategoryId(String BedCategoryId) {
		this.BedCategoryId = BedCategoryId;
	}
	
	public int getAddCount() {
		return addCount;
	}

	public int getDupCount() {
		return dupCount;
	}

	public int getInvCount() {
		return invCount;
	}

	public void setAddCount() {
		addCount = addCount+1;
	}

	public void setDupCount() {
		dupCount = dupCount+1;
	}

	public void setInvCount() {
		invCount = invCount+1;
	}
	

}
