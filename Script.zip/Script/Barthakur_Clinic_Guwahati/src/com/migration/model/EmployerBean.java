package com.migration.model;

public class EmployerBean
{
	private String strEmpName = "";
	private String strempAddress1 = "";
	private String strempAddress2 = "";
	private String strempCity = "";
	private String strempState = "";
	private String strempZip = "";
	private String strempPhone= "";
	private String strempFax = "";
	private String strCompanyCode = "";
	private int EnterpriseId =0;
	private int addCount =0;
	private int dupCount =0;
	private int invCount =0;
	
	public void clearAll()
	{
		strEmpName = "";
		strempAddress1 = "";
		strempAddress2 = "";
		strempCity = "";
		strempState = "";
		strempZip = "";
		strempPhone= "";
		strempFax = "";
		strCompanyCode = "";
		EnterpriseId =0;
	}
	
	public String getStrEmpName() {
		return strEmpName;
	}

	public void setStrEmpName(String strEmpName) {
		this.strEmpName = strEmpName;
	}

	public String getStrempAddress1() {
		return strempAddress1;
	}

	public void setStrempAddress1(String strempAddress1) {
		this.strempAddress1 = strempAddress1;
	}

	public String getStrempAddress2() {
		return strempAddress2;
	}

	public void setStrempAddress2(String strempAddress2) {
		if(strempAddress2 != null)
			this.strempAddress2 = strempAddress2;
	}

	public String getStrempCity() {
		return strempCity;
	}

	public void setStrempCity(String strempCity) {
		this.strempCity = strempCity;
	}

	public String getStrempState() {
		return strempState;
	}

	public void setStrempState(String strempState) {
		this.strempState = strempState;
	}

	public String getStrempZip() {
		return strempZip;
	}

	public void setStrempZip(String strempZip) {
		this.strempZip = strempZip;
	}

	public String getStrempPhone() {
		return strempPhone;
	}

	public void setStrempPhone(String strempPhone) {
		this.strempPhone = strempPhone;
	}

	public String getStrempFax() {
		return strempFax;
	}

	public void setStrempFax(String strempFax) {
		this.strempFax = strempFax;
	}

	public String getStrCompanyCode() {
		return strCompanyCode;
	}

	public void setStrCompanyCode(String strCompanyCode) {
		this.strCompanyCode = strCompanyCode;
	}

	public int getEnterpriseId() {
		return EnterpriseId;
	}

	public void setEnterpriseId(int enterpriseId) {
		EnterpriseId = enterpriseId;
	}
	/**
	 * @param strAddCount the strAddCount to set
	 */
	public void setAddCount(int addCount) {
		this.addCount = addCount;
	}
	/**
	 * @return the strAddCount
	 */
	public int getAddCount() {
		return addCount;
	}
	
	public void incrAddCount() {
		addCount = addCount + 1;
	}
	
	/**
	 * @param strDupCount the strDupCount to set
	 */
	public void setDupCount(int dupCount) {
		this.dupCount =dupCount;
	}
	
	public void incrDupCount() {
		dupCount = dupCount + 1;
	}
	
	/**
	 * @return the strDupCount
	 */
	public int getDupCount() {
		return dupCount;
	}
	
	/**
	 * @param strInvCount the strInvCount to set
	 */
	public void setInvCount(int invCount) {
		this.invCount = invCount;
	}
	
	public void incrInvCount() {
		invCount = invCount + 1;
	}
	
	/**
	 * @return the strInvCount
	 */
	public int getInvCount() {
		return invCount;
	}
	
}