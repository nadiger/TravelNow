package com.migration.model;

import java.sql.Blob;

import com.sun.org.apache.xerces.internal.impl.dv.xs.DecimalDV;

public class PharmacyBean {

	private String strPharmacyId ="";
	private String strPharmacyName = "";
	private String strIsPharmacyLocation = "";
	private String strAddress1 = "";
	private String strAddress2 = "";
	private String strCity = "";
	private String strState = "";
	private String strZip = "";
	private String strTelephone = "";
	private String strFax = "";
	private String strVmid = "";
	private String strEmail = "";
	
	private int addCount =0;
	private int dupCount =0;
	private int invCount =0;
	
	public void clearAll() {
		String strPharmacyId = "";
		String strPharmacyName = "";
		String strIsPharmacyLocation = "";
		String strAddress1 = "";
		String strAddress2 = "";
		String strCity = "";
		String strState = "";
		String strZip = "";
		String strTelephone = "";
		String strFax = "";
		String strVmid = "";
		String strEmail = "";
	
	}

	



	public String getStrPharmacyId() {
		return strPharmacyId;
	}





	public void setStrPharmacyId(String strPharmacyId) {
		this.strPharmacyId = strPharmacyId;
	}





	public String getStrEmail() {
		return strEmail;
	}



	public void setStrEmail(String strEmail) {
		this.strEmail = strEmail;
	}



	public String getStrPharmacyName() {
		return strPharmacyName;
	}



	public void setStrPharmacyName(String strPharmacyName) {
		this.strPharmacyName = strPharmacyName;
	}



	public String getStrIsPharmacyLocation() {
		return strIsPharmacyLocation;
	}



	public void setStrIsPharmacyLocation(String strIsPharmacyLocation) {
		this.strIsPharmacyLocation = strIsPharmacyLocation;
	}



	public String getStrAddress1() {
		return strAddress1;
	}



	public void setStrAddress1(String strAddress1) {
		this.strAddress1 = strAddress1;
	}



	public String getStrAddress2() {
		return strAddress2;
	}



	public void setStrAddress2(String strAddress2) {
		this.strAddress2 = strAddress2;
	}



	public String getStrCity() {
		return strCity;
	}



	public void setStrCity(String strCity) {
		this.strCity = strCity;
	}



	public String getStrState() {
		return strState;
	}



	public void setStrState(String strState) {
		this.strState = strState;
	}



	public String getStrZip() {
		return strZip;
	}



	public void setStrZip(String strZip) {
		this.strZip = strZip;
	}



	public String getStrTelephone() {
		return strTelephone;
	}



	public void setStrTelephone(String strTelephone) {
		this.strTelephone = strTelephone;
	}



	public String getStrFax() {
		return strFax;
	}



	public void setStrFax(String strFax) {
		this.strFax = strFax;
	}





	public String getStrVmid() {
		return strVmid;
	}



	public void setStrVmid(String strVmid) {
		this.strVmid = strVmid;
	}



	/**
	 * @param strAddCount the strAddCount to set
	 */
	public void setAddCount(int addCount) {
		this.addCount = addCount;
	}
	/**
	 * @return the strAddCount
	 */
	public int getAddCount() {
		return addCount;
	}
	
	public void incrAddCount() {
		addCount = addCount + 1;
	}
	
	/**
	 * @param strDupCount the strDupCount to set
	 */
	public void setDupCount(int dupCount) {
		this.dupCount =dupCount;
	}
	
	public void incrDupCount() {
		dupCount = dupCount + 1;
	}
	
	/**
	 * @return the strDupCount
	 */
	public int getDupCount() {
		return dupCount;
	}
	
	/**
	 * @param strInvCount the strInvCount to set
	 */
	public void setInvCount(int invCount) {
		this.invCount = invCount;
	}
	
	public void incrInvCount() {
		invCount = invCount + 1;
	}
	
	/**
	 * @return the strInvCount
	 */
	public int getInvCount() {
		return invCount;
	}

}


