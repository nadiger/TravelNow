package com.migration.model;

public class PatientPharmacy {

}
