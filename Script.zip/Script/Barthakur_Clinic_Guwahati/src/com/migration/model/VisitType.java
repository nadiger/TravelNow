package com.migration.model;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.migration.lib.CommonFunction;
import com.migration.lib.JLib;
import com.migration.lib.JUtil;

public class VisitType {

	
	
	public VisitType() {
	}
	
	
	
	// Throws exception to outer class as well, so error can be displayed in form
	public int insertData(VisitTypeBean objVTypeBean,Connection connSrc, Connection connDest) throws Exception
	{
		
		
		PreparedStatement stmtPr =null;
		Boolean insertFlag = true;
		String strException = "";
		
		String strInsertSql = "";
		int result = 0;
		int i = 0;
		
		try
		{
			
			if (insertFlag == true)
			{
				
				strInsertSql = " insert into Visitcodes";
				strInsertSql += " (Name, Description, ChartTitle, Color, visitType)";
				strInsertSql += " values (?,?,?,?,?) ";
				
				stmtPr = connDest.prepareStatement(strInsertSql);
				stmtPr.setString(++i, objVTypeBean.getStrVName());
				stmtPr.setString(++i, objVTypeBean.getStrVDescription());
				stmtPr.setString(++i, "ProgressNotes");
				stmtPr.setString(++i, "CC00FF");
				stmtPr.setString(++i, "1");
				
				stmtPr.executeUpdate();
				
				objVTypeBean.incrAddCount();
				
			}
			else  {
				strException = objVTypeBean.getStrVName() + "," + "duplicate VisitType";
				JUtil.appendToFile("VisitType_Exception.csv", strException);
				
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw e;
		}
		finally
		{
			if (stmtPr != null)
			stmtPr.close();
		}
		return result;
		
	}
	
}

