/**
 * 
 */
package com.migration.model;

import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.swing.DropMode;
import javax.swing.JTable.DropLocation;

import sun.misc.JavaUtilJarAccess;


import com.migration.lib.CommonFunction;
import com.migration.lib.JLib;
import com.migration.lib.JUtil;
import com.sun.org.apache.xml.internal.security.utils.JavaUtils;

/**
 * @author jay.shah
 *
 */
public class Facility {
	public String telno = "";
	public String faxno = "";
	public String billingtel = "";
	public String billingfax = "";
	public String Zip="";
	public String BillingZip = "";
	public String POS = "";
	public Facility()
	{
		
	}
	
	
	
	// Throws exception to outer class as well, so error can be displayed in form
	public int insertData(FacilityBean objFacBean,Connection connSrc, Connection connDest) throws Exception
	{
		
		
		PreparedStatement stmtPr =null;
		Boolean insertFlag = true;
		String strException = "";
		
		String strInsertSql = "";
		int result = 0;
		int i = 0;
		
		telno=JUtil.validateString(objFacBean.getStrTel());
		telno = CommonFunction.convertPhone(telno);
		faxno=JUtil.validateString(objFacBean.getStrFax());
		faxno = CommonFunction.convertPhone(faxno);
		billingtel=JUtil.validateString(objFacBean.getStrBillingTel());
		billingtel = CommonFunction.convertPhone(billingtel);
		billingfax=JUtil.validateString(objFacBean.getStrBillingFax());
		billingfax = CommonFunction.convertPhone(billingfax);
		Zip = JUtil.validateString(objFacBean.getStrZip());
		Zip = CommonFunction.convertzip(Zip);
		BillingZip = JUtil.validateString(objFacBean.getStrBillingZip());
		BillingZip = CommonFunction.convertzip(BillingZip);
		
		try
		{
			
			if (JLib.getFacilityByVMID(objFacBean.getStrvmid(), connDest) != 0 )
			{
				insertFlag = false;	
				objFacBean.incrDupCount();
			}
			
			if (insertFlag == true)
			{
				
				strInsertSql = " insert into edi_facilities";
				strInsertSql += " (Name, AddressLine1, AddressLine2, City, State, Zip, Tel, Fax, EMail, BillingAddressLine1,"; 
				strInsertSql += "		BillingAddressLine2, BillingCity, BillingState, BillingZip, BillingTel, BillingFax, BillingEMail, PracticeType,"; 
				strInsertSql += "		PracticeOption, PayableTo, BankAccount, FederalTaxID, Notes, PrimaryFacility, CliaId, code, POS, MammoCertId, ";
				strInsertSql += "		HPSAFlag, HPSAModifier, DeleteFlag, vmid, hl7id, FeeSchedule, FacilityIdType, NPI, TaxonomyCode)";
				strInsertSql += " values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ";
				
				stmtPr = connDest.prepareStatement(strInsertSql);
				stmtPr.setString(++i, JUtil.validateString(objFacBean.getStrName()));
				stmtPr.setString(++i, JUtil.validateString(objFacBean.getStrAddressLine1()));
				stmtPr.setString(++i, JUtil.validateString(objFacBean.getStrAddressLine2()));
				stmtPr.setString(++i, JUtil.validateString(objFacBean.getStrCity()));
				stmtPr.setString(++i, JUtil.validateString(objFacBean.getStrState()));
				stmtPr.setString(++i, Zip);
				stmtPr.setString(++i, telno);
				stmtPr.setString(++i, faxno);
				stmtPr.setString(++i, JUtil.validateString(objFacBean.getStrEMail()));
				stmtPr.setString(++i, JUtil.validateString(objFacBean.getStrBillingAddressLine1()));
				stmtPr.setString(++i, JUtil.validateString(objFacBean.getStrBillingAddressLine2()));
				stmtPr.setString(++i, JUtil.validateString(objFacBean.getStrBillingCity()));
				stmtPr.setString(++i, JUtil.validateString(objFacBean.getStrBillingState()));
				stmtPr.setString(++i, JUtil.validateString(objFacBean.getStrBillingZip()));
				stmtPr.setString(++i, billingtel);
				stmtPr.setString(++i, billingfax);
				stmtPr.setString(++i, JUtil.validateString(objFacBean.getStrBillingEMail()));
				stmtPr.setString(++i, JUtil.validateString(objFacBean.getStrPracticeType()));
				stmtPr.setString(++i, JUtil.validateString(objFacBean.getStrPracticeOption()));
				stmtPr.setString(++i, JUtil.validateString(objFacBean.getStrPayableTo()));
				stmtPr.setString(++i, JUtil.validateString(objFacBean.getStrBankAccount()));
				stmtPr.setString(++i, JUtil.validateString(objFacBean.getStrFederalTaxID()));
				stmtPr.setString(++i, JUtil.validateString(objFacBean.getStrNotes()));
				stmtPr.setInt(++i, (objFacBean.getPrimaryFacility()));
				stmtPr.setString(++i, JUtil.validateString(objFacBean.getStrCliaId()));
				stmtPr.setString(++i, JUtil.validateString(objFacBean.getStrcode()));
				stmtPr.setInt(++i, (objFacBean.getPOS()));
				stmtPr.setString(++i, JUtil.validateString(objFacBean.getStrMammoCertId()));
				stmtPr.setInt(++i, (objFacBean.getHPSAFlag()));
				stmtPr.setString(++i, JUtil.validateString(objFacBean.getStrHPSAModifier()));
				stmtPr.setInt(++i, (objFacBean.getDeleteFlag()));
				stmtPr.setString(++i, JUtil.validateString(objFacBean.getStrvmid()));
				stmtPr.setString(++i, JUtil.validateString(objFacBean.getStrHl7id()));
				stmtPr.setInt(++i, (objFacBean.getFeeSchedule()));
				stmtPr.setInt(++i, (objFacBean.getFacilityIdType()));
				stmtPr.setString(++i, JUtil.validateString(objFacBean.getStrNPI()));
				stmtPr.setString(++i, JUtil.validateString(objFacBean.getStrTaxonomyCode()));
				
				stmtPr.executeUpdate();
				
				objFacBean.incrAddCount();
				
				result = JLib.getFacilityByVMID(objFacBean.getStrvmid(), connDest);
			}
			else  //Duplicate Facilty
			{
				strException = objFacBean.getStrName() + "," + "duplicate Facility";
				JUtil.appendToFile("Facility_Exception.csv", strException);
								
				
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw e;
		}
		finally
		{
			if (stmtPr != null)
			stmtPr.close();
		}
		return result;
		
	}

}
