package com.migration.model;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.migration.lib.CommonFunction;
import com.migration.lib.JLib;
import com.migration.lib.JUtil;

public class VisitStatus {
	public VisitStatus() {
	}
	// Throws exception to outer class as well, so error can be displayed in form
	public int insertData(VisitStatusBean objVStsBean,Connection connSrc, Connection connDest) throws Exception
	{
		
		
		PreparedStatement stmtPr =null;
		Boolean insertFlag = true;
		String strException = "";
		
		String strInsertSql = "";
		int result = 0;
		int i = 0;
		
		try
		{
			if (insertFlag == true)
			{
				
				strInsertSql = " insert into visitstscodes";
				strInsertSql += " (code, status, Color)";
				strInsertSql += " values (?,?,?) ";
				
				stmtPr = connDest.prepareStatement(strInsertSql);
				stmtPr.setString(++i, objVStsBean.getStrVisitCode());
				stmtPr.setString(++i, objVStsBean.getStrVisitstatus());
				stmtPr.setString(++i, "CC00FF");
				
				stmtPr.executeUpdate();
				objVStsBean.incrAddCount();
			}
			else  {
				strException = objVStsBean.getStrVisitCode() + " , " + "duplicate VisitStatus";
				JUtil.appendToFile("VisitStatus_Exception.csv", strException);
				
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw e;
		}
		finally
		{
			if (stmtPr != null)
			stmtPr.close();
		}
		return result;
		
	}
	
}

