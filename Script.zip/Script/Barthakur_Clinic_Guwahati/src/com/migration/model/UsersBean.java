/*
*UsersBean.java
*/
package com.migration.model;

import com.migration.lib.CommonFunction;
import com.migration.lib.JUtil;

/*
 *  @author mihir.patel
 *  @ModifiedBy Jay
 */

public class UsersBean {
	// Variables Declared Here

	private int UID=0;											//Unique Id Returned from Users Table
	private String ulname ="";									//Last Name
	private String ufname="";									//First Name
	private String uname="";									//Username
	//private String uinitial="";								//Never really used
	private String upwd="";										//Password
	private String upaddress="";								//Address Line 1
	private String upaddress2="";								//Address Line 2
	private String upcity="";									//City
	private String upstate="";									//State
	private String zipcode="";									//Zip Code
	private String CountryCode="";								//Country
	private String upphone="";									//Home Phone
	private String umobileno="";								//Mobile No
	private String upagerno="";									//Pager No
	private String uemail="";									//Email
	private String dob="";										//varchar date
	private String ssn="";										//Social Security No.
	private String sex="";										//Gender
	private String Vmid="";										//Our Internal Key
	private String suffix="";									//Suffix
	private String prefix="";									//Prefix
	private String initials="";									//Users Initials
	private String ptDob="";									//Actual Date goes into the Table
	private String uminitial="";								//Middle Initial
	//private String utype="";									//User Type
	private String prevname="";									//Previous Name
	private String mrn="";										//Medical Record No
	private String FacVmid="";									//Facility
	public String upin = "";
	public String NPI = "";
	public String GrpNPI = "";
	public String taxonomycode = "";
	public String taxid = "";
	private int PSL=0;											//Primary Service Location
	private String status = "";                                      
	public int defaultFacility=0;
	public String language = "";
	//Counters
	public long addCount =0;
	public long dupCount=0;
	public long invCount=0;
	
	
	
	/*
	 * function to clear all variable declared
	 */
	
	public void clearallUsers(){
		UID=0;
		ulname ="";
		ufname="";
		uname="";
		//uinitial="";
		upwd="";
		upaddress="";
		upaddress2="";
		upcity="";
		upstate="";
		zipcode="";
		CountryCode="";
		upphone="";
		umobileno="";
		upagerno="";
		uemail="";
		dob="";
		ssn="";
		sex="";
		Vmid="";
		suffix="";
		prefix="";
		initials="";
		ptDob="";
		uminitial="";
		//utype="";
		prevname="";
		mrn="";
		FacVmid="";
		PSL=0;
		language="";
			}

	
	
	/**
	 * @return the uID
	 */
	
	public void setLanguage(String language) {
		this.language = language;
	}
	public String getLanguage() {
		return language;
	}
	
	public void setDefaultFacility(int defaultFacility) {
		this.defaultFacility = defaultFacility;
	}
	public int getDefaultFacility() {
		return defaultFacility;
	}
	
	public int getUID() {
		return UID;
	}

	/**
	 * @param uID the uID to set
	 */
	public void setUID(int uID) {
		UID = uID;
	}

	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the ulname
	 */
	public String getUlname() {
		return ulname;
	}

	/**
	 * @param ulname the ulname to set
	 */
	public void setUlname(String ulname) {
		this.ulname = ulname;
	}

	/**
	 * @return the ufname
	 */
	public String getUfname() {
		return ufname;
	}

	/**
	 * @param ufname the ufname to set
	 */
	public void setUfname(String ufname) {
		this.ufname = ufname;
	}

	/**
	 * @return the uname
	 */
	public String getUname() {
		return uname;
	}

	/**
	 * @param uname the uname to set
	 */
	public void setUname(String uname) {
		this.uname = uname;
	}

	/**
	 * @return the upwd
	 */
	public String getUpwd() {
		return upwd;
	}

	/**
	 * @param upwd the upwd to set
	 */
	public void setUpwd(String upwd) {
		this.upwd = upwd;
	}

	/**
	 * @return the upaddress
	 */
	public String getUpaddress() {
		return upaddress;
	}

	/**
	 * @param upaddress the upaddress to set
	 */
	public void setUpaddress(String upaddress) {
		this.upaddress = upaddress;
	}

	/**
	 * @return the upaddress2
	 */
	public String getUpaddress2() {
		return upaddress2;
	}

	/**
	 * @param upaddress2 the upaddress2 to set
	 */
	public void setUpaddress2(String upaddress2) {
		this.upaddress2 = upaddress2;
	}

	/**
	 * @return the upcity
	 */
	public String getUpcity() {
		return upcity;
	}

	/**
	 * @param upcity the upcity to set
	 */
	public void setUpcity(String upcity) {
		this.upcity = upcity;
	}

	/**
	 * @return the upstate
	 */
	public String getUpstate() {
		return upstate;
	}

	/**
	 * @param upstate the upstate to set
	 */
	public void setUpstate(String upstate) {
		this.upstate = upstate;
	}

	/**
	 * @return the zipcode
	 */
	public String getZipcode() {
		return zipcode;
	}

	/**
	 * @param zipcode the zipcode to set
	 */
	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}

	/**
	 * @return the countryCode
	 */
	public String getCountryCode() {
		return CountryCode;
	}

	/**
	 * @param countryCode the countryCode to set
	 */
	public void setCountryCode(String countryCode) {
		CountryCode = countryCode;
	}

	/**
	 * @return the upphone
	 */
	public String getUpphone() {
		return upphone;
	}

	/**
	 * @param upphone the upphone to set
	 */
	public void setUpphone(String upphone) {
		upphone = CommonFunction.convertPhone(upphone);
		this.upphone = upphone;
	}

	/**
	 * @return the umobileno
	 */
	public String getUmobileno() {
		return umobileno;
	}

	/**
	 * @param umobileno the umobileno to set
	 */
	public void setUmobileno(String umobileno) 
	{
		umobileno = CommonFunction.convertPhone(umobileno);
		this.umobileno = umobileno;
	}

	/**
	 * @return the upagerno
	 */
	public String getUpagerno() {
		return upagerno;
	}

	/**
	 * @param upagerno the upagerno to set
	 */
	public void setUpagerno(String upagerno) {
		upagerno = CommonFunction.convertPhone(upagerno);
		this.upagerno = upagerno;
	}

	/**
	 * @return the uemail
	 */
	public String getUemail() {
		return uemail;
	}

	/**
	 * @param uemail the uemail to set
	 */
	public void setUemail(String uemail) {
		this.uemail = uemail;
	}

	/**
	 * @return the dob
	 */
	public String getDob() {
		return dob;
	}

	/**
	 * @param dob the dob to set
	 * @param strDateInputPattern The pattern in which the given date is formatted 
	 * 		(M=Month, d=Day (Small d), y= Year(small y) ex. "yyyyMMdd", "MMddyyyy" ,"MM/dd/yyyy" )
	 */
	public void setDob(String dob, String strDateInputPattern) throws Exception
	{
		dob = JUtil.formatDate_DOB_MMDDYYYY(dob, strDateInputPattern);
		this.dob = dob;
	}

	/**
	 * @return the ssn
	 */
	public String getSsn() {
		return ssn;
	}

	/**
	 * @param ssn the ssn to set
	 */
	public void setSsn(String ssn) {
		ssn = JUtil.formatSSN(ssn);
		this.ssn = ssn;
	}

	/**
	 * @return the sex
	 */
	public String getSex() {
		return sex;
	}

	/**
	 * @param sex the sex to set
	 */
	public void setSex(String sex) {
		this.sex = sex;
	}

	/**
	 * @return the vmid
	 */
	public String getVmid() {
		return Vmid;
	}

	/**
	 * @param vmid the vmid to set
	 */
	public void setVmid(String vmid) {
		Vmid = vmid;
	}

	/**
	 * @return the suffix
	 */
	public String getSuffix() {
		return suffix;
	}

	/**
	 * @param suffix the suffix to set
	 */
	public void setSuffix(String suffix) {
		this.suffix = suffix;
	}

	/**
	 * @return the prefix
	 */
	public String getPrefix() {
		return prefix;
	}

	/**
	 * @param prefix the prefix to set
	 */
	public void setPrefix(String prefix) {
		this.prefix = prefix;
	}

	/**
	 * @return the initials
	 */
	public String getInitials() {
		return initials;
	}

	/**
	 * @param initials the initials to set
	 */
	public void setInitials(String initials) {
		this.initials = initials;
	}

	/**
	 * @return the ptDob
	 */
	public String getPtDob() {
		return ptDob;
	}

	/**
	 * @param ptDob the ptDob to set
	 * @param strDateInputPattern The pattern in which the given date is formatted 
	 * 		(M=Month, d=Day (small d), y= Year(small y) ex. "yyyyMMdd", "MMddyyyy" ,"MM/dd/yyyy" )
	 */
	
	public void setPtDob(String ptDob,  String strDateInputPattern) throws Exception
	{
		//ptDob = JUtil.formatDate_PTDOB_YYYYMMDD(ptDob, strDateInputPattern);
		this.ptDob = ptDob;
	}

	/**
	 * @return the uminitial
	 */
	public String getUminitial() {
		return uminitial;
	}

	/**
	 * @param uminitial the uminitial to set
	 */
	public void setUminitial(String uminitial) {
		this.uminitial = uminitial;
	}

	/**
	 * @return the prevname
	 */
	public String getPrevname() {
		return prevname;
	}

	/**
	 * @param prevname the prevname to set
	 */
	public void setPrevname(String prevname) {
		this.prevname = prevname;
	}

	/**
	 * @return the mrn
	 */
	public String getMrn() {
		return mrn;
	}

	/**
	 * @param mrn the mrn to set
	 */
	public void setMrn(String mrn) {
		this.mrn = mrn;
	}

	/**
	 * @return the facVmid
	 */
	public String getFacVmid() {
		return FacVmid;
	}

	/**
	 * @param facVmid the facVmid to set
	 */
	public void setFacVmid(String facVmid) {
		FacVmid = facVmid;
	}

	/**
	 * @return the pSL
	 */
	public int getPSL() {
		return PSL;
	}

	/**
	 * @param pSL the pSL to set
	 */
	public void setPSL(int pSL) {
		PSL = pSL;
	}
	
	//Incrementing the counters
	public void incrAddCount(){
		addCount+=1;
	}
	
	public void incrInvCount(){
		invCount+=1;
	}
	
	public void incrDupCount(){
		dupCount+=1;
	}
	
	/**
	 * @return the addCount
	 */
	public long getAddCount() {
		return addCount;
	}

	/**
	 * @param addCount the addCount to set
	 */
	public void setAddCount(long addCount) {
		this.addCount = addCount;
	}

	/**
	 * @return the dupCount
	 */
	public long getDupCount() {
		return dupCount;
	}

	/**
	 * @param dupCount the dupCount to set
	 */
	public void setDupCount(long dupCount) {
		this.dupCount = dupCount;
	}

	/**
	 * @return the invCount
	 */
	public long getInvCount() {
		return invCount;
	}

	/**
	 * @param invCount the invCount to set
	 */
	public void setInvCount(long invCount) {
		this.invCount = invCount;
	}

}

