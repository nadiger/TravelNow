package com.migration.model;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import com.migration.lib.JLib;
import com.migration.lib.JUtil;

import java.util.Date;

/** 
* Created by   : Ravi 
* Date Created : Oct/28/2012
* Purpose      : Class [Appointments.java] for Appointment schedule details of the Patient
* Comments     :
* Date Modified: Nov/1/2012
* Modified by  : Ravi 
*/

public class Appointments {

	
	public String workPhone = "";
	public com.migration.lib.CommonFunction CommonFunction;
	
	public Appointments()	{
		
	}
	
	
	// Throws exception to outer class as well, so error can be displayed in form
	public long insertData(AppointmentsBean objAppointmentsBean, Connection connSrc, Connection connDest) throws Exception	{   
		PreparedStatement stmtPr =null;
		
		Statement st = null;
		
		Boolean insertFlag = true;
		
		String strInsertSql = "";
		int result = 0;
		int i = 0;
		
		long PatientID_Dest = 0;
		long DoctorUID_Dest = 0;
		long ResourceUID_Dest = 0;
		long FacilityID_Dest = 0;
		
		long EncounterID_Dest = 0;
		
		String AptDate_Dest = "";
		String AptStartTime_Dest = "";
		String AptEndTime_Dest = "";
		
		String AptStatus_Dest = "";
		String AptVisitType_Dest = "";
		String AptClaimReq_Dest = "";
		
		String strVMID_Dest = "";
		
		String startTime="";
		String startDate="";
		
		long lngCntDB = 0;
		
		try	{	
			strVMID_Dest = "ENC_" + objAppointmentsBean.getStrPatientID_Source() + "_" + objAppointmentsBean.getStrDoctorID_Source() + "_" + objAppointmentsBean.getStrFacilityID_Source() + "_" + objAppointmentsBean.getLngApt_RecordID_Source();
			
			if (JLib.getEncByVMID(strVMID_Dest, connDest) != 0 )	{
				insertFlag = false;
				objAppointmentsBean.incrDupCount();
								
				strInsertSql = " insert into exp_Apt ";
				strInsertSql += "  ( Facility_VMID, Doctor_VMID, Resource_VMID, Patient_vmid, AptDate, startTime, Exception_Code, Exception_Description) ";
				strInsertSql += " values ( '" + objAppointmentsBean.getStrFacilityID_Source() + "', '" + objAppointmentsBean.getStrDoctorID_Source() + "', '";
				strInsertSql +=  objAppointmentsBean.getStrResourceID_Source() + "', '" + objAppointmentsBean.getStrPatientID_Source() + "', ' ";
				strInsertSql +=  objAppointmentsBean.getStrAptDate_Source() + "', '" + objAppointmentsBean.getStrStartTime_Source() + "','36', 'Duplicate record on VMID') ";				
				
				System.out.println("Writing error record!" + strInsertSql );
				
				st = connDest.createStatement();
				st.executeUpdate(strInsertSql);
			}
		
		
			PatientID_Dest = JLib.getUsersByVMID("Pat-" + objAppointmentsBean.getStrPatientID_Source(), connDest) ;
			if(PatientID_Dest==0)
			{
	/*HERE*/	PatientID_Dest=JLib.getUidByVmidFromMdb(objAppointmentsBean.getStrPatientID_Source(), connSrc);
			}
			
			System.out.println("PAT-"+PatientID_Dest);
			// PatientID_Dest = JLib.getPatientByNameDOB(objAppointmentsBean.getUlname(), objUsrBean.getUfname(), objUsrBean.getDob(), connDest) ;
			
			DoctorUID_Dest = JLib.getUsersByVMID("Dr-" + objAppointmentsBean.getStrDoctorID_Source(), connDest) ;
 			System.out.println("DOC-"+DoctorUID_Dest);
 			if(DoctorUID_Dest==0){
 				DoctorUID_Dest=52919;
 			}
			ResourceUID_Dest = JLib.getUsersByVMID("Res-" + objAppointmentsBean.getStrResourceID_Source(), connDest) ;
			//ResourceUID_Dest = DoctorUID_Dest;		//Resource is same as Doctor
			System.out.println("RESO-"+ResourceUID_Dest);
			FacilityID_Dest = JLib.getFacilityByVMID("Fac-" + objAppointmentsBean.getStrFacilityID_Source(), connDest);
			//FacilityID_Dest=1;
			System.out.println("FAC-"+FacilityID_Dest);
			
			if (DoctorUID_Dest == 0) {				
				DoctorUID_Dest=ResourceUID_Dest;
			}
			
			
			if (ResourceUID_Dest == 0)	{
				ResourceUID_Dest = JLib.getUsersByVMID("Dr-" + objAppointmentsBean.getStrResourceID_Source(), connDest) ;
				if (ResourceUID_Dest == 0)
				    ResourceUID_Dest=DoctorUID_Dest;
			}
			
			
			if (PatientID_Dest == 0 ||  DoctorUID_Dest  == 0 || ResourceUID_Dest == 0)	{
				insertFlag = false;
				objAppointmentsBean.incrInvCount();
			}
			
			/*HERE*/
			startTime=objAppointmentsBean.getStrStartTime_Source();
			//"945"
			//String mins = startTime.substring(startTime.length()-2);
			//String hrs =  startTime.substring(0,startTime.length()-2);
			
			startDate=objAppointmentsBean.getStrAptDate_Source();
			System.out.println("APT DATE AND TIME"+startDate+" + "+startTime);
			//PatientInsuranceException.csv
			
			if( startDate == "" || startTime==""){
				insertFlag=false;
				objAppointmentsBean.incrInvCount();
				
				strInsertSql = 	objAppointmentsBean.getStrFacilityID_Source() + "', '" + objAppointmentsBean.getStrDoctorID_Source() + "', '";
				strInsertSql +=  objAppointmentsBean.getStrResourceID_Source() + "', '" + objAppointmentsBean.getStrPatientID_Source() + "', ' ";
				strInsertSql +=  objAppointmentsBean.getStrAptDate_Source() + "', '" + objAppointmentsBean.getStrStartTime_Source() + "', 'Start Date or time not found') ";				
				
				//System.out.println("Writing error record!" + strInsertSql );
				JUtil.appendToFile("AppointmentsException.csv", strInsertSql);
				
			}
			
			
			if (PatientID_Dest == 0 )	{   
				objAppointmentsBean.incrNoPatCount();
				
			    strInsertSql = " insert into exp_Apt ";
				strInsertSql += "  ( Facility_VMID, Doctor_VMID, Resource_VMID, Patient_vmid, AptDate, startTime, Exception_Code, Exception_Description  ) ";
				strInsertSql += " values ( '" + objAppointmentsBean.getStrFacilityID_Source() + "', '" + objAppointmentsBean.getStrDoctorID_Source() + "', '";
				strInsertSql +=  objAppointmentsBean.getStrResourceID_Source() + "', '" + objAppointmentsBean.getStrPatientID_Source() + "', ' ";
				strInsertSql +=  objAppointmentsBean.getStrAptDate_Source() + "', '" + objAppointmentsBean.getStrStartTime_Source() + "','31', 'Patient not found') ";				
				
				//System.out.println("Writing error record!" + strInsertSql );
				JUtil.appendToFile("AppointmentsException.csv", strInsertSql);
				st = connDest.createStatement();
				st.executeUpdate(strInsertSql);				
			}
			
			
			else if (DoctorUID_Dest == 0 )	{   
				objAppointmentsBean.incrNoDr();
			
				strInsertSql = " insert into exp_Apt ";
				strInsertSql += "  ( Facility_VMID, Doctor_VMID, Resource_VMID, Patient_vmid, AptDate, startTime, Exception_Code, Exception_Description  ) ";
				strInsertSql += " values ( '" + objAppointmentsBean.getStrFacilityID_Source() + "', '" + objAppointmentsBean.getStrDoctorID_Source() + "', '";
				strInsertSql +=  objAppointmentsBean.getStrResourceID_Source() + "', '" + objAppointmentsBean.getStrPatientID_Source() + "', ' ";
				strInsertSql +=  objAppointmentsBean.getStrAptDate_Source() + "', '" + objAppointmentsBean.getStrStartTime_Source() + "','32', 'Doctor not found') ";				
				
				//System.out.println("Writing error record!" + strInsertSql );
				JUtil.appendToFile("AppointmentsException.csv", strInsertSql);
				st = connDest.createStatement();
				st.executeUpdate(strInsertSql);								
			}
			
			
			else if (FacilityID_Dest == 0 )	{ 	
				objAppointmentsBean.incrNoFacCount();
			
			    strInsertSql = " insert into exp_Apt ";
				strInsertSql += "  ( Facility_VMID, Doctor_VMID, Resource_VMID, Patient_vmid, AptDate, startTime, Exception_Code, Exception_Description  ) ";
				strInsertSql += " values ( '" + objAppointmentsBean.getStrFacilityID_Source() + "', '" + objAppointmentsBean.getStrDoctorID_Source() + "', '";
				strInsertSql +=  objAppointmentsBean.getStrResourceID_Source() + "', '" + objAppointmentsBean.getStrPatientID_Source() + "', ' ";
				strInsertSql +=  objAppointmentsBean.getStrAptDate_Source() + "', '" + objAppointmentsBean.getStrStartTime_Source() + "','33', 'Facility not found') ";				
				
				//System.out.println("Writing error record!" + strInsertSql );
				JUtil.appendToFile("AppointmentsException.csv", strInsertSql);
				st = connDest.createStatement();
				st.executeUpdate(strInsertSql);
			}
			
			
			//Find duplicate Appointment.................
			if (JLib.getEncByPatID( PatientID_Dest , DoctorUID_Dest, ResourceUID_Dest, AptDate_Dest, objAppointmentsBean.getStrStartTime_Source(), connDest) != 0 )	{
				insertFlag = false;
				objAppointmentsBean.incrDupCount();
								
				strInsertSql = " insert into exp_Apt ";
				strInsertSql += "  ( Facility_VMID, Doctor_VMID, Resource_VMID, Patient_vmid, AptDate, startTime, Exception_Code, Exception_Description  ) ";
				strInsertSql += " values ( '" + objAppointmentsBean.getStrFacilityID_Source() + "', '" + objAppointmentsBean.getStrDoctorID_Source() + "', '";
				strInsertSql +=  objAppointmentsBean.getStrResourceID_Source() + "', '" + objAppointmentsBean.getStrPatientID_Source() + "', ' ";
				strInsertSql +=  objAppointmentsBean.getStrAptDate_Source() + "', '" + objAppointmentsBean.getStrStartTime_Source() + "','37', 'Duplicate record for the same Patient') ";				
				
				//System.out.println("Writing error record!" + strInsertSql );
				JUtil.appendToFile("AppointmentsException.csv", strInsertSql);
				st = connDest.createStatement();
				st.executeUpdate(strInsertSql);
			}
			
			if (insertFlag == true)	{			    
				AptDate_Dest = objAppointmentsBean.getStrAptDate_Source() ;
				AptDate_Dest=JLib.Left(objAppointmentsBean.getStrAptDate_Source(),10);
				// Find the Appointment is for future or not
				DateFormat formatterInput;
				
				formatterInput = new SimpleDateFormat("MM/dd/yyyy");
				Date Date1 = formatterInput.parse(objAppointmentsBean.getStrAptDate_Source());
				
				/*
				if (Date1.getTime() / (1000 * 60 * 60 * 24)  >= System.currentTimeMillis() / (1000 * 60 * 60 * 24)) 
					AptStatus_Dest = "PEN";
				else*/
					AptStatus_Dest = objAppointmentsBean.getStrStatus_Source();
				
				
				AptVisitType_Dest=objAppointmentsBean.getStrVisitType_Source();
				
				System.out.println("pi " + objAppointmentsBean.getStrPatientID_Source());
				AptStartTime_Dest =JUtil.getTime_from_Duration(objAppointmentsBean.getStrStartTime_Source(),"0", "HH:mm") + ":00" ;				
				AptEndTime_Dest = JUtil.getTime_from_Duration( objAppointmentsBean.getStrEndTime_Source() ,"0",  "HH:mm")+":00" ;
				//String[] splits = end.split(" ");
				//String t = splits[2];
				//String sendt = t.substring(0,t.length()-2);
				
				strInsertSql = " insert into enc ";
				strInsertSql += "  (vmid, facilityid, doctorId, ResourceID, patientId, date, startTime, endTime, encType, visittype, Status, ClaimReq, Reason, Notes, generalNotes, POS)"; 
				strInsertSql += " values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ";
				
				stmtPr = connDest.prepareStatement(strInsertSql);
				
				stmtPr.setString(++i, strVMID_Dest);
				stmtPr.setLong(++i, FacilityID_Dest);
				stmtPr.setLong(++i, DoctorUID_Dest);
				stmtPr.setLong(++i, ResourceUID_Dest);
				stmtPr.setLong(++i, PatientID_Dest);
				
				stmtPr.setString(++i, AptDate_Dest);	
				stmtPr.setString(++i, AptStartTime_Dest);
				stmtPr.setString(++i, AptEndTime_Dest);
				
				stmtPr.setLong(++i, 1);
				stmtPr.setString(++i, AptVisitType_Dest);
				stmtPr.setString(++i, AptStatus_Dest);			
				stmtPr.setString(++i, AptClaimReq_Dest);
				
				stmtPr.setString(++i, JUtil.validateString(objAppointmentsBean.getStrReason_Source()));
				stmtPr.setString(++i, JUtil.validateString(objAppointmentsBean.getStrNotes_Source()));
				stmtPr.setString(++i, JUtil.validateString(objAppointmentsBean.getStrNotes_Source()));
                
				stmtPr.setString(++i, JUtil.validateString(objAppointmentsBean.getStrPOS()));
								  		
				lngCntDB = stmtPr.executeUpdate();
						
				if (lngCntDB > 0) {
					objAppointmentsBean.incrAddCount();
					result = JLib.getEncByVMID(strVMID_Dest, connDest);
				}
				
				
				EncounterID_Dest= JLib.getEncByVMID(strVMID_Dest, connDest);
				
				strInsertSql = "insert into annualnotes(encounterid, type) values('" + EncounterID_Dest + "','Billing') ";
				st = connDest.createStatement();
				st.executeUpdate(strInsertSql);
				
				strInsertSql = "insert into encounterdata (encounterid,chiefComplaint) values('" + EncounterID_Dest + "','')";
				st = connDest.createStatement();
				st.executeUpdate(strInsertSql);
						
				strInsertSql = "insert into encdetail (encounterid) values ('" + EncounterID_Dest + "')";
				st = connDest.createStatement();
				st.executeUpdate(strInsertSql);				
			}
		}
		catch(Exception e)	{
			e.printStackTrace();
			throw e;
		}
		finally	{
			if (stmtPr != null)
			stmtPr.close();			
		}
		return result;
		
			
	}
	
}
