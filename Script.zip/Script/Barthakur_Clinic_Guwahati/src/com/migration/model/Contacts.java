package com.migration.model;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.migration.lib.JLib;
import com.migration.lib.JUtil;

/** 
* Created by   : Ravi 
* Date Created : Aug/18/2011
* Purpose      : Class [Contacts.java] for Emergency Contact details of the Patients
* Comments     :
* Date Modified: 
* Modified by  :  
*/

public class Contacts {
	public String zip = "";
	public String homePhone = "";
	public String workPhone = "";
	public int resultID=0;
	public com.migration.lib.CommonFunction CommonFunction;
	
	public Contacts()
	{
		
	}
	
	// Throws exception to outer class as well, so error can be displayed in form
	public int insertData(ContactsBean objContactsBean,Connection connSrc, Connection connDest) throws Exception
	{
		PreparedStatement stmtPr =null;
		Boolean insertFlag = true;
		
		String strInsertSql = "";
		int result = 0;
		int i = 0;
		long lngCntDB = 0;
		
		try
		{
			
			resultID=JLib.getUsersByVMID("Pat-" + objContactsBean.getStrPatVMID(), connDest);
			
			if (resultID==0){
				insertFlag=false;
			}
			
			if (JLib.getContactsByVMID(objContactsBean.getStrVMID(), connDest) != 0 )
			{
				insertFlag = false;	
				objContactsBean.incrDupCount();
			}
			
			if (objContactsBean.getStrName() == "" && objContactsBean.getStrHomePhone() == "") 
			{
				insertFlag = false;
				objContactsBean.incrInvCount();
			}
			
			 zip = CommonFunction.convertzip(zip);
			 homePhone = CommonFunction.convertPhone(homePhone);
			 workPhone = CommonFunction.convertPhone(workPhone);
			
			if (insertFlag == true)
			{
				
				strInsertSql = " insert into Contacts";
				strInsertSql += " ( PID, Name, Relation, address, address2, city,"; 
				strInsertSql += "	State, Zipcode, Homephone, Workphone, vmid )";
				strInsertSql += " values (?,?,?,?,?,?,?,?,?,?,?) ";
				
				stmtPr = connDest.prepareStatement(strInsertSql);
				
				stmtPr.setLong(++i, resultID);
				stmtPr.setString(++i, JUtil.validateString(objContactsBean.getStrName()));
				stmtPr.setString(++i, JUtil.validateString(objContactsBean.getStrRelation()));
				stmtPr.setString(++i, JUtil.validateString(objContactsBean.getStrAddress()));			
				stmtPr.setString(++i, JUtil.validateString(objContactsBean.getStrAddress2()));			
				
				stmtPr.setString(++i, JUtil.validateString(objContactsBean.getStrCity()));
				stmtPr.setString(++i, JUtil.validateString(objContactsBean.getStrState()));
				stmtPr.setString(++i, JUtil.validateString(objContactsBean.getStrZipcode()));
				stmtPr.setString(++i, JUtil.validateString(objContactsBean.getStrHomePhone()));
				stmtPr.setString(++i, JUtil.validateString(objContactsBean.getStrWorkPhone()));
				stmtPr.setString(++i, JUtil.validateString(objContactsBean.getStrVMID()));
								  		
				lngCntDB = stmtPr.executeUpdate();
						
				if (lngCntDB > 0) {
					objContactsBean.incrAddCount();						
					result = JLib.getContactsByVMID(objContactsBean.getStrVMID(), connDest);
				}																			
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw e;
		}
		finally
		{
			if (stmtPr != null)
			stmtPr.close();
		}
		return result;
		
	}

	
}
