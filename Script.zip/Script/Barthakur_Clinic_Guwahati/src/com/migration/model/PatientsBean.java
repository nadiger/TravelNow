package com.migration.model;

public class PatientsBean extends UsersBean {
	
	private int pid = 0;
	private String employername = "";
	private String employeraddress = "";
	private String employeraddress2 = "";
	private String employercity = "";
	private String employerstate = "";
	private String employerzip = "";
	private String employerphone = "";
	private int doctorID = 0;
	private String maritalstatus = "";
	private String studentstatus = "";
	private String empstatus = "";
	private String notes = "";
	private int controlno = 0;
	private String hl7ID = "";
	private String selfpay = "";
	private String defFeeschid = "";
	private String race = "";
	private String ethnicity = "";
	private int grid = 0;
	private String grrel = "";
	private String isgrpt = "";
	private String deceased = "";
	private String DeceasedNotes = "";
	private String refPrID = "";
	private String BillingAlertNotes = "";
	private String empid = "";
	public String patLanguage = "";
	public String deceasedDate="";
	private String relinfo = "";
	private String relinfodate = "";
	private String rendprid = "";
	private String controlNo="";
	private int billingAlert=0;
	
	
	
	
	 

	public int getBillingAlert() {
		return billingAlert;
	}

	public void setBillingAlert(int billingAlert) {
		this.billingAlert = billingAlert;
	}

	private int empId=0;
	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}
	
	
	
	public String getControlNo() {
		return controlNo;
	}

	public void setControlNo(String controlNo) {
		this.controlNo = controlNo;
	}

	public void clearall(){
		pid = 0;
		employername = "";
		employeraddress = "";
		employeraddress2 = "";
		employercity = "";
		employerstate = "";
		employerzip = "";
		employerphone = "";
		doctorID = 0;
		maritalstatus = "";
		studentstatus = "";
		empstatus = "";
		notes = "";
		controlno = 0;
		hl7ID = "";
		selfpay = "";
		defFeeschid = "";
		race = "";
		ethnicity = "";
		grid = 0;
		grrel = "";
		isgrpt = "";
		deceased = "";
		DeceasedNotes = "";
		refPrID = "";
		BillingAlertNotes = "";
		empid = "";
		relinfo = "";
		relinfodate = "";
		rendprid = "";
		patLanguage="";
		billingAlert=0;
		
	}

	public void setDeceasedDate(String deceasedDate) {
		this.deceasedDate = deceasedDate;
	}
	
	public String getDeceasedDate() {
		return deceasedDate;
	}
	
	public void setPatLanguage(String language) {
		this.language = language;
	}
	public String getPatLanguage() {
		return language;
	}
	public int getPid() {
		return pid;
	}

	public void setPid(int pid) {
		this.pid = pid;
	}

	public String getEmployername() {
		return employername;
	}

	public void setEmployername(String employername) {
		this.employername = employername;
	}

	public String getEmployeraddress() {
		return employeraddress;
	}

	public void setEmployeraddress(String employeraddress) {
		this.employeraddress = employeraddress;
	}

	public String getEmployeraddress2() {
		return employeraddress2;
	}

	public void setEmployeraddress2(String employeraddress2) {
		this.employeraddress2 = employeraddress2;
	}

	public String getEmployercity() {
		return employercity;
	}

	public void setEmployercity(String employercity) {
		this.employercity = employercity;
	}

	public String getEmployerstate() {
		return employerstate;
	}

	public void setEmployerstate(String employerstate) {
		this.employerstate = employerstate;
	}

	public String getEmployerzip() {
		return employerzip;
	}

	public void setEmployerzip(String employerzip) {
		this.employerzip = employerzip;
	}

	public String getEmployerphone() {
		return employerphone;
	}

	public void setEmployerphone(String employerphone) {
		this.employerphone = employerphone;
	}

	public int getDoctorID() {
		return doctorID;
	}

	public void setDoctorID(int doctorID) {
		this.doctorID = doctorID;
	}

	public String getMaritalstatus() {
		return maritalstatus;
	}

	public void setMaritalstatus(String maritalstatus) {
		this.maritalstatus = maritalstatus;
	}

	public String getStudentstatus() {
		return studentstatus;
	}

	public void setStudentstatus(String studentstatus) {
		this.studentstatus = studentstatus;
	}

	public String getEmpstatus() {
		return empstatus;
	}

	public void setEmpstatus(String empstatus) {
		this.empstatus = empstatus;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public int getControlno() {
		return controlno;
	}

	public void setControlno(int contNo) {
		this.controlno = contNo;
	}

	public String getHl7ID() {
		return hl7ID;
	}

	public void setHl7ID(String hl7id) {
		hl7ID = hl7id;
	}

	public String getSelfpay() {
		return selfpay;
	}

	public void setSelfpay(String selfpay) {
		this.selfpay = selfpay;
	}

	public String getDefFeeschid() {
		return defFeeschid;
	}

	public void setDefFeeschid(String defFeeschid) {
		this.defFeeschid = defFeeschid;
	}

	public String getRace() {
		return race;
	}

	public void setRace(String race) {
		this.race = race;
	}

	public String getEthnicity() {
		return ethnicity;
	}

	public void setEthnicity(String ethnicity) {
		this.ethnicity = ethnicity;
	}

	public int getGrid() {
		return grid;
	}

	public void setGrid(int i) {
		this.grid = i;
	}

	public String getGrrel() {
		return grrel;
	}

	public void setGrrel(String grrel) {
		this.grrel = grrel;
	}

	public String getIsgrpt() {
		return isgrpt;
	}

	public void setIsgrpt(String isgrpt) {
		this.isgrpt = isgrpt;
	}

	public String getDeceased() {
		return deceased;
	}

	public void setDeceased(String deceased) {
		this.deceased = deceased;
	}

	public String getDeceasedNotes() {
		return DeceasedNotes;
	}

	public void setDeceasedNotes(String deceasedNotes) {
		DeceasedNotes = deceasedNotes;
	}

	public String getRefPrID() {
		return refPrID;
	}

	public void setRefPrID(String string) {
		this.refPrID = string;
	}

	public String getBillingAlertNotes() {
		return BillingAlertNotes;
	}

	public void setBillingAlertNotes(String billingAlertNotes) {
		BillingAlertNotes = billingAlertNotes;
	}

	public String getEmpid() {
		return empid;
	}

	public void setEmpid(String string) {
		this.empid = string;
	}

	public String getRelinfo() {
		return relinfo;
	}

	public void setRelinfo(String relinfo) {
		this.relinfo = relinfo;
	}

	public String getRelinfodate() {
		return relinfodate;
	}

	public void setRelinfodate(String relinfodate) {
		this.relinfodate = relinfodate;
	}

	public String getRendprid() {
		return rendprid;
	}

	public void setRendprid(String rendprid) {
		this.rendprid = rendprid;
	}

//	public long getAddCount() {
//		return addCount;
//	}
//
//	public void setAddCount(long addCount) {
//		this.addCount = addCount;
//	}
//
//	public long getDupCount() {
//		return dupCount;
//	}
//
//	public void setDupCount(long dupCount) {
//		this.dupCount = dupCount;
//	}
//
//	public long getInvCount() {
//		return invCount;
//	}
//
//	public void setInvCount(long invCount) {
//		this.invCount = invCount;
//	}

	
	
}
