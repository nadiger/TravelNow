package com.migration.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Date;

import com.migration.lib.JLib;
import com.migration.lib.JUtil;



public class InsuranceDetail {
	public int PatientID= 0;
	public int InsID= 0;
	public int GrID= 0;
	public int IsGrPt= 0;
	public String EndDate;
	public String StartDate;
	public String GrRel;
	ResultSet rsInsCk = null;
	

	
	public InsuranceDetail() {
		
	}
	
	// Throws exception to outer class as well, so error can be displayed in form
	public int insertData(InsDetBean objInsDetBean,Connection connSrc, Connection connDest) throws Exception {
		
		PreparedStatement stmtPr = null;
		Statement stmt=null;
		Boolean insertFlag = true;
		Statement stmtCk = null;
		stmtCk = connDest.createStatement();
		String strInsertSql = "";
		int result = 0;
		int i = 0;
		long lngCntDB = 0;
		
		
		
		String sqlQuery2="";
		Statement stmt2=null;
		ResultSet rs3=null;
		stmt2=connSrc.createStatement();
		
		try {
			String strException = "";
			PatientID= 0;
			InsID= 0;
			GrID= 0;
			IsGrPt= 0;	
			EndDate = "";
			StartDate = "";
			GrRel="";
			String strSQL = "";
				
					PatientID = JLib.getUsersByVMID( objInsDetBean.getStrPatvmid(),connDest);
		    	    if (PatientID == 0 && objInsDetBean.getStrPatvmid() != "")
		    	    { 
		    	    	PatientID = JLib.getUidByVmidFromMdb(objInsDetBean.getStrPatvmid(),connSrc);
		    	  		System.out.println("INS MDB PATIENT ID = "+PatientID);
		    	    }
		    	        
		    	    if (PatientID == 0)
		    	    {
		    	    insertFlag = false;
		    	    }
		    	    
		    	    if (PatientID == 0){
			    	    insertFlag = false;
			    	    
						String strRemark = "Patient Not Found";					
						strSQL = "insert into Exp_PatIns ( PatAccount, InsCode, InsPriority, Exception_Code, " +
						"Exception_Description) values ('" + objInsDetBean.getStrPatvmid() + "', '" + 
						objInsDetBean.getStrvmid() + "', '" + objInsDetBean.getStrPriority() + "','21','" + 
						strRemark + "')";
						stmtPr = connDest.prepareStatement(strSQL);
						stmtPr.executeUpdate();
						objInsDetBean.incrInvCount();
			    	   
			    	    }
			    	    
			    	    if (InsID == 0 && objInsDetBean.getStrvmid() != ""){
			    	    InsID = JLib.getInsByVMID("Ins-" + objInsDetBean.getStrvmid(),connDest);
			    	    if(InsID==0){
			    	    	String insVmid= "Ins-"+objInsDetBean.getStrvmid();
			    	    	sqlQuery2="select MapToVMID from Insuranceinfo where VMID='"+insVmid+"'";
			    	    	rs3=stmt2.executeQuery(sqlQuery2);
			    	    	if(rs3!=null){
			    	    		while(rs3.next()){
			    	    			String insVmidMdb=rs3.getString("MapToVMID");
			    	    			InsID = JLib.getInsByVMID(insVmidMdb,connDest);
			    	    		}
			    	    	}
			    	    	
			    	    }
			    	    }
			    	    
			    	    if (InsID==0){
			    	    String strRemark = "Insurance Company Not Found";
						strSQL = "insert into Exp_PatIns ( PatAccount, InsCode, InsPriority, Exception_Code, " +
						"Exception_Description) values ('" + objInsDetBean.getStrPatvmid() + "', '" + 
						objInsDetBean.getStrvmid() + "', '" + objInsDetBean.getStrPriority() + "','22','" + 
						strRemark + "')";
						stmtPr = connDest.prepareStatement(strSQL);
						stmtPr.executeUpdate();
						objInsDetBean.incrInvCount(); 	
						insertFlag=false;
			    	    }
		    	    		    	
			    	    
			    	    
			    	    
			    	    
			    	    String rel=objInsDetBean.getStrGrRel();
			    	    GrRel = JUtil.convertRel(rel);
			    	    
			    	    
			    	    String lName="";
			    	    String fName="";
			    	    String mName="";
			    	    String fMName="";
			    	    String guarName=objInsDetBean.getGuarName();
			    	    if( guarName==null  || guarName.equals("") ){
			    	    	
			    	    }else{
			    	    String[] gNameSplited=guarName.split(",");
			    	    
			    	    if(gNameSplited.length==1){
			    	    	 lName=gNameSplited[0];
			    	    }else if(gNameSplited.length==2){
			    	    	 lName=gNameSplited[0];
			    	    	 fMName=gNameSplited[1];
			    	    }
			    	   
			    	     
			    	    
			    	    fMName=fMName.trim();
			    	    
			    	    if(fMName.contains(" ")){
			    	    	String[] fMNameSplited=fMName.split(" ");
			    	    	fMName=fMNameSplited[0];
			    	    	 	if(fName.contains(" ")){
			    	    	 		fName=fName.replaceAll(" ", "");
			    	    	 	}
			    	    	 	mName=fMNameSplited[1];
			    	    }
			    	    
			    	    System.out.println(lName+" "+fMName+" "+mName);
			    	    
			    	    }
			    	    
		     
			    	    
			    	    
			    	    
			    	    
			    	    if(rel=="self" || rel.equalsIgnoreCase("self") || rel.contains("self")){
			    	    	GrID = PatientID;
		    	            //objInsDetBean.setStrGrRel("1");
		    	            GrRel="1";
		    	            IsGrPt = 1;
			    	    } else if(rel=="child" || rel.equalsIgnoreCase("child") || rel.contains("child") || rel=="spouse" || rel.equalsIgnoreCase("spouse") || rel.contains("spouse") || rel.equals("")){
			    	    	GrID=JLib.getUidGuarByFnameLName(fMName,lName,connDest);
			    	    	if(GrID==0){
			    	    	GrID=JLib.getUidGUarPatByFnameLName(fMName,lName,connDest);
			    	    	}
			    	    	if(GrID==0){
			    	    		GrID=PatientID;
			    	    		GrRel="1";
			    	    		IsGrPt=1;
			    	    	}
			    	    	else{
			    	    		
			    	    	
			    	    	System.out.println(GrRel);
				    	    if (JUtil.getUserType(GrID, connDest) == 3){
				    	    IsGrPt = 0; 
				    	    }
				    	    else
				    	    {
				    	    IsGrPt = 1;	
				    	    }
				    	    
				    	    
			    	    }
			    	    }
			    	    
			    	  
			    	    
			    	    
			    	    
			    	    /*
			    	    if (objInsDetBean.getStrGuarVmid() != "" && GrID == 0){
			    	    	GrID = JLib.getUsersByVMID("Pat-" + objInsDetBean.getStrGuarVmid(),connDest);
			    	    }
			    	    
			    	    if (objInsDetBean.getStrGuarVmid() != "" && GrID == 0){
			    	    	GrID = JLib.getUsersByVMID("Gr-" + objInsDetBean.getStrGuarVmid(),connDest);
			    	    }
			    	        
			    	    if (GrID == 0 || GrID == PatientID){
			    	            GrID = PatientID;
			    	            //objInsDetBean.setStrGrRel("1");
			    	            GrRel="1";
			    	            IsGrPt = 1;
			    	    }
			    	    else
			    	    {
			    	    GrRel = objInsDetBean.getStrGrRel();
			    	    GrRel = JUtil.convertRel(GrRel);
			    	    System.out.println(GrRel);
			    	    if (JUtil.getUserType(GrID, connDest) == 3){
			    	    IsGrPt = 0; 
			    	    }
			    	    else
			    	    {
			    	    IsGrPt = 1;	
			    	    }
			    	    }
		   
			    	    */
			    	    
		   StartDate = JUtil.formatDate_DOB_MMDDYYYY(StartDate, "MM/dd/YYYY");	    
		   EndDate = JUtil.formatDate_DOB_MMDDYYYY(EndDate, "MM/dd/YYYY");
		   																																		/*HERE*/
			strSQL = "SELECT * FROM insurancedetail where pid = '" + PatientID + "' and insorder = '" + objInsDetBean.getStrPriority() + "' And Insid='"+InsID+"'";
			rsInsCk = stmtCk.executeQuery(strSQL);
			if (InsID!=0){
    	    	System.out.println(InsID);
    	    }
			if (rsInsCk.next()){
			   insertFlag=false;
			   objInsDetBean.incrDupCount();
				strException = InsID + "," + objInsDetBean.getStrSubscriberNo() + "," + objInsDetBean.getStrPriority() + "," + "duplicate Records";
				JUtil.appendToFile("DuplicatePatientInsurance.csv", strException);

		   }
			rsInsCk.close();
			stmtCk.close();
			//Invalid
			if(InsID==0)
			{
				
				insertFlag=false;
				System.out.println(objInsDetBean.getStrvmid());
				  // objInsDetBean.incrInvCount();
					strException = PatientID+ ","+InsID + "," + objInsDetBean.getStrSubscriberNo() + "," + objInsDetBean.getStrPriority() + "," + "Invalid Records";
					JUtil.appendToFile("PatientInsuranceException.csv", strException);
					/*HERE*/
					strException = "Insurance Details: Ins_Name: "+objInsDetBean.getStrName()+ ", SubscriberNo: " + objInsDetBean.getStrSubscriberNo() + ", Priority: " + objInsDetBean.getStrPriority() + ", GroupNo:" + objInsDetBean.getStrGroupNo();
					stmt = connDest.createStatement();
					
					//String updateQuery = "UPDATE patients SET notes = concat(notes, '"+strException+"') where pid="+PatientID ;
					String updateQuery = "UPDATE patients SET notes = CAST(notes as varchar(8000)) + cast('" +strException+"' as varchar(5000)) where pid="+PatientID ;
					//System.out.println(updateQuery);
					stmt.executeUpdate(updateQuery);
					//System.out.println("stmt executed");
			}
			if (insertFlag == true) {
				
				strInsertSql = "INSERT INTO InsuranceDetail";
				strInsertSql += " (InsId,SubscriberNo,GroupName,GroupNo,seqNo,AssignBenefits, EligibilityMessage,ptSigSource,paymentsource,GrId,GrRel,IsGrPt,StartDate,EndDate,Copays,PId, insorder)";
				strInsertSql += " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
								
				stmtPr = connDest.prepareStatement(strInsertSql);
				
				stmtPr.setLong(++i, InsID);
				stmtPr.setString(++i, objInsDetBean.getStrSubscriberNo());
				stmtPr.setString(++i, objInsDetBean.getStrGroupName());
				stmtPr.setString(++i, objInsDetBean.getStrGroupNo());
/*HERE*/		stmtPr.setString(++i, objInsDetBean.getStrSeqNo());//seqNo
				stmtPr.setString(++i, "Y");			
				stmtPr.setString(++i, "S");
				stmtPr.setString(++i, "B");	
				stmtPr.setString(++i, "S");	
				stmtPr.setString(++i, ""+GrID);	
				stmtPr.setString(++i, GrRel);
				stmtPr.setString(++i, ""+IsGrPt);
				stmtPr.setString(++i, objInsDetBean.getStrStartDate());
				stmtPr.setString(++i, objInsDetBean.getStrEndDate());
				stmtPr.setString(++i, objInsDetBean.getStrCopay());
				stmtPr.setLong(++i, PatientID);
				stmtPr.setString(++i, objInsDetBean.getStrPriority());
				
				lngCntDB=stmtPr.executeUpdate();
				 		
				if (lngCntDB > 0) {
					objInsDetBean.incrAddCount();						
					result = JLib.getInsByVMID("Ins-"+objInsDetBean.getStrvmid(), connDest);
				}																			
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			if (stmtPr != null)
			stmtPr.close();
		}
		return result;
	}
	
}
