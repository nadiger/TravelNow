package com.migration.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;


public class StructInfo {
	
	public StructInfo()
	{
		
	}
	
	public int insertData(StructInfoBean objStructBean,Connection connSrc, Connection connDest) throws Exception
	{
		PreparedStatement stmtPr =null;
		Boolean insertFlag = true;
		
		String strInsertSql = "";
		int result = 0;
		int i = 0;
		
		try
		{
			
			if (checkDuplicate(objStructBean.getStrDetailid(),objStructBean.getStrPatientid(), connDest) != 0 )
			{
				insertFlag = false;	
				objStructBean.incrDupCount();
			}
			
			if (insertFlag == true)
			{
				
				strInsertSql = " insert into structdemographics";
				strInsertSql += " (patientid,catid,itemid,detailid,value,notes,valueid)";				
				strInsertSql += " values (?,?,?,?,?,?,?) ";
				
				stmtPr = connDest.prepareStatement(strInsertSql);
				stmtPr.setInt(++i, objStructBean.getStrPatientid());
				stmtPr.setInt(++i, 0);
				stmtPr.setInt(++i, 0);
				stmtPr.setInt(++i, objStructBean.getStrDetailid());
				stmtPr.setString(++i, objStructBean.getStrValue());
				stmtPr.setString(++i, objStructBean.getStrNotes());
				stmtPr.setString(++i, "");
				
				stmtPr.executeUpdate();
				
				objStructBean.incrAddCount();				
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw e;
		}
		finally
		{
			if (stmtPr != null)
			stmtPr.close();
		}
		return result;
		
	} 
	
	public static int checkDuplicate(Integer strDetailid,Integer strPatientid, Connection con) throws Exception
	{
		String strSQL = "";
		ResultSet rsUsers = null;
		Statement stmt = con.createStatement();
		int id = 0 ;
		
		
		strSQL = "Select id from structdemographics where patientid= '" + strPatientid + "' and detailid = '" + strDetailid + "'";
		rsUsers = stmt.executeQuery(strSQL);
		if(rsUsers.next())
		{
			id = rsUsers.getInt("ID");
		}
		
		stmt.close();
		return id;
	}
}