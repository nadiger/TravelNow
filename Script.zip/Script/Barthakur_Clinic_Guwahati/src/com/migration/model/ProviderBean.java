package com.migration.model;

public class ProviderBean extends UsersBean {
	
	public String upin = "";
	public String NPI = "";
	public String GrpNPI = "";
	public String taxonomycode = "";
	public String taxid = "";
	public String specialty = "";
	public String deano="";
	public String faxno="";
	public String printName="";
	public String taxidtype="";
	public String orgtype="";
	public String spLicNo="";
	public String medicareNo="";
	public String medicaidNo="";
	public String champusNo="";
	public String blueshieldNo="";
	public String licenceKey="";
	public String stLicNo="";
	
	public ProviderBean() {
	}
	
	public void clearall(){
		upin = "";
		NPI = "";
		GrpNPI = "";
		taxonomycode = "";
		taxid = "";
		specialty = "";
	    deano="";
		faxno="";
		printName="";
		taxidtype="";
		orgtype="";
		spLicNo="";
		medicareNo="";
		medicaidNo="";
		champusNo="";
		blueshieldNo="";
		licenceKey="";
		stLicNo="";
	}



	public String getSpecialty() {
		return specialty;
	}

	public void setSpecialty(String specialty) {
		this.specialty = specialty;
	}

	public String getDeano() {
		return deano;
	}

	public void setDeano(String deano) {
		this.deano = deano;
	}

	public String getFaxno() {
		return faxno;
	}

	public void setFaxno(String faxno) {
		this.faxno = faxno;
	}
	
	public String getChampusNo() {
		return champusNo;
	}

	public void setChampusNo(String champusNo) {
		this.champusNo = champusNo;
	}

	public String getBlueshieldNo() {
		return blueshieldNo;
	}

	public void setBlueshieldNo(String blueshieldNo) {
		this.blueshieldNo = blueshieldNo;
	}

	public String getLicenceKey() {
		return licenceKey;
	}

	public void setLicenceKey(String licenceKey) {
		this.licenceKey = licenceKey;
	}

	public String getStLicNo() {
		return stLicNo;
	}

	public void setStLicNo(String stLicNo) {
		this.stLicNo = stLicNo;
	}

	public String getPrintName() {
		return printName;
	}

	public void setPrintName(String printName) {
		this.printName = printName;
	}

	public String getTaxidtype() {
		return taxidtype;
	}

	public void setTaxidtype(String taxidtype) {
		this.taxidtype = taxidtype;
	}

	public String getOrgtype() {
		return orgtype;
	}

	public void setOrgtype(String orgtype) {
		this.orgtype = orgtype;
	}

	public String getSpLicNo() {
		return spLicNo;
	}

	public void setSpLicNo(String spLicNo) {
		this.spLicNo = spLicNo;
	}

	public String getMedicareNo() {
		return medicareNo;
	}

	public void setMedicareNo(String medicareNo) {
		this.medicareNo = medicareNo;
	}

	public String getMedicaidNo() {
		return medicaidNo;
	}

	public void setMedicaidNo(String medicaidNo) {
		this.medicaidNo = medicaidNo;
	}

	public String getUpin() {
		return upin;
	}

	public void setUpin(String upin) {
		this.upin = upin;
	}

	public String getNPI() {
		return NPI;
	}

	public void setNPI(String nPI) {
		NPI = nPI;
	}

	public String getGrpNPI() {
		return GrpNPI;
	}

	public void setGrpNPI(String grpNPI) {
		GrpNPI = grpNPI;
	}

	public String getTaxonomycode() {
		return taxonomycode;
	}

	public void setTaxonomycode(String taxonomycode) {
		this.taxonomycode = taxonomycode;
	}

	public String getTaxid() {
		return taxid;
	}

	public void setTaxid(String taxid) {
		this.taxid = taxid;
	}

	
	
}
