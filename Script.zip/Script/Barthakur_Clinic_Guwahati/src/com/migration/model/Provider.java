/**
 * 
 */
package com.migration.model;

import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.swing.DropMode;
import javax.swing.JTable.DropLocation;

import sun.misc.JavaUtilJarAccess;


import com.migration.lib.CommonFunction;
import com.migration.lib.JLib;
import com.migration.lib.JUtil;
import com.sun.org.apache.xml.internal.security.utils.JavaUtils;

/**
 * @author jay.shah
 *
 */
public class Provider {
	public String telno = "";
	public String faxno = "";
	public String billingtel = "";
	public String billingfax = "";
	public String Zip="";
	public String BillingZip = "";
	public String POS = "";

	public Provider()
	{
	}
	
	
	
	// Throws exception to outer class as well, so error can be displayed in form
	public int insertData(ProviderBean objPrvBean,Connection connSrc, Connection connDest, int ResultUID) throws Exception {
		PreparedStatement stmtPr =null;
		Boolean insertFlag = true;
		String strException = "";
		
		String strSQL = "";
		int i = 0;
		
		try {
			
			if(ResultUID!=0)
			{
			if (insertFlag) 
			{
				
				strSQL = "INSERT INTO doctors (doctorid, deano, NPI, GrpNPI, faxno, printname, speciality, taxonomycode,taxid,";
				strSQL+= "TaxIDType, OrgType, SpLicNo, UPIN, MedicareNo, MedicaidNo, ChampusNo,";
				strSQL+= "BlueShieldNo, LicenseKey, StLicNo) Values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)" ;
	            
	            stmtPr = connDest.prepareStatement(strSQL);
				stmtPr.setInt(++i, ResultUID);
				stmtPr.setString(++i, JUtil.validateString(objPrvBean.getDeano()));
				stmtPr.setString(++i, JUtil.validateString(objPrvBean.getNPI()));
				stmtPr.setString(++i, JUtil.validateString(objPrvBean.getGrpNPI()));
				stmtPr.setString(++i, JUtil.validateString(objPrvBean.getFaxno()));
				stmtPr.setString(++i, JUtil.validateString(objPrvBean.getPrintName()));
				stmtPr.setString(++i, JUtil.validateString(objPrvBean.getSpecialty()));
				stmtPr.setString(++i, JUtil.validateString(objPrvBean.getTaxonomycode()));
				stmtPr.setString(++i, JUtil.validateString(objPrvBean.getTaxid()));
				stmtPr.setString(++i, JUtil.validateString(objPrvBean.getTaxidtype()));
				stmtPr.setString(++i, JUtil.validateString(objPrvBean.getOrgtype()));
				stmtPr.setString(++i, JUtil.validateString(objPrvBean.getSpLicNo()));
				stmtPr.setString(++i, JUtil.validateString(objPrvBean.getUpin()));
				stmtPr.setString(++i, JUtil.validateString(objPrvBean.getMedicareNo()));
				stmtPr.setString(++i, JUtil.validateString(objPrvBean.getMedicaidNo()));
				stmtPr.setString(++i, JUtil.validateString(objPrvBean.getChampusNo()));	
				stmtPr.setString(++i, JUtil.validateString(objPrvBean.getBlueshieldNo()));
				stmtPr.setString(++i, JUtil.validateString(objPrvBean.getLicenceKey()));
				stmtPr.setString(++i, JUtil.validateString(objPrvBean.getStLicNo()));	
				stmtPr.executeUpdate();
						}
			
		}
			}
		catch (Exception e) 
		{
			e.printStackTrace();
			throw e;
		}finally
		{
			if (stmtPr != null)
				stmtPr.close();
		}	
		
		return ResultUID;
	}
}