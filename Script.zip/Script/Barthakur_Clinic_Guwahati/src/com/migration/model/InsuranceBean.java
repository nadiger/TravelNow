package com.migration.model;

public class InsuranceBean {
	
	public String strInsVMID = "";
	public String strName = "";
	public String strAddress1 = "";
	public String strAddress2 = "";
	public String strCity ="";
	public String strState = "";
	public String strZip = "";
	public String strPhone = "";
	public String strPhone2 ="";
	public String strFax = "";
	public String strEmail = "";
	public String strPayorID = "";
	public String strMediGapID = "";
	public String strhl7id = "";
	public String strNotes ="";
	public String strClaimSubmitType = "";
	public String strPaymentSrc = "";

	private int addCount =0;
	private int dupCount =0;
	private int invCount =0;
	
	
	public void clearAll() {
		strInsVMID = "";
		strName = "";
		strAddress1 = "";
		strAddress2 = "";
		strCity ="";
		strState = "";
		strZip = "";
		strPhone = "";
		strPhone2 ="";
		strFax = "";
		strPayorID = "";
		strMediGapID = "";
		strhl7id = "";
		strNotes = "";
		strEmail = "";
		strClaimSubmitType = "";
		strPaymentSrc = "";
	}
    

	public String getStrInsVMID() {
		return strInsVMID;
	}


	public void setStrInsVMID(String strInsVMID) {
		this.strInsVMID = strInsVMID;
	}

	

	public String getStrClaimSubmitType() {
		return strClaimSubmitType;
	}


	public void setStrClaimSubmitType(String strClaimSubmitType) 
	{
		this.strClaimSubmitType = strClaimSubmitType;
	}


	public String getStrMediGapID() {
		return strMediGapID;
	}


	public void setStrMediGapID(String strMediGapID) {
		this.strMediGapID = strMediGapID;
	}


	public String getStrhl7id() {
		return strhl7id;
	}


	public void setStrhl7id(String strhl7id) {
		this.strhl7id = strhl7id;
	}


	public String getStrNotes() {
		return strNotes;
	}


	public void setStrNotes(String strNotes) {
		this.strNotes = strNotes;
	}

	public String getStrEmail() {
		return strEmail;
	}


	public void setStrEmail(String strEmail) {
		this.strEmail = strEmail;
	}


	public String getStrPaymentSrc() {
		return strPaymentSrc;
	}


	public void setStrPaymentSrc(String strPaymentSrc) {
		this.strPaymentSrc = strPaymentSrc;
	}


	public String getStrName() {
		return strName;
	}




	public void setStrName(String strName) {
		this.strName = strName;
	}




	public String getStrAddress1() {
		return strAddress1;
	}




	public void setStrAddress1(String strAddress1) {
		this.strAddress1 = strAddress1;
	}




	public String getStrAddress2() {
		return strAddress2;
	}




	public void setStrAddress2(String strAddress2) {
		this.strAddress2 = strAddress2;
	}




	public String getStrCity() {
		return strCity;
	}




	public void setStrCity(String strCity) {
		this.strCity = strCity;
	}




	public String getStrState() {
		return strState;
	}




	public void setStrState(String strState) {
		this.strState = strState;
	}




	public String getStrZip() {
		return strZip;
	}




	public void setStrZip(String strZip) {
		this.strZip = strZip;
	}




	public String getStrPhone() {
		return strPhone;
	}




	public void setStrPhone(String strPhone) {
		this.strPhone = strPhone;
	}




	public String getStrPhone2() {
		return strPhone2;
	}




	public void setStrPhone2(String strPhone2) {
		this.strPhone2 = strPhone2;
	}




	public String getStrFax() {
		return strFax;
	}




	public void setStrFax(String strFax) {
		this.strFax = strFax;
	}




	public String getStrPayorID() {
		return strPayorID;
	}




	public void setStrPayorID(String strPayorID) {
		this.strPayorID = strPayorID;
	}




	/**
	 * @param strAddCount the strAddCount to set
	 */
	public void setAddCount(int addCount) {
		this.addCount = addCount;
	}
	/**
	 * @return the strAddCount
	 */
	public int getAddCount() {
		return addCount;
	}
	
	public void incrAddCount() {
		addCount = addCount + 1;
	}
	
	/**
	 * @param strDupCount the strDupCount to set
	 */
	public void setDupCount(int dupCount) {
		this.dupCount =dupCount;
	}
	
	public void incrDupCount() {
		dupCount = dupCount + 1;
	}
	
	/**
	 * @return the strDupCount
	 */
	public int getDupCount() {
		return dupCount;
	}
	
	/**
	 * @param strInvCount the strInvCount to set
	 */
	public void setInvCount(int invCount) {
		this.invCount = invCount;
	}
	
	public void incrInvCount() {
		invCount = invCount + 1;
	}
	
	/**
	 * @return the strInvCount
	 */
	public int getInvCount() {
		return invCount;
	}
	
}
