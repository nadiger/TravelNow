package com.migration.model;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.migration.lib.CommonFunction;
import com.migration.lib.JLib;
import com.migration.lib.JUtil;

public class Pharmacy {
	
	public String zip = "";
	public String phone = "";
	public String fax = "";

	
	public Pharmacy() {
	}
	
	
	
	
	// Throws exception to outer class as well, so error can be displayed in form
	public int insertData(PharmacyBean objPharBean,Connection connSrc, Connection connDest) throws Exception
	{
		
		
		PreparedStatement stmtPr =null;
		Boolean insertFlag = true;
		String strException = "";
		
		String strInsertSql = "";
		String strUpdateSql = "";
		int result = 0;
		int i = 0;

	
		phone=objPharBean.getStrTelephone();
		phone = CommonFunction.convertPhone(phone);
		fax=objPharBean.getStrFax();
		fax = CommonFunction.convertPhone(fax);
		zip = objPharBean.getStrZip();
		zip = CommonFunction.convertzip(zip);
		
		
		try
		{
			
			if (JLib.getPharmByVMID(objPharBean.getStrVmid(), connDest) != 0 )
			{
				insertFlag = false;	
				
				strUpdateSql = "update pharmacy set pharmacyname = ?,";
				strUpdateSql += "pharmacyaddress = ?, ";
				strUpdateSql += "pharmacyaddress2 = ?, ";
				strUpdateSql += "pharmacycity = ?, ";
				strUpdateSql += "pharmacystate = ?, ";
				strUpdateSql += "pharmacyzip = ?, ";
				strUpdateSql += "pharmacyphone = ?, ";
				strUpdateSql += "pharmacyfax = ? ";
				strUpdateSql += "where vmid = ?";
				
				stmtPr = connDest.prepareStatement(strUpdateSql);
				stmtPr.setString(++i, objPharBean.getStrPharmacyName());
				stmtPr.setString(++i, objPharBean.getStrAddress1());
				stmtPr.setString(++i, objPharBean.getStrAddress2());
				stmtPr.setString(++i, objPharBean.getStrCity());
				stmtPr.setString(++i, objPharBean.getStrState());
				stmtPr.setString(++i, zip);
				stmtPr.setString(++i, phone);
				stmtPr.setString(++i, fax);
				stmtPr.setString(++i, objPharBean.getStrVmid());
				
			
				stmtPr.executeUpdate();

				objPharBean.incrDupCount();
			}
			
			if (insertFlag == true)
			{
				
				strInsertSql = " insert into pharmacy";
				strInsertSql += " (pmcid, pharmacyname, pharmacyaddress,pharmacyaddress2, pharmacycity, pharmacystate, pharmacyzip, ";
				strInsertSql += "pharmacyphone, pharmacyfax, vmid, delFlag)"; 
				strInsertSql += " values (?,?,?,?,?,?,?,?,?,?,?) ";
				
				stmtPr = connDest.prepareStatement(strInsertSql);
				stmtPr.setString(++i, objPharBean.getStrVmid());
				stmtPr.setString(++i, objPharBean.getStrPharmacyName());
				stmtPr.setString(++i, objPharBean.getStrAddress1());
				stmtPr.setString(++i, objPharBean.getStrAddress2());
				stmtPr.setString(++i, objPharBean.getStrCity());
				stmtPr.setString(++i, objPharBean.getStrState());
				stmtPr.setString(++i, zip);
				stmtPr.setString(++i, phone);
				stmtPr.setString(++i, fax);
				stmtPr.setString(++i, objPharBean.getStrVmid());
				stmtPr.setString(++i, "0");
			
				stmtPr.executeUpdate();
				
				objPharBean.incrAddCount();
				
				result = JLib.getPharmByVMID(objPharBean.getStrVmid(), connDest);
			}
			else  {
				strException = objPharBean.getStrPharmacyName() + "," + "duplicate Pharmacy";
				JUtil.appendToFile("Pharmacy_Exception.csv", strException);				
				
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw e;
		}
		finally
		{
			if (stmtPr != null)
			stmtPr.close();
		}
		return result;
		
	}

	
}
