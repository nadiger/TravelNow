package com.migration.model;

public class ZipCodesBean {
	private String strZipID = "";
	private String strCity = "";
	private String strState = "";
	private String strZip = "";
	private String strVmid = "";
	
	private int addCount =0;
	private int dupCount =0;
	private int invCount =0;
	
	public void clearAll() {
		strZipID = "";
		strCity = "";
		strState = "";
		strZip = "";
		strVmid = "";
	}

	public String getStrZipID() {
		return strZipID;
	}

	public void setStrZipID(String strZipID) {
		this.strZipID = strZipID;
	}

	public String getStrCity() {
		return strCity;
	}

	public void setStrCity(String strCity) {
		this.strCity = strCity;
	}

	public String getStrState() {
		return strState;
	}

	public void setStrState(String strState) {
		this.strState = strState;
	}

	public String getStrZip() {
		return strZip;
	}

	public void setStrZip(String strZip) {
		this.strZip = strZip;
	}

	public String getStrVmid() {
		return strVmid;
	}

	public void setStrVmid(String strVmid) {
		this.strVmid = strVmid;
	}
	
	/**
	 * @return the strAddCount
	 */
	public int getAddCount() {
		return addCount;
	}
	
	public void incrAddCount() {
		addCount = addCount + 1;
	}
	
	/**
	 * @param strDupCount the strDupCount to set
	 */
	public void setDupCount(int dupCount) {
		this.dupCount =dupCount;
	}
	
	public void incrDupCount() {
		dupCount = dupCount + 1;
	}
	
	/**
	 * @return the strDupCount
	 */
	public int getDupCount() {
		return dupCount;
	}
	
	/**
	 * @param strInvCount the strInvCount to set
	 */
	public void setInvCount(int invCount) {
		this.invCount = invCount;
	}
	
	public void incrInvCount() {
		invCount = invCount + 1;
	}
	
	/**
	 * @return the strInvCount
	 */
	public int getInvCount() {
		return invCount;
	}
	
}
