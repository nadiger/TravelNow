/**
 * 
 */
package com.migration.model;

import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.DropMode;
import javax.swing.JTable.DropLocation;

import sun.misc.JavaUtilJarAccess;


import com.migration.form.DBConnection;
import com.migration.form.PMMigUI;
import com.migration.lib.CommonFunction;
import com.migration.lib.JLib;
import com.migration.lib.JUtil;
import com.sun.org.apache.xml.internal.security.utils.JavaUtils;


public class MasterLab {


	public MasterLab()
	{

	}
	private static Connection getConnection() throws Exception{
		Connection connDes2 = DBConnection.getDSNConnection(PMMigUI.destDNSName,PMMigUI.destUname,PMMigUI.destPwd);
		return connDes2;
	}


	// Throws exception to outer class as well, so error can be displayed in form
	public int insertData(MasterLabBean objMasterLabBean,Connection connSrc, Connection connDest) throws Exception
	{
		PreparedStatement pstmt1 =null;
		PreparedStatement pstmt2 =null;
		PreparedStatement pstmt3 =null;
		PreparedStatement pstmt4 =null;

		Boolean insertFlag = true;
		String strException = "";
		String sqlRangeMain = "";
		String sqlRangeDetails = "";
		String sqlServiceProfileDetail = "";
		String sqlRdResultTextFormat = "";
		String strSQL5 = "";
		Statement stmt = null;
		Statement stmt2Dest = null;
		Statement stmt3Dest = null;
		ResultSet rsUsr = null;
		ResultSet rsUsr2 = null;
		stmt = connSrc.createStatement();
		stmt2Dest = connDest.createStatement();
		stmt3Dest = connDest.createStatement();
		int rangeID=0;
		int rangeDetailID=0;
		int result = 0;
		int i = 0;
		Connection connection1=getConnection();
		Connection connection2=getConnection();
		Connection connection3=getConnection();

		try
		{

			if(objMasterLabBean.getServiceId().equals("0"))
			{
				insertFlag=false;
				objMasterLabBean.incrementInvCount();
			}
			rangeID = JLib.getRangeId(objMasterLabBean,connDest);

			if(rangeID!=0 && !objMasterLabBean.equals("")){
				rangeDetailID = JLib.getRangeDetailId(objMasterLabBean, rangeID, connDest);
			}
			if(rangeDetailID!=0){
				insertFlag=false;
				JUtil.appendToFile("MasterLabDuplicates.csv", objMasterLabBean.getServiceName()+"|"+objMasterLabBean.getCategoryType()+"|"+objMasterLabBean.getReportType()+"|"+objMasterLabBean.getMethod()+"|"+objMasterLabBean.getSample()+"|"+objMasterLabBean.getUnits()+"|Duplicates");
				objMasterLabBean.incrementDupCount();
			}

			/*stmt2Dest.executeQuery("Select * from InvestrangeDetail_New where rangeID="+rangeID+" and Gender='"+objMasterLabBean.getGender()
					+"' and ");
			 */
			if(insertFlag){

				sqlRangeMain = "INSERT INTO investrangemain_New(ServiceID,UnitId,SampleId,MethodId," +
						"Formula,ReportType,CategoryType,Status,EncodedBy,EncodedDate,LocationID,MultipleResult)" +
						"VALUES(?,?,?,?,?,?,?,?,?,?,?,?)";

				i=0;
				pstmt1 = connDest.prepareStatement(sqlRangeMain);

				pstmt1.setInt(++i, Integer.parseInt(objMasterLabBean.getServiceId()));
				pstmt1.setInt(++i, Integer.parseInt(objMasterLabBean.getUnitId()));
				pstmt1.setInt(++i, Integer.parseInt(objMasterLabBean.getSampleId()));
				pstmt1.setInt(++i, Integer.parseInt(objMasterLabBean.getMethodId()));
				pstmt1.setString(++i, objMasterLabBean.getFormula());
				pstmt1.setString(++i, objMasterLabBean.getReportType());
				pstmt1.setString(++i, objMasterLabBean.getCategoryType());
				pstmt1.setString(++i, "A");
				pstmt1.setInt(++i, 2);
				pstmt1.setString(++i, "2016-05-01");
				pstmt1.setInt(++i, 1);
				pstmt1.setString(++i, "N");
				pstmt1.executeUpdate();

				rangeID = JLib.getRangeId(objMasterLabBean,connDest);

				sqlRangeDetails="INSERT INTO InvestrangeDetail_New(RangeId,MinimumValue,MaximumValue," +
						"Gender,AgeType,AgeFrom,AgeUpto,Status,EncodedBy,EncodedDate,LocationID,Symbol)" +
						"VALUES(?,?,?,?,?,?,?,?,?,?,?,?)";
				i=0;
				pstmt2 = connection1.prepareStatement(sqlRangeDetails);

				pstmt2.setInt(++i, rangeID);
				pstmt2.setString(++i, objMasterLabBean.getMinimumValue());
				pstmt2.setString(++i, objMasterLabBean.getMaximumValue());
				pstmt2.setString(++i, objMasterLabBean.getGender());
				pstmt2.setInt(++i, Integer.parseInt(objMasterLabBean.getAgeType()));
				pstmt2.setInt(++i, Integer.parseInt(objMasterLabBean.getAgeFrom()));
				pstmt2.setInt(++i, Integer.parseInt(objMasterLabBean.getAgeUpTo()));
				pstmt2.setString(++i, "A");
				pstmt2.setInt(++i, 2);
				pstmt2.setString(++i, "2016-05-01");
				pstmt2.setInt(++i, 1);
				pstmt2.setString(++i, objMasterLabBean.getSymbol());// symbol??? 
				pstmt2.executeUpdate();


				if(objMasterLabBean.getReportType().equals("G")){
					//insert into ServiceProfileDetail

					sqlServiceProfileDetail = "INSERT INTO ServiceProfileDetail(" +
							"ServiceId,SubServiceId,Sequence,Type,Status,EncodedBy," +
							"EncodedDate,LocationId) VALUES(?,?,?,?,?,?,?,?)";
					i=0;
					pstmt3 = connection2.prepareStatement(sqlServiceProfileDetail);

					pstmt3.setInt(++i, Integer.parseInt(objMasterLabBean.getServiceId()));
					pstmt3.setInt(++i, Integer.parseInt(objMasterLabBean.getSubServiceId()));
					pstmt3.setInt(++i, Integer.parseInt(objMasterLabBean.getSubServiceSequence()));
					pstmt3.setString(++i, "G");// General Profile
					pstmt3.setString(++i, "A");
					pstmt3.setInt(++i, 2);
					pstmt3.setString(++i, "2016-05-01");
					pstmt3.setInt(++i, 1);
					pstmt3.executeUpdate();
				}

				if(objMasterLabBean.getReportType().equals("T")){
					// insert into RD_ResultTextForm
					sqlRdResultTextFormat = "INSERT INTO RD_ResultTextForm(DepartmentID,SubDepartmentID" +
							",ServiceID,Gender,ResultFormatText,Status,EncodedBy,EncodedDate" +
							",LocationID,FormatName) VALUES(?,?,?,?,?,?,?,?,?,?)";
					i=0;
					pstmt4 = connection3.prepareStatement(sqlRdResultTextFormat);

					pstmt4.setInt(++i, Integer.parseInt(objMasterLabBean.getDeptID()));
					pstmt4.setInt(++i, Integer.parseInt(objMasterLabBean.getSubDeptId()));
					pstmt4.setInt(++i, Integer.parseInt(objMasterLabBean.getServiceId()));
					pstmt4.setString(++i, objMasterLabBean.getGender());
					pstmt4.setString(++i, "RADIOLOGY TEST TEMPLATE&nbsp;<br />"+
							"<br />"+
							"<br />"+
							"<br />"+
							"<br />"+
							"RADIOLOGY &nbsp;INVESTIGATION FINDINGS-TEST DATA");
					pstmt4.setString(++i, "A");
					pstmt4.setInt(++i, 2);
					pstmt4.setString(++i, "2016-05-01");
					pstmt4.setInt(++i, 1);
					pstmt4.setString(++i, "Format-"+objMasterLabBean.getGender());//FormatName
					pstmt4.executeUpdate();

				}
				objMasterLabBean.incrementAddCount();

				/*
			i=0;
			pstmt2 = connDest.prepareStatement("");

			pstmt2.setString(++i, "");
			pstmt2.setString(++i, "");
			pstmt2.setString(++i, "");
			pstmt2.setString(++i, "");

			pstmt2.executeUpdate();
				 */
			}

		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			connection1.close();
			connection2.close();
			connection3.close();
		}
		return result;

	}

}
