/**
 * 
 */
package com.migration.model;

import java.sql.Date;
public class AdditionalNotesBean {

	private int id = 1;
	private int patientId = 0;
	private int loggedInUid = 0;
	private Date date;
	private Date time;
	private String message = new String();
	private int deleteFlag = 0;

	private int addCount =0;
	private int dupCount =0;
	private int invCount =0;
	
	public AdditionalNotesBean() {

	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getPatientId() {
		return patientId;
	}

	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}

	public int getLoggedInUid() {
		return loggedInUid;
	}

	public void setLoggedInUid(int loggedInUid) {
		this.loggedInUid = loggedInUid;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public Date getTime() {
		return time;
	}

	public void setTime(Date time) {
		this.time = time;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public int getDeleteFlag() {
		return deleteFlag;
	}

	public void setDeleteFlag(int deleteFlag) {
		this.deleteFlag = deleteFlag;
	}

	/**
	 * @param addCount the addCount to set
	 */
	public void setAddCount(int addCount) {
		this.addCount = addCount;
	}

	/**
	 * @return the addCount
	 */
	public int getAddCount() {
		return addCount;
	}

	/**
	 * @param dupCount the dupCount to set
	 */
	public void setDupCount(int dupCount) {
		this.dupCount = dupCount;
	}

	/**
	 * @return the dupCount
	 */
	public int getDupCount() {
		return dupCount;
	}

	/**
	 * @param invCount the invCount to set
	 */
	public void setInvCount(int invCount) {
		this.invCount = invCount;
	}

	/**
	 * @return the invCount
	 */
	public int getInvCount() {
		return invCount;
	}
}
