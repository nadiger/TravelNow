package com.migration.model;

public class ServiceBean {
	
	private String SubServiceName;//**
	private String ServiceName;//**
	private int Sequence;//**
	private String type;
	private static int addCount;
	private static int dupCount;
	private static int invCount;
	
	public ServiceBean() {

	}
	public void clearall(){
		SubServiceName="";//**
		ServiceName="";//**
		Sequence=0;//**
		type="";
	}

	public String getSubServiceName() {
		return SubServiceName;
	}

	public String getServiceName() {
		return ServiceName;
	}

	public int getSequence() {
		return Sequence;
	}

	public String getType() {
		return type;
	}

	public void setSubServiceName(String subServiceName) {
		SubServiceName = subServiceName;
	}

	public void setServiceName(String serviceName) {
		ServiceName = serviceName;
	}

	public void setSequence(int sequence) {
		Sequence = sequence;
	}

	public void setType(String type) {
		this.type = type;
	}
	
	public int getAddCount() {
		return addCount;
	}

	public int getDupCount() {
		return dupCount;
	}

	public int getInvCount() {
		return invCount;
	}

	public void setAddCount() {
		addCount = addCount+1;
	}

	public void setDupCount() {
		dupCount = dupCount+1;
	}

	public void setInvCount() {
		invCount = invCount+1;
	}
	

}
