/**
 * 
 */
package com.migration.model;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class AdditionalNotes {
	
	public AdditionalNotes()
	{
		
	}
	
	// Throws exception to outer class as well, so error can be displayed in form
	public int insertData(AdditionalNotesBean objAddInfoBean,Connection connSrc, Connection connDest) throws Exception
	{
		PreparedStatement stmtPr =null;
		Boolean insertFlag = true;
		
		String strInsertSql = "";
		int result = 0;
		int i = 0;
		
		try
		{
			
			if (insertFlag == true)
			{
				
				strInsertSql = " insert into additionalnotes";
				strInsertSql += " values (?,?,?,?,?,?,?)";
				
				stmtPr = connDest.prepareStatement(strInsertSql);
				
				stmtPr.setInt(++i, objAddInfoBean.getId());
				stmtPr.setInt(++i, objAddInfoBean.getPatientId());
				stmtPr.setInt(++i, objAddInfoBean.getLoggedInUid());
				stmtPr.setDate(++i, objAddInfoBean.getDate());
				stmtPr.setDate(++i, objAddInfoBean.getTime());
				stmtPr.setString(++i, objAddInfoBean.getMessage());
				stmtPr.setInt(++i, objAddInfoBean.getDeleteFlag());
				
				stmtPr.executeUpdate();
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw e;
		}
		finally
		{
			if (stmtPr != null)
			stmtPr.close();
		}
		return result;
		
	}
	
}
