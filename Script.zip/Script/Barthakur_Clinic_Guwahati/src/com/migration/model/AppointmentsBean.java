package com.migration.model;

import com.migration.lib.*;

/** 
* Created by   : Ravi 
* Date created : Oct/28/2012
* Purpose      : Bean Class [AppointmentsBean.java] for Appointment details for the Patients
* Comments     : 
* Date Modified:   
* Modified by  :
*/


public class AppointmentsBean {
	
	/** 
	private long lngEncType = 1;                       
	     1.      Physical encounter
	     2.      Telephone encounter
	     3.      Out of office encounter
	     4.      claims
 	     5.      Labs
	     6.      Web encounter
	     7.      ePriscription and refill responses
	     8.      Dashboard
	     9.      Orderset template encounter.	
	*/
	
	private long   lngApt_RecordID_Source = 0;
	private String strFacilityID_Source = "";
	private String strDoctorID_Source = "";
	private String strResourceID_Source = "";
	private String strPatientID_Source = "";
	private String strAptDate_Source = "";
	private String strStartTime_Source = "";
	private String strEndTime_Source = "";
	private String strVisitType_Source = "";
	private String Duration="";
	private String strReason_Source = "";
	private String strNotes_Source = "";
	private String strGeneralNotes_Source = "";
	private String strPOS = "11";                   // 11
	private String AMPM = "";
	private String strStatus_Source = "";
	
	// private long lngDeleteFlag = 0;                 // 0, 1
	// 
	// private long lngClaimReq = 0;					//0 = No Claims ;   1 = Claims
	

	private int cntRead =0;
	private int cntAdd =0;
	private int cntDup =0;
	private int cntInv =0;
		
	private int cntNoPat =0;
	private int cntNoDr =0;
	private int cntNoFac =0;	
		
	public void clearAll()	{	
		lngApt_RecordID_Source = 0;
		strFacilityID_Source = "";
		strDoctorID_Source = "";
		strResourceID_Source = "";
		strPatientID_Source = "";
		strAptDate_Source = "";
		strStartTime_Source = "";
		strEndTime_Source = "";
		strVisitType_Source = "";		
		strReason_Source = "";
		strNotes_Source = "";
		strGeneralNotes_Source = "";
		strPOS = "11";		
		Duration="";
	}

	
	public String getStrReason_Source() {
		return strReason_Source;
	}
    
	
	public String getStrNotes_Source() {
		return strNotes_Source;
	}
    
	
	
    
	public String getDuration() {
		return Duration;
	}


	public void setDuration(String duration) {
		Duration = duration;
	}


	public void setStrNotes_Source(String strNotes_Source) {
		this.strNotes_Source = strNotes_Source;
	}
    
    
	public String getStrGeneralNotes_Source() {
		return strGeneralNotes_Source;
	}
    
    
	public void setStrGeneralNotes_Source(String strGeneralNotes_Source) {
		this.strGeneralNotes_Source = strGeneralNotes_Source;
	}
	
	


	public String getAMPM() {
		return AMPM;
	}


	public void setAMPM(String aMPM) {
		AMPM = aMPM;
	}


	public void setStrReason_Source(String strReason_Source) {
		this.strReason_Source = strReason_Source;
	}


	public String getStrFacilityID_Source() {
		return strFacilityID_Source;
	}

	public void setStrFacilityID_Source(String s) {
		this.strFacilityID_Source = s;
	}


	public String getStrPatientID_Source() {
		return strPatientID_Source;
	}

	public void setStrPatientID_Source(String strPatientID_Source) {
		this.strPatientID_Source = strPatientID_Source;
	}


	public String getStrDoctorID_Source() {
		return strDoctorID_Source;
	}
    
	public void setStrDoctorID_Source(String strDoctorID_Source) {
		this.strDoctorID_Source = strDoctorID_Source;
	}
    
    
	public String getStrResourceID_Source() {
		return strResourceID_Source;
	}

	public void setStrResourceID_Source(String strResourceID_Source) {
		this.strResourceID_Source = strResourceID_Source;
	}
    
    
	public String getStrAptDate_Source() {
		return strAptDate_Source;
	}
            
	public void setStrAptDate_Source(String strDate_Source) {
		this.strAptDate_Source = strDate_Source;
	}
    
        
	public String getStrStartTime_Source() {
		return strStartTime_Source;
	}    
    
	public void setStrStartTime_Source(String strStartTime_Source) {
		this.strStartTime_Source = strStartTime_Source;
	}
    
        
	public String getStrEndTime_Source() {
		return strEndTime_Source;
	}

	public void setStrEndTime_Source(String strEndTime_Source) {
		this.strEndTime_Source = strEndTime_Source;
	}


	public String getStrVisitType_Source() {
		return strVisitType_Source;
	}

	public void setStrVisitType_Source(String strVisitType_Source) {
		this.strVisitType_Source = strVisitType_Source;
	}


	public String getStrStatus_Source() {
		return strStatus_Source;
	}

	public void setStrStatus_Source(String strStatus_Source) {
		this.strStatus_Source = strStatus_Source;
	}


	public String getStrPOS() {
		return strPOS;
	}

	public void setStrPOS(String strPOS) {
		this.strPOS = strPOS;
	}

	
	public long getLngApt_RecordID_Source() {
		return lngApt_RecordID_Source;
	}

	public void setLngApt_RecordID_Source(long lngApt_RecordID_Source) {
		this.lngApt_RecordID_Source = lngApt_RecordID_Source;
	}


	//Counters for migration statistics..........
	public int getCntRead() {
		return cntRead;
	}
	
	public void setCntRead(int cntRead) {
		this.cntRead = cntRead;
	}

	
	public int getCntAdd() {
		 return cntAdd;
	}

	public void setCntAdd(int cntAdd) {
		this.cntAdd = cntAdd;
	}
	
	
	public int getCntDup() {
		return cntDup;
	}

	public void setCntDup(int cntDup) {
		this.cntDup = cntDup;
	}


	public int getCntInv() {
		return cntInv;
	}

	public void setCntInv(int cntInv) {
		this.cntInv = cntInv;
	}


	public int getCntNoFac() {
		return cntNoFac;
	}

	public void setCntNoFac(int cntNoFac) {
		this.cntNoFac = cntNoFac;
	}

	
	public int getCntNoDr() {
		return cntNoDr;
	}

	public void setCntNoDr(int cntNoDr) {
		this.cntNoDr = cntNoDr;
	}


	public int getCntNoPat() {
		return cntNoPat;
	}

	public void setCntNoPat(int cntNoPat) {
		this.cntNoPat = cntNoPat;
	}

	
    // Counter Increment methods.............................
	public void incrReadCount() {
		cntRead = cntRead + 1;
	}

	public void incrAddCount() {
		cntAdd = cntAdd + 1;
	}
		
	public void incrDupCount() {
		cntDup = cntDup + 1;
	}
		
	public void incrInvCount() {
		cntInv = cntInv + 1;
	}
			
	public void incrNoFacCount() {
		cntNoFac = cntNoFac + 1;
	}
	
	public void incrNoDr() {
		cntNoDr = cntNoDr + 1;
	}

	public void incrNoPatCount() {
		cntNoPat = cntNoPat + 1;
	}
	
}
