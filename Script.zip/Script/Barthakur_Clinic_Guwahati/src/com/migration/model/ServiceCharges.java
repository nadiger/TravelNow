/**
 * 
 */
package com.migration.model;

import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.DropMode;
import javax.swing.JTable.DropLocation;

import org.omg.PortableServer.LIFESPAN_POLICY_ID;

import sun.misc.JavaUtilJarAccess;


import com.migration.form.DBConnection;
import com.migration.form.PMMigUI;
import com.migration.lib.CommonFunction;
import com.migration.lib.JLib;
import com.migration.lib.JUtil;
import com.sun.org.apache.xml.internal.security.utils.JavaUtils;


public class ServiceCharges {


	public ServiceCharges()
	{

	}
	private static Connection getConnection() throws Exception{
		Connection connDes2 = DBConnection.getDSNConnection(PMMigUI.destDNSName,PMMigUI.destUname,PMMigUI.destPwd);
		return connDes2;
	}


	// Throws exception to outer class as well, so error can be displayed in form
	public int insertData(ServiceChargesBean ServiceChargesBean,Connection connSrc, Connection connDest) throws Exception
	{
		PreparedStatement pstmt1 =null;
		PreparedStatement pstmt2 =null;
		PreparedStatement pstmt3 =null;
		PreparedStatement pstmt4 =null;

		Boolean insertFlag = true;
		String strException = "";
		String sqlRangeMain = "";
		String sqlRangeDetails = "";
		String sqlServiceProfileDetail = "";
		String sqlRdResultTextFormat = "";
		String strSQL5 = "";
		Statement stmt = null;
		Statement stmt2Dest = null;
		Statement stmt3Dest = null;
		ResultSet rsUsr = null;
		ResultSet rsUsr2 = null;
		stmt = connSrc.createStatement();
		stmt2Dest = connDest.createStatement();
		stmt3Dest = connDest.createStatement();
		int chargeID=0;
		int rangeDetailID=0;
		int result = 0;
		int i = 0;
		Connection connection1=getConnection();
		Connection connection2=getConnection();
		Connection connection3=getConnection();

		try
		{

			if(ServiceChargesBean.getServiceId().equals("0"))
			{
				insertFlag=false;
				ServiceChargesBean.setInvCount();
			}
			chargeID = JLib.getChargeId(ServiceChargesBean);

			if(chargeID!=0){
				insertFlag=false;
				JUtil.appendToFile("ServiceChargeDuplicates.csv", ServiceChargesBean.getServiceName()+"|"+ServiceChargesBean.getSponsorName()+"|"+ServiceChargesBean.getServiceCharges()+"|"+ServiceChargesBean.getBedCategoryId()+"|Duplicates");
				ServiceChargesBean.setDupCount();
			}


			if(insertFlag){

				sqlRangeMain = "INSERT INTO ServiceCharges(SponsorID,ServiceID,BedCategoryID," +
						"ServiceCharges,Discountable,EffectiveDate,EncodedBy,EncodedDate,LocationID" +
						",Hospitalshare,Hospitalamount,Doctorpercent) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)";

				i=0;
				pstmt1 = connection2.prepareStatement(sqlRangeMain);

				pstmt1.setInt(++i, Integer.parseInt(ServiceChargesBean.getSponsorID()));
				pstmt1.setInt(++i, Integer.parseInt(ServiceChargesBean.getServiceId()));
				pstmt1.setInt(++i, Integer.parseInt(ServiceChargesBean.getBedCategoryId()));
				pstmt1.setDouble(++i, Double.parseDouble(ServiceChargesBean.getServiceCharges()));
				pstmt1.setString(++i, "N");
				pstmt1.setString(++i, "2016-04-01");
				pstmt1.setInt(++i, 2);
				pstmt1.setString(++i, "2016-05-09");
				pstmt1.setInt(++i, 1);
				pstmt1.setDouble(++i,  Double.parseDouble("100.00"));
				pstmt1.setDouble(++i, Double.parseDouble(ServiceChargesBean.getServiceCharges()));
				pstmt1.setDouble(++i, Double.parseDouble("0.00"));
				pstmt1.executeUpdate();

				ServiceChargesBean.setAddCount();


				/*i=0;
			pstmt2 = connDest.prepareStatement("");

			pstmt2.setString(++i, "");
			pstmt2.setString(++i, "");
			pstmt2.setString(++i, "");
			pstmt2.setString(++i, "");

			pstmt2.executeUpdate();*/

			}

		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			connection1.close();
			connection2.close();
			connection3.close();
		}
		return result;

	}

}
