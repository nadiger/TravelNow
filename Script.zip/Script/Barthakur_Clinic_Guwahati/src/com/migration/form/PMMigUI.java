package com.migration.form;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;
import java.sql.Connection;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Properties;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JScrollPane;

import com.migration.action.PMMigAction;
import com.migration.form.DBConnection;
import com.migration.lib.JLib;


public class PMMigUI extends JPanel implements ActionListener {

	public static String srcDNSName = "";
	public static String srcUname = "";
	public static String srcPwd= "";
	public static String destDNSName = "";
	public static String destUname = "";
	public static String destPwd= "";
	
	
	
	private static final long serialVersionUID = 1L;
	
	JTextField jtDSN1 = new JTextField(15);
	JTextField jtDSN2 = new JTextField("GNRC"); // / Barthakur
	JTextField jtUserName1 = new JTextField(15);
	JTextField jtUserName2 = new JTextField("sa"); // / sa
	JTextField txtStatus = new JTextField(50);
	JTextArea  txtProgress = new JTextArea();
    
	JPasswordField jpPwd1 = new JPasswordField(15);
	JPasswordField jpPwd2 = new JPasswordField("Pwd4db@114");//  / Pwd4db@114
	JLabel jlFacStatus  = new JLabel("");

	JButton Browse = new JButton("Browse");
	//Swings File Chooser to select the files.
	JFileChooser jfFileChooser = new JFileChooser();

	JButton jbPatientDemographics = new JButton("PatientDemographics");
	
	JButton jbFacility = new JButton("MasterLab");
	JButton jbDoctor = new JButton("Services");
	JButton jbResource = new JButton("ServiceCharges");
	JButton jbRefDoc = new JButton("facility");
	JButton jbInsurance = new JButton("Insurance");
	JButton jbEmployers = new JButton("Employers");
	JButton jbGuarantorEmployers = new JButton("GuarantorEmployers");
	JButton jbPatients = new JButton("Patients");
	JButton jbContacts = new JButton("Contacts");
	JButton jbGuarantors = new JButton("Guarantor");
	JButton jbPatientInsuredGuarantors = new JButton("PatientInsuredGuarantors");
	JButton jbPatIns = new JButton("PatientInsurance");
	JButton jbAppointments = new JButton("Appointments");
	JButton jbAdditionalNotes = new JButton("AdditionalNotes");
	JButton jbStructInfo = new JButton("StructInfo");
	JButton jbMiscInfo = new JButton("MiscInfo");
	JButton jbZipCodes = new JButton("ZipCodes");
	JButton jbPharmacy = new JButton("Pharmacy");
	JButton jbVisitType = new JButton("VisitType");
	JButton jbVisitStatus = new JButton("VisitStatus");
	JButton jbFeeSchedule = new JButton("FeeSchedule");
	JButton jbRelation = new JButton("Relation");
	
	//Constructor for the class.
	PMMigUI()	{

		setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));
		add(Box.createRigidArea(new Dimension(0, 5)));
		add(PanelConnection());
		add(Box.createRigidArea(new Dimension(0, 5)));
		add(PanelButtons());
		add(Box.createRigidArea(new Dimension(0, 5)));
		add(PanelStatus());
		add(Box.createRigidArea(new Dimension(0, 5)));
		add(PanelStatusBar());
	}

	private  JPanel PanelSrcConn() {

		JPanel controls = new JPanel();
		controls.setLayout(new GridLayout(3,3));
		controls.add(new JLabel("DSN/AccessPath"));
		controls.add(jtDSN1 );
		controls.add(Browse );
		controls.add(new JLabel("UserName"));
		controls.add(jtUserName1 );
		controls.add(new JLabel(""));
		controls.add(new JLabel("Password"));
		controls.add(jpPwd1 );
		controls.add(new JLabel(""));
		
		add(controls, BorderLayout.CENTER);
		controls.setBorder(BorderFactory.createTitledBorder(
				"Source Connection"));
		Browse.addActionListener(new BrowseClick());

		return controls;
	}

	private  JPanel PanelDestConn() {

		JPanel controls = new JPanel();
		controls.setLayout(new GridLayout(3,2));
		controls.add(new JLabel("DSN") );
		controls.add(jtDSN2 );
		controls.add(new JLabel("UserName"));
		controls.add(jtUserName2 );
		controls.add(new JLabel("Password"));
		controls.add(jpPwd2 );
		controls.setBorder(BorderFactory.createTitledBorder(
				"Destination Connection"));
		return controls;
	}


	private JPanel PanelConnection() {

		JPanel controls = new JPanel();
		controls.setLayout(new GridLayout(1,2));
		controls.add(PanelSrcConn());
		controls.add(PanelDestConn());
		controls.setBorder(BorderFactory.createEmptyBorder());
		return controls;
	}


	//Add any extra buttons here

	private JPanel PanelButtons() {

		JPanel controls = new JPanel();
		controls.setLayout(new GridLayout(1,3));

		controls.add(jbPatientDemographics);
		controls.add(jbFacility);
		controls.add(jbDoctor);
		controls.add(jbRefDoc);
		controls.add(jbResource);
		
		/*controls.add(jbInsurance);
		controls.add(jbEmployers);
		controls.add(jbGuarantorEmployers);
		controls.add(jbPatients);
		controls.add(jbContacts);
		controls.add(jbGuarantors);
		controls.add(jbPatientInsuredGuarantors);
		controls.add(jbPatIns);
		controls.add(jbAppointments);
		controls.add(jbAdditionalNotes);
		controls.add(jbStructInfo);
		controls.add(jbMiscInfo);
		controls.add(jbZipCodes);
		controls.add(jbPharmacy);
		controls.add(jbVisitType);
		controls.add(jbVisitStatus);
		controls.add(jbFeeSchedule);
		controls.add(jbRelation);*/
		
		
		jbPatientDemographics.addActionListener(this);
		jbFacility.addActionListener(this);
		jbDoctor.addActionListener(this);
		jbResource.addActionListener(this);
		jbRefDoc.addActionListener(this);
		jbInsurance.addActionListener(this);
		jbEmployers.addActionListener(this);
		jbGuarantorEmployers.addActionListener(this);
		jbPatients.addActionListener(this);
		jbContacts.addActionListener(this);
		jbGuarantors.addActionListener(this);
		jbPatientInsuredGuarantors.addActionListener(this);
		jbPatIns.addActionListener(this);
		jbAppointments.addActionListener(this);
		jbAdditionalNotes.addActionListener(this);
		jbStructInfo.addActionListener(this);
		jbMiscInfo.addActionListener(this);
		jbZipCodes.addActionListener(this);
		jbPharmacy.addActionListener(this);
		jbVisitType.addActionListener(this);
		jbVisitStatus.addActionListener(this);
		jbFeeSchedule.addActionListener(this);
		jbRelation.addActionListener(this);
		
		controls.setBorder(BorderFactory.createEmptyBorder());
		return controls;
	}


	private JPanel PanelStatus() 
	{

		JPanel controls = new JPanel();
		controls.setLayout(new BoxLayout(controls, BoxLayout.Y_AXIS));
		//controls.add(new JLabel("Status: "));
		controls.add(txtStatus);

		txtProgress.setText("");
		JScrollPane scrollPaneProgress = new JScrollPane(txtProgress);
		scrollPaneProgress.setPreferredSize(new Dimension(700, 150));
		txtProgress.setEditable(true);
		controls.add(scrollPaneProgress);

		//controls.setBorder(BorderFactory.createEmptyBorder());
		controls.setBorder(BorderFactory.createTitledBorder("Status"));
		return controls;
	}



	private JPanel PanelStatusBar()	{

		JPanel controls = new JPanel();
		controls.setLayout(new FlowLayout(FlowLayout.LEADING));
		//controls.add(new JLabel("  "));
		controls.add(new JLabel("You are connected to: "));
		controls.add(jlFacStatus);

		controls.setBorder(BorderFactory.createEmptyBorder());

		return controls;
	}
	
	//Action event when the browser button clicked.
	class BrowseClick implements ActionListener {
		public void actionPerformed(ActionEvent ae) {
			//... Open a file dialog.
			File dir = new File(".");
			jfFileChooser.setCurrentDirectory(dir);
			int retval = jfFileChooser.showOpenDialog(PMMigUI.this);
			if (retval == JFileChooser.APPROVE_OPTION) {
				//... The user selected a file, get it, use it.
				File file1 = jfFileChooser.getSelectedFile();
				//... Update user interface.
				jtDSN1.setText(file1.getPath());
			}            
		}
	}

	//Function to create and setup a new window and add all the fields into it.
	private static void createAndShowGUI() {


		//Create and set up the window.
		JFrame frame = new JFrame("eClinicalWorks - PM Migration Utility");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		//Create and set up the content pane.
		JComponent newContentPane = new PMMigUI();
		newContentPane.setOpaque(true); //content panes must be opaque
		frame.setContentPane(newContentPane);

		frame.pack();
		frame.setLocation(100, 100);
		frame.setVisible(true);

	}

	public static void main(String[] args) 
	{
		javax.swing.SwingUtilities.invokeLater(new Runnable() 
		{
			public void run() {
				createAndShowGUI();
			}
		});
	}

	/* Call this method to display status information ex. add/update/invalid count
	 * 
	 */
	public void displayStatus(String strStatus)	{
		txtStatus.setText(strStatus);

	}

	/* Call this method to display current utility Progress information
	 *  ex. any exceptions, task completed
	 */
	public void displayProgress(String strProgress)	{
		txtProgress.setText(txtProgress.getText() +  strProgress + "\n");

	}
	
	public void displayPrimaryFacility(Connection conn) throws Exception	{
		try	{
			Hashtable<Integer, String> ht = null;
			
			//Calling function to get priamry faciliy details in Hash table
			ht = JLib.getPrimaryFacility(conn);
			//Using iterator to loop through hastable keys
			Iterator<Integer> it = (Iterator<Integer>) ht.keySet().iterator();
	
			if (it.hasNext())
			{
				jlFacStatus.setText( ht.get(it.next()) );
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}

	}
	
	public void actionPerformed(ActionEvent ae)	{
		JButton jb = (JButton) ae.getSource();
		
		try	{
			Connection connSrc = null;
			Connection connDest = null;	
			
			Connection connSrc2 = null;
			Connection connDes2 = null;	
			
			
			Properties prop = new Properties();
			InputStream input = null;
			 
			//Local Connection
			//connSrc = DBConnection.getAccessConnection("Data\\GNRC-Guwahati-Assam_FinalData.mdb");
			connSrc = DBConnection.getAccessConnection("Data\\BlankDB.mdb");
			
			//server
			connDest = DBConnection.getDSNConnection(PMMigUI.destDNSName=jtDSN2.getText(),PMMigUI.destUname=jtUserName2.getText(),PMMigUI.destPwd=jpPwd2.getText());
			
			/*input = new FileInputStream("config.properties");
			// load a properties file
			prop.load(input);
			// get the property value and print it out
			System.out.println("IP Address: "+prop.getProperty("ipaddress"));
			System.out.println("DB Name: "+prop.getProperty("databasename"));
			System.out.println("Port: "+prop.getProperty("port"));
			System.out.println("UserName: "+prop.getProperty("username"));
			System.out.println("Password: "+prop.getProperty("password"));
			
			
			connSrc = DBConnection.getAccessConnection("Data\\GNRC-Guwahati-Assam_FinalData.mdb");
			connDest = DBConnection.getMSSQLConnection(prop.getProperty("ipaddress"), prop.getProperty("databasename"), prop.getProperty("port"),prop.getProperty("username"), prop.getProperty("password"));
			*/
			
			// TEST SERVER Connection
			/*connSrc = DBConnection.getAccessConnection("mdb\\GNRC-Guwahati-Assam_FinalData.mdb");
			connDest = DBConnection.getMSSQLConnection("10.103.20.134", "dbi_ghgnrc", "1433", "ghgnrc", "hbfkuelr86");
			*/
			
			
			
			
			jb.setEnabled(false);
			new SimpleThread(jb.getText(),connSrc,connDest,this).start();
			//displayPrimaryFacility(connDest);
		}
		catch(Exception e)	{
			e.printStackTrace();
		}
	}
}

class SimpleThread extends Thread {

	String strButtonName = "";
	Connection connSrc = null;
	Connection connDest = null;
	PMMigUI objUI = null;

	public SimpleThread(String strButtonName, Connection connSrc, Connection connDest, PMMigUI objUI )	{
		super(strButtonName);
		this.strButtonName= strButtonName;
		this.connSrc = connSrc;
		this.connDest = connDest;
		this.objUI = objUI;
	}

	public void run() 
	{

		try {
			objUI.displayProgress(strButtonName + " - Task Started");
			PMMigAction objAction = new PMMigAction();

			objAction.execute(strButtonName, connSrc, connDest,objUI);        
			objUI.displayProgress(strButtonName + " - Task Completed");

		} catch (Exception e)	{

		}

	}
}


