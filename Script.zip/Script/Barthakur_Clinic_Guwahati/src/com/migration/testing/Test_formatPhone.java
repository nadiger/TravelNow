package com.migration.testing;

import com.migration.lib.CommonFunction;
import com.migration.lib.JUtil;

public class Test_formatPhone {

	
	public static void main(String[] args) {
		//System.out.println("hh"+JUtil.formatPhone("1234567891"));
		System.out.println(CommonFunction.convertPhone("4567891"));
		System.out.println(CommonFunction.convertPhone("1234567891"));

	}

}
