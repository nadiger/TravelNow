package com.migration.testing;

public class FetchData {

	private static int countryID=0;
	private static int stateID=0;
	private static int cityID=0;
	
	private static String countryName="";
	private static String stateName="";
	private static String cityName="";	
	
	public static void main(String[] args) {
		
	}
	
	

}
