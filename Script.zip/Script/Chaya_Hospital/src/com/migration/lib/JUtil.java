
package com.migration.lib;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;


/**
 * @author jay.shah
 *
 */
public class JUtil {


	public static Date PROCESS_startTime=null;
	public static Date PROCESS_EndTime=null;

	/* write all utility functions here which doesn't require DB Connection
	 * 
	 */

	/**
	 * @param strFileName
	 * @param strContent
	 * @throws IOException
	 * @author jay
	 * @DateCreated Oct-01-2011
	 */


	public static void appendToFile(String strFileName, String strContent) throws IOException
	{
		FileWriter fw = new FileWriter(strFileName,true);
		BufferedWriter out = new BufferedWriter(fw);
		out.write(strContent);
		out.newLine();
		out.close();
	}

	public static String convertRel (String strRelation) {
		String strResult = "";

		strRelation = removeSplChars(strRelation);

		if (strRelation.equalsIgnoreCase("1") || strRelation.equalsIgnoreCase("0") || strRelation.equalsIgnoreCase("SELF") || strRelation.equalsIgnoreCase("S") || strRelation.equalsIgnoreCase("SELF / SAME AS PATIENT") || strRelation.equalsIgnoreCase("1") || strRelation.equalsIgnoreCase("PATIENT IS INSURED") || strRelation.equalsIgnoreCase("SELF/SAME AS PATIENT")) {
			strResult  = "1";
		}
		else if (strRelation.equalsIgnoreCase("2") || strRelation.equalsIgnoreCase("HUSBAND") || strRelation.equalsIgnoreCase("WIFE") || strRelation.equalsIgnoreCase("H") || strRelation.equalsIgnoreCase("2") || strRelation.equalsIgnoreCase("W") || strRelation.equalsIgnoreCase("SPOUSE") || strRelation.equalsIgnoreCase("SPOUSE/HUSBAND OR WIFE") || strRelation.equalsIgnoreCase("LIFE PARTNER")) {
			strResult  = "2";
		}
		else if (strRelation.equalsIgnoreCase("C") || strRelation.equalsIgnoreCase("CHILD") || strRelation.equalsIgnoreCase("SON") || strRelation.equalsIgnoreCase("DAUGHTER") || strRelation.equalsIgnoreCase("3") || strRelation.equalsIgnoreCase("NATURAL CHILD WITH FINANCIAL RESPONSIBILITY") || strRelation.equalsIgnoreCase("NATURAL CHILD WITHOUT FINANCIAL RESPONSIBILITY") || strRelation.equalsIgnoreCase("CHILD/SON OR DAUGHTER")) {
			strResult  = "3";
		}
		else if (strRelation.equalsIgnoreCase("CHILD/INSURED NO FINANCIAL RES")) {
			strResult  = "4";
		}
		else if (strRelation.equalsIgnoreCase("STEP SON") || strRelation.equalsIgnoreCase("STEP DAUGHTER") || strRelation.equalsIgnoreCase("STEP CHILD") || strRelation.equalsIgnoreCase("STEPSON OR STEPDAUGHTER")) {
			strResult  = "5";
		}
		else if (strRelation.equalsIgnoreCase("FOSTER SON") || strRelation.equalsIgnoreCase("FOSTER DAUGHTER") || strRelation.equalsIgnoreCase("FOSTER CHILD") || strRelation.equalsIgnoreCase("ADOPTED CHILD")) {
			strResult  = "6";
		}
		else if (strRelation.equalsIgnoreCase("WARD") || strRelation.equalsIgnoreCase("WARD OF THE COURT")) {
			strResult  = "7";
		}
		else if (strRelation.equalsIgnoreCase("EMPLOYER") || strRelation.equalsIgnoreCase("EMPLOYEE")) {
			strResult  = "8";
		}
		else if (strRelation.equalsIgnoreCase("UNKNOWN")) {
			strResult  = "9";
		}
		else if (strRelation.equalsIgnoreCase("HANDICAPPED DEPENDENT")) {
			strResult  = "10";
		}
		else if (strRelation.equalsIgnoreCase("ORGAN DONOR")) {
			strResult  = "11";
		}
		else if (strRelation.equalsIgnoreCase("CADAVER DONOR")) {
			strResult  = "12";
		}
		else if (strRelation.equalsIgnoreCase("GRANDSON") || strRelation.equalsIgnoreCase("GRANDDAUGHTER") || strRelation.equalsIgnoreCase("GRANDS") || strRelation.equalsIgnoreCase("GRAND DAUGHTER") || strRelation.equalsIgnoreCase("GRAND CHILD") || strRelation.equalsIgnoreCase("GRANDSON OR GRANDDAUGHTER")) {
			strResult  = "13";
		}
		else if (strRelation.equalsIgnoreCase("NIECE") || strRelation.equalsIgnoreCase("NEPHEW") || strRelation.equalsIgnoreCase("NIECE/NEPHEW")) {
			strResult  = "14";
		}
		else if (strRelation.equalsIgnoreCase("INJURED PLAINTIFF")) {
			strResult  = "15";
		}
		else if (strRelation.equalsIgnoreCase("SPONSORED DEPENDENT")) {
			strResult  = "16";
		}
		else if (strRelation.equalsIgnoreCase("DEPENDENT OF A MINOR DEPENDENT") || strRelation.equalsIgnoreCase("MINOR DEPENDENT OF A MINOR DEPENDENT")) {
			strResult  = "17";
		}
		else if (strRelation.equalsIgnoreCase("PARENT") || strRelation.equalsIgnoreCase("MOTHER") || strRelation.equalsIgnoreCase("FATHER") || strRelation.equalsIgnoreCase("STEP MOTHER")  || strRelation.equalsIgnoreCase("FOSTER MOTHER") || strRelation.equalsIgnoreCase("FOSTER FATHER")  || strRelation.equalsIgnoreCase("STEP FATHER") || strRelation.equalsIgnoreCase("STEP MOTHER")  || strRelation.equalsIgnoreCase("FOSTER MOTHER") || strRelation.equalsIgnoreCase("PARENT")) {
			strResult  = "18";
		}
		else if (strRelation.equalsIgnoreCase("GRANDFATHER") || strRelation.equalsIgnoreCase("GRANDPARENT") || strRelation.equalsIgnoreCase("GRANDS a") || strRelation.equalsIgnoreCase("GRAND MOTHER")  || strRelation.equalsIgnoreCase("GRAND PARENT") || strRelation.equalsIgnoreCase("GRANDFATHER OR GRANDMOTHER")) {
			strResult  = "19";
		}

		else {
			strResult = "99";
		}
		return strResult;
	}

	public static String convertName(String userName)
	{
		System.out.println(userName);
		if(userName !=null)
		{
			String one  = userName.substring(0, 1);
			one = one.toUpperCase();
			userName = userName.substring(1, userName.length());
			userName = one + userName;
		}	
		return userName;
	}

	public static int getUserType(int strVMID, Connection con) throws Exception {

		String strSQL = "";
		ResultSet rsUsers = null;
		int uid = 0 ;
		Statement stmt3 = con.createStatement();

		strSQL = "Select usertype from users where uid = '" + strVMID + "'";
		rsUsers = stmt3.executeQuery(strSQL);
		if (rsUsers.next()) {
			uid = rsUsers.getInt("usertype");
		}

		stmt3.close();
		return uid;
	}






	public static void logExceptions(Exception e) 
	{
		try
		{
			FileWriter fw = new FileWriter("Exceptions.txt",true);
			BufferedWriter out = new BufferedWriter(fw);
			out.write(e.toString());
			out.newLine();
			out.close();
		}catch(IOException e1)
		{
			e1.printStackTrace();
		}
	}



	/**
	 * @param str
	 * @return Validation of String
	 * @author Ravi
	 * @DateCreated aug-21-2011
	 * 
	 */

	public static String validateString(String str) throws Exception
	{
		String strRet = "";
		if (str == null || str=="NULL" ||str.equals("NULL"))
			str = "";

		//strRet = str.trim();
		strRet = str.replaceAll("'", "");
		return strRet;
	}


	/**
	 * @param str: Phone number 
	 * @return Validation for Special characters
	 * @author Ravi
	 * @Date aug-21-2011
	 * 
	 */

	/*public static String formatPhone(String str)
		{		
			String s=str;
			String s2="";
			final StringBuilder result = new StringBuilder();

			for (int i = 0; i < s.length(); i++) {
				if (Character.isDigit(s.charAt(i)))
					result.append(s.charAt(i));
				}
			s2=result.toString();

			if (s2.length() == 10)
				return s2.substring(0, 3) + "-" + s2.substring(3, 6)  + "-" + s2.substring(6, 10);
			else
				return "";		
			}*/


	/**
	 * @param str: Any String 
	 * @return Returns True if the given String is numeric
	 * @author Ravi
	 * @DateCreated aug-21-2011
	 * 
	 */

	public static boolean isNumeric(String str)
	{
		//Return false if we find a non-digit character.
		String s=str;
		for (int i = 0; i < s.length(); i++) {
			if (!Character.isDigit(s.charAt(i)))
				return false;
		}
		return true;
	}


	/**
	 * @param str: Any String 
	 * @return Returns True if the given String has no digit, else False
	 * @author Ravi
	 * @Date aug-21-2011
	 * 
	 */

	public static boolean isAlpha(String str)
	{
		//Return false if we find a non-digit character.
		String s=str;
		for (int i = 0; i < s.length(); i++) {
			if (s.charAt(i) >= 'A' && s.charAt(i) <= 'Z'|| s.charAt(i) >= 'a' && s.charAt(i) <= 'z') 			
				return false;
		}
		return true;
	}



	/**
	 * @param str: Any String 
	 * @return String removing special characters
	 * @author Ravi
	 * @DateCreated aug-21-2011
	 * 
	 */

	public static String removeSplChars(String str)
	{
		//remove special character.				
		String s=str;
		final StringBuilder result = new StringBuilder();

		for (int i = 0; i < s.length(); i++) { //s.charAt(i) != '.' ||
			if (s.charAt(i) == '?' || s.charAt(i) == '!' || s.charAt(i) == '&' || s.charAt(i) == '>' || +
					s.charAt(i) == '<' || s.charAt(i) == '#' || s.charAt(i) == '$' || s.charAt(i) == '(' || +
					s.charAt(i) == ')' || s.charAt(i) == '[' || s.charAt(i) == ']' || s.charAt(i) == '{' || +
					s.charAt(i) == '}' || s.charAt(i) == '%' || s.charAt(i) == '*' || s.charAt(i) == '+' || +
					s.charAt(i) == '\t' || s.charAt(i) == ',' || s.charAt(i) == ';' || s.charAt(i) == ':' || + 			
					s.charAt(i) == '/' || s.charAt(i) == '=' || s.charAt(i) == '@' ||  s.charAt(i) != '-' ||+		
					s.charAt(i) == '^' || s.charAt(i) == '_' || s.charAt(i) == '"' || s.charAt(i) == '`' || +
					s.charAt(i) == '~' || s.charAt(i) == '|' || s.charAt(i) == '\\' || s.charAt(i) == '\'') {}
			else
				result.append(s.charAt(i));
		}  //end of for loop
		return result.toString();
	}


	/**
	 * @param str: Any String 
	 * @return Formatted SSN
	 * @author Mihir
	 * @DateCreated : Oct-04-2011
	 * 
	 */

	public static String formatSSN(String str)
	{		
		String s=str;
		String s2="";
		StringBuilder result = new StringBuilder();

		for (int i = 0; i < s.length(); i++) {
			if (Character.isDigit(s.charAt(i)))
				result.append(s.charAt(i));
		}
		s2=result.toString();

		if (s2.length() == 9)
			return s2.substring(0, 3) + "-" + s2.substring(3,5)  + "-" + s2.substring(5, 9);
		else
			return "";	
	}



	/**
	 * @param strDate: String format of Date
	 * @param strDatePattern: Pattern of String date without special character 
	 * 				(Supported format: MMDDYY, YYMMDD,MMDDYYYY,YYYYDDMM,YYYYMMDD  )
	 * @return String Containing Formatted DOB
	 * @throws Exception
	 * @author Mihir
	 * @ModifiedBy Jay
	 */

	public static String formatDateTo_MMDDYYYY(String strDOB, String strDatePattern)  throws Exception
	{		
		String s=removeSplChars(strDOB);

		if (strDatePattern.equals("MMDDYY"))
		{
			return s.substring(0,2) + "/" + s.substring(2,4) + "/" + s.substring(4,6);
		}
		else if (strDatePattern.equals("YYMMDD"))
		{
			return s.substring(2,4) + "/" + s.substring(4,6) + "/" + s.substring(0,2);
		}
		else if (strDatePattern.equals("MMDDYYYY"))
		{
			return s.substring(0,2) + "/" + s.substring(2,4) + "/" + s.substring(4,8);
		}
		else if (strDatePattern.equals("YYYYDDMM"))
		{
			return s.substring(6,8) + "/" + s.substring(4,6) + "/" + s.substring(0,4);
		}
		else if (strDatePattern.equals("YYYYMMDD")){
			return s.substring(4,6) + "/" + s.substring(6,8) + "/" + s.substring(0,4);
		}
		else if (strDatePattern.equals("MM/DD/YYYY")){
			return s;
		}

		else
		{
			return "";
		}		
	}


	/**
	 * @param strDate: String format of Date
	 * @param strDatePattern: Pattern of String date (Provide the pattern in which the String is formatted - M or d or y )
	 *  					M = Month, d= Day (Small d), y (Small y) = Year , for ex. 01/01/2000 -> MM/dd/yyyy, 
	 *  					 20101005 -> yyyyMMdd ;   1/1/2000 -> MM/dd/YYYY,
	 * @return  Date in YYYY-MM-DD format, used by PTDOB field
	 * @throws Exception
	 * @author jay
	 */

	public static String formatDate_PTDOB_YYYYMMDD(String strDate, String strDateInputPattern) throws Exception
	{	
		DateFormat formatterInput;
		DateFormat formatterOutput;

		if (strDate.equals(""))
			return "";

		if ( strDateInputPattern == "")
		{
			strDateInputPattern = "MM/DD/yyyy";
		}

		formatterInput = new SimpleDateFormat(strDateInputPattern);
		Date date = formatterInput.parse(strDate);

		formatterOutput = new SimpleDateFormat("yyyy-MM-DD");

		return formatterOutput.format(date);		
	}

	/**
	 * @param strDate: String format of Date
	 * @param strDatePattern: Pattern of String date (Provide the pattern in which the String is formatted - M or d or y )
	 *  					M = Month, d= Day (Small d), y (Small y) = Year , for ex. 01/01/2000 -> MM/dd/yyyy, 
	 *  					 20101005 -> yyyyMMdd ;   1/11/2000 -> MM/dd/YYYY,
	 * @return  Date in MM/DD/YYYY format, used by DOB field
	 * @throws Exception
	 * @author jay
	 */

	public static String formatDate_DOB_MMDDYYYY(String strDate, String strDateInputPattern) throws Exception
	{	
		DateFormat formatterInput;
		DateFormat formatterOutput;


		if (strDate.equals("") || strDate==null)
			return "";

		if ( strDateInputPattern == "")
		{
			strDateInputPattern = "MM/dd/yyyy";
		}

		formatterInput = new SimpleDateFormat(strDateInputPattern);
		Date date = formatterInput.parse(strDate);

		formatterOutput = new SimpleDateFormat("MM/dd/yyyy");

		return formatterOutput.format(date);		
	}




	/**
	 * @param  <<strStartTime>>          String format of TIME
	 * @param  <<strDatePattern>>        "HH:mm:ss"
	 * @return <<Time>>  in HH:mm:ss format, used Appointment start time
	 * @throws Exception
	 * author: Ravi
	 * Date  : Nov/1/2012    UNDER TESTING - DONT USE
	 */

	public static String getTime_from_Duration(String strStartTime, String strMinutes, String strDateInputPattern) throws Exception
	{	
		// String strEndTime = "";

		String[] splitsTime = strStartTime.split(":");


		String min = splitsTime[1];
		String hrs = splitsTime[0];
		String time = hrs + ":" + min;
		if (strStartTime.equals(""))
			return "";

		if ( strDateInputPattern == "")
		{
			strDateInputPattern = "HH:mm:ss";
			//strDateInputPattern = "HHmm";
		}

		SimpleDateFormat format = new SimpleDateFormat(strDateInputPattern);
		Date startDate = format.parse(time);
		Calendar calendar = new GregorianCalendar();
		calendar.setTime(startDate);
		calendar.add(Calendar.MINUTE, Integer.parseInt(strMinutes));
		return format.format(calendar.getTime());
	}



	/**
	 * @param deceased
	 * @return  dear or alive
	 * @author Niteesh
	 */
	public static String convertDeceased(String strDeceased){

		String dCode="";

		if(strDeceased.equalsIgnoreCase("D") || strDeceased.equalsIgnoreCase("Dead")){
			dCode="1";
		}
		else if(strDeceased.equalsIgnoreCase("A") || strDeceased.equalsIgnoreCase("Alive")){
			dCode="0";
		}
		else{
			dCode="0";
		}
		return dCode;
	}


	/**
	 * @param Patient status
	 * @return  Active or Inactive 
	 * @author Niteesh
	 */
	public static String convertStatus(String strStatus){

		String dCode="";

		if(strStatus.equalsIgnoreCase("T") || strStatus.equalsIgnoreCase("True")){
			dCode="1";
		}
		else{
			dCode="0";
		}
		return dCode;
	}

	/**
	 * @param strSex
	 * @return  male or female
	 * @author Jay
	 */
	public static String convertSex(String strSex)
	{
		String strResult = "";

		if (strSex.equalsIgnoreCase("MALE") || strSex.equalsIgnoreCase("M"))
		{
			strResult = "M";
		}
		else if (strSex.equalsIgnoreCase("FEMA") || strSex.equalsIgnoreCase("F"))
		{
			strResult = "F";
		}
		else
		{
			strResult = "";
		}

		return strResult;
	}


	/**
	 * @param strZip
	 * @return
	 * @author Jay
	 */
	public static String convertZip(String strZip)
	{
		if(strZip.equals("")) return "";
		strZip = removeSplChars(strZip);

		StringBuffer sbResult = new StringBuffer();
		strZip = strZip.trim();

		if(strZip.length() >=9 )
		{
			sbResult.append(strZip.substring(0, 4)).append("-").append(strZip.substring(5, 8));
		}
		else if (strZip.length()> 5  && strZip.length()< 9)
		{
			sbResult.append(strZip.substring(0, 4));
		}
		else if (strZip.length() <=5)
		{
			//Prefix 0
			int i = 0;
			for(i=0 ;i < 5 - strZip.length(); i++)
			{
				sbResult.append("0");
			}
			sbResult.append(strZip);
		}

		return sbResult.toString();

	}


	/**
	 * @param strMaritalStatus
	 * @return
	 * @author Jay
	 */

	public static String convertMaritalStatus(String strMaritalStatus)
	{
		String strResult = "";

		strMaritalStatus = removeSplChars(strMaritalStatus);

		if (strMaritalStatus.equalsIgnoreCase("M") || strMaritalStatus.equalsIgnoreCase("Married") || strMaritalStatus.equalsIgnoreCase("2"))
		{
			strResult  = "Married";
		}
		else if (strMaritalStatus.equalsIgnoreCase("S") || strMaritalStatus.equalsIgnoreCase("Single") || strMaritalStatus.equalsIgnoreCase("3"))
		{
			strResult  = "Single";
		}
		else if (strMaritalStatus.equalsIgnoreCase("W") || strMaritalStatus.equalsIgnoreCase("Widowed") || strMaritalStatus.equalsIgnoreCase("4"))
		{
			strResult  = "Widowed";
		}
		else if (strMaritalStatus.equalsIgnoreCase("D") || strMaritalStatus.equalsIgnoreCase("Divorced") || strMaritalStatus.equalsIgnoreCase("0"))
		{
			strResult  = "Divorced";
		}
		else if (strMaritalStatus.equalsIgnoreCase("P") || strMaritalStatus.equalsIgnoreCase("PARTNER"))
		{
			strResult  = "Partner";
		}
		else if (strMaritalStatus.equalsIgnoreCase("LS") || strMaritalStatus.equalsIgnoreCase("1")
				|| strMaritalStatus.equalsIgnoreCase("Legally separated") || strMaritalStatus.equalsIgnoreCase("SEPARATED"))
		{
			strResult  = "Legally Separated";
		}
		else
		{
			strResult = "Unknown";
		}

		return strResult;

	}





	public static String convertRace(String race)
	{
		String strResult="";


		if (race.equalsIgnoreCase("ASIAN") ||race.equalsIgnoreCase("A") || race.equalsIgnoreCase("2139"))
		{
			strResult  = "Asian";
		}
		else if (race.equalsIgnoreCase("BLACK OR AFRICAN AMERICAN") || race.equalsIgnoreCase("2233") || race.equalsIgnoreCase("2141") || race.equalsIgnoreCase("African American"))
		{
			strResult  = "Black or African American";
		}
		else if (race.equalsIgnoreCase("Caucasian") || race.equalsIgnoreCase("2140") || race.equalsIgnoreCase("2648"))
		{
			strResult  = "Caucasian";
		}
		else if (race.equalsIgnoreCase("Hispanic") || race.equalsIgnoreCase("2138"))
		{
			strResult  = "Hispanic";
		}
		else if (race.equalsIgnoreCase("AMERICAN INDIAN OR ALASKA NATIVE")||race.equalsIgnoreCase("2234")  || race.equalsIgnoreCase("2142"))
		{
			strResult  = "American Indian or Alaska Native";
		}
		else if (race.equalsIgnoreCase("Other")||race.equalsIgnoreCase("E") || race.equalsIgnoreCase("2143")  || race.equalsIgnoreCase("2145")  || race.equalsIgnoreCase("2146") || race.equalsIgnoreCase("2147") || race.equalsIgnoreCase("2149"))
		{
			strResult  = "Other Race";
		}
		else if (race.equalsIgnoreCase("P") || race.equalsIgnoreCase("2148") || race.equalsIgnoreCase("2150"))
		{
			strResult  = "Native Hawaiian or Other Pacific Islander";
		}
		else if (race.equalsIgnoreCase("Not Indicated") || race.equalsIgnoreCase("Unknown") || race.equalsIgnoreCase("2144"))
		{
			strResult  = "Unknown";
		}
		else if (race.equalsIgnoreCase("White") || race.equalsIgnoreCase("W") || race.equalsIgnoreCase("2649"))
		{
			strResult  = "White";
		}
		else
		{
			strResult = "Unreported/Refuse to Report";
		}

		return strResult;

	}

	/**
	 * @param strLanguage
	 * @return
	 * @author vishwanath.maity
	 */


	public static String convertLanguage(String language)
	{
		String strLanguage="";


		if (language.equalsIgnoreCase("2151")  )
		{
			strLanguage  = "English";
		}
		else if (language.equalsIgnoreCase("2152") )
		{
			strLanguage  = "French";
		}
		else if (language.equalsIgnoreCase("2153")  )
		{
			strLanguage  = "German";
		}
		else if (language.equalsIgnoreCase("2154")  )
		{
			strLanguage  = "Vietnamese";
		}
		else if (language.equalsIgnoreCase("2155")  )
		{
			strLanguage  = "Italian";
		}
		else if (language.equalsIgnoreCase("2156") )
		{
			strLanguage  = "Mandarin";
		}
		else if (language.equalsIgnoreCase("2157")  )
		{
			strLanguage  = "Spanish";
		}
		else if (language.equalsIgnoreCase("2646"))
		{
			strLanguage  = "Russian";
		}
		else if (language.equalsIgnoreCase("2647") )
		{
			strLanguage  = "English";
		}
		else
		{
			strLanguage = "English";
		}

		return strLanguage;

	}















	/**
	 * @param strEmpStatus
	 * @return
	 * @author Jay
	 */

	public static  String convertEmpStatus1(String strEmpStatus)
	{
		String strResult = "";
		strEmpStatus = removeSplChars(strEmpStatus);

		if (strEmpStatus.equalsIgnoreCase("F") || strEmpStatus.equalsIgnoreCase("E")|| strEmpStatus.equalsIgnoreCase("FULL TIME EMPLOYED")
				|| strEmpStatus.equalsIgnoreCase("Y") || strEmpStatus.equalsIgnoreCase("YES")|| strEmpStatus.equalsIgnoreCase("EMP")	)
		{
			strResult  = "1";
		}
		else if (strEmpStatus.equalsIgnoreCase("P") || strEmpStatus.equalsIgnoreCase("PART TIME") || strEmpStatus.equalsIgnoreCase("PART-TIME EMPLOYE") )
		{
			strResult  = "2";
		}
		else if (strEmpStatus.equalsIgnoreCase("N") || strEmpStatus.equalsIgnoreCase("NOT EMPLOYED") || strEmpStatus.equalsIgnoreCase("UNEMPLOYED")
				|| strEmpStatus.equalsIgnoreCase("NO") || strEmpStatus.equalsIgnoreCase("UNE"))
		{
			strResult  = "3";
		}
		else if (strEmpStatus.equalsIgnoreCase("S") || strEmpStatus.equalsIgnoreCase("SELF EMPLOYED") || strEmpStatus.equalsIgnoreCase("SELF EMPLOYED") )
		{
			strResult  = "4";
		}
		else if (strEmpStatus.equalsIgnoreCase("R") || strEmpStatus.equalsIgnoreCase("RETIRED") || strEmpStatus.equalsIgnoreCase("RET") )
		{
			strResult  = "5";
		}
		else if (strEmpStatus.equalsIgnoreCase("MILITARY") || strEmpStatus.equalsIgnoreCase("ACTIVE MILITARY DUTY") )
		{
			strResult  = "6";
		}
		else
		{
			strResult = "9";
		}

		return strResult;
	}






	public static  String convertEmpStatus(String strEmpStatus)
	{
		String strResult = "";
		strEmpStatus = removeSplChars(strEmpStatus);

		if (strEmpStatus.equalsIgnoreCase("F") || strEmpStatus.equalsIgnoreCase("2178")|| strEmpStatus.equalsIgnoreCase("246")
				|| strEmpStatus.equalsIgnoreCase("Full time") || strEmpStatus.equalsIgnoreCase("YES")|| strEmpStatus.equalsIgnoreCase("-1")	)
		{
			strResult  = "1";
		}
		else if (strEmpStatus.equalsIgnoreCase("2") || strEmpStatus.equalsIgnoreCase("Part time") || strEmpStatus.equalsIgnoreCase("PART-TIME EMPLOYE") )
		{
			strResult  = "2";
		}
		else if (strEmpStatus.equalsIgnoreCase("N") || strEmpStatus.equalsIgnoreCase("NOT EMPLOYED") || strEmpStatus.equalsIgnoreCase("Not employed")
				|| strEmpStatus.equalsIgnoreCase("NO") || strEmpStatus.equalsIgnoreCase("247"))
		{
			strResult  = "3";
		}
		else if (strEmpStatus.equalsIgnoreCase("S") || strEmpStatus.equalsIgnoreCase("SELF EMPLOYED") || strEmpStatus.equalsIgnoreCase("SELF EMPLOYED") )
		{
			strResult  = "4";
		}
		else if (strEmpStatus.equalsIgnoreCase("R") || strEmpStatus.equalsIgnoreCase("RETIRED") || strEmpStatus.equalsIgnoreCase("245") )
		{
			strResult  = "5";
		}
		else if (strEmpStatus.equalsIgnoreCase("MILITARY") || strEmpStatus.equalsIgnoreCase("ACTIVE MILITARY DUTY") )
		{
			strResult  = "6";
		}
		else
		{
			strResult = "9";
		}

		return strResult;
	}















	/**
	 * @param strStudentStatus
	 * @return
	 * @author Jay
	 */

	public static  String convertStudentStatus1(String strStudentStatus)
	{
		String strResult = "";
		//strStudentStatus = removeSplChars(strStudentStatus);

		if (strStudentStatus.equalsIgnoreCase("F") || strStudentStatus.equalsIgnoreCase("Full time")
				|| strStudentStatus.equalsIgnoreCase("FULLTIMESTUDENT") || strStudentStatus.equalsIgnoreCase("FTS"))
		{
			strResult  = "F";
		}
		else if (strStudentStatus.equalsIgnoreCase("P") || strStudentStatus.equalsIgnoreCase("Part time")
				|| strStudentStatus.equalsIgnoreCase("PARTTIMESTUDENT") || strStudentStatus.equalsIgnoreCase("PTS"))
		{
			strResult  = "P";
		}
		else if (strStudentStatus.equalsIgnoreCase("N") || strStudentStatus.equalsIgnoreCase("Non-student"))
		{
			strResult  = "N";
		}
		else
		{
			strResult = "";
		}
		System.out.println("Convert Student Status="+strResult);
		return strResult;
	}






	public static  String convertStudentStatus(String strStudentStatus)
	{
		String strResult = "";
		//strStudentStatus = removeSplChars(strStudentStatus);

		if (strStudentStatus.equalsIgnoreCase("F") || strStudentStatus.equalsIgnoreCase("FULL TIME")
				|| strStudentStatus.equalsIgnoreCase("FULLTIMESTUDENT") || strStudentStatus.equalsIgnoreCase("276"))
		{
			strResult  = "F";
		}
		else if (strStudentStatus.equalsIgnoreCase("P") || strStudentStatus.equalsIgnoreCase("PART TIME")
				|| strStudentStatus.equalsIgnoreCase("PARTTIMESTUDENT") || strStudentStatus.equalsIgnoreCase("0"))
		{
			strResult  = "P";
		}
		else if (strStudentStatus.equalsIgnoreCase("N") || strStudentStatus.equalsIgnoreCase("1"))
		{
			strResult  = "N";
		}
		else
		{
			strResult = "";
		}
		// System.out.println("Convert Student Status="+strResult);
		return strResult;
	}



	public static String convertReleseOfInfo(String str){
		String strResult="";
		if(str.equals("-1")){
			strResult="Y";
		}else{
			strResult="N";
		}
		return strResult;
	}












	public static String convertToProperCase(String name) {
		return name.toLowerCase().substring(0, 1).toUpperCase()+name.toLowerCase().substring(1);
	}

	public static String convertEthnicityStatus(String strEthnicity)
	{
		String strResult = "";

		strEthnicity = removeSplChars(strEthnicity);

		if (strEthnicity.equalsIgnoreCase("3")||strEthnicity.equalsIgnoreCase("NOT HISPANIC OR LATINO"))
		{
			strResult  = "2186-5";
		}
		else if (strEthnicity.equalsIgnoreCase("H") ||  strEthnicity.equalsIgnoreCase("HISPANIC OR LATINO") )
		{
			strResult  = "2135-2";
		}

		else if (strEthnicity.equalsIgnoreCase("PATIENT DECLINED"))
		{
			strResult = "2145-2";
		}
		else
		{
			strResult = "";
		}

		return strResult;

	}

	public static String convertReportType(String reportType) {
		String strResult = "";

		if(reportType==null){
			strResult = "";
		}

		if(reportType.equalsIgnoreCase("Numeric"))
		{
			strResult = "N";
		} 
		else if(reportType.equalsIgnoreCase("C/S"))
		{
			strResult = "C";
		}
		else if(reportType.equalsIgnoreCase("Findings"))
		{
			strResult = "F";
		}

		else if(reportType.equalsIgnoreCase("General Profile"))
		{
			strResult = "G";
		}

		else if(reportType.equalsIgnoreCase("R/M"))
		{
			strResult = "R";
		}

		else if(reportType.equalsIgnoreCase("Text"))
		{
			strResult = "T";
		}else
		{
			strResult="";
		}
	
		return strResult;
	}

	public static String convertCategoryType(String categoryType) {
		String strResult = "";

		if(categoryType==null){
			strResult = "";
		}

		if(categoryType.equalsIgnoreCase("General"))
		{
			strResult = "GN";
		} 
		else if(categoryType.equalsIgnoreCase("Age and Gender"))
		{
			strResult = "AG";
		}
		else if(categoryType.equalsIgnoreCase("Age Wise"))
		{
			strResult = "AW";
		}

		else if(categoryType.equalsIgnoreCase("Gender"))
		{
			strResult = "G";
		}
		else
		{
			strResult="";
		}
	
		return strResult;
	}

	


}
