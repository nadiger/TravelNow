package com.migration.lib;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.Format;
import java.util.HashMap;
import java.util.Map;




public class CommonFunction {
	
	static Map<String, String> states = new HashMap<String, String>();


	public CommonFunction(){
	}
	
	
	public static String convertSex(String strSex){
    strSex=strSex.toLowerCase();
    if (strSex == "1" || strSex == "male" || strSex == "m"){
    	strSex = "male";
    }
    else
    if (strSex == "f" || strSex == "female" || strSex == "2"|| strSex == "-1"){
    	strSex = "female";
    }
    else {
    strSex = "unknown";
	}
    return strSex;
	}
	
	public static String ConvertAlphaNumberic(String foo) {
	    char charArray[] = new char[0];
	    String strReturn="";
	    if (foo.length() > 0) // must have 1 digit at least
	    {
	      charArray = new char[foo.length()];
	      foo.getChars(0, (foo.length()), charArray, 0); //put string into char array
	      for (int intIndex = 0; intIndex < foo.length(); intIndex++)
	      {
	        if (Character.isDigit(charArray[intIndex]) == true)
	        {
	          //if it's a number add it to the string.
	          strReturn = strReturn + charArray[intIndex];
	        }
	      }
	      return (strReturn); //return the integer value of the string.
	    }
	    return ""; //return 0 if there was a 0 length argument.
	  }
	
	public static String convertSubmitType(String strSubmit){
		strSubmit=strSubmit.toLowerCase();
	    if (strSubmit.equals("paper") || strSubmit .equals("p")) {
	    	strSubmit = "1";
	    }
	    else
	    if (strSubmit .equals("electronic") || strSubmit .equals("e")){
	    	strSubmit = "0";
	    }
	    else {
	    	strSubmit = "0";
		}
	    return strSubmit;
		}
	
	
		
    public static String toState(String s) { 
		states.put("Alabama","AL");
		states.put("Alaska","AK");
		states.put("Alberta","AB");
		states.put("American Samoa","AS");
		states.put("Arizona","AZ");
		states.put("Arkansas","AR");
		states.put("Armed Forces (AE)","AE");
		states.put("Armed Forces Americas","AA");
		states.put("Armed Forces Pacific","AP");
		states.put("British Columbia","BC");
		states.put("California","CA");
		states.put("Colorado","CO");
		states.put("Connecticut","CT");
		states.put("Delaware","DE");
		states.put("District Of Columbia","DC");
		states.put("Florida","FL");
		states.put("Georgia","GA");
		states.put("Guam","GU");
		states.put("Hawaii","HI");
		states.put("Idaho","ID");
		states.put("Illinois","IL");
		states.put("Indiana","IN");
		states.put("Iowa","IA");
		states.put("Kansas","KS");
		states.put("Kentucky","KY");
		states.put("Louisiana","LA");
		states.put("Maine","ME");
		states.put("Manitoba","MB");
		states.put("Maryland","MD");
		states.put("Massachusetts","MA");
		states.put("Michigan","MI");
		states.put("Minnesota","MN");
		states.put("Mississippi","MS");
		states.put("Missouri","MO");
		states.put("Montana","MT");
		states.put("Nebraska","NE");
		states.put("Nevada","NV");
		states.put("New Brunswick","NB");
		states.put("New Hampshire","NH");
		states.put("New Jersey","NJ");
		states.put("New Mexico","NM");
		states.put("New York","NY");
		states.put("Newfoundland","NF");
		states.put("North Carolina","NC");
		states.put("North Dakota","ND");
		states.put("Northwest Territories","NT");
		states.put("Nova Scotia","NS");
		states.put("Nunavut","NU");
		states.put("Ohio","OH");
		states.put("Oklahoma","OK");
		states.put("Ontario","ON");
		states.put("Oregon","OR");
		states.put("Pennsylvania","PA");
		states.put("Prince Edward Island","PE");
		states.put("Puerto Rico","PR");
		states.put("Quebec","PQ");
		states.put("Rhode Island","RI");
		states.put("Saskatchewan","SK");
		states.put("South Carolina","SC");
		states.put("South Dakota","SD");
		states.put("Tennessee","TN");
		states.put("Texas","TX");
		states.put("Utah","UT");
		states.put("Vermont","VT");
		states.put("Virgin Islands","VI");
		states.put("Virginia","VA");
		states.put("Washington","WA");
		states.put("West Virginia","WV");
		states.put("Wisconsin","WI");
		states.put("Wyoming","WY");
		states.put("Yukon Territory","YT");
		
        return states.get(s);
    }
    
	public static String convertSSN(String strSSN){
    strSSN = removeNonChar(strSSN);
	strSSN = String.format(strSSN, "000-00-0000");
    if (strSSN.length() == 7){
        strSSN = "00" + strSSN;
    }

    if (strSSN.length() == 8){
        strSSN = "0" + strSSN;
    }

    if (strSSN.length() == 9){
    	strSSN = strSSN.substring(0, 3) + "/" + strSSN.substring(3, 5) + "/" + strSSN.substring(5, 9);
    }
    else{
    	strSSN = "";
	}
	return strSSN;}
	
	public static String convertPtDob(String strDob){
		strDob = String.format(strDob, "YYYY/MM/DD");
    if (strDob == ""){
    	strDob = "0000-00-00";
    }
	return strDob;
	}
	
	public static String convertDOB(String strDob) {
        strDob = removeNonChar(strDob);
        if (strDob.length() == 8 || strDob.length() == 6){
        	int datetype = 0;
			switch(datetype){
//        	case "MMDDYY":
			case 1:
        	strDob = strDob.substring(0, 2) + "/" + strDob.substring(2, 4) + "/" + strDob.substring(4, 6);
//        	case "YYMMDD":
			case 2:
            strDob = strDob.substring(4, 6) + "/" + strDob.substring(0, 2) + "/" + strDob.substring(2, 4);
//        	case "MMDDYYYY":
			case 3:
            strDob = strDob.substring(0, 2) + "/" + strDob.substring(2, 4) + "/" + strDob.substring(4, 8);
//        	case "YYYYDDMM":
			case 4:
            strDob = strDob.substring(4, 8) + "/" + strDob.substring(2, 4) + "/" + strDob.substring(0, 2);
//        	case "YYYYMMDD":
			case 5:
            strDob = strDob.substring(4, 8) + "/" + strDob.substring(2, 4) + "/" + strDob.substring(0, 2);
        	}}
        else if (strDob.length() == 7){
        //strDob = strDob.substring(0, 2) + "/" + strDob.substring(2, 4) + "/" + strDob.substring(4, 6);
        
        }
        else{
            strDob = "";
            }
        	return strDob = String.format(strDob, "MM/DD/YYYY");
	}
	
	public static String convertzip(String zip2) {
		// TODO Auto-generated method stub
		zip2 = removeNonChar(zip2);
		
		if (zip2 == "0"){
			zip2 = "";
		}
		
	   switch(zip2.length()){
	   case 1:
		   zip2 = "0000" + zip2;
	   case 2: case 6:
		   zip2 = "000" + zip2; 
	   case 3: case 7:
		   zip2 = "00" + zip2; 
	   case 4: case 8:
		   zip2 = "0" + zip2; 
	   case 5:
		   zip2 = zip2;
	   }
	   
	   if (zip2.length() == 9){
		   if (zip2 == "000000000"){
			   zip2 = "";
		   }
		   else{
			   zip2 = zip2.substring(0, 5) + "-" + zip2.substring(5, 9);
		   }
	   }
	   else{
		   if (zip2 == "00000"){
			   zip2 = "";
		   }
		   else{
			   zip2 = zip2;
		   }
			   
	   }
	   
		return zip2;
	}
    


	public static String convertPhone(String telno) {
		// TODO Auto-generated method stub
		telno = removeNonChar(telno);
		
		if (telno.length() == 10){
		if (telno == "0000000000"){
			telno = "";
		}
		else
		{
		telno = telno.substring(0, 3) + "-" + telno.substring(3, 6) + "-" + telno.substring(6, 10);
		telno = String.format(telno, "000-000-0000");

		}
		}
		else if (telno.length() == 7) {
		if (telno == "0000000"){
				telno = "";
			}
		else
			{
			
			telno = "___-" + telno.substring(0, 3) + "-" + telno.substring(3, 7);
			telno = String.format(telno, "000-0000");
			}
		}
		else
		{
			telno = "";
		}
		return telno;
		
	}



	public static String removeNonChar(String telno) {
		telno = telno.replace(" ", "");
		telno = telno.replace("'", "");
		telno = telno.replace("-", "");
		telno = telno.replace("/", "");
		telno = telno.replace("(", "");
		telno = telno.replace(")", "");
		telno = telno.replace("-", "");
		return telno;
	}
	
	/*
	
	
	*/
	public static String convertDate(String strDob,String Dateformat, String FormatRequired) throws Exception {
		//strDob = removeNonChar(strDob);

		String y = "";
		String m = "";
		String d = "";
		strDob=JUtil.formatDate_DOB_MMDDYYYY(strDob, "MM/dd/yyyy"); // Replace all - by / => 13-03-2016 -> 13/03/2016
		if(!strDob.equals("") && strDob!=null){
			if(Dateformat.equals("MMDDYYYY")) // With no - or / in between
			{
				if(FormatRequired.equals("YYYY-MM-DD"))
				{
					y = strDob.substring(4,8);
					m = strDob.substring(0,2);
					d = strDob.substring(2,4);
					strDob = y+"/"+m+"/"+d;
				}
				if(FormatRequired.equals("MM-DD-YYYY"))
				{
					y = strDob.substring(4,8);
					m = strDob.substring(0,2);
					d = strDob.substring(2,4);
					strDob = m+"/"+d+"/"+y;
				}

			}
			if(Dateformat.equals("YYYYMMDD")) // With no - or / in between
			{
				if(FormatRequired.equals("YYYY-MM-DD"))
				{
					y = strDob.substring(0,4);
					m = strDob.substring(4,6);
					d = strDob.substring(6,8);
					strDob =  y+"/"+m+"/"+d;
				}
				if(FormatRequired.equals("MM-DD-YYYY"))
				{
					y = strDob.substring(0,4);
					m = strDob.substring(4,6);
					d = strDob.substring(6,8);
					strDob = m+"/"+d+"/"+y;
				}
			}

			if(Dateformat.equals("YYYY-MM-DD")) 
			{
				/*if(FormatRequired.equals("YYYY-MM-DD"))
        		{

        		}*/
				if(FormatRequired.equals("MM-DD-YYYY")) //
				{
					y = strDob.substring(0,4);
					m = strDob.substring(5,7);
					d = strDob.substring(8,10);
					strDob = m+"/"+d+"/"+y;
				}
			}


			if(Dateformat.equals("MM-DD-YYYY")) 
			{
				if(FormatRequired.equals("YYYY-MM-DD"))//05-16-1958
				{
					y = strDob.substring(6,10);
					m = strDob.substring(0,2);
					d = strDob.substring(3,5);
					strDob = y+"/"+m+"/"+d;
				}
				/*if(FormatRequired.equals("MM-DD-YYYY"))
        		{

        		}*/
			}


		}
		else{
			strDob = "";
		}

		return strDob;
	
	}
	
	
	
	
	
	
	

}
