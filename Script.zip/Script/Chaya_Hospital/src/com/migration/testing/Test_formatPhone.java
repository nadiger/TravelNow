package com.migration.testing;

import java.sql.Connection;

import com.migration.form.DBConnection;
import com.migration.form.PMMigUI;
import com.migration.lib.CommonFunction;
import com.migration.lib.JUtil;
import com.migration.lib.PatientDemographicsLib;

public class Test_formatPhone {

	private static Connection getConnection() throws Exception{
		Connection connDes2 = DBConnection.getDSNConnection("GNRC","sa","Pwd4db@114");
		return connDes2;
	}
	
	public static void main(String[] args) throws Exception {

		System.out.println(PatientDemographicsLib.getTitleByProcedureCall("",getConnection()));

	}

}
