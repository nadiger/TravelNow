/*
*UsersBean.java
*/
package com.migration.model;

import com.migration.lib.CommonFunction;
import com.migration.lib.JUtil;

/*
 *  @author mihir.patel
 *  @ModifiedBy Jay
 */

public class PatientDemographicsBean {
	// Variables Declared Here

	private String RegistrationNo="";
	private String RegistrationDate="";
	private String TitleID="";
	private String FirstName="";
	private String MiddleName="";
	private String LastName="";
	private String GuardianName="";
	private String DOB="";
	private String AgeYear="";
	private String AgeMonth="";
	private String AgeDay="";
	private String Gender="";
	private String BloodGroupID="";
	private String MaritalStatusID="";
	private String OccupationID="";
	private String ReligionID="";
	private String NationalityID="";
	private String PassportNo="";
	private String ConsultantID="";
	private String ReferralID="";
	private String SponsorID="";
	private String InsuranceID="";
	private String EmployeeID="";
	private String RelationID="";
	private String LocalAddress1="";
	private String LocalAddress2="";
	private String LocalAreaID="";
	private String LocalCityID="";
	private String LocalPostalCode="";
	private String LocalPhoneOff="";
	private String LocalPhoneRes="";
	private String PermanentAddress1="";
	private String PermanentAddress2="";
	private String PermanentAreaID="";
	private String PermanentCityID="";
	private String PermanentPostalCode="";
	private String PermanentPhoneOff="";
	private String PermanentPhoneRes="";
	private String Mobile="";
	private String Email="";
	private String ContactPerson="";
	private String ContactPersonMobile="";
	private String SpecialNote="";
	private String Status="";
	private String EncodedBy="";
	private String EncodedDate="";
	private String LastChangedBy="";
	private String LastChangedDate="";
	private String PlaceofIssue="";
	private String DateofExpiry="";
	private String MedicalAlerts="";
	private String Photo="";
	private String LocalStdCode="";
	private String LocalIsdCode="";
	private String PermanentStdCode="";
	private String PermanentIsdCode="";
	private String Category="";
	private String OLDUrg="";
	private String VIP="";
	private String LocationID="";
	private String Father="";
	private String Mother="";
	private String Husband="";
	private String UHID="";
	private String UHIDNew="";
	private String ReferralType_ID="";
	private String Handlewithcare="";
	private String HWCRemarks="";
	private String Pancard="";
	private String AadharCard="";
	private String CareOfID="";
	private String HouseNo="";
	private String PoliceStation="";
	private String PostOffice="";
	private String CCountryID="";
	private String CStateID="";
	private String CDistrictID="";
	private String CMandalID="";
	private String CVillageID="";
	private String CPhonetypeID="";
	private String CPhoneNo="";
	private String MLCNONMLC="";
	private String GaliMohalla="";
	private String CPincode="";
	private String DischargeType_ID="";
	private String DobStatus="";
	private String TOR="";
	private String EncodedName="";
	private String LastchangedName="";
	private String euid="";
	private String uid="";
	
	
	
	
	/*
	 * RegistrationNo
	 */
	public String getRegistrationNo() {
		return RegistrationNo;
	}

	public void setRegistrationNo(String registrationNo) {
		RegistrationNo = registrationNo;
	}

	
	/*
	 * RegistrationDate
	 */
	
	public String getRegistrationDate() {
		return RegistrationDate;
	}

	public void setRegistrationDate(String registrationDate) {
		RegistrationDate = registrationDate;
	}

	
	/*
	 * TitleID
	 */
	
	public String getTitleID() {
		return TitleID;
	}

	public void setTitleID(String titleID) {
		TitleID = titleID;
	}

	
	
	
	public String getFirstName() {
		return FirstName;
	}

	public void setFirstName(String firstName) {
		FirstName = firstName;
	}

	public String getMiddleName() {
		return MiddleName;
	}

	public void setMiddleName(String middleName) {
		MiddleName = middleName;
	}

	public String getLastName() {
		return LastName;
	}

	public void setLastName(String lastName) {
		LastName = lastName;
	}

	public String getGuardianName() {
		return GuardianName;
	}

	public void setGuardianName(String guardianName) {
		GuardianName = guardianName;
	}

	public String getDOB() {
		return DOB;
	}

	public void setDOB(String dOB) {
		DOB = dOB;
	}

	public String getAgeYear() {
		return AgeYear;
	}

	public void setAgeYear(String ageYear) {
		AgeYear = ageYear;
	}

	public String getAgeMonth() {
		return AgeMonth;
	}

	public void setAgeMonth(String ageMonth) {
		AgeMonth = ageMonth;
	}

	public String getAgeDay() {
		return AgeDay;
	}

	public void setAgeDay(String ageDay) {
		AgeDay = ageDay;
	}

	public String getGender() {
		return Gender;
	}

	public void setGender(String gender) {
		Gender = gender;
	}

	public String getBloodGroupID() {
		return BloodGroupID;
	}

	public void setBloodGroupID(String bloodGroupID) {
		BloodGroupID = bloodGroupID;
	}

	public String getMaritalStatusID() {
		return MaritalStatusID;
	}

	public void setMaritalStatusID(String maritalStatusID) {
		MaritalStatusID = maritalStatusID;
	}

	public String getOccupationID() {
		return OccupationID;
	}

	public void setOccupationID(String occupationID) {
		OccupationID = occupationID;
	}

	public String getReligionID() {
		return ReligionID;
	}

	public void setReligionID(String religionID) {
		ReligionID = religionID;
	}

	public String getNationalityID() {
		return NationalityID;
	}

	public void setNationalityID(String nationalityID) {
		NationalityID = nationalityID;
	}

	public String getPassportNo() {
		return PassportNo;
	}

	public void setPassportNo(String passportNo) {
		PassportNo = passportNo;
	}

	public String getConsultantID() {
		return ConsultantID;
	}

	public void setConsultantID(String consultantID) {
		ConsultantID = consultantID;
	}

	public String getReferralID() {
		return ReferralID;
	}

	public void setReferralID(String referralID) {
		ReferralID = referralID;
	}

	public String getSponsorID() {
		return SponsorID;
	}

	public void setSponsorID(String sponsorID) {
		SponsorID = sponsorID;
	}

	public String getInsuranceID() {
		return InsuranceID;
	}

	public void setInsuranceID(String insuranceID) {
		InsuranceID = insuranceID;
	}

	public String getEmployeeID() {
		return EmployeeID;
	}

	public void setEmployeeID(String employeeID) {
		EmployeeID = employeeID;
	}

	public String getRelationID() {
		return RelationID;
	}

	public void setRelationID(String relationID) {
		RelationID = relationID;
	}

	public String getLocalAddress1() {
		return LocalAddress1;
	}

	public void setLocalAddress1(String localAddress1) {
		LocalAddress1 = localAddress1;
	}

	public String getLocalAddress2() {
		return LocalAddress2;
	}

	public void setLocalAddress2(String localAddress2) {
		LocalAddress2 = localAddress2;
	}

	public String getLocalAreaID() {
		return LocalAreaID;
	}

	public void setLocalAreaID(String localAreaID) {
		LocalAreaID = localAreaID;
	}

	public String getLocalCityID() {
		return LocalCityID;
	}

	public void setLocalCityID(String localCityID) {
		LocalCityID = localCityID;
	}

	public String getLocalPostalCode() {
		return LocalPostalCode;
	}

	public void setLocalPostalCode(String localPostalCode) {
		LocalPostalCode = localPostalCode;
	}

	public String getLocalPhoneOff() {
		return LocalPhoneOff;
	}

	public void setLocalPhoneOff(String localPhoneOff) {
		LocalPhoneOff = localPhoneOff;
	}

	public String getLocalPhoneRes() {
		return LocalPhoneRes;
	}

	public void setLocalPhoneRes(String localPhoneRes) {
		LocalPhoneRes = localPhoneRes;
	}

	public String getPermanentAddress1() {
		return PermanentAddress1;
	}

	public void setPermanentAddress1(String permanentAddress1) {
		PermanentAddress1 = permanentAddress1;
	}

	public String getPermanentAddress2() {
		return PermanentAddress2;
	}

	public void setPermanentAddress2(String permanentAddress2) {
		PermanentAddress2 = permanentAddress2;
	}

	public String getPermanentAreaID() {
		return PermanentAreaID;
	}

	public void setPermanentAreaID(String permanentAreaID) {
		PermanentAreaID = permanentAreaID;
	}

	public String getPermanentCityID() {
		return PermanentCityID;
	}

	public void setPermanentCityID(String permanentCityID) {
		PermanentCityID = permanentCityID;
	}

	public String getPermanentPostalCode() {
		return PermanentPostalCode;
	}

	public void setPermanentPostalCode(String permanentPostalCode) {
		PermanentPostalCode = permanentPostalCode;
	}

	public String getPermanentPhoneOff() {
		return PermanentPhoneOff;
	}

	public void setPermanentPhoneOff(String permanentPhoneOff) {
		PermanentPhoneOff = permanentPhoneOff;
	}

	public String getPermanentPhoneRes() {
		return PermanentPhoneRes;
	}

	public void setPermanentPhoneRes(String permanentPhoneRes) {
		PermanentPhoneRes = permanentPhoneRes;
	}

	public String getMobile() {
		return Mobile;
	}

	public void setMobile(String mobile) {
		Mobile = mobile;
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}

	public String getContactPerson() {
		return ContactPerson;
	}

	public void setContactPerson(String contactPerson) {
		ContactPerson = contactPerson;
	}

	public String getContactPersonMobile() {
		return ContactPersonMobile;
	}

	public void setContactPersonMobile(String contactPersonMobile) {
		ContactPersonMobile = contactPersonMobile;
	}

	public String getSpecialNote() {
		return SpecialNote;
	}

	public void setSpecialNote(String specialNote) {
		SpecialNote = specialNote;
	}

	public String getStatus() {
		return Status;
	}

	public void setStatus(String status) {
		Status = status;
	}

	public String getEncodedBy() {
		return EncodedBy;
	}

	public void setEncodedBy(String encodedBy) {
		EncodedBy = encodedBy;
	}

	public String getEncodedDate() {
		return EncodedDate;
	}

	public void setEncodedDate(String encodedDate) {
		EncodedDate = encodedDate;
	}

	public String getLastChangedBy() {
		return LastChangedBy;
	}

	public void setLastChangedBy(String lastChangedBy) {
		LastChangedBy = lastChangedBy;
	}

	public String getLastChangedDate() {
		return LastChangedDate;
	}

	public void setLastChangedDate(String lastChangedDate) {
		LastChangedDate = lastChangedDate;
	}

	public String getPlaceofIssue() {
		return PlaceofIssue;
	}

	public void setPlaceofIssue(String placeofIssue) {
		PlaceofIssue = placeofIssue;
	}

	public String getDateofExpiry() {
		return DateofExpiry;
	}

	public void setDateofExpiry(String dateofExpiry) {
		DateofExpiry = dateofExpiry;
	}

	public String getMedicalAlerts() {
		return MedicalAlerts;
	}

	public void setMedicalAlerts(String medicalAlerts) {
		MedicalAlerts = medicalAlerts;
	}

	public String getPhoto() {
		return Photo;
	}

	public void setPhoto(String photo) {
		Photo = photo;
	}

	public String getLocalStdCode() {
		return LocalStdCode;
	}

	public void setLocalStdCode(String localStdCode) {
		LocalStdCode = localStdCode;
	}

	public String getLocalIsdCode() {
		return LocalIsdCode;
	}

	public void setLocalIsdCode(String localIsdCode) {
		LocalIsdCode = localIsdCode;
	}

	public String getPermanentStdCode() {
		return PermanentStdCode;
	}

	public void setPermanentStdCode(String permanentStdCode) {
		PermanentStdCode = permanentStdCode;
	}

	public String getPermanentIsdCode() {
		return PermanentIsdCode;
	}

	public void setPermanentIsdCode(String permanentIsdCode) {
		PermanentIsdCode = permanentIsdCode;
	}

	public String getCategory() {
		return Category;
	}

	public void setCategory(String category) {
		Category = category;
	}

	public String getOLDUrg() {
		return OLDUrg;
	}

	public void setOLDUrg(String oLDUrg) {
		OLDUrg = oLDUrg;
	}

	public String getVIP() {
		return VIP;
	}

	public void setVIP(String vIP) {
		VIP = vIP;
	}

	public String getLocationID() {
		return LocationID;
	}

	public void setLocationID(String locationID) {
		LocationID = locationID;
	}

	public String getFather() {
		return Father;
	}

	public void setFather(String father) {
		Father = father;
	}

	public String getMother() {
		return Mother;
	}

	public void setMother(String mother) {
		Mother = mother;
	}

	public String getHusband() {
		return Husband;
	}

	public void setHusband(String husband) {
		Husband = husband;
	}

	public String getUHID() {
		return UHID;
	}

	public void setUHID(String uHID) {
		UHID = uHID;
	}

	public String getUHIDNew() {
		return UHIDNew;
	}

	public void setUHIDNew(String uHIDNew) {
		UHIDNew = uHIDNew;
	}

	public String getReferralType_ID() {
		return ReferralType_ID;
	}

	public void setReferralType_ID(String referralType_ID) {
		ReferralType_ID = referralType_ID;
	}

	public String getHandlewithcare() {
		return Handlewithcare;
	}

	public void setHandlewithcare(String handlewithcare) {
		Handlewithcare = handlewithcare;
	}

	public String getHWCRemarks() {
		return HWCRemarks;
	}

	public void setHWCRemarks(String hWCRemarks) {
		HWCRemarks = hWCRemarks;
	}

	public String getPancard() {
		return Pancard;
	}

	public void setPancard(String pancard) {
		Pancard = pancard;
	}

	public String getAadharCard() {
		return AadharCard;
	}

	public void setAadharCard(String aadharCard) {
		AadharCard = aadharCard;
	}

	public String getCareOfID() {
		return CareOfID;
	}

	public void setCareOfID(String careOfID) {
		CareOfID = careOfID;
	}

	public String getHouseNo() {
		return HouseNo;
	}

	public void setHouseNo(String houseNo) {
		HouseNo = houseNo;
	}

	public String getPoliceStation() {
		return PoliceStation;
	}

	public void setPoliceStation(String policeStation) {
		PoliceStation = policeStation;
	}

	public String getPostOffice() {
		return PostOffice;
	}

	public void setPostOffice(String postOffice) {
		PostOffice = postOffice;
	}

	public String getCCountryID() {
		return CCountryID;
	}

	public void setCCountryID(String cCountryID) {
		CCountryID = cCountryID;
	}

	public String getCStateID() {
		return CStateID;
	}

	public void setCStateID(String cStateID) {
		CStateID = cStateID;
	}

	public String getCDistrictID() {
		return CDistrictID;
	}

	public void setCDistrictID(String cDistrictID) {
		CDistrictID = cDistrictID;
	}

	public String getCMandalID() {
		return CMandalID;
	}

	public void setCMandalID(String cMandalID) {
		CMandalID = cMandalID;
	}

	public String getCVillageID() {
		return CVillageID;
	}

	public void setCVillageID(String cVillageID) {
		CVillageID = cVillageID;
	}

	public String getCPhonetypeID() {
		return CPhonetypeID;
	}

	public void setCPhonetypeID(String cPhonetypeID) {
		CPhonetypeID = cPhonetypeID;
	}

	public String getCPhoneNo() {
		return CPhoneNo;
	}

	public void setCPhoneNo(String cPhoneNo) {
		CPhoneNo = cPhoneNo;
	}

	public String getMLCNONMLC() {
		return MLCNONMLC;
	}

	public void setMLCNONMLC(String mLCNONMLC) {
		MLCNONMLC = mLCNONMLC;
	}

	public String getGaliMohalla() {
		return GaliMohalla;
	}

	public void setGaliMohalla(String galiMohalla) {
		GaliMohalla = galiMohalla;
	}

	public String getCPincode() {
		return CPincode;
	}

	public void setCPincode(String cPincode) {
		CPincode = cPincode;
	}

	public String getDischargeType_ID() {
		return DischargeType_ID;
	}

	public void setDischargeType_ID(String dischargeType_ID) {
		DischargeType_ID = dischargeType_ID;
	}

	public String getDobStatus() {
		return DobStatus;
	}

	public void setDobStatus(String dobStatus) {
		DobStatus = dobStatus;
	}

	public String getTOR() {
		return TOR;
	}

	public void setTOR(String tOR) {
		TOR = tOR;
	}

	public String getEncodedName() {
		return EncodedName;
	}

	public void setEncodedName(String encodedName) {
		EncodedName = encodedName;
	}

	public String getLastchangedName() {
		return LastchangedName;
	}

	public void setLastchangedName(String lastchangedName) {
		LastchangedName = lastchangedName;
	}

	public String getEuid() {
		return euid;
	}

	public void setEuid(String euid) {
		this.euid = euid;
	}

	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}
	
	
	//Incrementing the counters
		public void incrAddCount(){
			addCount+=1;
		}
		
		public void incrInvCount(){
			invCount+=1;
		}
		
		public void incrDupCount(){
			dupCount+=1;
		}
	
	
	
	
	
	long invCount=0;
	
	
	/**
	 * @return the invCount
	 */
	public long getInvCount() {
		return invCount;
	}

	/**
	 * @param invCount the invCount to set
	 */
	public void setInvCount(long invCount) {
		this.invCount = invCount;
	}

	
	
	

	long dupCount=0;
	
	/**
	 * @return the dupCount
	 */
	public long getDupCount() {
		return dupCount;
	}

	/**
	 * @param dupCount the dupCount to set
	 */
	public void setDupCount(long dupCount) {
		this.dupCount = dupCount;
	}
	
	
	
	long addCount=0;
	
	/**
	 * @return the addCount
	 */
	public long getAddCount() {
		return addCount;
	}

	/**
	 * @param addCount the addCount to set
	 */
	public void setAddCount(long addCount) {
		this.addCount = addCount;
	}
	
	
	
	
	/*
	 * function to clear all variable declared
	 */
	
	public void clearallUsers(){
		RegistrationNo="";
		RegistrationDate="";
		TitleID="";
		FirstName="";
		MiddleName="";
		LastName="";
		GuardianName="";
		DOB="";
		AgeYear="";
		AgeMonth="";
		AgeDay="";
		Gender="";
		BloodGroupID="";
		MaritalStatusID="";
		OccupationID="";
		ReligionID="";
		NationalityID="";
		PassportNo="";
		ConsultantID="";
		ReferralID="";
		SponsorID="";
		InsuranceID="";
		EmployeeID="";
		RelationID="";
		LocalAddress1="";
		LocalAddress2="";
		LocalAreaID="";
		LocalCityID="";
		LocalPostalCode="";
		LocalPhoneOff="";
		LocalPhoneRes="";
		PermanentAddress1="";
		PermanentAddress2="";
		PermanentAreaID="";
		PermanentCityID="";
		PermanentPostalCode="";
		PermanentPhoneOff="";
		PermanentPhoneRes="";
		Mobile="";
		Email="";
		ContactPerson="";
		ContactPersonMobile="";
		SpecialNote="";
		Status="";
		EncodedBy="";
		EncodedDate="";
		LastChangedBy="";
		LastChangedDate="";
		PlaceofIssue="";
		DateofExpiry="";
		MedicalAlerts="";
		Photo="";
		LocalStdCode="";
		LocalIsdCode="";
		PermanentStdCode="";
		PermanentIsdCode="";
		Category="";
		OLDUrg="";
		VIP="";
		LocationID="";
		Father="";
		Mother="";
		Husband="";
		UHID="";
		UHIDNew="";
		ReferralType_ID="";
		Handlewithcare="";
		HWCRemarks="";
		Pancard="";
		AadharCard="";
		CareOfID="";
		HouseNo="";
		PoliceStation="";
		PostOffice="";
		CCountryID="";
		CStateID="";
		CDistrictID="";
		CMandalID="";
		CVillageID="";
		CPhonetypeID="";
		CPhoneNo="";
		MLCNONMLC="";
		GaliMohalla="";
		CPincode="";
		DischargeType_ID="";
		DobStatus="";
		TOR="";
		EncodedName="";
		LastchangedName="";
		euid="";
		uid="";
			}

	
	
	/**
	 * @return the uID
	 */
	
	

}

