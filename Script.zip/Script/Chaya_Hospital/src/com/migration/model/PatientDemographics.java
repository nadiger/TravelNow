/**
 * Users.java 
 */
package com.migration.model;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;



import com.migration.form.DBConnection;
import com.migration.form.PMMigUI;
import com.migration.lib.*;

/**
 * @author mihir.patel
 *
 */
public class PatientDemographics 
{
	public String dob = "";
	public String ptdob = "";
	public String ssn = "";
	public String upphone = "";
	public String umobileno="";
	public String upagerno = "";
	public String sex = "";
	public String zipcode="";
	public String countrycode = "";
	public String uname = "";
	public String upwd = "";
	public String psl = "";
	public PatientDemographics()
	{

	}
	
	private static Connection getConnection() throws Exception{
		Connection connDes2 = DBConnection.getDSNConnection(PMMigUI.destDNSName,PMMigUI.destUname,PMMigUI.destPwd);
		return connDes2;
	}

	// Throws exception to outer class as well, so error can be displayed in form	
	public int insertData(PatientDemographicsBean objPatientDemographicsBean,Connection connSrc, Connection connDest, int userType) throws Exception {
		PreparedStatement stmtPr =null;
		Boolean insertFlag = true;
		String strException = "";

		String strSQL = "";
		int resultUID = 0;
		int i = 0;

		try {
			

				//Find out the duplicate patients
			
				//resultUID = JLib.getPatientByNameDOB(objPatientDemographicsBean.getLastName(), objPatientDemographicsBean.getFirstName(), objPatientDemographicsBean.getDOB(), connDest) ;
				 
				resultUID=JLib.getUHIDByRegistractioNo(objPatientDemographicsBean.getRegistrationNo(),getConnection());
				
				if(resultUID!=0){
					String patientRegistrationNo=objPatientDemographicsBean.getFirstName()+","+objPatientDemographicsBean.getLastName()+","+objPatientDemographicsBean.getDOB()+","+objPatientDemographicsBean.getRegistrationNo();
					JUtil.appendToFile("DuplicateRegistrationNo.csv", patientRegistrationNo);
					insertFlag=false;
					objPatientDemographicsBean.incrDupCount();
				}
				
				/*if(resultUID!=0)
				{	
					String vmid = objPatientDemographicsBean.getRegistrationNo();
					insertFlag = false;
					objPatientDemographicsBean.incrDupCount();
					
					strException = objPatientDemographicsBean.getVmid() + "," + objPatientDemographicsBean.getUlname() + "," + objPatientDemographicsBean.getUfname() + "," + objPatientDemographicsBean.getDob() ;
					strException +=  objPatientDemographicsBean.getSsn() + "," + "duplicate Records";
					
					if (userType == 3)
					{

						JUtil.appendToFile("DuplicatePatients.csv", strException);
						String strRemark = "Duplicate Patient";
						strSQL = "insert into Exp_Patients(DupPatAccount, PatAccount, LastName,FirstName,DOB,Exception_Description,Exception_Code) values ('" + resultUID + "','" + objPatientDemographicsBean.getVmid() + "', '" + objPatientDemographicsBean.getUlname() + "', '" + objPatientDemographicsBean.getUfname() + "', '" + objPatientDemographicsBean.getDob() + "', '" + strRemark + "', '1')";
			            stmtPr = connDest.prepareStatement(strSQL);
						stmtPr.executeUpdate();
						objPatientDemographicsBean.incrInvCount();
						stmtPr.close();
						
						
						String strSQL1 = "";
						Statement stmt = null;
						ResultSet rsUsr = null;
						stmt = connSrc.createStatement();

						try{
							strSQL1="INSERT INTO duppat VALUES('"+vmid+"','"+resultUID+"')";
							stmt.executeUpdate(strSQL1);

						}
						catch(Exception e)
						{
							e.printStackTrace();
						}
					}
					
					
				}
				
				if(objPatientDemographicsBean.getUlname().equals("") || objPatientDemographicsBean.getUfname().equals("")){
					insertFlag = false;
					String strRemark = "Invalid PatientName";
					strSQL = "insert into Exp_Patients (PatAccount,LastName,FirstName,Exception_Description, Exception_Code) values ('" + objPatientDemographicsBean.getVmid() + "', '" + objPatientDemographicsBean.getUlname() + "', '" + objPatientDemographicsBean.getUfname() + "', '" + strRemark + "', '2')";
					stmtPr = connDest.prepareStatement(strSQL);
					stmtPr.executeUpdate();
					objPatientDemographicsBean.incrInvCount();
					stmtPr.close();
//					con = connDest.createStatement();
//					con.executeQuery(strSQL);
				}
				
				if(objPatientDemographicsBean.getUlname().toUpperCase().equals("DON'T USE") || objPatientDemographicsBean.getUlname().toUpperCase().equals("DO NOT USE") || objPatientDemographicsBean.getUlname().toUpperCase().equals("DONT USE") 
						|| objPatientDemographicsBean.getUfname().toUpperCase().equals("DON'T USE") || objPatientDemographicsBean.getUfname().toUpperCase().equals("DO NOT USE") || objPatientDemographicsBean.getUfname().toUpperCase().equals("DONT USE")
						|| objPatientDemographicsBean.getUpaddress().toUpperCase().equals("DON'T USE") || objPatientDemographicsBean.getUpaddress().toUpperCase().equals("DONT USE") || objPatientDemographicsBean.getUpaddress().toUpperCase().equals("DO NOT USE")
						|| objPatientDemographicsBean.getUpaddress2().toUpperCase().equals("DON'T USE") || objPatientDemographicsBean.getUpaddress2().toUpperCase().equals("DO NOT USE") || objPatientDemographicsBean.getUpaddress2().toUpperCase().equals("DONT USE")){
					insertFlag = false;
					String strRemark = "Do not use mentioned";
					strSQL = "insert into Exp_Patients (PatAccount,LastName,FirstName,Exception_Description, Exception_Code) values " +
					"('" + objPatientDemographicsBean.getVmid() + "', '" + objPatientDemographicsBean.getUlname() + "', '" + objPatientDemographicsBean.getUfname() + "', '" + 
					strRemark + "', '3')";
					stmtPr = connDest.prepareStatement(strSQL);
					stmtPr.executeUpdate();
					objPatientDemographicsBean.incrInvCount();
					stmtPr.close();
//					con = connDest.createStatement();
//					con.executeQuery(strSQL);
				}
*/
				
			if (insertFlag) 
			{
				strSQL="INSERT INTO PatientRegistration (Category,RegistrationNo,RegistrationDate,TitleID,FirstName,MiddleName," +
						"LastName,DOB,AgeYear,AgeMonth,AgeDay,Gender,status,EncodedBy,EncodedDate,uhidnew,ConsultantID,localcityid," +
						"localareaId,NationalityID,LocationID,dobstatus,MaritalStatusID,LocalAddress1,LocalAddress2,ContactPerson," +
						"RelationID,LocalPostalCode,ReligionID,OccupationID,mobile,tor,SponsorID,ReferralType_ID,SpecialNote," +
						"father,mother,BloodGroupID,ContactPersonMobile,PermanentAddress1,PermanentAddress2,PermanentAreaID,PermanentCityID,PermanentPostalCode) ";
				strSQL +=" Values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
				stmtPr = connDest.prepareStatement(strSQL);
				
				
				
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getCategory()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getRegistrationNo()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getRegistrationDate()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getTitleID()));
				stmtPr.setString(++i, JLib.Left(JUtil.validateString(objPatientDemographicsBean.getFirstName()),20));
				stmtPr.setString(++i, JLib.Left(JUtil.validateString(objPatientDemographicsBean.getMiddleName()),20));
				stmtPr.setString(++i, JLib.Left(JUtil.validateString(objPatientDemographicsBean.getLastName()),20));
				
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getDOB()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getAgeYear()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getAgeMonth()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getAgeDay()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getGender()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getStatus()));
				stmtPr.setString(++i, "2");  //encodedBy   //2015-11-24 05:33:16.350
				stmtPr.setString(++i, "2016-09-12 06:00:00.000");
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getUHIDNew()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getConsultantID()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getLocalCityID()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getLocalAreaID()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getNationalityID()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getLocationID()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getDobStatus()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getMaritalStatusID()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getLocalAddress1()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getLocalAddress2()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getContactPerson()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getRelationID()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getLocalPostalCode()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getReligionID()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getOccupationID()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getMobile()));
				stmtPr.setInt(++i, Integer.parseInt(objPatientDemographicsBean.getTOR()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getSponsorID()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getReferralType_ID()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getSpecialNote()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getFather()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getMother()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getBloodGroupID()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getContactPersonMobile()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getPermanentAddress1()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getPermanentAddress2()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getPermanentAreaID()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getPermanentCityID()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getPermanentPostalCode()));
			

				stmtPr.executeUpdate();
				
				
				/*strSQL="INSERT INTO PatientRegistration (RegistrationNo,RegistrationDate,TitleID,FirstName,MiddleName,LastName,GuardianName,DOB,AgeYear,AgeMonth,AgeDay,Gender,BloodGroupID, ";
				strSQL +="MaritalStatusID,OccupationID,ReligionID,NationalityID,PassportNo,ConsultantID,ReferralID,SponsorID,InsuranceID,EmployeeID, ";
				strSQL +=" RelationID,LocalAddress1,LocalAddress2,LocalAreaID,LocalCityID,LocalPostalCode,LocalPhoneOff,LocalPhoneRes,PermanentAddress1, ";
				strSQL +=" PermanentAddress2,PermanentAreaID,PermanentCityID,PermanentPostalCode,PermanentPhoneOff,PermanentPhoneRes,Mobile,Email,ContactPerson, ";
				strSQL +=" ContactPersonMobile,SpecialNote,Status,EncodedBy,EncodedDate,LastChangedBy,LastChangedDate,PlaceofIssue,DateofExpiry,MedicalAlerts, ";
				strSQL +=" Photo,LocalStdCode,LocalIsdCode,PermanentStdCode,PermanentIsdCode,Category,OLDUrg,VIP,LocationID,Father,Mother,Husband,UHIDNew, ";
				strSQL +=" ReferralType_ID,Handlewithcare,HWCRemarks,Pancard,AadharCard,CareOfID,HouseNo,PoliceStation,PostOffice,CCountryID,CStateID,CDistrictID, ";
				strSQL +=" CMandalID,CVillageID,CPhonetypeID,CPhoneNo,MLCNONMLC,GaliMohalla,CPincode,DischargeType_ID,DobStatus,TOR,EncodedName,LastchangedName, ";
				
				strSQL +=" euid,uid) Values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
				stmtPr = connDest.prepareStatement(strSQL);
				
				
				
				
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getRegistrationNo()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getRegistrationDate()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getTitleID()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getFirstName()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getMiddleName()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getLastName()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getGuardianName()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getDOB()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getAgeYear()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getAgeMonth()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getAgeDay()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getGender()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getBloodGroupID()));
				
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getMaritalStatusID()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getOccupationID()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getReligionID()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getNationalityID()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getPassportNo()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getConsultantID()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getReferralID()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getSponsorID()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getInsuranceID()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getEmployeeID()));
				
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getRelationID()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getLocalAddress1()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getLocalAddress2()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getLocalAreaID()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getLocalCityID()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getLocalPostalCode()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getLocalPhoneOff()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getLocalPhoneRes()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getPermanentAddress1()));
				
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getPermanentAddress2()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getPermanentAreaID()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getPermanentCityID()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getPermanentPostalCode()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getPermanentPhoneOff()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getPermanentPhoneRes()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getMobile()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getEmail()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getContactPerson()));
				
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getContactPersonMobile()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getSpecialNote()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getStatus()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getEncodedBy()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getEncodedDate()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getLastChangedBy()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getLastChangedDate()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getPlaceofIssue()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getDateofExpiry()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getMedicalAlerts()));
				
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getPhoto()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getLocalStdCode()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getLocalIsdCode()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getPermanentStdCode()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getPermanentIsdCode()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getCategory()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getOLDUrg()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getVIP()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getLocationID()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getFather()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getMother()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getHusband()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getUHIDNew()));
				
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getReferralType_ID()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getHandlewithcare()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getHWCRemarks()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getPancard()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getAadharCard()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getCareOfID()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getHouseNo()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getPoliceStation()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getPostOffice()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getCCountryID()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getCStateID()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getCDistrictID()));
				
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getCMandalID()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getCVillageID()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getCPhonetypeID()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getCPhoneNo()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getMLCNONMLC()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getGaliMohalla()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getCPincode()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getDischargeType_ID()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getDobStatus()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getTOR()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getEncodedName()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getLastchangedName()));
				
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getEuid()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getUid()));*/


				//stmtPr.executeUpdate();
				
				
				
				
				
				/*strSQL = "INSERT INTO users (uname, upwd, ufname, uminitial, ulname, dob,ssn," ;
				strSQL += " upaddress, upcity,upstate, zipcode, upphone,umobileno, upagerno,uemail, " ;
				strSQL += " usertype, upreviousname, sex, upaddress2, suffix, prefix, initials, ptdob, " ;
				strSQL += " primaryservicelocation, vmid,status,language, countrycode) Values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)" ;


				stmtPr.setInt(++i, objPatientDemographicsBean.getDefaultFacility());
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getVmid()));
				stmtPr.setString(++i, JUtil.validateString(objPatientDemographicsBean.getStatus()));
				stmtPr.setString(++i, objPatientDemographicsBean.getLanguage());
				stmtPr.setString(++i, objPatientDemographicsBean.getCountryCode());*/
				
				
				 
				
				objPatientDemographicsBean.incrAddCount();	            
			}

		}
		catch (Exception e) 
		{
			e.printStackTrace();
			throw e;
		}finally
		{
			if (stmtPr != null)
				stmtPr.close();
		}	

		return resultUID;


	} 



}
