package com.migration.model;



public class MasterLabBean {
	//** - Important and Mandatory
	private String Department;//**
	private String DeptID;//**
	private String SubDepartment;//**
	private String SubDeptId;//**
	private String ServiceName;//**
	private String ServiceId;//**
	private String subServiceName;//**
	private String subServiceId;//**
	private String subServiceSequence;//**
	private String ServiceNameReferanceCode;//**
	private String Units;//**
	private String UnitId;//**
	private String Sample;//**
	private String SampleId;//**
	private String Method;//**
	private String MethodId;//**
	private String ReportTimeIn;
	private String Formula;
	private String SampleCollectItem;
	private String ReportType; // **
	private String CategoryType;//**
	private String Gender;//**
	private String AgeType;
	private String AgeFrom;//**
	private String AgeUpTo;
	private String MinimumValue;
	private String MaximumValue;//**
	private String Interpretations;
	private String MinCritical;
	private String MaxCritical;
	private String ReferenceRange;
	private String symbol;
	private String MultipleResultEntry;
	private String ServiceNameReferanceCodePrev;
	private static int addCount;
	private static int dupCount;
	private static int invCount;


	public MasterLabBean()	{

	}

	public void clearall(){
		symbol="";
		subServiceSequence="";
		subServiceName="";//**
		subServiceId="";//**
		UnitId="";
		DeptID="";
		SubDeptId="";
		SampleId="";
		MethodId="";
		ServiceId="";
		Department="";//**
		SubDepartment="";//**
		ServiceName="";//**
		ServiceNameReferanceCode="";//**
		Units="";//**
		Sample="";//**
		Method="";//**
		ReportTimeIn="";
		Formula="";
		SampleCollectItem="";
		ReportType=""; // **
		CategoryType="";//**
		Gender="";//**
		AgeFrom="0";//**
		AgeUpTo="0";
		MinimumValue="0";
		MaximumValue="0";//**
		Interpretations="";
		MinCritical="";
		MaxCritical="";
		ReferenceRange="";
		MultipleResultEntry="";
		ServiceNameReferanceCodePrev="";
		AgeType="";
	}
	
	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}
	
	public String getSymbol() {
		return symbol;
	}
	
	public void setAgeType(String ageType) {
		AgeType = ageType;
	}

	public String getAgeType() {
		return AgeType;
	}

	public void setSubServiceSequence(String subServiceSequence) {
		this.subServiceSequence = subServiceSequence;
	}

	public String getSubServiceSequence() {
		return subServiceSequence;
	}

	public String getSubServiceName() {
		return subServiceName;
	}

	public String getSubServiceId() {
		return subServiceId;
	}

	public void setSubServiceName(String subServiceName) {
		this.subServiceName = subServiceName;
	}

	public void setSubServiceId(String subServiceId) {
		this.subServiceId = subServiceId;
	}

	public String getDeptID() {
		return DeptID;
	}

	public String getSubDeptId() {
		return SubDeptId;
	}

	public String getServiceId() {
		return ServiceId;
	}

	public String getUnitId() {
		return UnitId;
	}

	public String getSampleId() {
		return SampleId;
	}

	public String getMethodId() {
		return MethodId;
	}

	public void setDeptID(String deptID) {
		DeptID = deptID;
	}

	public void setSubDeptId(String subDeptId) {
		SubDeptId = subDeptId;
	}

	public void setServiceId(String serviceId) {
		ServiceId = serviceId;
	}

	public void setUnitId(String unitId) {
		UnitId = unitId;
	}

	public void setSampleId(String sampleId) {
		SampleId = sampleId;
	}

	public void setMethodId(String methodId) {
		MethodId = methodId;
	}

	public static void setAddCount(int addCount) {
		MasterLabBean.addCount = addCount;
	}

	public static void setDupCount(int dupCount) {
		MasterLabBean.dupCount = dupCount;
	}

	public static void setInvCount(int invCount) {
		MasterLabBean.invCount = invCount;
	}

	public String getDepartment() {
		return Department;
	}

	public void setDepartment(String department) {
		Department = department;
	}

	public String getSubDepartment() {
		return SubDepartment;
	}

	public void setSubDepartment(String subDepartment) {
		SubDepartment = subDepartment;
	}

	public String getServiceName() {
		return ServiceName;
	}

	public void setServiceName(String serviceName) {
		ServiceName = serviceName;
	}

	public String getServiceNameReferanceCode() {
		return ServiceNameReferanceCode;
	}

	public void setServiceNameReferanceCode(String serviceNameReferanceCode) {
		ServiceNameReferanceCode = serviceNameReferanceCode;
	}

	public String getUnits() {
		return Units;
	}

	public void setUnits(String units) {
		Units = units;
	}

	public String getSample() {
		return Sample;
	}

	public void setSample(String sample) {
		Sample = sample;
	}

	public String getMethod() {
		return Method;
	}

	public void setMethod(String method) {
		Method = method;
	}

	public String getReportTimeIn() {
		return ReportTimeIn;
	}

	public void setReportTimeIn(String reportTimeIn) {
		ReportTimeIn = reportTimeIn;
	}

	public String getFormula() {
		return Formula;
	}

	public void setFormula(String formula) {
		Formula = formula;
	}

	public String getSampleCollectItem() {
		return SampleCollectItem;
	}

	public void setSampleCollectItem(String sampleCollectItem) {
		SampleCollectItem = sampleCollectItem;
	}

	public String getReportType() {
		return ReportType;
	}

	public void setReportType(String reportType) {
		ReportType = reportType;
	}

	public String getCategoryType() {
		return CategoryType;
	}

	public void setCategoryType(String categoryType) {
		CategoryType = categoryType;
	}

	public String getGender() {
		return Gender;
	}

	public void setGender(String gender) {
		Gender = gender;
	}

	public String getAgeFrom() {
		return AgeFrom;
	}

	public void setAgeFrom(String ageFrom) {
		AgeFrom = ageFrom;
	}

	public String getAgeUpTo() {
		return AgeUpTo;
	}

	public void setAgeUpTo(String ageUpTo) {
		AgeUpTo = ageUpTo;
	}

	public String getMinimumValue() {
		return MinimumValue;
	}

	public void setMinimumValue(String minimumValue) {
		MinimumValue = minimumValue;
	}

	public String getMaximumValue() {
		return MaximumValue;
	}

	public void setMaximumValue(String maximumValue) {
		MaximumValue = maximumValue;
	}

	public String getInterpretations() {
		return Interpretations;
	}

	public void setInterpretations(String interpretations) {
		Interpretations = interpretations;
	}

	public String getMinCritical() {
		return MinCritical;
	}

	public void setMinCritical(String minCritical) {
		MinCritical = minCritical;
	}

	public String getMaxCritical() {
		return MaxCritical;
	}

	public void setMaxCritical(String maxCritical) {
		MaxCritical = maxCritical;
	}

	public String getReferenceRange() {
		return ReferenceRange;
	}

	public void setReferenceRange(String referenceRange) {
		ReferenceRange = referenceRange;
	}

	public String getMultipleResultEntry() {
		return MultipleResultEntry;
	}

	public void setMultipleResultEntry(String multipleResultEntry) {
		MultipleResultEntry = multipleResultEntry;
	}

	public String getServiceNameReferanceCodePrev() {
		return ServiceNameReferanceCodePrev;
	}

	public void setServiceNameReferanceCodePrev(String serviceNameReferanceCodePrev) {
		ServiceNameReferanceCodePrev = serviceNameReferanceCodePrev;
	}

	public int getAddCount() {
		return addCount;
	}

	public int getDupCount() {
		return dupCount;
	}

	public int getInvCount() {
		return invCount;
	}

	public void incrementAddCount() {
		addCount = addCount+1;
	}

	public void incrementDupCount() {
		dupCount = dupCount+1;
	}

	public void incrementInvCount() {
		invCount = invCount+1;
	}








}
